#!/usr/bin/env bash
set -Eeuo pipefail

APP_NAME='RGNODES VM SSH'
INSTALL_DIR='/opt/rgnodes-vm-ssh'
SERVICE_USER='rgnodesbot'
SERVICE_HOME='/var/lib/rgnodesbot'
STATE_DIR="${SERVICE_HOME}/state"
MANAGED_USERS_DIR='/var/lib/rgnodes-vm-ssh/users'
HELPER_PATH='/usr/local/sbin/rgnodes-vm-ssh-user'
SUDOERS_FILE='/etc/sudoers.d/rgnodes-vm-ssh'
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log() { printf '\n[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"; }
die() { printf '\n[ERROR] %s\n' "$*" >&2; exit 1; }

[[ "$(id -u)" -eq 0 ]] || die 'Run this installer with sudo: sudo bash install.sh'
for item in index.js package.json ecosystem.config.cjs .env.example rgnodes-vm-ssh-user; do
  [[ -f "$PROJECT_DIR/$item" ]] || die "Required project file is missing: $item"
done
[[ -r /etc/os-release ]] || die 'Cannot identify the Linux distribution.'
. /etc/os-release
case "${ID:-}" in ubuntu|debian) ;; *) die "Ubuntu and Debian are supported (detected: ${PRETTY_NAME:-unknown})." ;; esac

export DEBIAN_FRONTEND=noninteractive

install_apt_package() {
  local package="$1"
  if dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q 'install ok installed'; then
    log "$package is already installed; skipping."
  else
    log "Installing missing package: $package"
    apt-get install -y "$package"
  fi
}

log 'Refreshing apt package metadata...'
apt-get update -y
for package in ca-certificates curl openssh-client openssh-server iproute2 sudo openssl python3; do
  install_apt_package "$package"
done

SYSTEM_NODE_MAJOR="$(/usr/bin/node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)"
if [[ "$SYSTEM_NODE_MAJOR" != '26' || ! -x /usr/bin/npm ]]; then
  log 'Installing system-wide Node.js 26 LTS from NodeSource...'
  curl -fsSL https://deb.nodesource.com/setup_26.x -o /tmp/rgnodes-nodesource-26.sh
  bash /tmp/rgnodes-nodesource-26.sh
  apt-get install -y nodejs
else
  log "System-wide Node.js $(/usr/bin/node --version) is already installed; skipping."
fi
SYSTEM_NODE_MAJOR="$(/usr/bin/node -p 'process.versions.node.split(".")[0]')"
[[ "$SYSTEM_NODE_MAJOR" == '26' ]] || die "System-wide Node.js 26 setup failed (found $(/usr/bin/node --version))."

PATH="/usr/bin:/usr/local/bin" command -v pm2 >/dev/null 2>&1 || {
  log 'Installing PM2 for the system-wide Node.js installation...'
  PATH='/usr/bin:/usr/local/bin' /usr/bin/npm install --global pm2
}
PM2_BIN="$(PATH='/usr/bin:/usr/local/bin' command -v pm2)"
[[ -x "$PM2_BIN" ]] || die 'PM2 is not available in the system-wide PATH.'

if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  log "Creating non-login bot service account: $SERVICE_USER"
  useradd --system --create-home --home-dir "$SERVICE_HOME" --shell /usr/sbin/nologin "$SERVICE_USER"
else
  log "Bot service account $SERVICE_USER already exists; reusing it."
  mkdir -p "$SERVICE_HOME"
fi

install -d -m 0750 -o root -g "$SERVICE_USER" "$INSTALL_DIR"
for item in index.js package.json ecosystem.config.cjs README.md .env.example .gitignore; do
  [[ -f "$PROJECT_DIR/$item" ]] && install -m 0644 "$PROJECT_DIR/$item" "$INSTALL_DIR/$item"
done
install -m 0755 "$PROJECT_DIR/install.sh" "$INSTALL_DIR/install.sh"
install -o root -g root -m 0750 "$PROJECT_DIR/rgnodes-vm-ssh-user" "$HELPER_PATH"
install -d -m 0700 -o "$SERVICE_USER" -g "$SERVICE_USER" "$STATE_DIR"
install -d -m 0700 -o root -g root "$MANAGED_USERS_DIR"

# Permit the unprivileged bot account to invoke only this tightly validated root helper.
printf '%s ALL=(root) NOPASSWD: %s\n' "$SERVICE_USER" "$HELPER_PATH" > "$SUDOERS_FILE"
chmod 0440 "$SUDOERS_FILE"
visudo -cf "$SUDOERS_FILE" >/dev/null || die 'The generated sudoers rule did not pass visudo validation.'

if [[ ! -f "$INSTALL_DIR/.env" ]]; then
  install -o "$SERVICE_USER" -g "$SERVICE_USER" -m 0600 "$INSTALL_DIR/.env.example" "$INSTALL_DIR/.env"
  log 'Created private .env configuration file.'
fi

read_env_value() {
  local key="$1" value
  value="$(grep -m1 -E "^${key}=" "$INSTALL_DIR/.env" | cut -d= -f2- || true)"
  value="${value%\"}"; value="${value#\"}"
  printf '%s' "$value"
}
set_env_value() {
  local key="$1" value="$2"
  chown root:"$SERVICE_USER" "$INSTALL_DIR/.env"
  chmod 0640 "$INSTALL_DIR/.env"
}

TOKEN_VALUE="$(read_env_value DISCORD_TOKEN)"
CLIENT_VALUE="$(read_env_value CLIENT_ID)"
OWNER_VALUE="$(read_env_value OWNER_IDS)"
SSH_PORT_VALUE="$(read_env_value SSH_PORT)"
[[ -n "$SSH_PORT_VALUE" ]] || SSH_PORT_VALUE='22'

# Ask only for the bot token on a fresh install. Use Discord's bot-authenticated
# current-application endpoint to validate it and discover the application ID
# and the application/team owner ID. No token is printed or passed on a command line.
if [[ -z "$TOKEN_VALUE" ]]; then
  printf '\nDiscord bot token is required. The input will be hidden.\n'
  read -r -s -p 'Discord bot token: ' TOKEN_VALUE; printf '\n'
  [[ -n "$TOKEN_VALUE" ]] || die 'Discord token cannot be blank.'
fi

log 'Validating Discord token and detecting application/owner details...'
DISCORD_DETAILS="$(DISCORD_TOKEN_FOR_SETUP="$TOKEN_VALUE" python3 - <<'PYDISCORD'
import json, os, sys, urllib.error, urllib.request

token = os.environ.get('DISCORD_TOKEN_FOR_SETUP', '').strip()
if not token:
    print('Discord token is empty.', file=sys.stderr)
    raise SystemExit(2)
request = urllib.request.Request(
    'https://discord.com/api/v10/oauth2/applications/@me',
    headers={
        'Authorization': f'Bot {token}',
        'Accept': 'application/json',
        'User-Agent': 'RGNODES-VM-SSH-Installer/2.1'
    },
    method='GET'
)
try:
    with urllib.request.urlopen(request, timeout=20) as response:
        data = json.loads(response.read(1024 * 1024).decode('utf-8'))
except urllib.error.HTTPError as exc:
    # Never print request headers, response bodies, or the supplied credential.
    print(f'Discord rejected the token or API request (HTTP {exc.code}).', file=sys.stderr)
    raise SystemExit(3)
except Exception as exc:
    print(f'Could not verify the Discord token: {type(exc).__name__}. Check VPS internet/DNS and retry.', file=sys.stderr)
    raise SystemExit(4)

app_id = str(data.get('id') or '')
owner = data.get('owner') if isinstance(data.get('owner'), dict) else {}
team = data.get('team') if isinstance(data.get('team'), dict) else {}
owner_ids = []
for candidate in (owner.get('id'), team.get('owner_user_id')):
    candidate = str(candidate or '')
    if candidate.isdigit() and 15 <= len(candidate) <= 22 and candidate not in owner_ids:
        owner_ids.append(candidate)
if not (app_id.isdigit() and 15 <= len(app_id) <= 22):
    print('Discord API response did not include a valid application ID.', file=sys.stderr)
    raise SystemExit(5)
app_name = ''.join(ch for ch in str(data.get('name') or 'Discord application') if ch.isprintable())[:80]
print(json.dumps({'client_id': app_id, 'owner_ids': owner_ids, 'app_name': app_name}))
PYDISCORD
)" || die 'Discord token validation failed. Nothing was started. Re-run install.sh with a valid bot token.'

CLIENT_FROM_TOKEN="$(printf '%s' "$DISCORD_DETAILS" | python3 -c 'import json,sys; print(json.load(sys.stdin)["client_id"])')"
OWNER_FROM_TOKEN="$(printf '%s' "$DISCORD_DETAILS" | python3 -c 'import json,sys; print(",".join(json.load(sys.stdin).get("owner_ids", [])))')"
APP_NAME_FROM_TOKEN="$(printf '%s' "$DISCORD_DETAILS" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("app_name", "Discord application"))')"
[[ "$CLIENT_FROM_TOKEN" =~ ^[0-9]{15,22}$ ]] || die 'Could not derive a valid Discord application ID from the token.'

if [[ -n "$CLIENT_VALUE" && "$CLIENT_VALUE" != "$CLIENT_FROM_TOKEN" ]]; then
  log 'Existing CLIENT_ID did not match the supplied bot token; correcting it from Discord.'
fi
CLIENT_VALUE="$CLIENT_FROM_TOKEN"
set_env_value DISCORD_TOKEN "$TOKEN_VALUE"
set_env_value CLIENT_ID "$CLIENT_VALUE"
unset TOKEN_VALUE

if [[ -n "$OWNER_FROM_TOKEN" ]]; then
  if [[ -n "$OWNER_VALUE" ]]; then
    OWNER_VALUE="$OWNER_FROM_TOKEN,$OWNER_VALUE"
  else
    OWNER_VALUE="$OWNER_FROM_TOKEN"
  fi
  # Remove duplicates while preserving the primary application owner first.
  OWNER_VALUE="$(printf '%s' "$OWNER_VALUE" | tr ',' '\n' | awk 'NF && !seen[$0]++' | paste -sd, -)"
  log "Discord application verified: ${APP_NAME_FROM_TOKEN}. Application ID and owner detected automatically."
else
  log "Discord application verified: ${APP_NAME_FROM_TOKEN}. Its owner ID was not exposed by the API response."
  if [[ -z "$OWNER_VALUE" ]]; then
    read -r -p 'VPS administrator Discord user ID (needed to approve SSH access): ' OWNER_VALUE
  fi
fi
[[ "$OWNER_VALUE" =~ ^[0-9]{15,22}(,[0-9]{15,22})*$ ]] || die 'Owner IDs must be numeric Discord IDs separated by commas.'
set_env_value OWNER_IDS "$OWNER_VALUE"
[[ "$SSH_PORT_VALUE" =~ ^[0-9]+$ ]] && (( SSH_PORT_VALUE >= 1 && SSH_PORT_VALUE <= 65535 )) || die 'SSH_PORT must be between 1 and 65535.'

set_env_value SSH_PORT "$SSH_PORT_VALUE"
set_env_value SSH_HELPER_PATH "$HELPER_PATH"
set_env_value STATE_FILE "$STATE_DIR/access.json"

PUBLIC_SSH_ACK="$(read_env_value PUBLIC_SSH_ACK)"
if [[ "${PUBLIC_SSH_ACK,,}" != 'true' ]]; then
  cat <<'NOTICE'

SSH ACCESS SAFETY CONFIRMATION
This installer will enable the SSH server and install a bot command that can create
individual NON-ROOT Linux accounts after the VPS owner approves a submitted public key.
The accounts have no sudo privileges. Private keys are never generated or collected.
Make sure this is your VPS or you have explicit permission to administer it.
NOTICE
  read -r -p 'Type YES to enable SSH access provisioning: ' CONFIRM_SSH
  [[ "$CONFIRM_SSH" == 'YES' ]] || die 'Owner confirmation was not given; no SSH access provisioning was enabled.'
  set_env_value PUBLIC_SSH_ACK 'true'
fi

log 'Validating SSH daemon configuration...'
sshd -t || die 'Existing sshd configuration is invalid. Fix it before continuing.'
systemctl enable --now ssh
systemctl is-active --quiet ssh || die 'OpenSSH server service could not be started.'
if ! ss -ltnH "sport = :${SSH_PORT_VALUE}" | grep -q .; then
  die "sshd is not listening on configured port ${SSH_PORT_VALUE}. Configure the SSH daemon port and rerun install.sh."
fi

# If UFW is already enabled, add only the configured SSH TCP port.
# Do not enable UFW or change its default policy on the administrator's behalf.
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
  if ! ufw status | grep -qE "^${SSH_PORT_VALUE}/tcp[[:space:]]"; then
    log "UFW is active; allowing inbound TCP ${SSH_PORT_VALUE} for SSH."
    ufw allow "${SSH_PORT_VALUE}/tcp" comment 'RGNODES VM SSH'
  else
    log "UFW already has a rule for TCP ${SSH_PORT_VALUE}; leaving it unchanged."
  fi
else
  log 'UFW is not active; firewall policy was not changed.'
fi

log 'Installing Node.js dependencies...'
cd "$INSTALL_DIR"
chown -R "$SERVICE_USER:$SERVICE_USER" "$STATE_DIR"
chown root:"$SERVICE_USER" "$INSTALL_DIR" "$INSTALL_DIR/.env"
chmod 0750 "$INSTALL_DIR"
chmod 0640 "$INSTALL_DIR/.env"
# Allow the service group to create/update node_modules during installation only.
chmod 0770 "$INSTALL_DIR"
runuser -u "$SERVICE_USER" -- env HOME="$SERVICE_HOME" PATH='/usr/bin:/usr/local/bin' /usr/bin/npm install --omit=dev --no-audit --no-fund --fetch-retries=3 --fetch-timeout=120000
chmod 0750 "$INSTALL_DIR"
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR/node_modules"
runuser -u "$SERVICE_USER" -- env HOME="$SERVICE_HOME" PATH='/usr/bin:/usr/local/bin' /usr/bin/node --check "$INSTALL_DIR/index.js"

log 'Starting/updating the Discord bot with PM2...'
runuser -u "$SERVICE_USER" -- env HOME="$SERVICE_HOME" PATH='/usr/bin:/usr/local/bin' "$PM2_BIN" delete rgnodes-vm-ssh >/dev/null 2>&1 || true
runuser -u "$SERVICE_USER" -- env HOME="$SERVICE_HOME" PATH='/usr/bin:/usr/local/bin' "$PM2_BIN" start "$INSTALL_DIR/ecosystem.config.cjs" --only rgnodes-vm-ssh
runuser -u "$SERVICE_USER" -- env HOME="$SERVICE_HOME" PATH='/usr/bin:/usr/local/bin' "$PM2_BIN" save

log 'Configuring PM2 startup for automatic restart after VPS reboot...'
PATH='/usr/bin:/usr/local/bin' "$PM2_BIN" startup systemd -u "$SERVICE_USER" --hp "$SERVICE_HOME" --wait-ip >/tmp/rgnodes-pm2-startup.log 2>&1 || {
  cat /tmp/rgnodes-pm2-startup.log
  die 'PM2 startup service could not be configured.'
}
systemctl daemon-reload
systemctl enable "pm2-${SERVICE_USER}.service" >/dev/null
systemctl is-enabled --quiet "pm2-${SERVICE_USER}.service" || die 'PM2 startup service is not enabled for reboot persistence.'

log 'Running final local checks...'
sshd -t
systemctl is-active --quiet ssh || die 'SSH service is not active after installation.'
runuser -u "$SERVICE_USER" -- env HOME="$SERVICE_HOME" PATH='/usr/bin:/usr/local/bin' "$PM2_BIN" describe rgnodes-vm-ssh >/dev/null || die 'PM2 process could not be verified.'

BOT_INVITE_URL="https://discord.com/oauth2/authorize?client_id=${CLIENT_VALUE}&scope=bot%20applications.commands&permissions=19456"

cat <<SUMMARY

============================================================
${APP_NAME} installation completed
============================================================
Project:       ${INSTALL_DIR}
SSH server:    active (port ${SSH_PORT_VALUE})
SSH helper:    ${HELPER_PATH}
Bot process:   rgnodes-vm-ssh (PM2)
Bot service:   pm2-${SERVICE_USER}.service
Config:        ${INSTALL_DIR}/.env (root:${SERVICE_USER}, permission 640)
Discord app:   ${APP_NAME_FROM_TOKEN} (${CLIENT_VALUE})
Owner IDs:     ${OWNER_VALUE}
Token:         verified and stored (hidden)
Bot invite:     ${BOT_INVITE_URL}

Discord workflow:
  1. User:  /ssh-request public_key:<their ssh-ed25519 PUBLIC key>
  2. Owner: /ssh-pending
  3. Owner: /ssh-approve user:@member
  4. User:  /ssh
  5. Owner: /ssh-revoke user:@member (when access should be removed)

Read-only checks:
  sudo -u ${SERVICE_USER} env HOME=${SERVICE_HOME} PATH=/usr/bin:/usr/local/bin ${PM2_BIN} status
  sudo -u ${SERVICE_USER} env HOME=${SERVICE_HOME} PATH=/usr/bin:/usr/local/bin ${PM2_BIN} logs rgnodes-vm-ssh --lines 80
  sudo systemctl is-enabled pm2-${SERVICE_USER}.service
  sudo sshd -t
  sudo ss -lntp | grep ':${SSH_PORT_VALUE}'

IMPORTANT:
- Allow TCP ${SSH_PORT_VALUE} in your VPS provider firewall/security group.
- If UFW is active, allow this port only if that matches your security policy.
- Direct IPv4 is preferred when the SSH listener is on a non-loopback interface; Pinggy is used when direct SSH is unavailable or FORCE_PINGGY=true.
- Pinggy Free is time-limited. A Pro reservation is needed for a persistent endpoint.
- Every account is non-root and receives no sudo privileges.
- This installer does not disable existing root/password login or rewrite your sshd_config.
============================================================
SUMMARY
