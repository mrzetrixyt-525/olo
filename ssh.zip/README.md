# RGNODES™ VM SSH

Node.js 26 + Discord.js 14 SSH access manager for a VPS that you own or are explicitly authorized to administer. The primary job is to provision **separate, non-root Linux SSH accounts** after the VPS owner approves a user's SSH public key. It is not just an endpoint display bot.

## What it does

- Installs/checks OpenSSH Server and verifies the configured local SSH listener.
- Detects a public IPv4 first and uses it as the preferred SSH endpoint when `sshd` listens on a non-loopback interface.
- Starts a Pinggy TCP reverse tunnel if no public IPv4 is detected or SSH listens only on loopback.
- Reconnects the Pinggy process with backoff and periodically rechecks SSH service health.
- Lets a Discord user submit an `ssh-ed25519` **public key**.
- Lets only configured `OWNER_IDS` approve or revoke account access.
- Creates one Linux account per Discord user: `rgnssh_<discord-user-id>`.
- Accounts are non-root, have no sudo privileges, and receive a separate writable `~/workspace` folder.
- Each approved key permits an interactive terminal but disables SSH agent forwarding, X11 forwarding, and TCP port forwarding.
- Accounts can write inside `~/workspace`; the managed home and `.ssh` directories are root-owned so a user cannot replace or bypass a revoked key.
- The managed home and `.ssh` directory are root-owned so an SSH user cannot add an unapproved key or undo a revocation. Interactive shells start in `~/workspace`, the user's writable directory.
- Revocation removes the user's authorized key but deliberately preserves the Linux account and its workspace files. Existing SSH sessions are not forcibly terminated; they end when the user disconnects or the VPS owner closes them separately.
- Never creates, requests, sends, or stores a private SSH key or a usable login password.
- Uses colorless Discord embeds and ephemeral replies for account/endpoint information.
- Runs under PM2 with systemd startup persistence and automatic restarts.

## Important limits

- A detected public IPv4 does **not** prove inbound SSH is reachable. The provider firewall/security group, OS firewall, routing/NAT, and SSH daemon must permit the configured TCP port.
- The bot checks whether `sshd` listens on a non-loopback interface. If it only listens on loopback, Pinggy is used when enabled. A public IPv4 can still be blocked by provider firewall or routing rules that cannot be verified from inside the VPS.
- Pinggy Free TCP tunnels have a 60-minute timeout and their address/port can change after reconnects. The bot restarts the tunnel and shows the current endpoint. No free tunnel can be promised as never-expiring. Pinggy Pro reservation is needed for persistent endpoint behavior under the provider's terms.
- PM2 can restart the bot; it cannot prevent downtime caused by a stopped VPS, provider/network outage, expired credentials, Discord outage, or Pinggy outage.
- SSH accounts are full shell accounts on the same VPS, but non-root and without sudo. Approve only people who should be able to run commands on that machine. The bot does not provide filesystem isolation or resource quotas between these accounts.
- The installer enables the OpenSSH service but does not rewrite `sshd_config` or disable existing root/password login, which avoids unexpectedly locking out the VPS administrator. It adds the configured port to UFW only when UFW is already active; external provider firewall settings remain the VPS owner's responsibility.

## Requirements

- Ubuntu or Debian VPS with systemd.
- Root access for the one-time installer (`sudo`).
- Discord bot token. The installer validates it through Discord and automatically retrieves the application ID and application/team owner IDs when Discord exposes those fields. If no owner ID is available, the installer asks for one manual VPS administrator Discord ID; additional trusted owner IDs can be added later in `.env`.
- Outbound internet to Discord and, if needed, Pinggy.

The installer installs missing packages, targets Node.js 26 Active LTS, installs PM2 if missing, creates a dedicated unprivileged bot service account, installs a tightly validated root helper with a narrow sudoers entry, installs OpenSSH Server if missing, checks the SSH listener, and starts the bot with PM2.

## Install

1. Extract the ZIP on your Ubuntu/Debian VPS.
2. Enter the extracted project directory.
3. Run:

   ```bash
   sudo bash install.sh
   ```

4. Enter your Discord bot token when prompted (input is hidden). The installer verifies the token with Discord's `GET /oauth2/applications/@me` endpoint, then automatically detects and saves `CLIENT_ID` and the application/team owner ID(s). You do not need to copy the application ID manually. If Discord does not return an owner ID (for example, depending on application ownership), it asks for the VPS administrator's Discord user ID as a secure fallback.
5. Read the SSH access confirmation and type `YES` only when this is your VPS or you have authorization to administer it. This explicit confirmation is required before enabling SSH-account provisioning.
6. The installer enables OpenSSH Server, checks `sshd -t`, verifies the configured local SSH port, configures the limited access helper, installs dependencies with retry settings, locks configuration permissions, starts the bot with PM2, saves the PM2 process list, and enables PM2 systemd startup for reboot recovery. It prints a Discord bot invite URL at the end.
7. Open the printed invite URL and add the bot to your Discord server. Then allow TCP `SSH_PORT` in your VPS provider firewall/security group. If UFW is active, the installer adds only the SSH port rule. External provider firewall rules still need to be configured in the VPS provider panel.

## Discord workflow

1. **User:** Create an SSH key pair on their own computer or phone using an SSH client. For example, run `ssh-keygen -t ed25519 -C "my-device"`. Keep the private key on that device and submit only the single line from the `.pub` file with:

   `/ssh-request public_key:<ssh-ed25519 public key>`

2. **VPS owner:** Review requests using `/ssh-pending`.
3. **VPS owner:** Confirm the member's identity and approve using `/ssh-approve user:@member`.
4. **User:** Run `/ssh` to receive their host, port, individual Linux username and SSH command.
5. **VPS owner:** Revoke with `/ssh-revoke user:@member`. This removes SSH public-key access but preserves the home directory and files.

Only the configured `OWNER_IDS` may approve, revoke, list pending requests, view status, or refresh the tunnel. Being a Discord server administrator alone does not grant VPS-owner privileges. After connecting, users can write files inside `~/workspace`; the managed home and `.ssh` directory are protected from modification. The helper checks that OpenSSH public-key authentication and the expected `authorized_keys` file are active before provisioning an account.

## Commands

| Command | Purpose | Permission |
|---|---|---|
| `/ssh-request public_key` | Submit one Ed25519 public key for approval | Any member who can use the bot |
| `/ssh` | Show personal SSH details after approval | Approved account owner |
| `/ssh-pending` | List pending requests | Configured VPS owner |
| `/ssh-approve user` | Create/activate that member's non-root account and key | Configured VPS owner |
| `/ssh-revoke user` | Remove their SSH key; preserve files | Configured VPS owner |
| `/status` | Show SSH/tunnel status and account counts | Configured VPS owner |
| `/ssh-recheck` | Refresh endpoint and restart Pinggy tunnel | Configured VPS owner |
| `/ping` | Bot latency | Any member |
| `/help` | Help | Any member |

## Configuration

The installer creates `/opt/rgnodes-vm-ssh/.env` as `root:rgnodesbot` with mode `640` (the bot can read it, but cannot replace project code). Important fields:

| Variable | Meaning |
|---|---|
| `DISCORD_TOKEN` | Discord bot token |
| `CLIENT_ID` | Discord application/client ID |
| `GUILD_ID` | Optional guild-scoped slash command registration |
| `OWNER_IDS` | Required comma-separated Discord VPS-owner IDs |
| `LOG_CHANNEL_ID` | Optional private log channel |
| `SSH_PORT` | SSH daemon TCP port; default 22 |
| `PUBLIC_IPV4` | Optional fixed public IPv4 override |
| `ENABLE_PINGGY` | Enable Pinggy fallback when direct IPv4 is unavailable |
| `PINGGY_TOKEN` | Optional Pinggy Pro token; keep secret |
| `PUBLIC_SSH_ACK` | Owner authorization confirmation; installer sets `true` |
| `SSH_HELPER_PATH` | Installer-managed privileged helper path |
| `STATE_FILE` | Installer-managed access state file path |

## Operations and checks

```bash
sudo -u rgnodesbot -H pm2 status
sudo -u rgnodesbot -H pm2 logs rgnodes-vm-ssh --lines 80
sudo -u rgnodesbot -H pm2 restart rgnodes-vm-ssh --update-env
sudo systemctl is-enabled pm2-rgnodesbot.service
sudo sshd -t
sudo systemctl status ssh --no-pager
sudo ss -lntp | grep ':22'
sudo ls -la /home/rgnssh_*/.ssh/authorized_keys
```

Do not share the `.env` file, Discord token, or Pinggy token. The access state file contains public keys and Discord IDs, not private keys.

## Troubleshooting

- **Bot does not start:** check `/opt/rgnodes-vm-ssh/.env`, file permissions, then `sudo -u rgnodesbot -H pm2 logs rgnodes-vm-ssh --lines 100`. The token must be valid and the VPS must be able to reach Discord's API and Gateway.
- **Approval fails:** validate `/usr/local/sbin/rgnodes-vm-ssh-user` exists and `sudo -l -U rgnodesbot` lists only the expected helper command. Run `visudo -cf /etc/sudoers.d/rgnodes-vm-ssh`.
- **Public key rejected:** submit a single-line `ssh-ed25519` public key (usually the contents of the `.pub` file), not the private key.
- **SSH command times out:** confirm `sudo ss -lntp` shows the configured port and that both OS and provider firewalls permit the chosen route.
- **Public IPv4 works locally but not remotely:** outbound IPv4 detection cannot test inbound reachability. Check provider security groups, UFW/nftables, NAT and routing.
- **Pinggy unavailable:** check outbound TCP 443, Pinggy credentials and PM2 logs. Set `FORCE_PINGGY=true` when the server has a public IP but direct inbound SSH is blocked by NAT/provider policy. Free tunnel endpoint details change after timeout/reconnect; run `/ssh` again after reconnect.

## 24/7 process supervision

PM2 is configured with `autorestart`, a restart delay, a memory restart threshold, and a saved process list. The `pm2-rgnodesbot.service` systemd unit is enabled so PM2 can restore the bot after a VPS reboot. This protects against ordinary process exits and server reboots; it cannot prevent downtime caused by VPS-provider outages, network failures, Discord outages, revoked bot tokens, or Pinggy service limits.

## Upgrade

Preserve `/opt/rgnodes-vm-ssh/.env` and `/var/lib/rgnodesbot/state/access.json`. Replace the project files with the new release and run `sudo bash install.sh` again from its extracted directory. Existing approved user accounts and home directories are not deleted by upgrades.
