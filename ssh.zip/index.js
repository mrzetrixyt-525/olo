'use strict';

require('dotenv').config();

const {
  Client,
  Events,
  GatewayIntentBits,
  EmbedBuilder,
  REST,
  Routes,
  SlashCommandBuilder,
} = require('discord.js');
const { spawn, execFile } = require('node:child_process');
const { promisify } = require('node:util');
const net = require('node:net');
const os = require('node:os');
const fs = require('node:fs/promises');
const path = require('node:path');

const execFileAsync = promisify(execFile);
const APP_NAME = 'RGNODES™ VM SSH';
const STARTED_AT = Date.now();
const ANSI_RE = /\u001b\[[0-9;]*m/g;
const KEY_RE = /^ssh-ed25519\s+[A-Za-z0-9+/]+={0,2}(?:\s+[\x20-\x7e]{1,80})?$/;

function csvSet(value) {
  return new Set(String(value || '').split(',').map((v) => v.trim()).filter(Boolean));
}

function envBool(value, fallback = false) {
  if (value === undefined || value === null || value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).trim().toLowerCase());
}

function log(level, message, extra) {
  const line = `[${new Date().toISOString()}] [${level}] ${message}`;
  if (extra !== undefined) console.log(line, extra);
  else console.log(line);
}

const config = {
  token: (process.env.DISCORD_TOKEN || '').trim(),
  clientId: (process.env.CLIENT_ID || '').trim(),
  guildId: (process.env.GUILD_ID || '').trim(),
  ownerIds: csvSet(process.env.OWNER_IDS),
  logChannelId: (process.env.LOG_CHANNEL_ID || '').trim(),
  sshPort: Number.parseInt(process.env.SSH_PORT || '22', 10),
  publicIpv4Override: (process.env.PUBLIC_IPV4 || '').trim(),
  enablePinggy: envBool(process.env.ENABLE_PINGGY, true),
  forcePinggy: envBool(process.env.FORCE_PINGGY, false),
  pinggyToken: (process.env.PINGGY_TOKEN || '').trim(),
  publicSshAck: envBool(process.env.PUBLIC_SSH_ACK, false),
  helperPath: process.env.SSH_HELPER_PATH || '/usr/local/sbin/rgnodes-vm-ssh-user',
  stateFile: process.env.STATE_FILE || '/var/lib/rgnodesbot/state/access.json'
};

function isPublicIPv4(value) {
  if (net.isIPv4(value) !== 4) return false;
  const [a, b, c] = value.split('.').map(Number);
  if (a === 0 || a === 10 || a === 127 || a >= 224) return false;
  if (a === 169 && b === 254) return false;
  if (a === 172 && b >= 16 && b <= 31) return false;
  if (a === 192 && b === 168) return false;
  if (a === 100 && b >= 64 && b <= 127) return false;
  if (a === 192 && b === 0 && (c === 0 || c === 2)) return false;
  if (a === 198 && (b === 18 || b === 19)) return false;
  if (a === 198 && b === 51 && c === 100) return false;
  if (a === 203 && b === 0 && c === 113) return false;
  return true;
}

function validateConfig() {
  const errors = [];
  if (!config.token) errors.push('DISCORD_TOKEN is missing.');
  if (!/^\d{15,22}$/.test(config.clientId)) errors.push('CLIENT_ID must be a Discord application ID.');
  if (config.ownerIds.size === 0 || [...config.ownerIds].some((id) => !/^\d{15,22}$/.test(id))) {
    errors.push('OWNER_IDS must contain at least one valid Discord user ID.');
  }
  if (!Number.isInteger(config.sshPort) || config.sshPort < 1 || config.sshPort > 65535) {
    errors.push('SSH_PORT must be an integer from 1 to 65535.');
  }
  if (config.publicIpv4Override && !isPublicIPv4(config.publicIpv4Override)) {
    errors.push('PUBLIC_IPV4 must be a public IPv4 address or blank for auto-detection.');
  }
  if (!config.publicSshAck) errors.push('Set PUBLIC_SSH_ACK=true after confirming this VPS is yours or you are authorized to administer it.');
  if (errors.length) {
    for (const error of errors) log('CONFIG', error);
    process.exit(1);
  }
}

async function fetchText(url, timeoutMs = 4500) {
  const response = await fetch(url, {
    signal: AbortSignal.timeout(timeoutMs),
    headers: { 'user-agent': 'RGNODES-VM-SSH/2.0' }
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return (await response.text()).trim();
}

async function detectPublicIPv4() {
  if (config.publicIpv4Override) return config.publicIpv4Override;
  for (const url of ['https://api.ipify.org', 'https://ipv4.icanhazip.com/']) {
    try {
      const candidate = await fetchText(url);
      if (isPublicIPv4(candidate)) return candidate;
      log('WARN', `IP lookup at ${new URL(url).hostname} did not return a public IPv4.`);
    } catch (error) {
      log('WARN', `IPv4 lookup failed at ${new URL(url).hostname}: ${error.message}`);
    }
  }
  return null;
}

function canConnectLocal(port, timeoutMs = 1200) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host: '127.0.0.1', port });
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(result);
    };
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
  });
}

async function getSshServiceState() {
  const listening = await canConnectLocal(config.sshPort);
  if (!listening) return { active: false, externallyBound: false, service: 'not listening on localhost' };
  let serviceName = 'TCP listener';
  for (const service of ['ssh', 'sshd']) {
    try {
      const { stdout } = await execFileAsync('systemctl', ['is-active', service], { timeout: 2500 });
      if (stdout.trim() === 'active') { serviceName = service; break; }
    } catch (_) {
      // A local TCP probe is the fallback on non-systemd systems.
    }
  }
  let externallyBound = false;
  try {
    const { stdout } = await execFileAsync('ss', ['-ltnH', `sport = :${config.sshPort}`], { timeout: 2500 });
    const localAddresses = stdout.split(/\r?\n/).filter(Boolean).map((line) => line.trim().split(/\s+/)[3]).filter(Boolean);
    externallyBound = localAddresses.some((value) => {
      let address = value;
      if (address.startsWith('[') && address.includes(']')) address = address.slice(1, address.indexOf(']'));
      else address = address.replace(/:\d+$/, '');
      return !(
        address === '127.0.0.1' || address.startsWith('127.') ||
        address === '::1' || address === 'localhost' || address === '::ffff:127.0.0.1'
      );
    });
  } catch (error) {
    log('WARN', `Could not inspect SSH bind addresses: ${error.message}`);
  }
  return { active: true, externallyBound, service: serviceName };
}

async function ensureStateDirectory() {
  await fs.mkdir(path.dirname(config.stateFile), { recursive: true, mode: 0o700 });
  try { await fs.chmod(path.dirname(config.stateFile), 0o700); } catch (_) {}
}

async function readState() {
  await ensureStateDirectory();
  try {
    const parsed = JSON.parse(await fs.readFile(config.stateFile, 'utf8'));
    return {
      pending: parsed && typeof parsed.pending === 'object' ? parsed.pending : {},
      approved: parsed && typeof parsed.approved === 'object' ? parsed.approved : {}
    };
  } catch (error) {
    if (error.code === 'ENOENT') return { pending: {}, approved: {} };
    log('ERROR', `Access database could not be read: ${error.message}`);
    throw new Error('The SSH access database could not be read safely; no access data was changed.');
  }
}

let stateWriteQueue = Promise.resolve();
async function persistState(state) {
  const operation = stateWriteQueue.catch(() => {}).then(async () => {
    await ensureStateDirectory();
    const tmp = `${config.stateFile}.${process.pid}.tmp`;
    await fs.writeFile(tmp, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 });
    await fs.chmod(tmp, 0o600);
    await fs.rename(tmp, config.stateFile);
  });
  stateWriteQueue = operation.catch(() => {});
  return operation;
}

let stateMutationQueue = Promise.resolve();
function mutateState(mutator) {
  const operation = stateMutationQueue.catch(() => {}).then(async () => {
    const state = await readState();
    const result = await mutator(state);
    await persistState(state);
    return result;
  });
  stateMutationQueue = operation.catch(() => {});
  return operation;
}

function validDiscordId(value) {
  return /^\d{15,22}$/.test(String(value || ''));
}

function accountName(discordId) {
  if (!validDiscordId(discordId)) throw new Error('Invalid Discord user ID.');
  return `rgnssh_${discordId}`;
}

async function runAccessHelper(action, discordId, publicKey) {
  const args = [config.helperPath, action, String(discordId)];
  if (publicKey) args.push(publicKey);
  const { stdout, stderr } = await execFileAsync('sudo', ['-n', ...args], {
    timeout: 15000,
    maxBuffer: 1024 * 1024,
    windowsHide: true
  });
  if (stderr.trim()) log('WARN', `SSH access helper: ${stderr.trim().slice(0, 500)}`);
  return stdout.trim();
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commandDefinitions = [
  new SlashCommandBuilder()
    .setName('ssh-request')
    .setDescription('Request your own SSH account using your public key.')
    .addStringOption((option) => option.setName('public_key').setDescription('Your ssh-ed25519 PUBLIC key (never submit a private key).').setRequired(true).setMaxLength(1000)),
  new SlashCommandBuilder()
    .setName('ssh')
    .setDescription('Show your approved personal SSH connection details.'),
  new SlashCommandBuilder()
    .setName('ssh-pending')
    .setDescription('List pending SSH access requests (VPS owner only).'),
  new SlashCommandBuilder()
    .setName('ssh-approve')
    .setDescription('Approve a pending SSH request and create its Linux account (VPS owner only).')
    .addUserOption((option) => option.setName('user').setDescription('Discord user whose public key request should be approved.').setRequired(true)),
  new SlashCommandBuilder()
    .setName('ssh-revoke')
    .setDescription('Revoke SSH key access while preserving the user home directory (VPS owner only).')
    .addUserOption((option) => option.setName('user').setDescription('Discord user whose SSH access should be revoked.').setRequired(true)),
  new SlashCommandBuilder()
    .setName('status')
    .setDescription('Show VPS SSH and tunnel health status (VPS owner only).'),
  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check bot response latency.'),
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show RGNODES VM SSH commands and setup notes.'),
  new SlashCommandBuilder()
    .setName('ssh-recheck')
    .setDescription('Refresh the SSH endpoint and Pinggy tunnel (VPS owner only).')
].map((command) => command.toJSON());

let endpoint = null;
let sshState = { active: false, service: 'not checked' };
let publicIPv4 = null;
let directEndpointAvailable = false;
let pinggyProcess = null;
let pinggyRetryTimer = null;
let healthTimer = null;
let pinggyRetryMs = 5000;
let pinggyStarting = false;
let refreshPromise = null;
let shuttingDown = false;

function makeEmbed(title, description) {
  return new EmbedBuilder().setTitle(title).setDescription(description).setFooter({ text: APP_NAME });
}

function isOwner(interaction) {
  return config.ownerIds.has(interaction.user?.id);
}

async function sendLog(message) {
  if (!config.logChannelId || !client.isReady()) return;
  try {
    const channel = await client.channels.fetch(config.logChannelId);
    if (channel && channel.isTextBased()) await channel.send({ content: message });
  } catch (error) {
    log('WARN', `Could not post to LOG_CHANNEL_ID: ${error.message}`);
  }
}

function parsePinggyEndpoint(text) {
  const cleaned = String(text || '').replace(ANSI_RE, '');
  const match = cleaned.match(/tcp:\/\/([a-z0-9.-]+):(\d{2,5})/i);
  if (!match) return null;
  const port = Number(match[2]);
  if (!Number.isInteger(port) || port < 1 || port > 65535) return null;
  return { type: 'pinggy', host: match[1], port, discoveredAt: Date.now() };
}

function stopPinggyTunnel() {
  if (pinggyRetryTimer) {
    clearTimeout(pinggyRetryTimer);
    pinggyRetryTimer = null;
  }
  if (pinggyProcess && !pinggyProcess.killed) pinggyProcess.kill('SIGTERM');
  pinggyProcess = null;
  pinggyStarting = false;
}

function schedulePinggyRestart() {
  if (shuttingDown || !sshState.active || directEndpointAvailable || !config.enablePinggy || pinggyRetryTimer) return;
  const wait = pinggyRetryMs;
  pinggyRetryMs = Math.min(pinggyRetryMs * 2, 60000);
  pinggyRetryTimer = setTimeout(() => {
    pinggyRetryTimer = null;
    startPinggyTunnel().catch((error) => log('ERROR', `Pinggy restart failed: ${error.message}`));
  }, wait);
  pinggyRetryTimer.unref?.();
}

async function startPinggyTunnel() {
  if (shuttingDown || pinggyProcess || pinggyStarting || !config.enablePinggy || directEndpointAvailable) return;
  if (!(await canConnectLocal(config.sshPort))) {
    log('WARN', `Pinggy not started: SSH is not listening on 127.0.0.1:${config.sshPort}.`);
    return;
  }

  pinggyStarting = true;
  const account = config.pinggyToken ? `${config.pinggyToken}+tcp@pro.pinggy.io` : 'tcp@free.pinggy.io';
  const args = [
    '-p', '443',
    '-o', 'BatchMode=yes',
    '-o', 'ExitOnForwardFailure=yes',
    '-o', 'ServerAliveInterval=30',
    '-o', 'ServerAliveCountMax=3',
    '-o', 'ConnectTimeout=15',
    '-o', 'StrictHostKeyChecking=accept-new',
    '-R', `0:127.0.0.1:${config.sshPort}`,
    account
  ];

  log('INFO', `Starting ${config.pinggyToken ? 'Pinggy Pro' : 'Pinggy free'} TCP fallback for local SSH port ${config.sshPort}.`);
  const child = spawn('ssh', args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  pinggyProcess = child;
  pinggyStarting = false;
  let tunnelOutputBuffer = '';

  const collect = (chunk) => {
    const output = chunk.toString('utf8');
    tunnelOutputBuffer = (tunnelOutputBuffer + output).slice(-8192);
    const found = parsePinggyEndpoint(tunnelOutputBuffer);
    if (found) {
      const changed = !endpoint || endpoint.type !== found.type || endpoint.host !== found.host || endpoint.port !== found.port;
      endpoint = found;
      pinggyRetryMs = 5000;
      log('INFO', `Pinggy endpoint ready: ${found.host}:${found.port}`);
      if (changed) sendLog(`🔌 **${APP_NAME}** SSH endpoint updated: \`${found.host}:${found.port}\`. Use /ssh to view your personal connection details.`).catch(() => {});
    }
    const safeText = output.replace(ANSI_RE, '').trim();
    if (safeText && (!config.pinggyToken || !safeText.includes(config.pinggyToken))) {
      log('PINGGY', safeText.slice(0, 500));
    }
  };

  child.stdout.on('data', collect);
  child.stderr.on('data', collect);
  child.once('error', (error) => {
    log('ERROR', `Could not launch OpenSSH client for Pinggy: ${error.message}`);
    if (pinggyProcess === child) pinggyProcess = null;
    schedulePinggyRestart();
  });
  child.once('exit', (code, signal) => {
    log('WARN', `Pinggy process exited (code=${code}, signal=${signal || 'none'}).`);
    if (pinggyProcess === child) pinggyProcess = null;
    if (endpoint?.type === 'pinggy') endpoint = null;
    schedulePinggyRestart();
  });
}

async function refreshEndpoint({ restartTunnel = false } = {}) {
  if (refreshPromise && !restartTunnel) return refreshPromise;
  refreshPromise = (async () => {
    sshState = await getSshServiceState();
    if (!sshState.active) {
      endpoint = null;
      publicIPv4 = null;
      directEndpointAvailable = false;
      stopPinggyTunnel();
      return { ready: false, reason: `SSH service is not listening on port ${config.sshPort}.` };
    }

    publicIPv4 = await detectPublicIPv4();
    directEndpointAvailable = Boolean(publicIPv4 && sshState.externallyBound && !config.forcePinggy);
    if (directEndpointAvailable) {
      if (pinggyProcess || pinggyRetryTimer) stopPinggyTunnel();
      endpoint = { type: 'ipv4', host: publicIPv4, port: config.sshPort, discoveredAt: Date.now() };
      return { ready: true, endpoint };
    }

    if (publicIPv4 && !sshState.externallyBound) {
      log('WARN', 'A public IPv4 was detected, but sshd appears bound only to loopback. Using Pinggy as the reachable fallback.');
    } else if (publicIPv4 && config.forcePinggy) {
      log('INFO', 'FORCE_PINGGY=true; using Pinggy even though a public IPv4 is available.');
    }
    if (endpoint?.type === 'ipv4') endpoint = null;
    if (!config.enablePinggy) {
      endpoint = null;
      stopPinggyTunnel();
      return { ready: false, reason: publicIPv4 && config.forcePinggy
        ? 'FORCE_PINGGY is enabled but Pinggy fallback is disabled.'
        : publicIPv4
          ? 'A public IPv4 exists, but SSH is not listening on a non-loopback interface and Pinggy is disabled.'
        : 'No public IPv4 was detected and Pinggy fallback is disabled.' };
    }

    if (restartTunnel) {
      stopPinggyTunnel();
      endpoint = null;
    }
    if (!endpoint || endpoint.type !== 'pinggy') await startPinggyTunnel();
    return endpoint
      ? { ready: true, endpoint }
      : { ready: false, reason: 'Waiting for the Pinggy TCP tunnel address.' };
  })();
  try { return await refreshPromise; }
  finally { refreshPromise = null; }
}

function endpointDetails(discordId) {
  if (!endpoint) return null;
  const username = accountName(discordId);
  return {
    host: endpoint.host,
    port: endpoint.port,
    username,
    command: `ssh -p ${endpoint.port} ${username}@${endpoint.host}`,
    type: endpoint.type
  };
}

function formatUptime(ms) {
  const total = Math.floor(ms / 1000);
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  return `${days}d ${hours}h ${minutes}m`;
}

function getHostSummary() {
  const cpus = os.cpus();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  return {
    platform: `${os.type()} ${os.release()}`,
    arch: os.arch(),
    cpuCount: cpus.length,
    memory: `${(freeMem / 1024 ** 3).toFixed(1)} GB free / ${(totalMem / 1024 ** 3).toFixed(1)} GB total`
  };
}

async function safeReply(interaction, embed) {
  if (interaction.deferred || interaction.replied) return interaction.editReply({ embeds: [embed] });
  return interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleSshRequest(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const publicKey = interaction.options.getString('public_key', true).trim();
  if (!KEY_RE.test(publicKey)) {
    return safeReply(interaction, makeEmbed('Invalid public key', 'Submit one complete `ssh-ed25519` PUBLIC key line. Never submit a private key, password, or file contents other than the public key.'));
  }
  if (publicKey.length > 1000 || /[\r\n\0]/.test(publicKey)) {
    return safeReply(interaction, makeEmbed('Invalid public key', 'The public key must be one line and no longer than 1000 characters.'));
  }
  const id = interaction.user.id;
  const outcome = await mutateState((state) => {
    if (state.approved[id]?.active) return 'already-active';
    state.pending[id] = {
      publicKey,
      username: accountName(id),
      requestedAt: new Date().toISOString(),
      requesterTag: interaction.user.tag || interaction.user.username
    };
    return 'submitted';
  });
  if (outcome === 'already-active') {
    return safeReply(interaction, makeEmbed('SSH account already active', 'Your SSH account is already active. Ask the VPS owner to revoke your existing access before requesting a replacement key.'));
  }
  await sendLog(`📝 **${APP_NAME}**: a new SSH access request is waiting for owner approval from Discord user \`${id}\`.`);
  return safeReply(interaction, makeEmbed('SSH request submitted', 'Your public key has been saved as a pending request. The VPS owner must approve it before an individual Linux account is created. Your private key must remain on your own device.'));
}

async function handleSsh(interaction) {
  await interaction.deferReply({ ephemeral: true });
  const state = await readState();
  const approved = state.approved[interaction.user.id];
  if (!approved?.active) {
    return safeReply(interaction, makeEmbed('SSH access not active', 'First submit your public key using `/ssh-request`. The VPS owner must approve your request before `/ssh` can show connection details.'));
  }
  try {
    await runAccessHelper('check', interaction.user.id);
  } catch (error) {
    log('ERROR', `Managed SSH account check failed for ${interaction.user.id}: ${error.message}`);
    return safeReply(interaction, makeEmbed('SSH account needs attention', 'The approved Linux account or its authorized public key is missing. Ask the VPS owner to review the account and approve your request again.'));
  }
  const result = await refreshEndpoint();
  if (!result.ready) {
    return safeReply(interaction, makeEmbed('SSH endpoint is not ready', `${result.reason || 'The endpoint is not currently available.'}\n\nThe VPS owner should check the SSH service, listening port and provider firewall.`));
  }
  const details = endpointDetails(interaction.user.id);
  const embed = makeEmbed('Your personal SSH connection', 'Your VPS account is individually assigned to your Discord ID. Use the private key that matches the public key you submitted.');
  embed.addFields(
    { name: 'Connection', value: details.type === 'ipv4' ? 'Direct public IPv4' : 'Pinggy TCP tunnel', inline: true },
    { name: 'Host', value: `\`${details.host}\``, inline: true },
    { name: 'Port', value: `\`${details.port}\``, inline: true },
    { name: 'Linux username', value: `\`${details.username}\``, inline: true },
    { name: 'Connect command', value: `\`${details.command}\`` },
    { name: 'Authentication', value: 'Public-key authentication. Your private key stays on your own device.' }
  );
  if (details.type === 'ipv4') {
    embed.addFields({ name: 'Network note', value: 'A public IPv4 was detected. External reachability still depends on provider firewall, OS firewall, routing and SSH port access.' });
  } else {
    embed.addFields({ name: 'Tunnel note', value: config.pinggyToken ? 'Pinggy Pro token configured. Persistent endpoint behavior depends on your Pinggy reservation/account.' : 'Free Pinggy tunnels are time-limited and their host/port can change after reconnects. Run `/ssh` again for the current endpoint.' });
  }
  return safeReply(interaction, embed);
}

async function handlePending(interaction) {
  if (!isOwner(interaction)) return safeReply(interaction, makeEmbed('Owner only', 'Only the configured VPS owner can review SSH requests.'));
  await interaction.deferReply({ ephemeral: true });
  const state = await readState();
  const ids = Object.keys(state.pending);
  if (!ids.length) return safeReply(interaction, makeEmbed('No pending requests', 'There are currently no SSH access requests waiting for approval.'));
  const lines = ids.slice(0, 20).map((id) => `• <@${id}> — \`${id}\` — ${state.pending[id].requestedAt}`);
  const embed = makeEmbed('Pending SSH requests', lines.join('\n'));
  if (ids.length > 20) embed.addFields({ name: 'More requests', value: `${ids.length - 20} additional request(s) not shown.` });
  embed.addFields({ name: 'Approve', value: 'Use `/ssh-approve user:@member` only after confirming the request belongs to the intended person.' });
  return safeReply(interaction, embed);
}

async function handleApprove(interaction) {
  if (!isOwner(interaction)) return safeReply(interaction, makeEmbed('Owner only', 'Only the configured VPS owner can approve SSH access.'));
  await interaction.deferReply({ ephemeral: true });
  const target = interaction.options.getUser('user', true);
  const id = target.id;
  try {
    const approved = await mutateState(async (state) => {
      const request = state.pending[id];
      if (!request) return false;
      await runAccessHelper('add', id, request.publicKey);
      state.approved[id] = {
        active: true,
        username: accountName(id),
        approvedAt: new Date().toISOString(),
        approvedBy: interaction.user.id
      };
      delete state.pending[id];
      return true;
    });
    if (!approved) return safeReply(interaction, makeEmbed('No pending request', 'That Discord user does not have a pending SSH public-key request.'));
    await sendLog(`✅ **${APP_NAME}**: SSH access approved for Discord user \`${id}\` as \`${accountName(id)}\`.`);
    return safeReply(interaction, makeEmbed('SSH access approved', `Created/updated the non-root Linux account \`${accountName(id)}\` and installed the submitted public key. The user can now run /ssh to obtain the endpoint.`));
  } catch (error) {
    log('ERROR', `Could not approve SSH request for ${id}: ${error.message}`);
    return safeReply(interaction, makeEmbed('Approval failed', 'The SSH account/key could not be installed. Check the installer helper and sudo permissions in the PM2 logs. No approval was recorded.'));
  }
}

async function handleRevoke(interaction) {
  if (!isOwner(interaction)) return safeReply(interaction, makeEmbed('Owner only', 'Only the configured VPS owner can revoke SSH access.'));
  await interaction.deferReply({ ephemeral: true });
  const target = interaction.options.getUser('user', true);
  const id = target.id;
  try {
    const revoked = await mutateState(async (state) => {
      if (!state.approved[id]?.active) return false;
      await runAccessHelper('revoke', id);
      state.approved[id].active = false;
      state.approved[id].revokedAt = new Date().toISOString();
      state.approved[id].revokedBy = interaction.user.id;
      return true;
    });
    if (!revoked) return safeReply(interaction, makeEmbed('No active SSH access', 'That Discord user does not have an active SSH approval in this bot.'));
    await sendLog(`⛔ **${APP_NAME}**: SSH public-key access revoked for Discord user \`${id}\`. The Linux home directory was preserved.`);
    return safeReply(interaction, makeEmbed('SSH access revoked', `Removed the authorized SSH public key for \`${accountName(id)}\`. The Linux account and its home directory were preserved; no files were deleted.`));
  } catch (error) {
    log('ERROR', `Could not revoke SSH access for ${id}: ${error.message}`);
    return safeReply(interaction, makeEmbed('Revocation failed', 'The SSH key could not be removed. Check the installer helper and sudo permissions in the PM2 logs.'));
  }
}

async function handleStatus(interaction) {
  if (!isOwner(interaction)) return safeReply(interaction, makeEmbed('Owner only', 'Only the configured VPS owner can view server status.'));
  await interaction.deferReply({ ephemeral: true });
  await refreshEndpoint();
  const host = getHostSummary();
  const state = await readState();
  const activeUsers = Object.values(state.approved).filter((item) => item.active).length;
  const details = endpoint ? `${endpoint.host}:${endpoint.port}` : 'Unavailable';
  const embed = makeEmbed('VPS SSH status', 'Live checks from the VPS running this bot.');
  embed.addFields(
    { name: 'SSH service', value: sshState.active ? `Online (${sshState.service}; ${sshState.externallyBound ? 'non-loopback bind' : 'loopback-only bind'})` : 'Offline / not detected', inline: true },
    { name: 'Endpoint type', value: endpoint ? (endpoint.type === 'ipv4' ? 'Direct IPv4' : 'Pinggy TCP') : 'Unavailable', inline: true },
    { name: 'SSH port', value: String(config.sshPort), inline: true },
    { name: 'Active SSH accounts', value: String(activeUsers), inline: true },
    { name: 'Pending requests', value: String(Object.keys(state.pending).length), inline: true },
    { name: 'Bot uptime', value: formatUptime(Date.now() - STARTED_AT), inline: true },
    { name: 'Current endpoint', value: `\`${details}\`` },
    { name: 'System', value: `${host.platform}\n${host.arch} • ${host.cpuCount} CPU cores\n${host.memory}` },
    { name: 'Reachability', value: 'Local SSH listener and endpoint detection are checked here. Provider firewall and remote inbound access cannot be conclusively verified from this VPS.' }
  );
  return safeReply(interaction, embed);
}

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(config.token);
  const route = config.guildId
    ? Routes.applicationGuildCommands(config.clientId, config.guildId)
    : Routes.applicationCommands(config.clientId);
  await rest.put(route, { body: commandDefinitions });
  log('INFO', `Registered ${commandDefinitions.length} slash commands (${config.guildId ? 'guild' : 'global'}).`);
}

client.once(Events.ClientReady, async (readyClient) => {
  log('INFO', `${APP_NAME} is online as ${readyClient.user.tag}.`);
  try { await registerCommands(); }
  catch (error) { log('ERROR', `Slash command registration failed: ${error.message}`); }
  const result = await refreshEndpoint();
  if (result.ready) log('INFO', `SSH endpoint ready: ${result.endpoint.host}:${result.endpoint.port} (${result.endpoint.type}).`);
  else log('WARN', result.reason || 'SSH endpoint is not ready.');
  healthTimer = setInterval(() => {
    refreshEndpoint().then((status) => {
      if (!status.ready && status.reason) log('WARN', status.reason);
    }).catch((error) => log('ERROR', `Periodic SSH health check failed: ${error.message}`));
  }, 30000);
  healthTimer.unref?.();
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  try {
    switch (interaction.commandName) {
      case 'ssh-request': await handleSshRequest(interaction); break;
      case 'ssh': await handleSsh(interaction); break;
      case 'ssh-pending': await handlePending(interaction); break;
      case 'ssh-approve': await handleApprove(interaction); break;
      case 'ssh-revoke': await handleRevoke(interaction); break;
      case 'status': await handleStatus(interaction); break;
      case 'ping': {
        const latency = client.ws.ping;
        await safeReply(interaction, makeEmbed('Pong!', `Discord gateway latency: \`${Math.round(latency)} ms\``));
        break;
      }
      case 'help': {
        const embed = makeEmbed('RGNODES VM SSH commands', 'Request, approve and manage individual SSH accounts on this VPS.');
        embed.addFields(
          { name: '/ssh-request public_key', value: 'Submit your ssh-ed25519 PUBLIC key for owner approval. Never submit a private key.' },
          { name: '/ssh', value: 'Show your personal SSH host, port, Linux username and command after approval.' },
          { name: '/ssh-pending', value: 'List pending requests (configured VPS owner only).' },
          { name: '/ssh-approve user', value: 'Create/activate a non-root Linux account and authorize that user public key (VPS owner only).' },
          { name: '/ssh-revoke user', value: 'Remove that user public key; preserve account files (VPS owner only).' },
          { name: '/status', value: 'Check local SSH service, endpoint and account counts (VPS owner only).' },
          { name: '/ssh-recheck', value: 'Refresh endpoint and Pinggy tunnel (VPS owner only).' },
          { name: 'Security', value: 'Each Discord user receives a separate non-root Linux account with no sudo privileges. Private keys are never generated, requested or stored by this bot.' }
        );
        await safeReply(interaction, embed);
        break;
      }
      case 'ssh-recheck': {
        if (!isOwner(interaction)) {
          await safeReply(interaction, makeEmbed('Owner only', 'Only the configured VPS owner can refresh the endpoint.'));
          break;
        }
        await interaction.deferReply({ ephemeral: true });
        const result = await refreshEndpoint({ restartTunnel: true });
        await safeReply(interaction, makeEmbed('SSH endpoint check', result.ready
          ? `Endpoint detected: \`${result.endpoint.host}:${result.endpoint.port}\` (${result.endpoint.type}).`
          : (result.reason || 'Endpoint is not ready yet.')));
        break;
      }
      default: break;
    }
  } catch (error) {
    log('ERROR', `Command /${interaction.commandName} failed: ${error.stack || error.message}`);
    await safeReply(interaction, makeEmbed('Command error', 'The request could not be completed. Check the VPS bot logs and configuration.')).catch(() => {});
  }
});

client.on(Events.Error, (error) => log('ERROR', `Discord client error: ${error.message}`));
process.on('unhandledRejection', (error) => log('ERROR', `Unhandled rejection: ${error?.stack || error}`));
process.on('uncaughtException', (error) => {
  log('FATAL', `Uncaught exception: ${error.stack || error.message}`);
  process.exit(1);
});

async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  log('INFO', `Received ${signal}; shutting down cleanly.`);
  if (healthTimer) clearInterval(healthTimer);
  stopPinggyTunnel();
  try { client.destroy(); } catch (_) {}
  setTimeout(() => process.exit(0), 500).unref();
}

process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));

validateConfig();
client.login(config.token).catch((error) => {
  log('FATAL', `Discord login failed: ${error.message}`);
  process.exit(1);
});
