'use strict';
module.exports = {
  apps: [{
    name: 'rgnodes-vm-ssh',
    script: '/opt/rgnodes-vm-ssh/index.js',
    cwd: '/opt/rgnodes-vm-ssh',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '250M',
    restart_delay: 5000,
    exp_backoff_restart_delay: 100,
    kill_timeout: 10000,
    time: true,
    env: { NODE_ENV: 'production' }
  }]
};
