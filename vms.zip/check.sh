#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'
umask 077

# Release/source integrity tests + host readiness report for the RGNODES installer bundle.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
APP_DIR="${RGNODES_APP_DIR:-$SCRIPT_DIR}"
MODE="${1:-all}"
# Some controller regression fixtures invoke terminal helpers; keep checks deterministic in CI
# and non-interactive SSH sessions where TERM is not exported.
export TERM="${TERM:-dumb}"
PASS=0; WARN=0; FAIL=0
pass(){ printf '[PASS] %s\n' "$*"; PASS=$((PASS+1)); }
warn(){ printf '[WARN] %s\n' "$*"; WARN=$((WARN+1)); }
fail(){ printf '[FAIL] %s\n' "$*" >&2; FAIL=$((FAIL+1)); }
info(){ printf '[INFO] %s\n' "$*"; }

case "$MODE" in all|--static|--host) ;; *) printf 'Usage: bash check.sh [--static|--host]\n' >&2; exit 2;; esac
for f in .env bot.py webssh.html requirements.txt setup.sh check.sh node.sh rename-bot.sh ecosystem.config.js nginx-ssh-terminal.conf; do
  if [[ -s "$APP_DIR/$f" ]]; then pass "Required bundle file exists: $f"; else fail "Required bundle file missing/empty: $APP_DIR/$f"; fi
done
for f in setup.sh check.sh node.sh rename-bot.sh; do
  if bash -n "$APP_DIR/$f"; then pass "Shell syntax: $f"; else fail "Shell syntax: $f"; fi
done
if grep -Fq -- '--repair-controller' "$APP_DIR/setup.sh" \
  && grep -Fq 'Installed controller verified:' "$APP_DIR/setup.sh" \
  && grep -Fq 'mv -fT -- "$CTL_TMP" /usr/local/sbin/vpsctl' "$APP_DIR/setup.sh"; then
  pass 'KVM controller repair/install is hash-verified, atomic and directory-safe'
else
  fail 'KVM controller repair/install lacks safe atomic verification'
fi
if command -v node >/dev/null 2>&1; then
  if node --check "$APP_DIR/ecosystem.config.js" >/dev/null 2>&1; then pass 'JavaScript syntax: ecosystem.config.js'; else fail 'JavaScript syntax: ecosystem.config.js'; fi
else warn 'Node.js is unavailable; ecosystem.config.js syntax check skipped.'; fi
if [[ -f "$APP_DIR/.env" ]]; then
  mode="$(stat -c '%a' "$APP_DIR/.env" 2>/dev/null || echo unknown)"
  [[ "$mode" == 600 ]] && pass '.env permissions are 0600' || warn ".env mode is $mode; run chmod 600 '$APP_DIR/.env'."
fi

TMP_DIR="$(mktemp -d /tmp/rgnodes-compact-check.XXXXXX)"
cleanup(){ rm -rf -- "$TMP_DIR"; }
trap cleanup EXIT
mkdir -p "$TMP_DIR/tests"
if python3 - "$APP_DIR/bot.py" "$APP_DIR/node.sh" "$TMP_DIR" <<'PYSTATIC'
import ast,base64,hashlib,re,sys,zlib,subprocess,os,urllib.parse,sqlite3,json
from pathlib import Path
bot_path,node_path,tmp=Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3])
bot=bot_path.read_text(encoding='utf-8'); node=node_path.read_text(encoding='utf-8')
tree=ast.parse(bot,filename='bot.py')
check_source=(bot_path.parent/'check.sh').read_text(encoding='utf-8')
if ('ast.get_source_' + 'segment(') in check_source:
    raise SystemExit('[FAIL] Static checker uses a slow stdlib AST source extractor; use cached byte-offset slices instead')
# Keep source extraction offset-based and cached: rebuilding line offsets per AST node made earlier
# versions unnecessarily slow on bot.py and easy to interrupt during setup.
_source_bytes=bot.encode('utf-8')
_source_offsets=[0]
for _line in bot.splitlines(keepends=True):
    _source_offsets.append(_source_offsets[-1]+len(_line.encode('utf-8')))
from functools import lru_cache
@lru_cache(maxsize=8192)
def _source_slice(start_line,start_col,end_line,end_col):
    if not start_line or not end_line or start_line < 1 or end_line >= len(_source_offsets): return ''
    start=_source_offsets[start_line-1]+start_col
    end=_source_offsets[end_line-1]+end_col
    if start < 0 or end < start or end > len(_source_bytes): return ''
    return _source_bytes[start:end].decode('utf-8','replace')
def source_segment(node):
    return _source_slice(getattr(node,'lineno',0),getattr(node,'col_offset',0),getattr(node,'end_lineno',0),getattr(node,'end_col_offset',0))

def payload(source, payload_pattern, hash_pattern, name, flags=0):
    pm=re.search(payload_pattern,source,flags); hm=re.search(hash_pattern,source,flags)
    if not pm or not hm: raise SystemExit(f'[FAIL] {name} embedded payload/hash not found')
    encoded=pm.group(2) if name=='KVM controller' else pm.group(1)
    raw=zlib.decompress(base64.b64decode(encoded,validate=True))
    actual=hashlib.sha256(raw).hexdigest()
    if actual != hm.group(1): raise SystemExit(f'[FAIL] {name} SHA-256 mismatch: {actual}')
    ast.parse(raw.decode('utf-8'),filename=name)
    print(f'[PASS] {name}: embedded bytes/hash/syntax verified ({actual})')
    return raw
controller=payload(bot,r"_EMBEDDED_VPSCTL_ZLIB_B64\s*=\s*(['\"])(.*?)\1",r"_EMBEDDED_VPSCTL_SHA256\s*=\s*['\"]([0-9a-f]{64})['\"]",'KVM controller',re.S)
agent=payload(node,r"^NODE_AGENT_ZLIB_B64='([^']+)'$",r"^NODE_AGENT_SHA256='([0-9a-f]{64})'$",'Remote node agent',re.M)
node_controller=payload(node,r"^VPSCTL_ZLIB_B64='([^']+)'$",r"^VPSCTL_SHA256='([0-9a-f]{64})'$",'Node KVM controller',re.M)
if controller != node_controller: raise SystemExit('[FAIL] bot.py and node.sh carry different KVM controllers')
print('[PASS] Main and remote-node controllers are byte-for-byte identical')
text=controller.decode('utf-8')
if not all(x in text for x in ('KVM/QEMU/libvirt only','def compat(','virsh','is_real_public_ipv4','allocate_public_ipv4','def download_image(',"if op=='health':")):
    raise SystemExit('[FAIL] KVM/public-IP safety markers missing from embedded controller')
# Exercise every OS dropdown value through the production resolver and verify a matching
# cloud-image entry exists in the embedded KVM controller.
resolver_fn=next((n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='resolve_vps_image'),None)
label_fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='friendly_os_label'),None)
os_assignment=next((n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='OS_OPTIONS' for t in n.targets)),None)
if resolver_fn is None or label_fn is None or os_assignment is None:
    raise SystemExit('[FAIL] OS resolver, label mapper or OS catalogue missing')
os_ns={'RuntimeError':RuntimeError}
exec(compile(ast.Module(body=[resolver_fn,label_fn,os_assignment],type_ignores=[]),'<os-catalogue-tests>','exec'),os_ns)
os_catalog=os_ns['OS_OPTIONS']
expected_os={'ubuntu:20.04':'ubuntu:20.04','ubuntu:22.04':'ubuntu:22.04','ubuntu:24.04':'ubuntu:24.04','ubuntu:26.04':'ubuntu:26.04','images:debian/11':'debian:11','images:debian/12':'debian:12','images:debian/13':'debian:13','alpine:3.24':'alpine:3.24','rocky:9':'rocky:9','rocky:10':'rocky:10','alma:9':'alma:9','alma:10':'alma:10','centos-stream:10':'centos-stream:10','fedora:45':'fedora:45'}
if len(os_catalog)!=14 or {o['value'] for o in os_catalog} != set(expected_os):
    raise SystemExit('[FAIL] OS dropdown catalogue is incomplete or contains unsupported entries')
async def _check_all_os():
    for option in os_catalog:
        resolved=await os_ns['resolve_vps_image'](option['value'],1)
        if resolved!=expected_os[option['value']] or not os_ns['friendly_os_label'](resolved).lower().startswith(('ubuntu','debian','alpine','rocky','alma','centos','fedora')):
            raise SystemExit('[FAIL] OS menu entry did not resolve to a supported image: '+str(option))
import asyncio as _check_asyncio
_check_asyncio.run(_check_all_os())
for image_id in expected_os.values():
    if repr(image_id) not in text:
        raise SystemExit('[FAIL] Embedded KVM controller has no cloud-image URL entry for '+image_id)
print('[PASS] All fourteen OS dropdown options resolve and map to embedded KVM cloud-image entries')
if text.index('def compat(') < 12000:
    raise SystemExit('[FAIL] Regression fixture no longer places the compat marker beyond the historical scan boundary')
find_fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_is_kvm_vpsctl'),None)
if find_fn is None:
    raise SystemExit('[FAIL] KVM controller file validator missing')
fn_src=source_segment(find_fn)
if 'payload[:12000]' in fn_src:
    raise SystemExit('[FAIL] KVM controller validator still truncates marker scan at 12,000 bytes')
digest_match=re.search(r"_EMBEDDED_VPSCTL_SHA256\s*=\s*['\"]([0-9a-f]{64})['\"]",bot)
if not digest_match: raise SystemExit('[FAIL] Embedded controller digest constant is missing')
ns={'Path':Path,'hashlib':hashlib,'KVM_CONTROLLER_MARKERS':('KVM/QEMU/libvirt only','def compat(','virsh'),'_EMBEDDED_VPSCTL_SHA256':digest_match.group(1)}
exec(compile(ast.Module(body=[find_fn],type_ignores=[]),'bot.py#_is_kvm_vpsctl','exec'),ns)
ctl_fixture=tmp/'controller-validator-fixture'; ctl_fixture.write_bytes(controller); ctl_fixture.chmod(0o755)
if not ns['_is_kvm_vpsctl'](str(ctl_fixture)):
    raise SystemExit('[FAIL] Valid embedded KVM controller is rejected by the runtime validator')
ctl_fixture.write_bytes(controller+b'\n#tamper')
if ns['_is_kvm_vpsctl'](str(ctl_fixture)):
    raise SystemExit('[FAIL] Runtime controller validator accepted a tampered controller')
print('[PASS] KVM controller marker validation scans the full source and checks SHA-256')
agent_text=agent.decode('utf-8')
if not all(x in agent_text for x in ('X-API-Key','hmac.compare_digest','def build_vpsctl_argv','ThreadingHTTPServer')):
    raise SystemExit('[FAIL] Remote agent authentication/allowlist markers missing')
if '[:12000]' in agent_text or 'payload = candidate.read_bytes()' not in agent_text or 'hashlib.sha256(payload).hexdigest()' not in agent_text:
    raise SystemExit('[FAIL] Remote agent controller validation still truncates its source or omits integrity validation')
agent_expected=re.search(r"EXPECTED_VPSCTL_SHA256\s*=\s*['\"]([0-9a-f]{64})['\"]",agent_text)
if not agent_expected or agent_expected.group(1)!=hashlib.sha256(controller).hexdigest():
    raise SystemExit('[FAIL] Remote agent trusted-controller digest does not match the embedded KVM controller')
print('[PASS] Remote-agent root cause fixed: full-file marker scan and pinned KVM-controller SHA-256')
if not all(x in node for x in ('KVM_NETWORK_MODE','PUBLIC_PARENT_INTERFACE','PUBLIC_BRIDGE_NAME','REAL_PUBLIC_IPV4_REQUIRED','PUBLIC_IPV4_POOL_CIDR','PUBLIC_IPV4_GATEWAY','PUBLIC_IPV4_DNS','RGNODES_VPS_ROOT','RGNODES_PUBLIC_IPV4','RGNODES_PUBLIC_IPV6')):
    raise SystemExit('[FAIL] Remote installer does not set/retain complete KVM network configuration')
if 'if key in forced: value=forced[key]' not in node and 'if key in forced: value=forced[key]' not in node.replace('\\n','\n'):
    raise SystemExit('[FAIL] Remote installer no longer enforces credentials or preserves defaults safely')
print('[PASS] KVM, public-IP, API-key authentication, command allowlist and network defaults present')
functions={n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
classes={n.name for n in ast.walk(tree) if isinstance(n,ast.ClassDef)}
if 'MonitoringDashboardView' not in classes: raise SystemExit('[FAIL] Live monitoring dashboard view class is missing')
required={'init_db','create_port_forward','remove_port_forward','recreate_port_forwards','ensure_docker_ready','get_pinggy_session_info','apply_guest_motd','build_rgnodes_motd_profile_script','deploy_command','resize_vps','send_progress','_find_kvm_vpsctl','_make_discord_user_agent','build_monitoring_dashboard_embed','monitoring_dashboard'}
missing=required-functions
if missing: raise SystemExit('[FAIL] Critical bot functions missing: '+', '.join(sorted(missing)))
print('[PASS] Required DB, VPS, port, tunnel, access, deployment and embedded-controller functions present')
# OS selector must be wired through one acknowledged private response and the real deployment pipeline.
for marker in ('class DeployTypeView', 'class NodeSelectView', 'class OSSelectView', 'async def select_node', 'async def select_os',
               'await interaction.response.defer(ephemeral=True, thinking=True)', 'await interaction.edit_original_response(embed=selector_embed, view=view)',
               'await resolve_vps_image(selected, self.node_id)', 'async def _deployment_preflight()',
               'DOCKER_VPS_ENABLED', 'self.product_type == "DOCKER"', 'docker_strict = self.product_type == "DOCKER"',
               '"product_type": self.product_type', 'Deploy Docker VPS', 'ensure_column("vps", "product_type"',
               'product_type = excluded.product_type', 'previous_product' , 'clone_product'):
    if marker not in bot:
        raise SystemExit('[FAIL] OS/KVM/Docker deployment flow marker missing: '+marker)
if 'Node Protected' in bot or 'Node Protection' in bot:
    raise SystemExit('[FAIL] Retired Node Protection feature/wording remains in bot source')
for forbidden in ('name="lxc-list"', 'HOST_LXC_TOOLS_ENABLED', 'LXC VPS Backend'):
    if forbidden in bot or forbidden in (bot_path.parent/'.env').read_text(encoding='utf-8'):
        raise SystemExit('[FAIL] Retired LXC VPS feature remains: '+forbidden)
print('[PASS] OS selector flow, KVM/Docker product propagation, and removed Node Protection/LXC VPS features')
# Verify the Discord REST User-Agent is ASCII even with a Unicode-branded BOT_NAME.
ua_fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_make_discord_user_agent'),None)
if ua_fn is None: raise SystemExit('[FAIL] ASCII-safe Discord User-Agent helper missing')
ua_ns={'re':re}
exec(compile(ast.Module(body=[ua_fn],type_ignores=[]),'bot.py#user-agent','exec'),ua_ns)
for name in ('RGNODES™','RGNODES™™','名称™',''):
    ua=ua_ns['_make_discord_user_agent'](name,'15.3.0 VPS KVM')
    if not ua.isascii() or any(ord(ch)>127 for ch in ua): raise SystemExit('[FAIL] Discord User-Agent contains non-ASCII characters')
if 'RGNODES' not in ua_ns['_make_discord_user_agent']('RGNODES™','15.3.0'):
    raise SystemExit('[FAIL] ASCII User-Agent fallback is not branded')
# Run the actual preflight function with a mocked HTTP client to ensure the Unicode-branded
# BOT_NAME can never leak a non-ASCII character into a request header or crash startup.
preflight_fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='discord_token_preflight'),None)
if preflight_fn is None: raise SystemExit('[FAIL] Discord token preflight function missing')
seen={}
class _FakeRequestException(Exception): pass
class _FakeResponse:
    def __init__(self,status): self.status_code=status
class _FakeRequests:
    RequestException=_FakeRequestException
    status=200
    @classmethod
    def get(cls,url,headers,timeout):
        seen.update({'url':url,'headers':dict(headers),'timeout':timeout})
        for value in headers.values():
            if not str(value).isascii(): raise UnicodeEncodeError('latin-1',str(value),0,1,'test')
        return _FakeResponse(cls.status)
class _FakeLogger:
    def info(self,*a,**k): pass
    def warning(self,*a,**k): pass
    def error(self,*a,**k): pass
preflight_ns={'requests':_FakeRequests,'logger':_FakeLogger(),'BOT_NAME':'RGNODES™','BOT_VERSION':'15.3.0','_make_discord_user_agent':ua_ns['_make_discord_user_agent']}
exec(compile(ast.Module(body=[preflight_fn],type_ignores=[]),'bot.py#preflight','exec'),preflight_ns)
if not preflight_ns['discord_token_preflight']('A'*64) or not seen.get('headers',{}).get('User-Agent','').isascii():
    raise SystemExit('[FAIL] Unicode brand can still crash Discord token preflight')
_FakeRequests.status=401
if preflight_ns['discord_token_preflight']('A'*64):
    raise SystemExit('[FAIL] HTTP 401 is not treated as an invalid token')
print('[PASS] Discord preflight simulated against Unicode ™ branding and HTTP 401/200 responses')
# Validate the pure parts of dashboard formatting with representative and failure values.
helper_names={'_dashboard_valid_global_ipv4','_dashboard_progress','_dashboard_uptime'}
helper_nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in helper_names]
if {n.name for n in helper_nodes} != helper_names: raise SystemExit('[FAIL] Dashboard validation/format helper missing')
dash_ns={'Optional':__import__('typing').Optional,'create_progress_bar':lambda v: f'BAR:{v}'}
exec(compile(ast.Module(body=helper_nodes,type_ignores=[]),'bot.py#dashboard-helpers','exec'),dash_ns)
if not dash_ns['_dashboard_valid_global_ipv4']('1.1.1.1') or dash_ns['_dashboard_valid_global_ipv4']('192.168.1.1') or dash_ns['_dashboard_valid_global_ipv4']('224.0.0.1'):
    raise SystemExit('[FAIL] Dashboard public IPv4 validator accepts a non-global address')
if dash_ns['_dashboard_progress'](None) != '`unavailable`' or dash_ns['_dashboard_uptime'](90061) != '1d 01h 01m':
    raise SystemExit('[FAIL] Dashboard unavailable metrics / uptime formatting regression')
print('[PASS] Dashboard IPv4 validation, missing-metric fallback and uptime formatting')
# Execute the real dashboard embed builder against deterministic fake host probes, without
# importing discord.py or making any network/host changes.
build_fn=next((n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='build_monitoring_dashboard_embed'),None)
if build_fn is None: raise SystemExit('[FAIL] Live monitoring dashboard renderer missing')
class _TestEmbed:
    def __init__(self,title='',description=''): self.title=title; self.description=description; self.fields=[]
    def set_author(self,**kwargs): self.author=kwargs
    def set_footer(self,**kwargs): self.footer=kwargs
    def add_field(self,**kwargs): self.fields.append(kwargs)
class _TestBot:
    latency=0.025
    def is_ready(self): return True
class _TestDiscord:
    Embed=_TestEmbed
class _TestLogger:
    def debug(self,*a,**k): pass
samples={'cpu':22.0,'ram_pct':41.0,'ram_used_gb':4.1,'ram_total_gb':10.0,'disk_pct':55.0,'disk_used_gb':55.0,'disk_total_gb':100.0,'uptime_seconds':90061,'load1':0.4,'cpu_count':4,'net_rx_mb':123.0,'net_tx_mb':456.0,'interfaces_up':['ens3']}
services_sample={'kvm_device':True,'libvirt_ok':True,'libvirt_detail':'qemu:///system responding','docker_ok':True,'docker_detail':'daemon online · 27.1','ufw_state':'inactive','fail2ban_state':'active · sshd jail active','uplink':'ens3','bridge':'not configured','network_mode':'direct'}
async def _test_public_ip(): return '1.1.1.1','auto-detected host egress'
ns={'discord':_TestDiscord,'asyncio':__import__('asyncio'),'Dict':__import__('typing').Dict,'Any':__import__('typing').Any,'Optional':__import__('typing').Optional,
    'logger':_TestLogger(),'_collect_dashboard_host_metrics':lambda:samples,'_collect_dashboard_services':lambda:services_sample,
    'get_nodes':lambda:[{'id':1,'name':'local','is_local':True,'url':'','api_key':'','total_vps':10}],
    'vps_data':{'123':[{'status':'running','suspended':False},{'status':'stopped','suspended':False},{'status':'running','suspended':True}]},
    '_dashboard_public_ipv4':_test_public_ip,'_DASHBOARD_FRAMES':('◐','◓','◑','◒'),'_dashboard_uptime':dash_ns['_dashboard_uptime'],
    '_dashboard_progress':dash_ns['_dashboard_progress'],'create_progress_bar':lambda v:f'BAR:{v}','create_embed':lambda title,description:_TestEmbed(title,description),
    'add_field':lambda embed,name,value,inline=False:embed.add_field(name=name,value=value,inline=inline),
    'truncate_text':lambda text,length=1024:str(text)[:length],'PUBLIC_IPV4_POOL_CIDR':'8.8.8.0/29','PUBLIC_IPV4_REQUIRED':True,
    'KVM_NETWORK_MODE':'direct','PUBLIC_PARENT_INTERFACE':'ens3','PUBLIC_BRIDGE_NAME':'','ANTI_MINING_ENABLED':True,
    'HOST_CPU_MAX_DEPLOY_PCT':85.0,'HOST_RAM_RESERVE_GB':2.0,'HOST_DISK_RESERVE_GB':10.0,'BOT_ICON_URL':'',
    'bot':_TestBot(),'datetime':__import__('datetime').datetime,'time':__import__('time'),'BOT_NAME':'RGNODES™','BOT_VERSION':'15.3.0'}
# add_field is a local helper in bot.py and sees the same embed interface above.
exec(compile(ast.Module(body=[build_fn],type_ignores=[]),'bot.py#dashboard-renderer','exec'),ns)
embed=__import__('asyncio').run(ns['build_monitoring_dashboard_embed'](2))
joined=' '.join(str(f.get('name',''))+' '+str(f.get('value','')) for f in embed.fields)
if len(embed.fields)<6 or '1.1.1.1' not in joined or 'active · sshd jail active' not in joined or '3' not in joined:
    raise SystemExit('[FAIL] Live dashboard failed to render required host/network/security/VPS sections')
print('[PASS] Live dashboard embed rendered deterministically with metrics, host egress IP, protection and VPS state')
# All registered bot commands must be classic prefix commands; no slash/hybrid decorators.
if any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'hybrid_command','hybrid_group'} for n in ast.walk(tree)):
    raise SystemExit('[FAIL] Hybrid/slash command decorator found; release policy is prefix-only')
if not any(isinstance(n,ast.AsyncFunctionDef) and n.name=='monitoring_dashboard' for n in tree.body):
    raise SystemExit('[FAIL] Prefix monitoring dashboard command missing')
print('[PASS] Prefix-only command policy and live monitoring dashboard present')
setup_text=(bot_path.parent/'setup.sh').read_text(encoding='utf-8')
env_text=(bot_path.parent/'.env').read_text(encoding='utf-8')
if 'HOST_FAIL2BAN_SSH_ENABLED=true' not in env_text or 'fail2ban' not in setup_text.lower() or 'backend = systemd' not in setup_text or 'maxretry = 5' not in setup_text:
    raise SystemExit('[FAIL] Optional main-host SSH Fail2ban hardening flow is incomplete')
if 'ufw enable' in setup_text.lower() or 'sshd_config' in setup_text:
    raise SystemExit('[FAIL] Setup unexpectedly changes UFW/SSH daemon policy and could lock out the operator')
if 'fail2ban-sshd.local' not in setup_text or '.absent-fail2ban-sshd.local' not in setup_text:
    raise SystemExit('[FAIL] Fail2ban jail backup/rollback flow is missing')
print('[PASS] Main-host SSH brute-force protection has opt-out, validation and rollback; UFW/sshd policies stay untouched')
# Exercise the pure MOTD builder without importing/running the Discord bot. Include hostile
# shell metacharacters to prove user-configured text is base64-encoded, not executed.
fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build_rgnodes_motd_profile_script'),None)
if fn is None: raise SystemExit('[FAIL] Safe MOTD script builder is missing')
mod=ast.Module(body=[fn],type_ignores=[])
ns={'base64':base64}
exec(compile(mod,'bot.py#motd-builder','exec'),ns)
probe="Welcome $(touch /tmp/rgnodes-motd-injection) ' ; `id`"
profile=ns['build_rgnodes_motd_profile_script'](probe)
expected=base64.b64encode(probe.encode()).decode()
if f"CUSTOM_MOTD_B64='{expected}'" not in profile or probe in profile:
    raise SystemExit('[FAIL] MOTD custom text is not safely encoded')
if any(x in profile for x in ('/etc/pam.d/','sed -i','chmod -x /etc/update-motd.d','rm -f /etc/motd','systemctl restart ssh')):
    raise SystemExit('[FAIL] Embedded MOTD installer contains PAM/SSH/distro-MOTD destructive changes')
motd_file=tmp/'motd-profile.sh'; motd_file.write_text(profile,encoding='utf-8')
syntax=subprocess.run(['sh','-n',str(motd_file)],capture_output=True,text=True)
if syntax.returncode: raise SystemExit('[FAIL] Embedded MOTD profile shell syntax: '+syntax.stderr[-500:])
env_config=(bot_path.parent/'.env').read_text(encoding='utf-8')
if 'AUTO_MOTD_INSTALLER=true' not in env_config or 'MOTD_INSTALL_COMMAND=bash <(curl -sSL https://raw.githubusercontent.com/mrzetrixyt-525/vm-/main/MOTD-Installer)' not in env_config or 'MOTD_INSTALL_COMMAND' not in bot:
    raise SystemExit('[FAIL] Configurable guest MOTD installer command/default is missing')
if 'bash -lc \"$cmd\"' not in bot or 'MOTD_COMMAND_ALREADY_DONE' not in bot:
    raise SystemExit('[FAIL] Configured MOTD command is not executed once inside the guest via Bash')
print('[PASS] MOTD: safe embedded fallback plus configurable one-time .env command execution')
# Exercise Pinggy endpoint parsing against ANSI-wrapped and malformed provider output.
regex_nodes=[]
for n in tree.body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in {'ANSI_RE','PINGGY_ENDPOINT_RE'} for t in n.targets):
        regex_nodes.append(n)
parser=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='parse_pinggy_endpoint'),None)
if parser is None or len(regex_nodes)!=2: raise SystemExit('[FAIL] Pinggy endpoint parser or regex definitions missing')
from typing import Optional as _Optional
parser_ns={'re':re,'Optional':_Optional}
exec(compile(ast.Module(body=regex_nodes+[parser],type_ignores=[]),'bot.py#pinggy-parser','exec'),parser_ns)
parse=parser_ns['parse_pinggy_endpoint']
if parse('\x1b[31mForwarding TCP: tcp://abc123.a.pinggy.link:443\x1b[0m') != ('abc123.a.pinggy.link',443,'tcp://abc123.a.pinggy.link:443'):
    raise SystemExit('[FAIL] Pinggy ANSI endpoint parser regression')
if parse('Your TCP URL is tcp://x.pinggy.io:2022') != ('x.pinggy.io',2022,'tcp://x.pinggy.io:2022'):
    raise SystemExit('[FAIL] Pinggy provider-format parser regression')
if parse('https://foo.pinggy.link:65536') != (None,None,None):
    raise SystemExit('[FAIL] Pinggy parser accepted an out-of-range TCP port')
print('[PASS] Pinggy parser: ANSI stripping, TCP URL formats, port-range validation')
# Detect duplicate prefixed command names/aliases before discord.py registers them.
registered={}
for n in ast.walk(tree):
    if not isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)): continue
    for dec in n.decorator_list:
        if not isinstance(dec,ast.Call): continue
        fn=dec.func
        if not (isinstance(fn,ast.Attribute) and fn.attr in {'command','hybrid_command'} and isinstance(fn.value,ast.Name) and fn.value.id=='bot'): continue
        kws={k.arg:k.value for k in dec.keywords if k.arg}
        name=kws.get('name')
        name=name.value if isinstance(name,ast.Constant) and isinstance(name.value,str) else n.name
        aliases=[]
        a=kws.get('aliases')
        if isinstance(a,(ast.List,ast.Tuple)):
            aliases=[v.value for v in a.elts if isinstance(v,ast.Constant) and isinstance(v.value,str)]
        for key in [name,*aliases]:
            normalized=key.casefold()
            previous=registered.get(normalized)
            if previous and previous != n.name: raise SystemExit(f'[FAIL] Duplicate command/alias {key!r}: {previous} and {n.name}')
            registered[normalized]=n.name
print(f'[PASS] No duplicate prefix command names/aliases ({len(registered)} registered)')
# Confirm progress edits a normal public message, not the ephemeral interaction original response.
if 'await progress_message.edit(embed=embed, view=None' not in bot or 'await interaction.edit_original_response(embed=embed)' in bot or 'await self.ctx.send(embed=creating_embed' not in bot:
    raise SystemExit('[FAIL] Deployment progress is not configured as a persistent public message')
# Verify the advanced deploy stages, protected status commands and local-only browser SSH terminal.
stages_node=next((n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DEPLOYMENT_STAGES' for t in n.targets)),None)
if stages_node is None:
    raise SystemExit('[FAIL] Animated deployment stage list is missing')
stages=ast.literal_eval(stages_node.value)
expected_stages=('Receiving VPS ID','Checking KVM / QEMU','Creating VPS Container','Applying Resource','Booting VPS','Configure Package','🐳 Docker Ready','Fixing systemctl','Register In Bot Database','Installing SSH + Password','Making Public Real IPv4','Creating SSH','Creating PINGGY','Final Full Check and Repair','Finished')
if tuple(stages)!=expected_stages:
    raise SystemExit('[FAIL] Deployment progress stages are missing or out of order')
for command_name in ('kvm-status','ssh-status','docker-status'):
    if not re.search(r"@bot\.command\(name=['\"]"+re.escape(command_name)+r"['\"]",bot):
        raise SystemExit('[FAIL] Status command missing: '+command_name)
if 'aiohttp>=3.12,<4' not in (bot_path.parent/'requirements.txt').read_text(encoding='utf-8'):
    raise SystemExit('[FAIL] aiohttp web-terminal dependency is not declared')
if 'aiohttp_web.TCPSite(runner, "127.0.0.1", WEB_TERMINAL_PORT' not in bot or 'StrictHostKeyChecking=accept-new' not in bot or 'secrets.compare_digest(supplied, expected)' not in bot:
    raise SystemExit('[FAIL] Browser SSH terminal is missing loopback binding, host-key policy or constant-time token comparison')
if 'def _get_owned_vps_for_status' not in bot or 'not is_admin_user(ctx.author)' not in bot:
    raise SystemExit('[FAIL] VPS status commands are missing owner/admin access control')
print('[PASS] RGNODES 15-stage deploy tracker, KVM/SSH/Docker status commands and authenticated browser SSH terminal')
if not all(x in bot for x in ("'cpu_chip': os.getenv('EMOJI_CPU', 'Cpu')", "'ram_chip': os.getenv('EMOJI_RAM', 'RAM')", "'disk': os.getenv('EMOJI_DISK', 'SSD')", "'statusonline': os.getenv('EMOJI_ONLINE', 'StatusOnline')", "'statusoffline': os.getenv('EMOJI_OFFLINE', 'StatusOffline')", 'async def prefix_hint_response', 'get_vps_ssh_endpoint', "My current command prefix is", "BOT_LANGUAGE = 'en'")):
    raise SystemExit('[FAIL] English-only prefix response, screenshot emoji mapping, or shared SSH endpoint helper is missing')
if re.search(r'[\u0980-\u09FF]', bot) or re.search(r'[\u0980-\u09FF]', (bot_path.parent/'README.txt').read_text(encoding='utf-8')):
    raise SystemExit('[FAIL] Bot source or documentation contains non-English Bengali user-facing text')
if not all(x in bot for x in ('network_mode\":\"unknown', 'network_mode_unverified', 'ssh_access_pending', 'Shared node IPv4 (NAT)', 'access_repair_task')):
    raise SystemExit('[FAIL] Deployment must preserve the created VM when remote network mode or SSH forwarding is temporarily unavailable')
print('[PASS] English-only prefix hint, screenshot emoji mappings, unified SSH endpoint and non-fatal access repair')
# Access regression guards: no stale DB-only mapping, quota-blocked SSH, or Manage-panel bypass.
env_text=(bot_path.parent/'.env').read_text(encoding='utf-8')
access_markers=(
    'async def ensure_vps_ssh_access',
    'await ensure_vps_ssh_access(str(self.owner_id), target_vps, repair=True)',
    'await ensure_vps_ssh_access(str(target_owner), target, repair=True)',
    'if vps_port != 22:',
    'await create_port_forward(str(owner_id),str(container_name),22,int(node_id))',
    'needs_forward = True',
    'def create_embed(title, description="", color=None):',
    'embed = discord.Embed(\n        title=truncate_text(title, 256),',
    'async def discover_node_public_endpoints',
    "The bot will not substitute its own public IP.",
    "if not node.get('is_local'):",
    "Subsystem sftp internal-sftp",
    "grep -Eq '^subsystem sftp '",
)
if not all(marker in bot for marker in access_markers):
    raise SystemExit('[FAIL] SSH access repair, Manage-panel wiring, port-22 exemption, endpoint discovery or embed color configuration is incomplete')
if 'EMBED_COLOR=none' not in env_text or "env_set EMBED_COLOR 'none'" not in setup_text or 'color=discord.Color(EMBED_COLOR)' in bot:
    raise SystemExit('[FAIL] Embeds must omit custom colours; .env and installer must use EMBED_COLOR=none')
for access_command in ('ssh_command','webssh_command','file_manager_command'):
    function=next((n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==access_command),None)
    if function is None or not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='ensure_vps_ssh_access' for n in ast.walk(function)):
        raise SystemExit('[FAIL] Prefix access command bypasses the common SSH repair path: '+access_command)
print('[PASS] Colourless embeds, SSH port-22 quota exemption, guest SSH verification and shared access repair path')
if not all(value in bot for value in ('"ubuntu:20.04"', '"ubuntu:22.04"', '"ubuntu:24.04"', '"ubuntu:26.04"', '"images:debian/11"', '"images:debian/12"', '"images:debian/13"', '"alpine:3.24"', '"rocky:9"', '"rocky:10"', '"alma:9"', '"alma:10"', '"centos-stream:10"', '"fedora:45"')):
    raise SystemExit('[FAIL] One or more advertised OS image values are missing')
if 'DOCKER_VPS_ENABLED=true' not in (bot_path.parent/'.env').read_text(encoding='utf-8'):
    raise SystemExit('[FAIL] Docker VPS product is not enabled in the default environment template')
if 'DOCKER_VPS_ENABLED' not in setup_text:
    raise SystemExit('[FAIL] Installer does not seed the Docker VPS product setting')
print('[PASS] All fourteen advertised cloud OS options and enabled Docker VPS default are present')
requested_commands={'list','info','stats','plans','claimfree','start','stop','restart','about-bot','addinv','removeinv','addboost','removeboost','user-stats','invite-logs','boost-logs','change-prefix','change-mode','check-resources','machine-status','start-all','purge-prot','purge-remove-prot','purge-status','purge-list-prot','purge-list-unprot','purge-vm-all'}
registered=set()
for _cmd_node in ast.walk(tree):
    if isinstance(_cmd_node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        for dec in _cmd_node.decorator_list:
            if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and isinstance(dec.func.value,ast.Name) and dec.func.value.id=='bot' and dec.func.attr in {'command','group'}:
                for kw in dec.keywords:
                    if kw.arg=='name' and isinstance(kw.value,ast.Constant): registered.add(str(kw.value.value))
                for kw in dec.keywords:
                    if kw.arg=='aliases' and isinstance(kw.value,(ast.List,ast.Tuple)):
                        registered.update(str(x.value) for x in kw.value.elts if isinstance(x,ast.Constant))
missing_commands=requested_commands-registered
if missing_commands: raise SystemExit('[FAIL] Requested commands missing: '+', '.join(sorted(missing_commands)))
print('[PASS] Requested VPS/user/admin aliases and reward tracking command handlers are registered')
for forbidden in ('async def start_sshx_session(', 'async def sshx_command(', 'async def sshx_health_command(', 'https://sshx.io/get', '"Creating SSHX"'):
    if forbidden in bot: raise SystemExit('[FAIL] Removed SSHX feature still active in source: '+forbidden)
if 'WEB_TERMINAL_HOST = (_WEB_TERMINAL_URL_PARTS.hostname' not in bot or 'domain_origin = parsed.scheme == WEB_TERMINAL_SCHEME' not in bot or 'secure=secure_cookie' not in bot:
    raise SystemExit('[FAIL] Configurable terminal origin or secure cookie policy is missing')
terminal_env=(bot_path.parent/'.env').read_text(encoding='utf-8')
release_mode=os.getenv('RGNODES_ENFORCE_RELEASE_DEFAULTS','').strip().lower() in {'1','true','yes'}
if release_mode:
    if 'WEB_TERMINAL_PUBLIC_URL=https://ssh.rgnodes.bond' not in terminal_env:
        raise SystemExit('[FAIL] Canonical RGNODES terminal URL is not configured in the release template')
else:
    terminal_values={}
    for row in terminal_env.splitlines():
        row=row.strip()
        if row and not row.startswith('#') and '=' in row:
            k,v=row.split('=',1); terminal_values[k.strip()]=v.strip().strip('"\'')
    parsed_url=urllib.parse.urlsplit(terminal_values.get('WEB_TERMINAL_PUBLIC_URL',''))
    if parsed_url.scheme!='https' or not parsed_url.hostname or parsed_url.username or parsed_url.password:
        raise SystemExit('[FAIL] Runtime terminal URL must be a valid HTTPS origin without embedded credentials')
proxy_path = bot_path.parent/'nginx-ssh-terminal.conf'
if not proxy_path.is_file(): raise SystemExit('[FAIL] HTTPS terminal reverse-proxy configuration is missing')
proxy = proxy_path.read_text(encoding='utf-8')
for required_proxy_setting in ('server_name ssh.rgnodes.bond;', 'limit_req zone=rgnodes_terminal_login', 'proxy_pass http://127.0.0.1:9090;', 'proxy_set_header X-Forwarded-For $remote_addr;', 'proxy_set_header Upgrade $http_upgrade;', 'return 301 https://$host$request_uri;'):
    if required_proxy_setting not in proxy: raise SystemExit('[FAIL] HTTPS reverse-proxy config missing '+required_proxy_setting)
if '_WEB_TERMINAL_LOGIN_ATTEMPTS' not in bot or 'len(_WEB_TERMINAL_ACTIVE_SESSIONS) >= WEB_TERMINAL_MAX_SESSIONS' not in bot:
    raise SystemExit('[FAIL] Browser terminal login/session caps are missing')
print('[PASS] Canonical HTTPS endpoint, rate-limited Nginx/WebSocket proxy and bounded terminal sessions')
# The supplied WebSSH UI must use the bot's one-time-ticket + cookie + WebSocket protocol.
webssh_path = bot_path.parent/'webssh.html'
webssh = webssh_path.read_text(encoding='utf-8') if webssh_path.is_file() else ''
for marker in ('/api/login', '/api/logout', 'new WebSocket(', 'location.host}/ws', "type:'connect'", "type:'input'", "type:'resize'", "type:'ping'", 'requestAnimationFrame', 'queueInput', 'FitAddon.FitAddon', 'https://unpkg.com/xterm@5.3.0/lib/xterm.min.js', '__BOT_NAME__', '__BOT_VERSION__'):
    if marker not in webssh: raise SystemExit('[FAIL] WebSSH UI missing WebSocket/auth/performance marker: '+marker)
for stale in ('/api/ssh/read', '/api/ssh/write', 'setInterval(tick,100)', 'Math.random()'):
    if stale in webssh: raise SystemExit('[FAIL] Laggy/unsafe legacy HTTP-polling WebSSH code remains: '+stale)
for marker in ('BASE_DIR / "webssh.html"', 'html_lib.escape', 'WEB_TERMINAL_SESSION_TTL', 'WEB_TERMINAL_SESSIONS_PER_IP', 'await ws.send_bytes(chunk)', 'action == "ping"'):
    if marker not in bot: raise SystemExit('[FAIL] WebSSH backend missing matching UI contract marker: '+marker)
if 'proxy_pass http://127.0.0.1:9090;' not in proxy or '127.0.0.1", WEB_TERMINAL_PORT' not in bot or "https://unpkg.com;" not in bot:
    raise SystemExit('[FAIL] WebSSH must use loopback-only service + matching Nginx port 9090')
print('[PASS] Supplied WebSSH UI uses one-time ticket login, cookie-authenticated WebSocket PTY, buffered input and frame-batched output')
if 'HOST_MOTD=bash <(curl -sSL https://raw.githubusercontent.com/mrzetrixyt-525/vm-/main/MOTD-Installer)' not in env_text or '_HOST_MOTD_IS_COMMAND' not in bot or 'MOTD_INSTALL_COMMAND' not in bot or 'bash -lc' not in bot:
    raise SystemExit('[FAIL] Configured MOTD installer command is not parsed and executed in the guest-only install path')
if any(marker in bot for marker in ('**Generated API Key:**', '**Current API Key:**', 'sudo bash node.sh --api-key={api_key}', 'add_field(success_embed, "New API Key"')):
    raise SystemExit('[FAIL] A remote-node API key appears to be posted into a public channel/command')
if 'send_private_node_setup' not in functions or '--prompt-api-key' not in node:
    raise SystemExit('[FAIL] Private node-key delivery or hidden rotation prompt is missing')
# Execute the exact env-writer embedded in node.sh against a temporary config: secrets must be
# enforced, custom bridge/pool settings preserved, empty uplink auto-filled, duplicates removed.
start=node.index('# Atomically write credentials and fill missing network defaults')
writer=re.search(r'''python3 - "\$ENV_FILE" "\$API_KEY" "\$HOST" "\$PORT" "\$CONTROLLER" "\$UPLINK" <<'PYENV'\n(.*?)\nPYENV''',node[start:],re.S)
if not writer: raise SystemExit('[FAIL] Remote node environment writer could not be extracted for testing')
envtest=tmp/'node-agent.env'
envtest.write_text('# preserve this comment\nRGNODES_NODE_API_KEY=old-key\nKVM_NETWORK_MODE=bridge\nPUBLIC_PARENT_INTERFACE=\nPUBLIC_BRIDGE_NAME=br-public\nPUBLIC_IPV4_POOL_CIDR=198.51.100.0/29\nPUBLIC_IPV4_GATEWAY=198.51.100.1\nKVM_NETWORK_MODE=direct\n',encoding='utf-8')
cp=subprocess.run([sys.executable,'-',str(envtest),'a'*64,'127.0.0.1','18443','/usr/local/sbin/vpsctl','ens3'],input=writer.group(1),text=True,capture_output=True)
if cp.returncode: raise SystemExit('[FAIL] Remote env-writer execution failed: '+cp.stderr[-500:])
envtext=envtest.read_text(encoding='utf-8')
for marker in ('RGNODES_NODE_API_KEY='+'a'*64,'KVM_NETWORK_MODE=bridge','PUBLIC_PARENT_INTERFACE=ens3','PUBLIC_BRIDGE_NAME=br-public','PUBLIC_IPV4_POOL_CIDR=198.51.100.0/29','PUBLIC_IPV4_GATEWAY=198.51.100.1'):
    if marker not in envtext: raise SystemExit('[FAIL] Remote env-writer lost required setting '+marker.split('=',1)[0])
if envtext.count('KVM_NETWORK_MODE=')!=1 or (envtest.stat().st_mode & 0o777)!=0o600:
    raise SystemExit('[FAIL] Remote env-writer failed duplicate cleanup or mode-0600 protection')
print('[PASS] Remote env writer: credentials enforced, custom network preserved, defaults filled, file mode 0600')
print('[PASS] Deployment progress is persistent; node API keys are DM-only and terminal input can be hidden')
# Credential/tunnel endpoints must never fall back to channel posts when DMs are closed.
def func_source(name):
    node=next((x for x in tree.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name==name),None)
    if node is None: raise SystemExit('[FAIL] Critical command handler missing: '+name)
    return source_segment(node)
for name in ('ssh_command','pinggy_command'):
    source=func_source(name)
    if 'except discord.Forbidden:' not in source or 'ctx.send(embed=access)' in source or 'ctx.send(embed=e)' in source:
        raise SystemExit('[FAIL] '+name+' may publicly reveal SSH credentials/tunnel endpoints when DMs are blocked')
password_source=func_source('vps_password')
if 'await recipient.send(' not in password_source or 'await ctx.send(embed=embed)' in password_source:
    raise SystemExit('[FAIL] VPS root passwords are not guaranteed to be DM-only')
for unsafe in ('Password report was posted publicly', 'await ctx.send(embed=access)'):
    if unsafe in password_source: raise SystemExit('[FAIL] VPS password command contains an unsafe channel delivery path')
status_source=func_source('system_status')
if 'BOT_PROCESS_STARTED_MONOTONIC' not in status_source or 'datetime.fromtimestamp(start_time - bot.latency)' in status_source:
    raise SystemExit('[FAIL] System status bot-uptime calculation is not based on process uptime')
manage_source=func_source('manage_vps')
manage_view_source='\n'.join((bot.split('    async def _pinggy_block(',1)[1].split('    async def create_vps_embed(',1)[0], bot.split('    async def create_vps_embed(',1)[1].split('    async def ',1)[0])) if '    async def _pinggy_block(' in bot and '    async def create_vps_embed(' in bot else ''
if not manage_source or not manage_view_source:
    raise SystemExit('[FAIL] VPS management dashboard safety paths could not be checked')
for unsafe in ('SSHX: <{sshx_url}>', 'Last session: <{sshx_url}>', 'ssh root@{host}', 'Host: `{host}`', 'Port: `{port}`'):
    if unsafe in manage_view_source:
        raise SystemExit('[FAIL] VPS management dashboard exposes a private tunnel endpoint: '+unsafe)
error_source=func_source('on_command_error')
if 'detail[:800]' in error_source or '**Technical:**' in error_source or 'Sensitive technical details are hidden.' not in error_source:
    raise SystemExit('[FAIL] Command errors may broadcast raw exception details into Discord/audit channels')
for name in ('ssh_command','pinggy_command'):
    source=func_source(name)
    if 'str(e)[:900]' in source or 'exc_info=True' in source or 'Session URL' in source and 'not posted' not in source:
        raise SystemExit('[FAIL] '+name+' may expose private exception or session details')
if 'endpoint omitted from logs' not in bot:
    raise SystemExit('[FAIL] Pinggy background supervisor may log a live connection endpoint')
exec_source=func_source('execute_command')
if 'await ctx.author.send(embed=embed' not in exec_source or 'await ctx.send(embed=embed)' in exec_source or 'Command: `{command}`' in exec_source:
    raise SystemExit('[FAIL] Remote command output/text is not restricted to the admin DM')
if 'def safe_error_summary(' not in bot or 'Sensitive details were hidden' not in bot:
    raise SystemExit('[FAIL] Safe exception summarizer is missing')
for command_name in ('deploy_command','create_machine'):
    command_node=next((n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==command_name),None)
    command_source=source_segment(command_node) if command_node else ''
    if not command_source or r'\\n' in command_source:
        raise SystemExit('[FAIL] '+command_name+' description may render literal \\n instead of real line breaks')
setup_text=(bot_path.parent/'setup.sh').read_text(encoding='utf-8')
if "ensure_env_default BOT_VERSION 'V9 Pro'" not in setup_text:
    raise SystemExit('[FAIL] Setup does not preserve/configure the requested V9 Pro release label')
# Installer checks: a malformed config/release should not stop a healthy service, failed writes
# must restore the previous .env/controller object, and the control bot must have bounded cgroups.
required_setup_markers=(
    'flock -n 9', 'apt_retry apt-get update', 'restore_env_config', 'ENV_ORIGINAL_PRESENT=1',
    'systemd-analyze verify', 'CPUQuota=${BOT_CPU_QUOTA_PERCENT}%',
    'MemoryMax=${BOT_MEMORY_MAX_MB}M', 'TasksMax=${BOT_TASKS_MAX}',
    'vpsctl-object.type', 'unit-object.type', 'cp -a -- /usr/local/sbin/vpsctl', 'env_remove REMOTE_NODE_ONLY', 'env_remove HOST_LXC_TOOLS_ENABLED',
    'mv -fT -- "$UNIT_TMP" "$SYSTEMD_UNIT_PATH"', 'env-backup-rollback.XXXXXX',
    'NO_COLOR', 'StartLimitIntervalSec=300',
    'The existing $SERVICE_NAME is active/enabled but DISCORD_TOKEN is missing or invalid',
    'Less than 350 MiB free', 'normalize_int_env DEFAULT_VPS_STORAGE_GB',
    'sync_resource_alias VPS_MAX_RAM_GB MAX_VPS_RAM_GB',
    'prompt_resource INITIAL_VPS_RAM_GB DEFAULT_VPS_RAM_GB',
    'Additional ADMIN_USER_IDS (comma-separated IDs',
    'HOST_DOCKER_ENABLED', 'HOST_FASTFETCH_ENABLED',
    'DOCKER_DEFAULT=no', 'FASTFETCH_DEFAULT=no',
    'apt-get full-upgrade -y', 'RGNODES_FULL_UPGRADE', 'answer_num=$((10#$answer))',
    'MAIN_ADMIN_ID is not ready', 'systemctl is-enabled --quiet "$SERVICE_NAME"',
    'Release checks passed; continuing with configuration, dependency repair and 24/7 service setup.',
)
if 'HOST_LXC_TOOLS_ENABLED' not in setup_text or 'env_remove HOST_LXC_TOOLS_ENABLED' not in setup_text:
    raise SystemExit('[FAIL] Setup does not clean retired LXC config from existing installations')
if 'apt-get install -y lxc' in setup_text or 'Install LXC tools' in setup_text:
    raise SystemExit('[FAIL] Installer still offers or installs LXC host tools')
if not all(marker in setup_text for marker in required_setup_markers):
    missing=[marker for marker in required_setup_markers if marker not in setup_text]
    raise SystemExit('[FAIL] Hardened installer is missing safeguards: '+', '.join(missing))
if 'TasksMax=infinity' in setup_text:
    raise SystemExit('[FAIL] Bot service still has an unbounded task limit')
unit_match=re.search(r'cat > "\$UNIT_TMP" <<EOFUNIT\n(.*?)\nEOFUNIT', setup_text, re.S)
if not unit_match:
    raise SystemExit('[FAIL] Generated systemd unit template is missing')
unit_text=unit_match.group(1)
unit_part, _, service_part=unit_text.partition('[Service]')
if 'StartLimitIntervalSec=300' not in unit_part or 'StartLimitBurst=5' not in unit_part:
    raise SystemExit('[FAIL] systemd restart limits must be declared in [Unit], not [Service]')
if not all(marker in service_part for marker in ('CPUQuota=', 'MemoryHigh=', 'MemoryMax=', 'TasksMax=', 'Nice=5')):
    raise SystemExit('[FAIL] Bot service cgroup/priority safeguards are incomplete')
if not all(marker in setup_text for marker in ('Enable Pinggy SSH tunneling', 'Auto-detect the control/node public IPv4', 'Require a real public IPv4', 'Restart=always', 'HOST_DOCKER_ENABLED', 'FASTFETCH_PACKAGE', 'Optional Docker package install failed', 'Missing command tools detected', 'trying the compatible fallback')):
    raise SystemExit('[FAIL] Interactive options for Pinggy, public IPv4, optional host tools or persistent service are incomplete')
print('[PASS] Interactive setup wizard validates admin IDs/resources, offers Pinggy/IP/Docker/Neofetch, and guards full-upgrade')
print('[PASS] Installer lock, preflight, .env/controller rollback, reconciled resource policy and bounded systemd service are present')
if "env_set REMOTE_NODE_ONLY 'true'" in setup_text or 'Restrict deployments to REMOTE nodes only?' in setup_text:
    raise SystemExit('[FAIL] setup.sh still exposes a remote-only mode')
if "env_remove REMOTE_NODE_ONLY" not in setup_text or 'Local Node was automatically registered' not in setup_text or 'LOCAL_KVM_ENABLED' not in setup_text or 'env_remove REMOTE_NODE_ONLY' not in setup_text:
    raise SystemExit('[FAIL] setup.sh lacks fixed combined mode, optional local KVM, or automatic Local Node verification')
if 'Install KVM/QEMU/libvirt on THIS control host?' not in setup_text:
    raise SystemExit('[FAIL] Local host KVM is not optional in the setup wizard')
print('[PASS] Installer fixes combined Local + Remote mode, keeps host KVM optional, and verifies automatic Local Node registration')
raw_error=re.compile(r'(?:str\(\s*(?:e|exc|error|db_error|start_error|rollback_error)\s*\)|\{\s*(?:e|exc|error|db_error|start_error|rollback_error)\s*(?:![a-zA-Z]|:[^}]*)?\})')
for call in ast.walk(tree):
    if not isinstance(call,ast.Call): continue
    fn=call.func
    attr=fn.attr if isinstance(fn,ast.Attribute) else ''
    name=fn.id if isinstance(fn,ast.Name) else ''
    if attr in ('send','send_message') or name in ('add_field','create_error_embed','create_warning_embed'):
        snippet=source_segment(call)
        if raw_error.search(snippet):
            raise SystemExit('[FAIL] Raw exception text may reach a Discord-facing message/embed near line '+str(call.lineno))
# Runtime mode is fixed to combined Local + Remote; host KVM installation is optional.
if 'REMOTE_NODE_ONLY' in bot or 'remote-only' in bot.lower():
    raise SystemExit('[FAIL] Runtime source still contains a remote-only mode/branch')
if not all(s in bot for s in ('def _preferred_deployment_node_id', 'if local_ready:', 'if remote_nodes:', 'HOST_VCPU_OVERCOMMIT_RATIO', 'def detect_local_node_location')):
    raise SystemExit('[FAIL] Combined Local + Remote default-node routing or proportional vCPU admission guard missing')
node_env=(bot_path.parent/'.env').read_text(encoding='utf-8')
node_values={}
for row in node_env.splitlines():
    row=row.strip()
    if row and not row.startswith('#') and '=' in row:
        k,v=row.split('=',1); node_values[k.strip()]=v.strip().strip('"\'')
if release_mode:
    if not all(s in node_env for s in ('LOCAL_KVM_ENABLED=false','NODE_LOCATION_AUTO_DETECT=true','PINGGY_SSH_PORT=443','PINGGY_REMOTE_PORT=890','HOST_VCPU_OVERCOMMIT_RATIO=1.5')):
        raise SystemExit('[FAIL] Release defaults do not enable combined local+remote mode, Pinggy ports and vCPU ratio')
else:
    if node_values.get('LOCAL_KVM_ENABLED','false').lower() not in {'1','true','yes','on','0','false','no','off'}:
        raise SystemExit('[FAIL] LOCAL_KVM_ENABLED must be a boolean setting')
    if 'REMOTE_NODE_ONLY' in node_values:
        raise SystemExit('[FAIL] Release/runtime .env should not expose a remote-only mode setting')
    for key in ('PINGGY_SSH_PORT','PINGGY_REMOTE_PORT'):
        try: port=int(node_values.get(key,'0'),10)
        except ValueError: raise SystemExit('[FAIL] Runtime '+key+' must be numeric')
        if not 0<=port<=65535 or (key=='PINGGY_SSH_PORT' and port==0):
            raise SystemExit('[FAIL] Runtime '+key+' is outside the supported port range')
    try: ratio=float(node_values.get('HOST_VCPU_OVERCOMMIT_RATIO','1.5'))
    except ValueError: raise SystemExit('[FAIL] Runtime HOST_VCPU_OVERCOMMIT_RATIO must be numeric')
    if not 0.75<=ratio<=2.0: raise SystemExit('[FAIL] Runtime HOST_VCPU_OVERCOMMIT_RATIO is outside 0.75-2.0')
if 'for requested_port in "$REMOTE_PORT" 0' not in bot or '-R "$forward"' not in bot:
    raise SystemExit('[FAIL] Pinggy remote port 890 request does not fall back to an auto-assigned public port')
if 'HOST_VCPU_OVERCOMMIT_RATIO' not in controller.decode('utf-8') or 'MAX_DEPLOY_RAM_SHARE' not in controller.decode('utf-8'):
    raise SystemExit('[FAIL] Controller-level RAM/vCPU admission guard is missing')
print('[PASS] Fixed combined Local + Remote routing, Singapore remote preference, RAM/vCPU safety budgets and Pinggy 890/fallback behavior')
if "BOT_DEVELOPER = os.getenv('BOT_DEVELOPER', '𝐌ɾ. 𝐙ᥱ𝚝ɾ𝐢𝐱')" not in bot or "VPS_HOSTNAME = (os.getenv('PUBLIC_VPS_HOSTNAME')" not in bot or "VPS_HOSTNAME = 'rgnodes-vps'" not in bot:
    raise SystemExit('[FAIL] Configurable developer identity or validated guest hostname fallback is missing')
if 'hostnamectl set-hostname' in setup_text or 'local host hostname is never modified' not in setup_text:
    raise SystemExit('[FAIL] Installer could modify the control host hostname or lacks the fixed-hostname policy')
rename_text=(bot_path.parent/'rename-bot.sh').read_text(encoding='utf-8')
if not all(mark in rename_text for mark in ('BOT_NAME=', 'os.replace(tmp,path)', 'chmod 600', 'BACKUP=', 'systemctl restart')):
    raise SystemExit('[FAIL] One-command bot label changer lacks atomic writes, backup, permissions, or service restart behavior')
if 'def detect_local_node_location' not in bot or 'ipapi.co/json/' not in bot:
    raise SystemExit('[FAIL] Local Node location auto-detection is missing')
if 'REMOTE_NODE_ONLY' in node_values:
    raise SystemExit('[FAIL] .env exposes a remote-only mode toggle')
print('[PASS] Immutable developer name, fixed hostname policy, one-command bot label update, and auto location detection')

preferred_fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_preferred_deployment_node_id'),None)
if preferred_fn is None: raise SystemExit('[FAIL] Preferred node resolver missing')
node_samples=[
 {'id':1,'name':'NODE - 1','location':'Asia/Singapore','is_local':False},
 {'id':7,'name':'Local Node','location':'Local','is_local':True},
]
route_ns={'get_nodes':lambda:node_samples,'DEFAULT_NODE_ID':0,'RuntimeError':RuntimeError,'_local_kvm_ready':lambda:True}
exec(compile(ast.Module(body=[preferred_fn],type_ignores=[]),'bot.py#preferred-node-test','exec'),route_ns)
if route_ns['_preferred_deployment_node_id']()!=7:
 raise SystemExit('[FAIL] Combined mode did not prefer the actual local node ID when it was not 1')
route_ns['DEFAULT_NODE_ID']=1
if route_ns['_preferred_deployment_node_id']()!=1:
 raise SystemExit('[FAIL] DEFAULT_NODE_ID cannot pin the remote node in combined mode')
route_ns['DEFAULT_NODE_ID']=0; route_ns['_local_kvm_ready']=lambda:False
if route_ns['_preferred_deployment_node_id']()!=1:
 raise SystemExit('[FAIL] Combined mode did not fall back to remote when local KVM is unavailable')
print('[PASS] Executed node-routing regression: non-1 local ID, explicit remote pin, and local-unready remote fallback')
local_ready_fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_local_kvm_ready'),None)
if local_ready_fn is None: raise SystemExit('[FAIL] Local KVM readiness helper missing')
from types import SimpleNamespace as _SNS
class _FakePath:
 def __init__(self,_path): pass
 def exists(self): return readiness['device']
class _FakeSubprocess:
 DEVNULL=-3
 TimeoutExpired=TimeoutError
 @staticmethod
 def run(*args,**kwargs):
  readiness['calls']+=1
  if readiness.get('timeout'): raise TimeoutError()
  return _SNS(returncode=readiness['returncode'])
readiness={'device':False,'calls':0,'returncode':0,'timeout':False}
local_ns={'Path':_FakePath,'shutil':type('_Shutil',(),{'which':staticmethod(lambda name:'/usr/bin/virsh')})(), 'subprocess':_FakeSubprocess}
exec(compile(ast.Module(body=[local_ready_fn],type_ignores=[]),'bot.py#local-ready-test','exec'),local_ns)
if local_ns['_local_kvm_ready']() or readiness['calls']!=0: raise SystemExit('[FAIL] Local KVM readiness should fail fast when /dev/kvm is absent')
readiness.update(device=True,calls=0,returncode=0,timeout=False)
if not local_ns['_local_kvm_ready']() or readiness['calls']!=1: raise SystemExit('[FAIL] Ready local KVM probe failed')
readiness.update(device=True,calls=0,returncode=1,timeout=False)
if local_ns['_local_kvm_ready'](): raise SystemExit('[FAIL] Local KVM probe accepted a failing libvirt result')
readiness.update(device=True,calls=0,returncode=0,timeout=True)
if local_ns['_local_kvm_ready'](): raise SystemExit('[FAIL] Local KVM probe accepted a timed-out libvirt service')
if 'if local_node is None:' not in bot or 'INSERT INTO nodes' not in bot or 'local_location = detect_local_node_location()' not in bot:
 raise SystemExit('[FAIL] Local Node is no longer created automatically in combined mode')
if 'Local Node Already Registered' not in bot or 'if is_local:' not in bot:
 raise SystemExit('[FAIL] Node creation still permits confusing duplicate local node entries')
print('[PASS] Local KVM readiness tests: missing device, healthy libvirt, failed libvirt, timeout, auto node creation/location, and duplicate-local prevention')
# Execute the actual database migration/registration helpers against an older SQLite schema
# which lacks is_local and already has a remote row named Local Node.
node_schema_fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='ensure_node_schema_columns'),None)
local_record_fn=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='ensure_local_node_record'),None)
if node_schema_fn is None or local_record_fn is None:
    raise SystemExit('[FAIL] Early legacy node schema/local registration helpers are missing')
db=sqlite3.connect(':memory:')
cur=db.cursor(); cur.execute('CREATE TABLE nodes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL)')
cur.execute("INSERT INTO nodes (name) VALUES ('Local Node')")
node_db_ns={'json':json,'detect_local_node_location':lambda:'Dhaka, Bangladesh','LOCAL_NODE_SLOTS':100}
exec(compile(ast.Module(body=[node_schema_fn,local_record_fn],type_ignores=[]),'bot.py#node-migration-test','exec'),node_db_ns)
node_db_ns['ensure_node_schema_columns'](cur)
cols={row[1] for row in cur.execute('PRAGMA table_info(nodes)').fetchall()}
if 'is_local' not in cols or 'last_updated' not in cols:
    raise SystemExit('[FAIL] Old node schema was not migrated before Local Node query')
node_db_ns['ensure_local_node_record'](cur)
node_db_ns['ensure_local_node_record'](cur)
rows=cur.execute('SELECT name,location,is_local FROM nodes ORDER BY id').fetchall()
if len(rows)!=2 or sum(int(row[2] or 0)==1 for row in rows)!=1 or rows[1][0] == 'Local Node' or rows[1][1] != 'Dhaka, Bangladesh':
    raise SystemExit('[FAIL] Local Node creation is not idempotent/collision-safe or location was not saved')
db.close()
print('[PASS] Executed legacy SQLite migration and duplicate-name test: Local Node registers once before node queries')
if 'remote_healthy_nodes' not in bot or 'Local KVM is not ready, but remote node(s) passed authenticated KVM health' not in bot:
 raise SystemExit('[FAIL] Combined-mode self-check incorrectly treats local-only KVM failure as fatal when a healthy remote node exists')
if 'REMOTE_NODE_ONLY' in bot or 'remote-only' in bot.lower():
    raise SystemExit('[FAIL] Remote-only mode must not exist in the bot runtime')
if "json={'command': f'{shlex.quote(controller_path)} compat health'}" not in bot or 'Combined-mode remote self-check skipped node ID' not in bot:
    raise SystemExit('[FAIL] Combined self-check does not verify authenticated remote KVM health')
if 'CLI-style secrets' not in bot or '--?(?:password|passwd|token|api[-_]?key|secret|authorization)' not in bot:
    raise SystemExit('[FAIL] Diagnostic redaction omits CLI-style credential arguments')
print('[PASS] No remote-only runtime mode; combined node checks and CLI-secret log redaction')
print('[PASS] SSH/Pinggy/password reports are private; exec output is DM-only; dashboard hides tunnel endpoints; Discord errors are redacted; uptime is monotonic; branding normalized')
# Verify requested resource ceilings, five-minute housekeeping, idempotent emoji creation,
# and failure recovery so these protections cannot silently regress in a future release.
env_text=(bot_path.parent/'.env').read_text(encoding='utf-8')
env_values={}
for row in env_text.splitlines():
    row=row.strip()
    if row and not row.startswith('#') and '=' in row:
        key,value=row.split('=',1); env_values[key.strip()]=value.strip().strip('"\'')
release_defaults={'INITIAL_VPS_RAM_GB':'8','DEFAULT_VPS_RAM_GB':'8','INITIAL_VPS_CPU':'2','DEFAULT_VPS_CPU':'2','INITIAL_VPS_DISK_GB':'25','DEFAULT_VPS_STORAGE_GB':'25','MAX_VPS_RAM_GB':'22','MAX_VPS_CPU':'10','MAX_VPS_DISK_GB':'100','RESOURCE_AUTOSCALE_ENABLED':'false','RESOURCE_AUTOSCALE_INTERVAL':'300','HOST_DOCKER_ENABLED':'false','HOST_FASTFETCH_ENABLED':'false','DOCKER_VPS_ENABLED':'true'}
if os.getenv('RGNODES_ENFORCE_RELEASE_DEFAULTS','').strip().lower() in {'1','true','yes'}:
    release_defaults.update({'BOT_CPU_QUOTA_PERCENT':'100','BOT_MEMORY_MAX_MB':'1024','BOT_TASKS_MAX':'512'})
    if any(env_values.get(k)!=v for k,v in release_defaults.items()):
        raise SystemExit('[FAIL] Release template does not match default 8/2/25, admin ceiling 22/10/100, low-load autoscale policy, or systemd limits')
    for secret_key in ('DISCORD_TOKEN','MAIN_ADMIN_ID','WEB_TERMINAL_TOKEN'):
        if env_values.get(secret_key,'').strip():
            raise SystemExit('[FAIL] Release .env must not ship a value for '+secret_key)
else:
    # Installed .env is intentionally preserved and may contain operator-defined plans. Validate
    # its numeric policy without treating a valid customization as a broken source release.
    ranges={'MIN_VPS_RAM_GB':(1,22),'INITIAL_VPS_RAM_GB':(1,22),'DEFAULT_VPS_RAM_GB':(1,22),'MAX_VPS_RAM_GB':(1,22),
            'INITIAL_VPS_CPU':(1,10),'DEFAULT_VPS_CPU':(1,10),'MAX_VPS_CPU':(1,10),
            'MIN_VPS_DISK_GB':(5,100),'INITIAL_VPS_DISK_GB':(5,100),'DEFAULT_VPS_STORAGE_GB':(5,100),'MAX_VPS_DISK_GB':(5,100),
            'RESOURCE_AUTOSCALE_INTERVAL':(300,86400)}
    for key,(low,high) in ranges.items():
        if key in env_values:
            try: value=int(env_values[key],10)
            except ValueError: raise SystemExit('[FAIL] Runtime configuration has a nonnumeric '+key)
            if not low<=value<=high: raise SystemExit('[FAIL] Runtime configuration '+key+' is outside supported range '+str(low)+'-'+str(high))
if not all(x in bot for x in ('async def resource_housekeeping_task()', 'await asyncio.sleep(300)', '_cleanup_orphaned_rgnodes_temp_files', '_opportunistic_sqlite_maintenance()', 'gc.collect(0)', 'await guild.fetch_emojis()', '.casefold()', 'def _build_emoji_provision_plan(', 'def _emoji_candidate_names(', 'CUSTOM_EMOJI_ALIASES', 'planned_names', 'no duplicate retry', 'guild.create_custom_emoji(')):
    raise SystemExit('[FAIL] Five-minute low-load housekeeping or alias-aware, duplicate-safe emoji provisioning is missing')
# Execute the production emoji planner against an existing mixed-case emoji inventory.
planner_node=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_build_emoji_provision_plan'),None)
candidate_node=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_emoji_candidate_names'),None)
markup_node=next((n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_emoji_markup_name'),None)
auto_node=next((n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='auto_provision_server_emojis'),None)
if not all((planner_node,candidate_node,markup_node,auto_node)):
    raise SystemExit('[FAIL] Emoji planner helpers are missing')
emoji_ns={'re':re,'Optional':__import__('typing').Optional,'CUSTOM_EMOJI_ALIASES':{'cpu':('cpu','cpu_chip'),'ram':('ram','ram_chip'),'disk':('ssd','disk'),'online':('online','statusonline'),'error':('offline','statusoffline','wong')}}
emoji_nodes=[markup_node,candidate_node,planner_node]
exec(compile(ast.Module(body=emoji_nodes,type_ignores=[]),'<emoji-planner-tests>','exec'),emoji_ns)
emoji_plan,emoji_resolved,emoji_missing=emoji_ns['_build_emoji_provision_plan'](
    {'cpu':'Cpu','ram':'RAM','disk':'SSD','online':'StatusOnline','error':'StatusOffline','new_a':'new_a','new_b':'new_b','same':'new_a','direct':'<:direct:123456789012345678>'},
    {'cPu','ram','SSD','statusonline','WONG'}, 5)
if emoji_plan != [('new_a','new_a'),('new_b','new_b')] or emoji_missing != 2:
    raise SystemExit('[FAIL] Emoji sync plans uploads for existing aliases or duplicate configured names')
if emoji_resolved.get('cpu','').casefold()!='cpu' or emoji_resolved.get('ram')!='RAM' or emoji_resolved.get('disk')!='SSD' or emoji_resolved.get('online')!='StatusOnline' or emoji_resolved.get('error')!='wong' or emoji_resolved.get('direct')!='<:direct:123456789012345678>':
    raise SystemExit('[FAIL] Emoji sync does not resolve existing emoji aliases or explicit emoji IDs')
print('[PASS] Emoji planner reuses existing mixed-case names/aliases and plans only unique missing uploads')
# Simulate the actual async uploader with a fake Discord guild. It must reuse existing
# mixed-case/alias names and issue create_custom_emoji only for unique missing names.
import asyncio as _real_asyncio
from types import SimpleNamespace as _SimpleNamespace
class _FakeHTTPException(Exception): pass
class _FakeForbidden(_FakeHTTPException): pass
class _FakeEmoji:
    _next_id=8000
    def __init__(self,name):
        self.name=name; _FakeEmoji._next_id+=1; self.id=_FakeEmoji._next_id
    def __str__(self): return f'<:{self.name}:{self.id}>'
class _FakeMember:
    guild_permissions=_SimpleNamespace(manage_emojis_and_stickers=True,manage_emojis=True)
class _FakeGuild:
    def __init__(self):
        self.id=987654; self.name='Static emoji integration test'; self.emoji_limit=30; self.me=_FakeMember()
        self.emojis=[_FakeEmoji('cPu'),_FakeEmoji('RAM'),_FakeEmoji('SSD'),_FakeEmoji('StatusOnline'),_FakeEmoji('wong')]
        self.created=[]
    async def fetch_emojis(self): return list(self.emojis)
    async def create_custom_emoji(self,name,image,reason):
        if any(item.name.casefold()==name.casefold() for item in self.emojis):
            raise _FakeHTTPException('duplicate upload attempted')
        item=_FakeEmoji(name); self.emojis.append(item); self.created.append(name); return item
async def _no_emoji_sleep(_seconds): return None
emoji_runtime_ns={
    're':re,'Optional':__import__('typing').Optional,'Dict':__import__('typing').Dict,'Any':__import__('typing').Any,
    'discord':_SimpleNamespace(Guild=object,HTTPException=_FakeHTTPException,Forbidden=_FakeForbidden),
    'asyncio':_SimpleNamespace(Lock=_real_asyncio.Lock,sleep=_no_emoji_sleep,CancelledError=_real_asyncio.CancelledError,TimeoutError=_real_asyncio.TimeoutError),
    'CUSTOM_EMOJI_ALIASES':{'cpu':('cpu','cpu_chip'),'ram':('ram','ram_chip'),'disk':('ssd','disk'),'online':('online','statusonline'),'error':('offline','statusoffline','wong')},
    'CUSTOM_EMOJI_NAMES':{'cpu':'Cpu','ram':'RAM','disk':'SSD','online':'StatusOnline','error':'StatusOffline','new_a':'new_a','new_b':'new_b','new_a_alias':'new_a'},
    'AUTO_CREATE_SERVER_EMOJIS':True,'EMOJI_PROVISION_LOCK':_real_asyncio.Lock(),
    '_EMOJI_RESOLUTION_CACHE':{},'_EMOJI_PROVISION_SUMMARY':{},
    'bot':_SimpleNamespace(user=_SimpleNamespace(id=123456),emojis=[]),'BOT_NAME':'Test Bot',
    'logger':_SimpleNamespace(info=lambda *a,**k:None,warning=lambda *a,**k:None,exception=lambda *a,**k:None),
    '_builtin_emoji_gif':lambda _key:None,'_builtin_emoji_png':lambda _key:b'PNG',
}
exec(compile(ast.Module(body=[markup_node,candidate_node,planner_node,auto_node],type_ignores=[]),'<emoji-uploader-smoke>','exec'),emoji_runtime_ns)
_fake_guild=_FakeGuild()
_emoji_summary=_real_asyncio.run(emoji_runtime_ns['auto_provision_server_emojis'](_fake_guild))
if _fake_guild.created != ['new_a','new_b'] or _emoji_summary.get('created') != 2 or _emoji_summary.get('pending') != 0:
    raise SystemExit('[FAIL] Actual emoji uploader did not limit uploads to unique missing emoji')
if len({item.name.casefold() for item in _fake_guild.emojis}) != len(_fake_guild.emojis):
    raise SystemExit('[FAIL] Actual emoji uploader created duplicate emoji names')
print('[PASS] Actual async emoji uploader reuses existing emoji and creates only missing unique names')
if any(x in bot for x in ('/proc/sys/vm/drop_caches', 'echo 3 > /proc/sys/vm/drop_caches')):
    raise SystemExit('[FAIL] Housekeeping must not flush kernel page cache and degrade disk/VM performance')
if not all(x in bot for x in ('VPS resource addition failed for', 'Failed to restore VPS', 'Post-failure access repair skipped', 'found_vps[\'ram\'] = f"{new_ram_gb}GB"', 'found_vps[\'storage\'] = f"{new_disk_gb}GB"', 'VPS resize failed for')):
    raise SystemExit('[FAIL] Resource-update partial state persistence and VPS restart recovery is missing')
print('[PASS] 8/2/25 standard plan, 22/10/100 admin ceilings, guarded host capacity, five-minute safe cleanup, idempotent emojis, and resource-update recovery')
# These checks target two subtle integration regressions: inconsistent defaults when .env
# is edited outside the wizard, and repeated terminal bind attempts during Discord reconnects.
if not all(x in bot for x in ("DEFAULT_VPS_CPU = max(1, min(MAX_VPS_CPU, env_int('DEFAULT_VPS_CPU', '2')))", "DEFAULT_VPS_STORAGE_GB = max(VPS_MIN_DISK_GB, min(VPS_MAX_DISK_GB, env_int('DEFAULT_VPS_STORAGE_GB', '25')))")):
    raise SystemExit('[FAIL] Runtime VPS defaults must be clamped by their configured hard ceilings')
if not all(x in bot for x in ('_WEB_TERMINAL_START_TASK = None', 'global _WEB_TERMINAL_START_TASK', '_WEB_TERMINAL_START_TASK.done()', 'start_web_terminal_server(), name=\"rgnodes_openssh_web_terminal\"')):
    raise SystemExit('[FAIL] Browser terminal startup is not protected against duplicate on_ready/reconnect races')
for required_key in ('DEFAULT_STORAGE_POOL','VPS_BACKUP_DIR','YOUR_SERVER_IP','DEPLOY_NODE_SERIALIZE','GUEST_ACCESS_RETRY_INTERVAL','MAX_BACKGROUND_REPAIR_CONCURRENCY','TUNNEL_START_TIMEOUT','LOG_CHANNEL_SNAPSHOT_LINES'):
    if required_key not in env_values:
        raise SystemExit('[FAIL] Release .env is missing documented runtime setting '+required_key)
print('[PASS] Canonical resource ceilings, reconnect-safe terminal startup, and complete runtime .env knobs')
# Execute the actual top-level resource-policy assignments with adversarial test settings.
# This guards against defaults exceeding a lower operator-configured ceiling.
policy_names={'MAX_VPS_RAM_GB','MIN_VPS_RAM_GB','DEFAULT_VPS_RAM_GB','MAX_VPS_CPU','DEFAULT_VPS_CPU','VPS_MIN_DISK_GB','VPS_MAX_DISK_GB','MAX_VPS_DISK_GB','DEFAULT_VPS_STORAGE_GB'}
policy_nodes=[]
for node in tree.body:
    if isinstance(node,ast.Assign) and node.lineno < 220 and any(isinstance(t,ast.Name) and t.id in policy_names for t in node.targets):
        policy_nodes.append(node)
def test_env_int_factory(values):
    def _env_int(name, default=0):
        raw=values.get(name, str(default))
        try: return int(str(raw).strip())
        except (ValueError,TypeError): return int(default)
    return _env_int
probe={'MAX_VPS_RAM_GB':'4','DEFAULT_VPS_RAM_GB':'8','MIN_VPS_RAM_GB':'1',
       'MAX_VPS_CPU':'1','DEFAULT_VPS_CPU':'10','MIN_VPS_DISK_GB':'10',
       'MAX_VPS_DISK_GB':'12','DEFAULT_VPS_STORAGE_GB':'90'}
policy_ns={}
exec(compile(ast.Module(body=policy_nodes,type_ignores=[]),'<resource-policy-regression>','exec'), {'env_int':test_env_int_factory(probe)}, policy_ns)
if policy_ns.get('DEFAULT_VPS_RAM_GB')!=4 or policy_ns.get('DEFAULT_VPS_CPU')!=1 or policy_ns.get('DEFAULT_VPS_STORAGE_GB')!=12:
    raise SystemExit('[FAIL] Direct .env edits can make displayed resource defaults exceed hard ceilings')
print('[PASS] Executed resource-policy edge case: lower custom ceilings clamp RAM/CPU/disk defaults correctly')
(tmp/'vpsctl.py').write_bytes(controller)
(tmp/'node-agent.py').write_bytes(agent)
PYSTATIC
then pass 'Python, embedded payload, command, and progress static checks'; else fail 'Python/embedded payload static checks'; fi

# The controller regression suite stays embedded so the bundle is self-contained.
cat > "$TMP_DIR/tests/test_vpsctl.py" <<'PYTEST'
"""Host-independent regression tests for the embedded KVM controller/node agent."""
from __future__ import annotations
import os, importlib.util, shutil, sys, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
ROOT_TMP=tempfile.TemporaryDirectory(prefix='rgnodes-vpsctl-tests-')
os.environ['RGNODES_VPS_ROOT']=str(Path(ROOT_TMP.name)/'state')
os.environ['KVM_NETWORK_MODE']='direct'; os.environ['PUBLIC_BRIDGE_NAME']=''; os.environ['PUBLIC_PARENT_INTERFACE']=''
os.environ['PUBLIC_IPV4_POOL_CIDR']=''; os.environ['PUBLIC_IPV4_GATEWAY']=''; os.environ['REAL_PUBLIC_IPV4_REQUIRED']='true'
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import vpsctl
spec=importlib.util.spec_from_file_location('rgnodes_node_agent',Path(__file__).resolve().parents[1]/'node-agent.py')
assert spec and spec.loader
node_agent=importlib.util.module_from_spec(spec); spec.loader.exec_module(node_agent)
class VpsCtlTests(unittest.TestCase):
 def setUp(self):
  for path in (vpsctl.IMAGE_DIR,vpsctl.DISK_DIR,vpsctl.SEED_DIR,vpsctl.SECRET_DIR,vpsctl.META_DIR):
   shutil.rmtree(path,ignore_errors=True); path.mkdir(parents=True,exist_ok=True)
 def test_public_ipv4_validator_accepts_global_and_rejects_special_ranges(self):
  self.assertTrue(vpsctl.is_real_public_ipv4('1.1.1.1')); self.assertTrue(vpsctl.is_real_public_ipv4('8.8.8.8'))
  self.assertFalse(node_agent.is_global_unicast('224.0.0.1',4)); self.assertFalse(node_agent.is_global_unicast('ff02::1',6))
  self.assertTrue(node_agent.is_global_unicast('2001:4860:4860::8888',6))
  for a in ('10.1.2.3','192.168.1.2','127.0.0.1','198.51.100.1','203.0.113.1','224.0.0.1','bad-ip',''):
   with self.subTest(address=a): self.assertFalse(vpsctl.is_real_public_ipv4(a))
 def test_public_pool_rejects_private_and_documentation_ranges(self):
  for cidr,gateway in (('192.168.20.0/24','192.168.20.1'),('203.0.113.0/24','203.0.113.1'),('100.64.0.0/24','100.64.0.1')):
   with self.subTest(cidr=cidr),patch.object(vpsctl,'PUBLIC_POOL',cidr),patch.object(vpsctl,'PUBLIC_GATEWAY',gateway),patch.object(vpsctl,'REAL_PUBLIC_REQUIRED',True):
    with self.assertRaisesRegex(RuntimeError,'globally routable'): vpsctl.public_pool_ready()
 def test_public_pool_validation_does_not_materialize_all_hosts(self):
  with patch.object(vpsctl,'PUBLIC_POOL','11.0.0.0/8'),patch.object(vpsctl,'PUBLIC_GATEWAY','11.0.0.1'),patch.object(vpsctl,'REAL_PUBLIC_REQUIRED',True): self.assertTrue(vpsctl.public_pool_ready())
 def test_allocator_skips_gateway_and_previously_reserved_addresses(self):
  with patch.object(vpsctl,'PUBLIC_POOL','8.8.8.0/29'),patch.object(vpsctl,'PUBLIC_GATEWAY','8.8.8.1'):
   (vpsctl.META_DIR/'existing.json').write_text('{"name":"existing","public_ipv4":"8.8.8.2"}',encoding='utf-8')
   self.assertEqual(vpsctl.allocate_public_ipv4('new-vm'),'8.8.8.3')
 def test_compat_health_uses_same_kvm_readiness_gate_as_create(self):
  with patch.object(vpsctl,'ensure_kvm_ready') as ready, patch.object(vpsctl.Path,'exists',return_value=True), patch.object(vpsctl.shutil,'which',side_effect=lambda name:f'/usr/bin/{name}'), patch.object(vpsctl,'NETWORK_MODE','direct'), patch.object(vpsctl,'PUBLIC_POOL','8.8.8.0/29'):
   report=vpsctl.compat('health')
   ready.assert_called_once_with()
   self.assertEqual(report['status'],'ok')
   self.assertEqual(report['backend'],'KVM/QEMU/libvirt')
   self.assertTrue(report['kvm_device']); self.assertTrue(report['public_ipv4_pool_configured'])
  with patch.object(vpsctl,'ensure_kvm_ready',side_effect=RuntimeError('simulated /dev/kvm or public network failure')):
   with self.assertRaisesRegex(RuntimeError,'simulated /dev/kvm'): vpsctl.compat('health')
 def test_image_download_retries_tls_handshake_timeouts(self):
  from urllib.error import URLError
  attempts={'count':0}
  class FakeResponse:
   def __init__(self): self.remaining=2*1024*1024+1
   def __enter__(self): return self
   def __exit__(self,*_args): return False
   def read(self,size):
    if self.remaining<=0: return b''
    count=min(size,self.remaining); self.remaining-=count; return b'X'*count
  def fake_urlopen(_request,timeout):
   self.assertEqual(timeout,180)
   attempts['count']+=1
   if attempts['count']<3: raise URLError('simulated TLS handshake timeout')
   return FakeResponse()
  # The test is specifically about transient network retry behavior. Mock the
  # qemu-img validator so this host-independent test does not require qemu-img.
  with patch.object(vpsctl,'urlopen',side_effect=fake_urlopen),patch.object(vpsctl.time,'sleep') as sleeper,patch.object(vpsctl,'_validate_cloud_image',return_value='qcow2') as validate:
   result=vpsctl.download_image('ubuntu:24.04')
   validate.assert_called_once_with(result.with_suffix('.download'))
  self.assertEqual(attempts['count'],3)
  self.assertGreater(result.stat().st_size,2*1024*1024)
  self.assertFalse(result.with_suffix('.download').exists())
  self.assertEqual(sleeper.call_count,2)
 def test_seed_iso_is_rebuilt_after_retry(self):
  marker={'value':b'A'}
  def fake_run(argv,**_kwargs):
   if argv[0]=='openssl': return SimpleNamespace(stdout='fake-password-hash\n',returncode=0,stderr='')
   if argv[0]=='cloud-localds': Path(argv[-3]).write_bytes(marker['value']*2048); return SimpleNamespace(stdout='',returncode=0,stderr='')
   raise AssertionError(f'Unexpected command in unit test: {argv[0]}')
  def which(command): return '/usr/bin/cloud-localds' if command=='cloud-localds' else None
  with patch.object(vpsctl,'run',side_effect=fake_run),patch.object(vpsctl.shutil,'which',side_effect=which):
   iso=vpsctl.write_seed('retry-vm','password-one','retry-vm','52:54:00:00:00:01'); self.assertEqual(iso.read_bytes(),b'A'*2048)
   marker['value']=b'B'; second=vpsctl.write_seed('retry-vm','password-two','retry-vm','52:54:00:00:00:02')
   self.assertEqual(second,iso); self.assertEqual(iso.read_bytes(),b'B'*2048); self.assertFalse(list(iso.parent.glob('.seed-*.iso')))
 def test_nat_network_xml_and_public_pool_readiness(self):
  with patch.object(vpsctl,'NETWORK_MODE','nat'), patch.object(vpsctl,'KVM_NAT_CIDR','10.231.0.0/24'), patch.object(vpsctl,'KVM_NAT_GATEWAY','10.231.0.1'), patch.object(vpsctl,'KVM_NAT_BRIDGE','virbr-rgnodes'), patch.object(vpsctl,'NETWORK','rgnodes-nat'):
   self.assertTrue(vpsctl.public_pool_ready())
   xml=vpsctl.network_xml()
   self.assertIn("forward mode='nat'",xml); self.assertIn("bridge name='virbr-rgnodes'",xml)
   self.assertIn("address='10.231.0.1'",xml); self.assertIn("start='10.231.0.2'",xml)
 def test_nat_restart_with_no_forwards_does_not_wait_for_guest(self):
  meta={'name':'empty-vm','network_mode':'nat','nat_forwards':[]}
  with patch.object(vpsctl,'NETWORK_MODE','nat'), patch.object(vpsctl,'allocation_from_meta',return_value=meta), patch.object(vpsctl,'wait_for_nat_guest_ipv4',side_effect=AssertionError('must not wait')):
   result=vpsctl.reconcile_vm_nat_forwards('empty-vm',timeout=45)
  self.assertEqual(result['status'],'no-forwards'); self.assertEqual(result['updated'],0)
 def test_nat_port_mapping_rebinds_after_dhcp_change(self):
  meta={'name':'nat-vm','network_mode':'nat','nat_forwards':[{'host_port':22022,'guest_port':22,'proto':'tcp','guest_ip':'10.231.0.8'}]}
  calls=[]
  with patch.object(vpsctl,'NETWORK_MODE','nat'), patch.object(vpsctl,'allocation_from_meta',return_value=dict(meta)), patch.object(vpsctl,'_atomic_write_meta') as write_meta, patch.object(vpsctl,'_iptables_rule',side_effect=lambda *args:calls.append(args)), patch.object(vpsctl,'update_guest_managed_port',return_value={'status':'ok'}):
   result=vpsctl.nft_apply('add',22022,'tcp','10.231.0.9',22,'nat-vm')
  self.assertEqual(result['guest_ip'],'10.231.0.9')
  self.assertIn(('remove','nat','PREROUTING',vpsctl._nat_iptables_rules(22022,'tcp','10.231.0.8',22,'nat-vm')[0]),calls)
  self.assertIn(('add','nat','PREROUTING',vpsctl._nat_iptables_rules(22022,'tcp','10.231.0.9',22,'nat-vm')[0]),calls)
  write_meta.assert_called_once()
 def test_host_public_ipv4_uses_routing_source_when_global(self):
  fake=SimpleNamespace(returncode=0,stdout='1.1.1.1 via 192.0.2.1 dev ens3 src 8.8.8.8 uid 0\n',stderr='')
  with patch.object(vpsctl,'PUBLIC_IPV4',''), patch.object(vpsctl,'AUTO_DETECT_PUBLIC_IP',True), patch.object(vpsctl.shutil,'which',return_value='/usr/sbin/ip'), patch.object(vpsctl,'run',return_value=fake):
   self.assertEqual(vpsctl.detect_host_public_ipv4(),'8.8.8.8')
 def test_remote_agent_accepts_only_allowlisted_kvm_controller_command(self):
  controller=Path(ROOT_TMP.name)/'vpsctl'; controller.write_bytes(Path(vpsctl.__file__).read_bytes()); controller.chmod(0o755)
  with patch.dict(os.environ,{'RGNODES_VPSCTL_PATH':str(controller)}):
   command=f"{controller} compat 'status test-vm'"; self.assertEqual(node_agent.build_vpsctl_argv(command),[str(controller),'compat','status test-vm'])
   with self.assertRaisesRegex(ValueError,'only approved'): node_agent.build_vpsctl_argv("/bin/sh -c 'id'")
   with self.assertRaisesRegex(ValueError,'only approved'): node_agent.build_vpsctl_argv(f"{controller} compat 'status test-vm' ; id")
   controller.chmod(0o775)
   with self.assertRaisesRegex(ValueError,'group/world writable'): node_agent.build_vpsctl_argv(command)
 def test_create_refuses_orphan_disk_without_deleting_user_data(self):
  orphan=vpsctl.DISK_DIR/'orphan-vm.qcow2'; orphan.write_bytes(b'preserve-user-data')
  with patch.object(vpsctl,'ensure_kvm_ready'),patch.object(vpsctl,'ensure_dirs'),patch.object(vpsctl,'ensure_network'),patch.object(vpsctl,'domain_exists',return_value=False),patch.object(vpsctl,'host_capacity_ok') as capacity,patch.object(vpsctl,'download_image') as download:
   with self.assertRaisesRegex(RuntimeError,'orphaned VPS artifact'): vpsctl.create('orphan-vm','ubuntu:24.04',1,1,max(vpsctl.MIN_DISK,10),password='unit-test-password',start=False)
  self.assertEqual(orphan.read_bytes(),b'preserve-user-data'); capacity.assert_not_called(); download.assert_not_called()
 def test_create_rolls_back_disk_seed_and_secret_when_domain_definition_fails(self):
  base=vpsctl.IMAGE_DIR/'fake-base.img'; base.write_bytes(b'base-image')
  def fake_run(argv,**_kwargs):
   if argv[:2]==['qemu-img','info']: return SimpleNamespace(stdout='',returncode=1,stderr='not a qcow image')
   if argv[:2]==['qemu-img','create']: Path(argv[-2]).write_bytes(b'partial-disk'); return SimpleNamespace(stdout='',returncode=0,stderr='')
   if argv[:2] in (['virsh','destroy'],['virsh','undefine']): return SimpleNamespace(stdout='',returncode=0,stderr='')
   raise AssertionError(f'Unexpected command in unit test: {argv[:2]}')
  def fake_seed(name,*_args):
   seed_dir=vpsctl.SEED_DIR/name; seed_dir.mkdir(parents=True,exist_ok=True); iso=seed_dir/'seed.iso'; iso.write_bytes(b'test-seed'); return iso
  with patch.object(vpsctl,'ensure_kvm_ready'),patch.object(vpsctl,'ensure_dirs'),patch.object(vpsctl,'ensure_network'),patch.object(vpsctl,'domain_exists',return_value=False),patch.object(vpsctl,'host_capacity_ok'),patch.object(vpsctl,'download_image',return_value=base),patch.object(vpsctl,'run',side_effect=fake_run),patch.object(vpsctl,'write_seed',side_effect=fake_seed),patch.object(vpsctl,'define_domain',side_effect=RuntimeError('simulated define failure')):
   with self.assertRaisesRegex(RuntimeError,'simulated define failure'): vpsctl.create('rollback-test','ubuntu:24.04',1,1,max(vpsctl.MIN_DISK,10),password='unit-test-password',start=False)
  self.assertFalse((vpsctl.DISK_DIR/'rollback-test.qcow2').exists()); self.assertFalse(vpsctl.secret_path('rollback-test').exists()); self.assertFalse(vpsctl.meta_path('rollback-test').exists()); self.assertFalse((vpsctl.SEED_DIR/'rollback-test').exists())
if __name__=='__main__': unittest.main(verbosity=2)
PYTEST
if [[ "$MODE" != "--host" ]]; then
  export RGNODES_VPS_ROOT="$TMP_DIR/state"
  if PYTHONPATH="$TMP_DIR${PYTHONPATH:+:$PYTHONPATH}" python3 -m unittest discover -s "$TMP_DIR/tests" -v; then pass 'Embedded-controller regression tests'; else fail 'Embedded-controller regression tests'; fi
fi

if [[ "$MODE" != "--static" ]]; then
  [[ -s "$APP_DIR/.env" ]] && pass '.env present' || fail '.env missing'
  LOCAL_KVM='false'
  if [[ -s "$APP_DIR/.env" ]]; then
    LOCAL_KVM="$(python3 - "$APP_DIR/.env" <<'PYROLE'
import sys
from pathlib import Path
for line in Path(sys.argv[1]).read_text(encoding='utf-8',errors='replace').splitlines():
 s=line.strip()
 if s and not s.startswith('#') and '=' in s:
  k,v=s.split('=',1)
  if k.strip()=='LOCAL_KVM_ENABLED':
   print('true' if v.strip().strip('"\'').lower() in {'1','true','yes','on'} else 'false')
   break
else: print('false')
PYROLE
)"
  fi
  for bin in python3 ssh curl; do command -v "$bin" >/dev/null 2>&1 && pass "Control-host command available: $bin" || warn "Control-host command missing: $bin"; done
  if [[ "$LOCAL_KVM" == true ]]; then
    for bin in virsh qemu-img sshpass; do command -v "$bin" >/dev/null 2>&1 && pass "Optional local-KVM command available: $bin" || warn "Optional local-KVM command missing: $bin"; done
    [[ -e /dev/kvm ]] && pass '/dev/kvm exists' || warn '/dev/kvm missing: local KVM is enabled but provider/nested virtualization is unavailable.'
    if command -v virsh >/dev/null 2>&1 && virsh -c qemu:///system list --all >/dev/null 2>&1; then pass 'libvirt qemu:///system responds'; else warn 'libvirt qemu:///system is not ready.'; fi
  else
    pass 'Local KVM checks are optional; combined mode can use a ready local KVM host or registered remote node.'
  fi
  if python3 - "$APP_DIR/.env" <<'PYENV'
import sys
from pathlib import Path
v={}
for line in Path(sys.argv[1]).read_text(encoding='utf-8',errors='replace').splitlines():
 s=line.strip()
 if s and not s.startswith('#') and '=' in s:
  k,x=s.split('=',1); v[k.strip()]=x.strip().strip('"').strip("'")
t=v.get('DISCORD_TOKEN','')
raise SystemExit(0 if len(t)>=50 and not any(c.isspace() for c in t) else 1)
PYENV
  then pass 'DISCORD_TOKEN appears configured (value not displayed)'; else warn 'DISCORD_TOKEN not configured; bot cannot login until .env is completed.'; fi
  info 'Provider-routed IPv4, guest boot, actual SSH reachability and external tunnels require a real configured node and cannot be proven without the authenticated remote self-check.'
fi
printf '\nSummary: pass=%s warn=%s fail=%s\n' "$PASS" "$WARN" "$FAIL"
[[ $FAIL -eq 0 ]]
