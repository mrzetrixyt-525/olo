import discord
from discord.ext import commands
import asyncio
import subprocess
import json
from datetime import datetime, timedelta
import shlex
import logging
import shutil
import os
from typing import Optional, List, Dict, Any
import threading
import time
import sqlite3
import random
import requests
import string
import secrets
import base64
import socket
import ipaddress
import re
import sys
import io
import zlib
import hashlib
import gc
import html as html_lib
from dotenv import load_dotenv
from pathlib import Path
from urllib.parse import urlparse

try:
    from aiohttp import web as aiohttp_web
except Exception:  # The core Discord bot can still load when the optional web terminal dependency is absent.
    aiohttp_web = None

# Resolve configuration relative to this file, not the shell's current working directory.
BASE_DIR = Path(__file__).resolve().parent
BOT_PROCESS_STARTED_AT = datetime.now()
BOT_PROCESS_STARTED_MONOTONIC = time.monotonic()
ENV_FILE = BASE_DIR / '.env'
ENV_TEMPLATE_FILE = ENV_FILE  # .env is the only configuration source in this release.

# Runtime secrets and operator settings live in .env. The installer parses it as data;
# this module never sources it as shell code and never loads a separate env.txt template.
if ENV_FILE.exists():
    try:
        ENV_FILE.chmod(0o600)
    except OSError:
        pass

# Always prefer the bot's own .env file. This prevents stale exported shell/systemd
# variables from overriding a freshly entered token.
load_dotenv(dotenv_path=ENV_FILE, override=True, encoding='utf-8')

def _clean_env_value(value: Optional[str]) -> str:
    if value is None:
        return ''
    text = str(value).replace('\ufeff', '').replace('\u200b', '').strip()
    if text.lower().startswith('bot '):
        text = text[4:].strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in {'"', "'"}:
        text = text[1:-1].strip()
    return text

def env_int(name: str, default: int = 0) -> int:
    raw = os.getenv(name, '')
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        return int(default)

def env_float(name: str, default: float = 0.0) -> float:
    raw = os.getenv(name, '')
    try:
        value = float(str(raw).strip())
        if value != value or value in (float('inf'), float('-inf')):
            raise ValueError('non-finite numeric value')
        return value
    except (TypeError, ValueError, OverflowError):
        return float(default)

def env_bool(name: str, default: bool = False, *aliases: str) -> bool:
    """Read a boolean option; the first explicitly configured name wins."""
    for key in (name, *aliases):
        raw = os.getenv(key)
        if raw is not None and str(raw).strip() != '':
            return str(raw).strip().lower() in {'1', 'true', 'yes', 'y', 'on', 'enabled'}
    return bool(default)

def env_alias_int(primary: str, aliases: tuple[str, ...], default: int) -> int:
    for key in (primary, *aliases):
        raw = os.getenv(key)
        if raw is not None and str(raw).strip() != '':
            try:
                return int(str(raw).strip())
            except (TypeError, ValueError):
                return int(default)
    return int(default)

def _load_discord_token() -> str:
    token = _clean_env_value(os.getenv('DISCORD_TOKEN', ''))
    placeholders = {
        '', 'YOUR_DISCORD_BOT_TOKEN', 'your_discord_bot_token_here',
        'YOUR_BOT_TOKEN', 'changeme', 'change_me'
    }
    if token in placeholders:
        return ''
    if any(ch.isspace() for ch in token):
        raise RuntimeError('DISCORD_TOKEN contains whitespace. Paste only the raw Bot Token.')
    if not token.isascii():
        raise RuntimeError('DISCORD_TOKEN must contain only ASCII characters. Paste the raw Bot Token, without branding text or symbols.')
    if len(token) < 50:
        raise RuntimeError('DISCORD_TOKEN looks too short. Copy the Bot Token from Discord Developer Portal → Bot.')
    return token

try:
    DISCORD_TOKEN = _load_discord_token()
    DISCORD_TOKEN_CONFIG_ERROR = ''
except RuntimeError as exc:
    DISCORD_TOKEN = ''
    DISCORD_TOKEN_CONFIG_ERROR = str(exc)
BOT_NAME = os.getenv('BOT_NAME', 'RGNODES™')
# This release intentionally keeps bot-facing output English-only.
BOT_LANGUAGE = 'en'
PREFIX = os.getenv('PREFIX', '!')
_YOUR_SERVER_IP_RAW = str(os.getenv('YOUR_SERVER_IP', '') or '').strip()
try:
    _server_ip_obj = ipaddress.ip_address(_YOUR_SERVER_IP_RAW) if _YOUR_SERVER_IP_RAW else None
    YOUR_SERVER_IP = str(_server_ip_obj) if isinstance(_server_ip_obj, ipaddress.IPv4Address) and _server_ip_obj.is_global else ''
except ValueError:
    YOUR_SERVER_IP = ''
MAIN_ADMIN_ID = env_int('MAIN_ADMIN_ID', 0)
VPS_USER_ROLE_ID = env_int('VPS_USER_ROLE_ID', 0)
CONFIG_ADMIN_IDS = tuple(sorted({x.strip() for x in os.getenv('ADMIN_USER_IDS', '').split(',') if x.strip().isdigit()}))
_raw_owner_ids = str(os.getenv('OWNER_IDS', '') or '').strip()
CONFIG_OWNER_IDS = tuple(sorted({x for x in re.findall(r'\d{15,25}', _raw_owner_ids)})) if _raw_owner_ids else ((str(MAIN_ADMIN_ID),) if MAIN_ADMIN_ID else ())
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', 'default')
_HOST_MOTD_RAW = str(os.getenv('HOST_MOTD', '') or '').strip()
_HOST_MOTD_IS_COMMAND = _HOST_MOTD_RAW.startswith('bash <(curl -sSL https://raw.githubusercontent.com/mrzetrixyt-525/vm-/main/MOTD-Installer)')
DEFAULT_MOTD_TEXT = str(os.getenv('HOST_MOTD_TEXT', '') or ('Welcome to RGNODES™ Powerfull\nAuthorized access only. VPS resources are monitored for stability and safety.' if _HOST_MOTD_IS_COMMAND or not _HOST_MOTD_RAW else _HOST_MOTD_RAW)).replace('\\n', '\n')[:1200]
HOST_MOTD = DEFAULT_MOTD_TEXT
AUTO_MOTD_INSTALLER = str(os.getenv('AUTO_MOTD_INSTALLER', 'true')).strip().lower() in {'1', 'true', 'yes', 'on'}
MOTD_INSTALL_COMMAND = str(os.getenv('MOTD_INSTALL_COMMAND', '') or (_HOST_MOTD_RAW if _HOST_MOTD_IS_COMMAND else '')).strip()
MOTD_INSTALL_TIMEOUT = max(30, min(600, env_int('MOTD_INSTALL_TIMEOUT', '180')))
LOCAL_NODE_SLOTS = max(1, min(10000, env_int('LOCAL_NODE_SLOTS', '100')))
VPS_BANDWIDTH_GB = 50  # Fixed plan bandwidth quota for every VPS.
LOG_HEALTH_INTERVAL = max(300, env_int('LOG_HEALTH_INTERVAL', '900'))
HOST_STATS_CACHE_TTL = max(3.0, env_float('HOST_STATS_CACHE_TTL', '8'))
GUEST_ACCESS_RETRY_INTERVAL = max(120, env_int('GUEST_ACCESS_RETRY_INTERVAL', '300'))
MAX_BACKGROUND_REPAIR_CONCURRENCY = max(1, min(4, env_int('MAX_BACKGROUND_REPAIR_CONCURRENCY', '2')))
BANDWIDTH_SAMPLE_INTERVAL = max(300, env_int('BANDWIDTH_SAMPLE_INTERVAL', '600'))
BANDWIDTH_QUOTA_BYTES = VPS_BANDWIDTH_GB * 1024**3
# Background persistence / audit tuning: frequent full-database writes can create
# unnecessary disk I/O on a small Ryzen host. Critical operations still save immediately.
AUTOSAVE_INTERVAL = max(30, env_int('AUTOSAVE_INTERVAL', '60'))
AUDIT_NOISY_COMMANDS = {
    'ping', 'help', 'quickhelp', 'commands', 'stats', 'info', 'uptime',
}
LOG_CHANNEL_SNAPSHOT_LINES = max(8, min(30, env_int('LOG_CHANNEL_SNAPSHOT_LINES', '16')))
BOT_VERSION = os.getenv('BOT_VERSION', '9.4.2 VPS Manager Pro')
BOT_DEVELOPER = os.getenv('BOT_DEVELOPER', '𝐌ɾ. 𝐙ᥱ𝚝ɾ𝐢𝐱').strip() or '𝐌ɾ. 𝐙ᥱ𝚝ɾ𝐢𝐱'
BOT_THUMBNAIL_URL = os.getenv('BOT_THUMBNAIL_URL', 'https://cdn.discordapp.com/icons/1559081768215248918/7e76a8a1a7f1389b7b06bd407d25dd27.webp?size=2048')
BOT_ICON_URL = os.getenv('BOT_ICON_URL', 'https://cdn.discordapp.com/icons/1559081768215248918/7e76a8a1a7f1389b7b06bd407d25dd27.webp?size=2048')
EMBED_COLOR = None  # Standard embeds are intentionally colourless; Discord clients choose their own card background.
VPS_HOSTNAME = (os.getenv('PUBLIC_VPS_HOSTNAME') or os.getenv('VPS_HOSTNAME') or 'rgnodes-vps').strip().lower()
if not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', VPS_HOSTNAME):
    VPS_HOSTNAME = 'rgnodes-vps'
# Canonical resource policy: normalize each default against its configured hard ceiling.
# The setup wizard reconciles legacy VPS_MAX_* aliases, but runtime safety must still hold
# when an operator edits .env manually or deploys without running the wizard first.
MAX_VPS_RAM_GB = max(1, min(22, env_int('MAX_VPS_RAM_GB', '22')))
MIN_VPS_RAM_GB = max(1, min(MAX_VPS_RAM_GB, env_int('MIN_VPS_RAM_GB', '1')))
DEFAULT_VPS_RAM_GB = max(MIN_VPS_RAM_GB, min(MAX_VPS_RAM_GB, env_int('DEFAULT_VPS_RAM_GB', '8')))
MAX_VPS_CPU = max(1, min(10, env_int('MAX_VPS_CPU', '10')))
DEFAULT_VPS_CPU = max(1, min(MAX_VPS_CPU, env_int('DEFAULT_VPS_CPU', '2')))
VPS_MIN_DISK_GB = max(5, min(100, env_int('MIN_VPS_DISK_GB', '10')))
VPS_MAX_DISK_GB = max(VPS_MIN_DISK_GB, min(100, env_int('MAX_VPS_DISK_GB', '100')))
MAX_VPS_DISK_GB = VPS_MAX_DISK_GB
DEFAULT_VPS_STORAGE_GB = max(VPS_MIN_DISK_GB, min(VPS_MAX_DISK_GB, env_int('DEFAULT_VPS_STORAGE_GB', '25')))
DEFAULT_PORT_QUOTA = env_int('DEFAULT_PORT_QUOTA', '10')
PORT_HOST_MIN = env_int('PORT_HOST_MIN', '20000')
PORT_HOST_MAX = env_int('PORT_HOST_MAX', '50000')
VPS_BACKUP_DIR_NAME = os.getenv('VPS_BACKUP_DIR', 'vps_backups')
VPS_RENEWAL_DAYS = max(1, env_alias_int('VPS_RENEWAL_DAYS', ('PUBLIC_VPS_RENEWAL_DAYS',), 2))
RENEWAL_WINDOW_DAYS = max(0, env_alias_int('RENEWAL_WINDOW_DAYS', ('PUBLIC_VPS_RENEWAL_WINDOW_DAYS',), 1))
ANTI_MINING_ENABLED = env_bool('ANTI_MINING_ENABLED', True, 'ANTI_MINING')

AUTO_DETECT_PUBLIC_IP = env_bool('AUTO_DETECT_PUBLIC_IP', True)
# Use the supplied address only if it is a real, globally routable IPv4.
PUBLIC_IPV4 = str(os.getenv('PUBLIC_IPV4', '') or '').strip() or YOUR_SERVER_IP
try:
    _public_ipv4_obj = ipaddress.ip_address(PUBLIC_IPV4) if PUBLIC_IPV4 else None
    PUBLIC_IPV4 = str(_public_ipv4_obj) if isinstance(_public_ipv4_obj, ipaddress.IPv4Address) and _public_ipv4_obj.is_global else ''
except ValueError:
    PUBLIC_IPV4 = ''
PUBLIC_IPV6 = os.getenv('PUBLIC_IPV6', '').strip()
IPV4_SSH_ONLY = str(os.getenv('IPV4_SSH', 'true')).strip().lower() in {'1', 'true', 'yes', 'on'}
# Docker is optional during provisioning; enabling it on the host can add avoidable memory/IO pressure.
DOCKER_STRICT_DEPLOY = str(os.getenv('DOCKER_STRICT_DEPLOY', 'false')).strip().lower() in {'1','true','yes','on'}
VPS_SWAP_ENABLED = str(os.getenv('VPS_SWAP_ENABLED', 'false')).strip().lower() in {'1','true','yes','on'}

HOST_PROVIDER_NAME = os.getenv('HOST_PROVIDER_NAME', 'RGNODES™').strip() or 'RGNODES™'
DEFAULT_NODE_ID = max(0, env_int('DEFAULT_NODE_ID', '0'))
HOST_VCPU_OVERCOMMIT_RATIO = max(0.75, min(2.0, env_float('HOST_VCPU_OVERCOMMIT_RATIO', '1.5')))
HOST_RAM_RESERVE_GB = max(2.0, env_float('HOST_RAM_RESERVE_GB', '2'))
HOST_DISK_RESERVE_GB = max(2.0, env_float('HOST_DISK_RESERVE_GB', '10'))
HOST_CPU_MAX_DEPLOY_PCT = max(50.0, min(95.0, env_float('HOST_CPU_MAX_DEPLOY_PCT', '85')))
MIN_HOST_RAM_FREE_PCT_DEPLOY = max(5.0, min(50.0, env_float('MIN_HOST_RAM_FREE_PCT_DEPLOY', '18')))
MAX_DEPLOY_RAM_SHARE = max(0.10, min(0.90, env_float('MAX_DEPLOY_RAM_SHARE', '0.80')))
DEPLOY_EXECUTION_TIMEOUT = max(300, env_int('DEPLOY_EXECUTION_TIMEOUT', '1800'))
WEB_TERMINAL_ENABLED = env_bool('WEB_TERMINAL_ENABLED', True, 'WEBSSH_ENABLED')
WEB_TERMINAL_PORT = max(1, min(65535, env_alias_int('WEB_TERMINAL_PORT', ('WEBSSH_PORT',), 9090)) )
WEB_TERMINAL_PUBLIC_URL = os.getenv('WEB_TERMINAL_PUBLIC_URL', 'https://ssh.rgnodes.bond').strip().rstrip('/') or 'https://ssh.rgnodes.bond'
_WEB_TERMINAL_URL_PARTS = urlparse(WEB_TERMINAL_PUBLIC_URL)
WEB_TERMINAL_HOST = (_WEB_TERMINAL_URL_PARTS.hostname or '').lower()
WEB_TERMINAL_SCHEME = _WEB_TERMINAL_URL_PARTS.scheme.lower()
if WEB_TERMINAL_SCHEME not in {'http', 'https'} or not WEB_TERMINAL_HOST:
    WEB_TERMINAL_PUBLIC_URL = 'https://ssh.rgnodes.bond'
    _WEB_TERMINAL_URL_PARTS = urlparse(WEB_TERMINAL_PUBLIC_URL)
    WEB_TERMINAL_HOST = 'ssh.rgnodes.bond'
    WEB_TERMINAL_SCHEME = 'https'
WEB_TERMINAL_ORIGIN_PORT = _WEB_TERMINAL_URL_PARTS.port or (443 if WEB_TERMINAL_SCHEME == 'https' else 80)
WEB_TERMINAL_TOKEN = _clean_env_value(os.getenv('WEB_TERMINAL_TOKEN', ''))
WEBSSH_HOST = (os.getenv('WEBSSH_HOST', '0.0.0.0').strip() or '0.0.0.0')
WEBSSH_SERVER_IP = (os.getenv('WEBSSH_SERVER_IP', '127.0.0.1').strip() or '127.0.0.1')
WEBSSH_URL_FORMAT = os.getenv('WEBSSH_URL_FORMAT', 'http://{SERVER_IP}:{PORT}').strip() or 'http://{SERVER_IP}:{PORT}'
WEB_TERMINAL_MAX_SESSIONS = max(1, min(2000, env_alias_int('WEB_TERMINAL_MAX_SESSIONS', ('WEBSSH_MAX_SESSIONS',), 2000)))
_WEBSSH_TTL_RAW = (os.getenv('WEB_TERMINAL_SESSION_TTL') or os.getenv('WEBSSH_SESSION_TTL') or 'auto').strip().lower()
WEB_TERMINAL_SESSION_TTL = max(300, min(86400, 1800 if _WEBSSH_TTL_RAW == 'auto' else env_int('WEB_TERMINAL_SESSION_TTL', env_int('WEBSSH_SESSION_TTL', 1800))))
WEB_TERMINAL_SESSIONS_PER_IP = max(1, min(8, env_alias_int('WEB_TERMINAL_SESSIONS_PER_IP', ('WEBSSH_SESSION_MAX_PER_IP',), 8)))
WEB_TERMINAL_CONNECT_TIMEOUT = max(5, min(100, env_alias_int('WEB_TERMINAL_CONNECT_TIMEOUT', ('WEBSSH_CONNECT_TIMEOUT',), 100)))
WEB_TERMINAL_ALLOW_PRIVATE_HOSTS = env_bool('WEB_TERMINAL_ALLOW_PRIVATE_HOSTS', True, 'WEBSSH_ALLOW_PRIVATE_HOSTS')
WEB_TERMINAL_DEFAULT_PIN = env_bool('WEB_TERMINAL_DEFAULT_PIN', False, 'WEBSSH_DEFAULT_PIN')
WEB_TERMINAL_PIN_ATTEMPTS = max(1, min(20, env_alias_int('WEB_TERMINAL_PIN_ATTEMPTS', ('WEBSSH_PIN_ATTEMPTS',), 5)))
STATS_REFRESH_SECONDS = max(3, min(60, env_int('STATS_REFRESH_SECONDS', '5')))
MAX_LIVE_REFRESHES = max(1, min(120, env_int('MAX_LIVE_REFRESHES', '59')))
MANAGE_PANEL_TIMEOUT = max(30, min(900, env_int('MANAGE_PANEL_TIMEOUT', '500')))
CONSOLE_PANEL_TIMEOUT = max(30, min(1200, env_int('CONSOLE_PANEL_TIMEOUT', '900')))
COMMAND_TIMEOUT_SECONDS = max(30, min(900, env_int('COMMAND_TIMEOUT_SECONDS', '240')))
GUEST_BOOTSTRAP_TIMEOUT = max(120, env_int('GUEST_BOOTSTRAP_TIMEOUT', '600'))
AUTO_RESOURCE_ALLOCATION = str(os.getenv('AUTO_RESOURCE_ALLOCATION', 'true')).strip().lower() in {'1','true','yes','on'}
# Docker can be enabled explicitly in .env, but the default is off to protect the main node.
DOCKER_INSTALL_ON_DEPLOY = str(os.getenv('DOCKER_INSTALL_ON_DEPLOY', 'true')).strip().lower() in {'1','true','yes','on'}
DOCKER_VPS_ENABLED = str(os.getenv('DOCKER_VPS_ENABLED', 'true')).strip().lower() in {'1','true','yes','on'}
PINGGY_ENABLED = str(os.getenv('PINGGY_ENABLED', 'true')).strip().lower() in {'1','true','yes','on'}
PINGGY_AUTO_START = str(os.getenv('PINGGY_AUTO_START', 'true')).strip().lower() in {'1','true','yes','on'}
PINGGY_HOST = os.getenv('PINGGY_HOST', 'free.pinggy.io').strip() or 'free.pinggy.io'
PINGGY_SSH_PORT = max(1, min(65535, env_int('PINGGY_SSH_PORT', '443')))
PINGGY_REMOTE_PORT = max(0, min(65535, env_int('PINGGY_REMOTE_PORT', '890')))
AUTO_CREATE_SERVER_EMOJIS = str(os.getenv('AUTO_CREATE_SERVER_EMOJIS', 'true')).strip().lower() in {'1','true','yes','on'}
EMOJI_PROVISION_LOCK = asyncio.Lock()
_EMOJI_RESOLUTION_CACHE: Dict[str, str] = {}
_EMOJI_PROVISION_SUMMARY: Dict[int, Dict[str, Any]] = {}
DEPLOYMENT_GLOBAL_LOCK = asyncio.Lock()
TUNNEL_SETUP_LOCKS: Dict[tuple[str, int], asyncio.Lock] = {}
HOST_STATS_CACHE: Dict[int, tuple[float, Dict[str, Any]]] = {}
HOST_STATS_CACHE_LOCK = asyncio.Lock()
TUNNEL_REPAIR_INTERVAL = max(180, env_int('TUNNEL_REPAIR_INTERVAL', '900'))
ACCESS_REPAIR_INTERVAL = max(180, env_int('ACCESS_REPAIR_INTERVAL', '600'))
TUNNEL_START_TIMEOUT = max(25, env_int('TUNNEL_START_TIMEOUT', '65'))
DEPLOY_NODE_SERIALIZE = str(os.getenv('DEPLOY_NODE_SERIALIZE', 'true')).strip().lower() in {'1','true','yes','on'}
# Dynamic auto-scaling is opt-in: bounded resource limits plus admission control protect the main host by default.
RESOURCE_AUTOSCALE_ENABLED = str(os.getenv('RESOURCE_AUTOSCALE_ENABLED', 'false')).strip().lower() in {'1','true','yes','on'}
RESOURCE_AUTOSCALE_INTERVAL = max(300, env_int('RESOURCE_AUTOSCALE_INTERVAL', '300'))
RESOURCE_SCALE_UP_RAM_THRESHOLD = max(60.0, min(95.0, env_float('RESOURCE_SCALE_UP_RAM_THRESHOLD', '80')))
RESOURCE_SCALE_UP_CPU_THRESHOLD = max(60.0, min(98.0, env_float('RESOURCE_SCALE_UP_CPU_THRESHOLD', '85')))
RESOURCE_SCALE_UP_DISK_THRESHOLD = max(60.0, min(98.0, env_float('RESOURCE_SCALE_UP_DISK_THRESHOLD', '80')))
RESOURCE_SCALE_UP_DISK_STEP_GB = max(1, env_int('RESOURCE_SCALE_UP_DISK_STEP_GB', '10'))
HOST_PROCESSOR_NAME = (os.getenv('PUBLIC_VPS_PROCESSOR_NAME') or os.getenv('HOST_PROCESSOR_NAME') or 'RGNODES™ Reliable').strip() or 'RGNODES™ Reliable'

# Primary virtualization product: VPS via KVM/QEMU/libvirt only.
VPS_ENABLED = str(os.getenv('VPS_ENABLED', 'true')).strip().lower() in {'1', 'true', 'yes', 'on'}
VPSCTL_PATH = os.getenv('VPSCTL_PATH', '').strip()
# Legacy VPS_MAX_* keys are synchronized by setup.sh. At runtime use the canonical
# MAX_VPS_* policy as the single source of truth so UI, admission checks and controllers agree.
VPS_MAX_RAM_GB = MAX_VPS_RAM_GB
VPS_MAX_CPU = MAX_VPS_CPU
INITIAL_VPS_RAM_GB = max(MIN_VPS_RAM_GB, min(VPS_MAX_RAM_GB, env_int('INITIAL_VPS_RAM_GB', '8')))
INITIAL_VPS_CPU = max(1, min(VPS_MAX_CPU, env_int('INITIAL_VPS_CPU', '2')))
INITIAL_VPS_DISK_GB = max(VPS_MIN_DISK_GB, min(VPS_MAX_DISK_GB, env_int('INITIAL_VPS_DISK_GB', '25')))
KVM_NETWORK_MODE = os.getenv('KVM_NETWORK_MODE', 'nat').strip().lower()
PUBLIC_BRIDGE_NAME = os.getenv('PUBLIC_BRIDGE_NAME', '').strip()
PUBLIC_PARENT_INTERFACE = os.getenv('PUBLIC_PARENT_INTERFACE', '').strip()
PUBLIC_IPV4_POOL_CIDR = os.getenv('PUBLIC_IPV4_POOL_CIDR', '').strip()
PUBLIC_IPV4_GATEWAY = os.getenv('PUBLIC_IPV4_GATEWAY', '').strip()
REAL_PUBLIC_IPV4_REQUIRED = str(os.getenv('REAL_PUBLIC_IPV4_REQUIRED', 'true')).strip().lower() in {'1','true','yes','on'}
VPSCTL_CANDIDATES = tuple(dict.fromkeys(x for x in [VPSCTL_PATH, '/usr/local/sbin/vpsctl', '/usr/local/bin/vpsctl'] if x))
KVM_CONTROLLER_MARKERS = ('KVM/QEMU/libvirt only', 'def compat(', 'virsh')
# A compact integrity-protected copy of the bundled KVM controller. This allows bot.py
# to self-repair a stale /usr/local/sbin/vpsctl without touching VPS data.
_EMBEDDED_VPSCTL_ZLIB_B64 = 'eNrtvet64ziSKPjfT8Fy9QylSoqSnM7sKjmZc1yZrmqfrrxMpqtmzjrdalqkbLYlUkVSvrRa33d+nDfYfYJ9tHmSjQsAAiQoyVlZM9+e3eqZNEUCgQAQCAQCcfn6q/6yyPuXSdqP01tn8VBeZ+nTvf39/Q8/vn33+uTjf/yv/9v55f1HZ5KlZZ7NZnHu/Mf//L+cP//ypv+vJ29+7s+Sy9skL50snT34e3tn17HzOikmWR45l1npTMLZrHBKePvXSTZfhOVfnSQt43waTmKnyJykLJx5WC7zGFqYz8M0coolf52EqZPH8zBJ94oyvJzFzt11Av8isHBSLsMZIZYv0zKZx05SOCGUh7eAm4M4YYl5OLlO0th3EDGtD/H9IivigtAmMNkizsMyydLCx97vTfNs7ozH0yXiNh47yXyRQTfDNM1KLrcnX+VXizAvYs+5DIv4+aHnXIfFNYyL5ySLMIryuCg8529FlnpOBk85lCziSR6X8AMKxvf4Z1kmM/ibTW7iEv4uLxd5NqGaxQP8U8bzxRR6D0/QWcYORhObkai9h5/8YZnP4L2fx78u46KU3z/wTw8/Q29TLotjEt+XGhzxBuYivIrzvTJ/GO058J/4PJ2k5Wwvvp/Ei9I5pXcneZ7lXIi+OoHzNkvjvb0P796dwQ/ErJMV/lVcApF1XEFaYxj3MRZxPcft34Y5ElM/v0qzKC56t4vC7Xb3fnr36s/jH05/OgE4BK7vuH41kf4MRszdO31z/OPJ+PXpB895ffrxz/z08eTktXx69eHkjJ/fnJwd4xPAOxcA751plsO/Sep03GQO3S5cz42S4gb/FnEc8V+aM3iax2Xodi/23p6c/du7D38ev4HeADith0CCY/0r9jANS7frF2WeLDpdwPsuzjtdCcOsLgdIA4MQ5NAgJCeZOmb7ATfhxLMirsoulpezZFI17EBPO78J0t73H05f/1jr8Pufv//p9NWYP43fHr+hLlfN7r0//nDy9mx8+oO1nvz69uzkww/Hr+qVP5wc/zQWRT+c/OvPpx9OXtdGTCtx+v6XQ1UMpqvMl3Fz5HG2V+5QfvfcB5r1LHXXexKrd+9+sqJLLeDX8avT1x/qPeUyPx6fnfzb8f9ory8K2Gu/fvsRCfReTZui0BZoUAGwH/r0P+9bn/6HcBezpOzApy7Os4J3sadVbsWxhtvxz2fvxq9Pzk5enVVjbVa2FkEwj58EIv7jMxpiy+oSXxD2cOAfPB36A3/QPzjU8JXlrFNR+2jAGVqA2Kje/IYgYN+5zHtiyZirrvZt7/jt2en4zenb07c/1saw+jA+eXv8/U+fScV7UTx1xgByDFtuJw3nsHvAq3A5K7vMrZG3w34EW1yK23IHgGt82qyhmu5SVbEBdM4eFjHxf8/5JZwt+blrQJUQNISmsyxsR4ke8L9bhBhw4UfgRrvVlGs7XwXiAaaAH5DNM0w3Sadu1xM/evQLcQ8TYHxVdzpumqW9aZImJUyBakJ0kYBuHxPPeXcLcg/MW22IuPVqkN4c//v4w/EboIl5eN8Zes48STsHB141lS4Woc3z+M34x+9d7+CgC13Ht6/e/2xWHA5sFaGY6w0HVOv07Rj3TFHtmVEcvmFx2lOxIaxC7Wg1JADZnrVBDQK1CtR9dgosu9FR0Xsdhiyr9/hbHUij02Ik2oBQ7w90CK3dkX1tA6X6dfAM4f3p3cczwvHDyceTD7+cwCcBduDLkRXUZilKSDEMgtsAcuAPLEBqZcUs0Sfoqfwi8dB7Ui8DVWXNX/D1u19OPrx69+bNKWJ6dvpO9eWPzwRZWhGy1gXY/jNJpq9P3v/07n9Q9z/+CfZ+BRjJFQEP/O9qkG3VXG/gfzvo6r3Vir1/dSaJeuALuN89s2LcrAkkBkXlAlGT9cOHkxP8LEpK+BI8N2SgvaE2DMm33AbLrz9/+Al3/dWe4y4v4VizHB0AvEN35F6X5aIY9fuTWbaMeiyi+lwGhOF5P49nMRw+in4R58Bl+tMMDl7ybZ8L9ghYj0v0CFIyv+qF8+j5oQ9Prqe1e/B57f4tnM8fGu0e7N7u4ee1m2ZwPmy0e7h7u893bbfIZssy7k+WeR6npXqxpZkovkzCdDQc1tvw+Yuf5Vd9bo7f9y+XcHCOH+L+LCzh1Nbncr3hsHcVp3GeTBhFbubXSXZ3YDR0sHtDWXZzl+XzekMHuzX0dOeGYIe+Txr9ebq5mXC2gOP76Kl/oE9PNOtNotTnj7MkXd5Tc/y7f4ulKxLh1vlbDz/5T3v33z4fPz8UswXbei8faI3CyfvmYfSd0aBPL6u24DTUp1f972Q3GWj/A77tfdf7kfv1igaFe+1zkUZTw8GObQ0H1saGg91aC2fz0OhXHi8yH9/qgyh+Qcd46ERTouFj+P4Tfq91sbexUaOHG1uFLm5uttbZ1nYnsD6zogeSYRzOTQRQFYXqH58/+lyUEOE30Eh/kWfRcoKqHkGzvVdQ7N3H3kcqIoH0vwcqe/exhq5R1MQX8D8YHDwfDgdP4ajRQHsaR1kejg6f6SSR3aWwnUQ+fwTM/hZPSkUb/LbP46fo/vBZ/5VlIH+gwj3GBXGX2PUOn/WG/mEdo/Xe8U+nxx9PPgbavkT7CyBobFOe/Em7gPb1wPhKvFr7emh8lQxVK0C8GYeGezDi9325N9ZwqBU6MAsdWAsdmoUOrYWem4XqWDFD6xOLr9i9V/98oH0+aH5+qn1+WueAPn7VOaLnVpyC1rXkXMYHIn3FaOSSrCoJruBpr6mKXLieWEr8trGsPNtKa5aqkXb1vCdOqlESd+bFlefkk2AIx6NFjjIqvUHNZ1A84HqN4jzvHokj2seHooznJ/dJ2cknXYKSL9NOmF/dsqI0W5bB8ABEssl1PLkJzuCM7MH5b7Esx1FYhgGqKcXBcxFUSldfQaGyQVXDQ9UowwFcELxW6/3p+xOPUWy8ltiIv3yKhEMqIeag3nvh84FwkkXxV8GgOgVHcRkms6CzEN3XlQr0DuDp76ZuDCPirHSAa7d7Pjp4NhhcVMdXGsIPrD7nc+50f+U6rv+3DETZebjAM7eHw9DtrkfOivFY7zPu4vS64MmL0wL15FGSFx0xoKixWtBhG9WsXqWiVRpapaDV9LNSPdut+r/w5zcAuLMIUeQqePShi0U5znhOGSPg4JPreRZxe4Psj3DUND9o7YjPe/+tpu7GzlTq5TGql2WH9vf3PwKjhCXy99iZL/EaIL3SLg7wPgPZ1zKfxP3T9044g9r0Ce8y0qyEIZ/EPt4ukLZAHzIesWtUBC3itKO03h4s1idC52CoRoB0WNeeFA6CRkquvipVvD+lHkyvfVxDadbpeuIDNXHy75U64yGJZxHjkaSAu9aY0fJure+Kwc9vKwwa7fKg+CAPFHFH6I+SYoy3PGNWR4+Txe1hh1Qw1SwdT0gPczXLLhGek8MCoQuk0/e3h84yTSZhUTriakZeAnXSGAR4mNdZSd9RtEeZPuqqGTMnYBGo6x0/WYzFI+mpGJ+mUkqsmU6y8KGtAikjCJxDWv7wDrrGONMLHFd+qXBqjLBZTmJce71Mi0U8SaZJHG0BMMuyxWUo+JH2OklvcCWEM0P3V+m2RvUe/hDC4YXn6y5MyjHwAmPCWH2nODSc4dXk/RuUJ94hbvPEuDooNOYldO7yga4Ar/huqyzi2fTI4ckr8yW8U8OA9zTItJ2wgN0ky6ZqJqM4jKBXMbFjH//pdJ+QhmXg4a4juTT3dwZDT1sF/RK3kFXFFxJaNQxUgzAcS7wb/Td0lTOiSCQDC3njx665KsQ4z3SiIJSKWRwvOk/lRMHEQ9uB61b6XvUSKbXiUWO8DhzjkDF2qGntuBoaLmuxXYMGTugPVIf9OiyKPW2/mrpOR05FsJKtrj3uKw1OT00qt0MLNFhRAWhrP4Ux31936YpKAuBbKQT+eDh7LftexYH28S54hQOwBoGEF0EeT+LkNgaCBBqjZcSUqbXl3CXlNariBeGsC7lb+s6+gu7iJbSkZ8E5wwiAloBRhFQawnnjNvadVyQVAM3eJrDjEwOL4aieJ9FVDLRewoH9BjYfT6yC13969V7qLOA06zl4Ne/8SN+O4XwNb5C2Wi7b+tZbLZ9HS3Bd4GgJLKV4jEPDBMIEiY9ESfggCETdnQji5kH0p8sZSJTl5LqTu+fHvf8j7P190Pvuonr0x72L1cB7Pli7Hjdhmyz3NCVs6Noei7mGQIJvGOc0y+e0WY+zonMr8L0lZG9rmMrrlCMJRZx5aBHcerdy70Fhfbzg6+yxvuvcxA+B0Z76LgcBSjBLTZ1K22ft4NT9GUSDhaDodx+5WRDAJMy12WMlWfVhvfkgeOL4/sUY1ScgpY9dD3DoPnFJKyVvY9TEEvmMqakO9rDiyL+IIrAAJiHIq5E6jwJ6VIHI3/k1ni97ANu5jIF/x86yqISdJJ1mAUrV564shocfeAt/ej2gb5Sz0UjC9XCCCIMLTxPb5Wbx3cAiDZEwj7V9RKvoIGAhGWvixbykycfCzN2mOGOlYmzqUl7dP7EVybiASQ3oKktVFZ96+IkBDMyLMe3mp7oPIhT/+8d3b1/HKJXzTRAufKg12iiZu3RgF8OtNjZgIgmvBiAPgAGU4ZBZBzxLwoNuS8JbueJU7+bhnbve0qJOhROtdR41aBAhI3tdpjcpUMS+pEu8e9NGznnhPBsefDMcHBzSP4/oqDTjITDQ2TLLnAIW2Qxa15tYg1RQ4oWrvi4APXGyFOQqqLu2dCPgkoFtZcu+YAGfzhsgqBMjpTcFHAA6yEEIg5fWDjYEZ/t6Q3hd2/6OH9T7xpZr1KC9nRBbpiiwdUyAovK7jzTMkuTsMyAZLK92MRXiCHMZo1FWhuJVEU5jkNbthLfMZ0HF587tvJEPo+V8ERDiyEXGxXI6Te47ri9nza2EsHGMGFaimDG8JDOWaChFtJ6HKYzs0DtsSE6/BsIUqgNIetcgvIEsHqzcn0FW6dF26Y6kCU4PNpneK3Ue7A8P/AN33W2MfEOw/posztieSwq6TrhYzJIYydg5++ljH86ZKcg0LPelUQKbPRI7CBeRYY/WhH0MYtudU+A/2lWFM09wfAoCCBSUg6QMw1Ak0CXnGl4W1+FN3BfygzMF+QROoJYGiJ0LMzHYU371dEkdaSf3+JwKU+e5d5cuvZw2R6GSl5GH27/jf5dB7mO3O2oNdVvLCoHicuRcQpWb1nJT/y5Pyrhz2QQFIADz2gp+EViXsEE7FmnkdbUX6kwSmNUylTIrHC+Ja7lNVOwMAbBrFs0KGKPFLJzQd4+YxlGl3MDf3iB7fnhYiTEG/9B3J8EHPKMzzZ1IP8+IxScXeIP34IhaWY/W7g9ACm+z8odsmUZ8cqyODbUJEkv5xVP7VGiHncNvRNnupo3FVCq4UqxSmwMtB5TCpyVI3E9l+wWztRWsBpDl3RqUn/CEEXNHViVs851qpLr+mKTl8RiVZ9X7BhiXpX1YX5c4Ls6fzs7QIDV1zkCqPzx86jloDSYU4wmakcLB4P6hP03y+A6oysmXs7jwqlXvV/C7doWOWAByU7PsJK2z2XLwo42WTSR5G5UCPBNipXnrT92V5TSx9rmyS4BQwLGBkdrBViAkQTIu4W08ZpisbkA0ge9FAK2BJ7OKMSoCOyx+irJejOpTOGoF7rKc9r519RXXAIPLD7WKpIgGdqa3X6mZ67X0Y5I2J/a9GQ89DAH4S3gLNEuaLdz8+NhqykALYqvcsUZX1DmNEG5XBUjMa7Oit6PJ3nqTXbI6rDrFh/eV0PhfZ7AmJuEinCTlwzi76eThfHx16U0WSw+tb/HZ+cbDzo2hxzDXQoMPNDhbRjzzug5/Hs8DMjZ28fZu0offdMTo6qNAW2TgJlcgk8izY5mVIEneXAZqRPHHQOmxUbuDQgUAZItKfGEsHNThoKE57Cl5WeAG2nHfxPMzBDxyYTZVE3iO4KJkmtk9H15UKyyetQA6logRMAPNVoDcJA9qINvv4/ZG/xAXEG95Yga+6HIex7Ke3pRZV/9i1ocJHBPkANcK/JgAYyv5dmIoyIYVQ9hKANWOqjdQXht5ojnUHOPwy+Xvo5q0437Dy727Qd6e66dCBcug0LpiWycu4qnIEOZ86mN1Qzegc6ReEOYEbw2SVJgCVtJm1U/nSSCM/QQ0HOFZMk9KGGfXG+inyEZ9GBWsT1diXBvHlWpbqm4+KhiYohRPc325jAAuWjQlabVbslnWwDOIyek5FvO1rrel1jeOzYhLVOtW5CiKGySVTGtjKYaSy3adl/WObDllouFhGM2TgrTwUZwmcTTSVMfhPYgHzkpvc+QPp2vnx+R7aDyN7+Ajtc2vcMTjiPTMJespkbs5YlBXdeQUKKkiJUpb2cZn5A/+ae0gvsAqu4Jh4eRXE8aWj0gbauXBYLfb4nXlBGq2fzT+VXUe/MbQExnKlnDUK0S2Hevf//yoAQfAaznQ9Nwc4VuEKUe4QmQNg4r7mLNqH4GRfzBdj2DQaJbkHKzqg7KW4/2186cwj4Az38a9ZYFy49USXhQOXpcUZbagOwmGw1d+Aq+76zilb9QQOinNkPk8wPfiwRcK6fmYOO5igrPZ0biv06+voOEAVkTLWqFvSu2jNk0iLaM0SYp6qy+cTXaKOyylBeq00YuLhkVML/xZzLKHORw/R3zJttJbpUXwTzwwCAMHR24puB/8ugQBt4BFsQk1f4AwEGSlfKp1vSJq/NVmKfoCh6/qKZzf7zKnuEaXpyINF/AEZ4EbOG84IaBcMtp0NgjpuhHvgueo9qSzdbTM8QVp8JHg4YevXehPnTELP4CahF4Xw+kQTqdsIc3gcRVVd25TKMWDGx7wZ7Zb2AwvEO5w/2wrIld5dmeIHbjY3W77qZ2UOEVwjuzgXnNRIThSFhldXLQf5QGbgKGcP7140hGPhxckTkHP+UX35aHgR+1aASGHFsu5rOQhdJtSbeANKoFh6CXDwDYZR/oREw2T8c2BlxxYS1dzW4LoGpQHPYR80EuG6gtWAKoP5N4orOXhqROVvSjpfkO/+lHJUnNUvhyYe6A0GWFAzsugjZhrGq82drx90RKRY1FYmyvRrli2yyKOYESuAcZ1Nos03lnDhVaoWJzEOgP2dvRJxKc3ZLHRrURP/BLQFx9/91kt9M1TXazVytCLWiG1j1A5Jdj+byRRYscaIiWN6QaZ8hGCodpnqSWxtyrqrSahZ3NC6DYkB0ZXervw6Q4FCGszW3ac1wjrMcIEgm6IbwIJU34jipdnUmdlx05BYmWRaEbbgCQRw66Cy5w7rTubSKcjORBdQMo2jlsG4jQldfmENLzJfB5HCe561AlqH7XbeZbN5f6rMKv6UNs7NeHDhjzswRJ3IXp3Pw9H3PEldrQuSbOBu89yYWDLzWhjLmUEeYcpbBQWWTYbk2wld9I2x9YNqzslgdow7BHq8o7udejhEk4mpWZ9Jv+7gs7dhQ91KNI8qOZ22OAV0JqyDfoKbYNgZCRIcYuHOGpv8V4Pawk8x8rlHF9e5sCn0HRIvl43t/Omu5u4U0QTzFucK0BYNQcti5bcJvKAYM1fEotvuv4f+72L1dAbPlu7Xq1u9zGoStuIyh6gtuvjTLWyQavie+PdmE4N/dqktt/Fao7Fm4kwsJKgVt0TBEiWVg3+Xo3Q43tmtQZp6VKTaL8KDu1WG1awzhwNti7ZMs81LKKQakxX6u1wpaNvUsjjQ8QHMHvjUAx2vGlyBTJQpLXemBBB+3aDPxPJ320qNtOWGDSBqMFBdh+29slocqBHTUa2LIskiu3TYLZkdfVHmalDbVus4yy8r/2YULtRY+bUBrXBPL8AXDGS3e5WMmhZMZohV3PyQCi3mL3qhmoN61eP7x2Y02MkkhAWg1fZwXpKrPIcaR/qYQ+jbLLEUwKrO+i6vdDmEkRzVA2jKFIENEfL+biyuRVcA44g0+Qejnp4mnk65PNOo3TvQCcRHfKLg8dwG92C5Eia1zlh6aDLTOkADQngPFaq/abTt9pN6jIGWdnwZkQxRHKQHt01U3C1JapoGNXVlg7Rtgjs/fxQN0TUWd/lEi1/5GdGqs9W9FoUnkzaFzIAFKNMzug7H2PFi7UIH9QRu0kh9pfubVCiAzqqUAR6s8/NExtV++ZtljAr1q+r4qZd7WivuYXQjivBKPuRx2+0R4/fC/CgHBSxVBIot4jfePQ0r9mO0B59brHZrYtoCQjXiJEPKHesfUgW3Q3nRfOMiJ1JFmJL8GlF1i7FAK1AEx25MCJAgWhauX0b+0TkLAdjqf2BM3QiLCesXEFbKJLO4/vrEFgnCQBsEokmb3CGLkrWJNUjVODnIji/qGYTzizYK2X5XwWf0NwjmLVJUMqSw3WATXhGoBbN8wUgB/iPYVErRpbeJ0WUXKGijUZt+IIuA/FL90Xw/Nmzp8/YtQgxFHs3oT/iP364WMRpxBWMa2P8KoaDzdhhynLygOLLdJxqvlXHYFeetOjSL2P39/e/XyazCA+iZZ71wrsQo3wpK2Vh5H+ZZbRLec7Hj3/qsW4cI3hRs8p+FBpoNbEl603DwU+cZosxO8sFXNvQbQo3uqpovphbynWE45zwjhs1vN3ghXBlc8WygTNzkl6NmUzgM7tTaVTVEurle/KHef/uw9lHt+u5T+E/7xD+857Bf94f4T9veHgIL4f41mUloR5EhsM1uZL7qe43vDOmMKpf80Qwl99biD1+LOd15EyJ11a/V/Jxvce+UuO4nPAmPELHi3ivKK7Hi7twWV6LFzDxtFPDEb+UAJGOCsSoJ9cCPXMbWJCN/WDQx2SEEcmKvB74jbsisltzX4vrGA1CKYgdvN1bgISC+C0XaB4i6+fLdDKPuOVzIFmnN0HnqsWNw+Wcf/5nB38BG3R6vTTrkfUjKeChY2zczM4GIZoIOpNlPnMmYW+C5vvTBLeiogdEGKHABUSzABlnQRvrATygwrOQ4fXg79PeAljhJaALzCyP+fMVMAUHWeNVeHfjFMsoc6JJDpvCRQ1r8odzegunD3PQB/Tw/6MxT6YfOX3oLL1yOKxaduXU46sdOfC9B9QOnXF6x40mCJfer87+X05TUkq2tNX/9OkbjMc23bcWcP7xD+pRL3H2h4mzBdYmSA0M80lPzBxOGfVWUBQ2igR45EAZpOsEgw1iASBzXNtYoP6JPmxppEEEmxpsFFZNU6imzS3htG/uD5fYDJNcaKeOjOWIKrZPn9J95yWP8Dwro0ad4qGYlDOnd0dbOm66fjlZjIuHdJJlN0lcBEPnZT+Kb/vpcjZzDl7+81BrX9n7TwVP1TczWpZFwGV6cmmJ0Bn0qj5m9BJXGj+Yq43e8VLrpVf0S6w48UyrikuJuJbaMy5A+o2LkMHLhUi/cPnx62sY6Qd6lBZ3keon8R/ge2JWAhdpya33eSy8SwM3Sqf8FZn1f87Y6ANzoI8MjIAYtk3DkwNBAAPh/ofJ7OAyTOnHcnrHf1M0lUyjOAICvspDYC4bh2fD6ISL0t37/8ZGdWnbqQgZSQujlXxas3Ui3jMJjNAIb9TGRQcDGWSO2CkjFOfitgQGwR08HwwYJfJ+xpu+f4hZeS8sH49hdOBDIhyYH2JppPseIZUfYAB+yq6S5peT+aJ8kFBQ/BVf/3wZneKZk13cWsG/Ce/x21mOdvLPxUtq6Uf0nj7DUK9PB1Xhj3xjUDjDwejpYPRcfvr34fCHLAeRE+/JKyx+LmI0plW/X83wWuIY7ToIOxAoHQVD+/gKDdigOYXSe2Stb4CBarh/XF4WFJHAKablgo/YKfoIwa/GtBGbhdn67js5W71rwDYmU4HWeQPBzz5vrcza9j2fToZPn/6x+TGZzBfjeHKdjdk8cqxUYEVLYVkuu1oWbN+MbsgLwNfWOPbLBwbqs83EmJ3lx8SbgoG1tFh8j6ihwc9j1sAUuwHfVhwhF8DqdiqYL3DFAgm0DINsu1nuBsgmnvk3i5IGk/UPB+bHaB4XV9VXWXVa+MUyicbRcr5Alqbwgw/VXSYSGpp2F3q96nPxMJdfDakZeRZICTMhJgCho6QQp6QxQ5n5zllp3H4NwkElKKAgaK9D4letqC7O7NBsQ9b6beDEnvcbocjd8hFgSPLqCSbSLmU1qj5C0LMjLgXjHedPFt8wdSgC6AoEqaLnbaozDyeeptipdAZvM3YAFOXFxu90QjhHLMIcBWSMyEwxYY50dQJzIowC/ldRd/RX8rplhVPeQ+1FFcxhkkT5I5V/lbaaHQdTPN/LeClV4N5uXYQRtzEj52Avhm0P1m9J+7jg+8LqjO5GpUgIwyMwA4EGfqxZgIjLHgsgAIdXdnQ9WRzqoodSWo+c85U2wuv+Cru8Zr0V8c9CttZzymyEZkYUQ3eg+b+G0Lyp1Fwrt2+WTRUQo2EYm7VGAyzA4LyZvhiVHqlGD6RIsqqVyObf4vtxRGQRyJgyfXzJ77aHjzF8OuJIjx1ThLNSuGwUfpndxOn4Or7vfAt1SLQTTs0sr89cz2XRD72an+M/WN/18F/0c3ZVzy+UT93BoFsL4kMNEyZ9V1GuazipPEort82LxWxHOrFoSKCZkwUJ0kbjTlN0Vm6SAktIJ3EvidzRVEUNF04pnkvxQ3oSQ3ekpPTuE/dTarFplBr6MUd/IkRMpuBK/fqYbxmCyyybdTQq0i/L5D2ZHggBVrgyfKnAjFSrlhHfwsZaukFuHQpq5eKjXhmuVkmRif4S+cJPd0/6fd6FD3jDQ0ET2Scf3dSyPMwfmC+SV5vvfIiXBUq+IaoI8ELr4zthrRSmLJnmy0UpIsJ8rRn9Ud6FWRzexg6a9b05ftU/fd+XZOtwPJWyZNfgMhN2z2X+4BZkVvXLG1969Y5VR6auj397K9tKWlc9rIc4EpaCd9fJBO1ROd4fElJU1A1TQUwJzmtFLuq3H/okQ4UnUAP2apOoKP6AnJiuCQIXO9Y7xzKih12q0Fit2ltt+VTL/rlulWcoA9jGMZsFZu9hyqE1ml4OOGB+nt/A12lhN8pBcPYLRGPA+lobfQHQuFFElb225ermzbWG6bAanD9maJ50zs2hN2eM9dvnF93GjJxj94C9chQJnkA1OW7vNoPNAjjQq9PXx2fHyJT/Bm9itKXuoXbfvXhC2FqnRg4gg8NoSFiWXZnky7ofcdOB2Dbyr6pxpIWLK/Qu5Asjtl6PUCWFxwwMT0XHQIw3lvP9NYY7uoalOnT+nHzf1UZfMXaBnvAJ3rO7EVMJHKj2yF+qnw1/0B28emUc+CIzAsXd3M4btnp0XcveeyhPQhHYbja6Q/L1N94Wkbu1sgyEM7aA4ERZzENKgNCrtrymW7kImOQJi+tpXJA7CQeUSP7OOgkYaDSnCBF+Dy1CsSjuWvJSGhfDJScNgarFNdCTim3SbWdjl13EliKm2a1/VpdreXFImyrMdeRjIZT/lgu/uEZFZIWHdB21mEFuvQWVsQBEe1SvArvFelI0bPKhZEHXecifra3L7w2+gkaGc5oWo6t9nit4Cq9CGGzYcsSoOIkagm3GQ4hmFOPxlo339SvlHSxxjo2AT4gPj94kW84Y+GUs4NfMJSi9RsIeQFTPxzRL0FtxUrSn1ECUQwrxYDqF+42wPRFIwEoo6dhyKPw2i9bPsWbdbvj2O1hW2uxmcWJI51KMhX3TRhSMvCLKGA5Y7IcfXg2/G36rzGFp7ovlJcBW7mF/Rs8gnGWMxaWWFc2dCMg3C/OrGOY9W15dsyMCmlgtgAjQ8lmKzyIah+iRaTP1wvlWmN/WPrx08K7/+WN7h0pEXFKXgG0cpwAd8Xz+zANYWnjEDiIb34dzxNXItdKtWMXvZKO8qSN1s8VQGm+pEGspWR0a6WJ2C0q2m1XyJuSErVeFGxM3hbDWjZVhYw/vneEzZ3Idom4cSLj7OCSfYbg0yaq3YGdJLGWSAtndz+IS8YDZWc4v6SHKMG9YioFy8JYMp/b6YXEdp3IrxP0ImIRljp0nwuWbovEF9hl3eqIQeiAwrEASjxbhh748CaqyDNNSlD70tJJoF0P10eeEPObNoIotc0m7Ei1pMnDE1G5oUicIjaPv1c0EZSA6TOQmEPMYd459KAzYxhTcjPg3aWPGGfCvWbhAAbhSh32IpyyF6Lb4tIRB+oM1xnUw5A9LOHzbkfakJpBAV2HYFuNLmOWgsWebJMfF6nYj0q8Kb6QDFry5oOe4PcoVRY3hQ3Gd3bkXMuwyac+0cJ8D3TuIVOAqTjHy7oG1YT0MQ0fUY7WJiuVnDcwwxbC2BSCsh0ioizCiEAZPpqfzwQXJO0JH725wk2KHzltowHV1sFD31kVkGeJoe8gohiIQ4D9+AmvuvkOw0EVoeGGN5nOKpSxZmBpNGMF2KLTZLfbTZFpbOtvAXdFdi5ihhlTJGNucFrZgQC513GYzjq76IpeGtp52DQ/EwX2MDRO3r3W13FSf2X8c6R5FE365xmPGCsdWi45XWdzuNyIAiShAWUYrPUqm05iMdOWaZ1lDxlWkwyG2jeIGsgMx0L4JtCv4jOTH9/PZJscoYbPckO5tNLHB4lq3D65L+PWsiIFos7Ecd9uXrV5CO6K2dV9+PFJt+/Bj9mKxDauojppU0LRBn+6/EHP78gWi/HIlwKxfkPb75Ysp34DTsSqQM9x/+ULrZ+CueFzW+EHGhnu5v+MRsHWTA2bQdkhphMM2FUeP7BXi03+5X4dhdtFkcGsXGNEiwCx5wAFn4UPgDmwwkoXc2wGE6CTUBfTmYXED74S4g7/WbrM+3s28fMGCA92XQRUaIgASpxH8wpHigeey/WTRmIQqjJduvm5oU2rnP9u0CU8E69ZaL6+ihUo/Bp71x8QLbSz1lf7rq3x9RMoVxsoTC4/cSihN6p5V/8talkp9slF4o8K6UmhntQbR9Jj/bxcy3ijI7aws2covWhUnjbEGTGpKFKvSJOFsGedSe+Xg9UqPY/LKMWqT4fDSqlVqg52GBf1q39kzolrIbMb+W1ie0Zm8wEA9Yse9c9HiHs4gsZATLLElZWxHgG2qg9HCBoUon8JAt4osln7DcgIBEX4hiIuqp08HWxIUZIVUjFLQ4r0W+OGyzNjGVB/cajyNgRZ3j1gcJjmwwXskLFxMDK593nDq7Y3tThQskhuC8DFZfI3QUMqVvAUB7uAI+ZPILi71KWovUMHZqVMjZyU710yRon3R7ljXO7MDHg42zsDx6N2JURFWUIux2JCC4dYjjzDpKhLaIIWyu80c7HZR9ARoshja5KEqgOoXlnYU8arVsV9SNi4QBFDPqd0g2GMJ7xBzRKlL5RiQJm1a2enhriO+rS26PhnOGZPCj8XNgBkg0qBdF0oy5WIhGU2cp8bOyIJgoDeBFzuxGQOx0QCV2dTC8FkVj7Wersc4s+Khk6Il1lL6sF+HOEa4PAZ8GT0PJ1uwS6bocrJlABrn6woF65F6HmCc+TjMSRDunIMMHPamF6uDdedfRiPtZ3f1bN11PQTgQZVTYzecj8SgzP0r2DcXnaFFyqn6CkOhdZU0I1QuTJ3sUsT9YH0MJ2RAt28tnBRKG83EIKTuwrwLLLNijNWcHZOk8aYeiNmaB8Y66Cg28qCj1QfbLKILEQWX3jwPj5wLy3x8ip588o1/un34h+ehcT08Vxck1TwYnlLDgz/6tihQ9tlrDzCjdA/G8OFUBO2hR6voSYAlSWEUKAcLtCcoaXjLCVQVDCynnEDbMW7K27WULnWf04oq0eEP1XAqow47FE/wghFds7VkNvVcHY8mM4sx1GdRHfGeunDQ8Jn9DPokqwE19hggDI7SSRrBUCC9/suLr84/Rf5FF7jHpwhO0k/Xn/zuCv7lH/C6T4/AUP5FUHGTHOVJTTUkPSr7mNX4fHBhjVptD4XWktppYxQA8nWV6qggOHxsaqW2nE/tyZxG24KhCXzbgnFr+rZqcW7I62MuBzO5Ex5+JJ/eOb+TVG+Rfl3eBChmXl7ndFVWXx9IQOquWK6VNqvAzW7eWy5AW7NEDZ99kSxRFU9r5StG3DdZfAddslwNVjpWgKyR8WWFGilXl2p0uSepUoG3kLj+rUnn2ldF7C1h9yvv7tYlSKM/dVeqb2s98EgVzEBXmLJS193bvDZ2bIq6JLSJevQId0N+rtYI360ZqIwraJKLpRLYuHdmbXUjKZVMLDVrO1Z5BMbTbbxwuhpblEOB73mphswm9GxbuiAmiXp/TdYLfPWF7ELqM8YUvr7DdhlQlMLbl5mn5D6iW/mTS9zOx9q2W4ZXAYGEh4745FXwCJzgBKijgebQ7m/h8hfcKyMsyIZjqh5uonP0987maBdJeYrUM7SEdmTw8jUMPn0rsx6mW0hSGhDXAwoxerAeraourF0VPwDPPjakItczR8DEs4K1I6LHr16dvD8T7apkWTweno6HmCQguiydABcb05CW8gxZ1Lj74TNd+rlMMN4AH+FkEGRyhZe2ooS3WzgigzrTLdq8kHEqRgPo5zH+2Y23187vX7FCWIktKxfPZ8vCHbmwkHqUgGVC2kDPZa+7yB0N1nu7iqKYVSAKyI2/kkH1wWEhVFopSqUf1mrIlQZuPQXAc8UiZ6F2VJN39W9S4G32xaCcYOM2bc1MK+BpgdgTdEnBKBdmX9RyocgTWIjxVO8xCCWGTVHkWitYfRAlif5Jyq8K0TsYmXKycLvNPF3ZDPfMWh3ZTzNvoTYrneGLQKGph8uA9xVWRhwNRINV44gJDHu0cNfd7deVjCDB4MevAmOGahrFGamaPfwrFTebWSbzDAbtaYzSlCFIWW3A6LiczAm6klJw4fcfTj68+/ns9O2PrifQ2LE++7DBww/vPvzb8YfXro5+BSOdlmNchQ8dFzru1tl0jeW1doXsUplIx1IXgr6+ERVmwtYqU1vdx4X/+9p5A4iSVqqgwN8YKArR7c3i23jmUXgl3uhUJhZSBjnz8EFq6HH7C5PcTLGENHou6FNWHQtecBG4GJIFDaq31yF/S6giYsdiiudD7aDTNCvf0rJi+VGzcX+RLTp2BDxyz6kifzHveCKcC3dhq/jz3ORtF+YKoWLjsIRj72TMWk4Fw8MnQ3mksdbspsFRa9uq4p3iQeYj32wvCrvTayqhbDvdopkXlEJgUUg1cn0hSQ2md5EBEyTzN0xbG4osptldGitB26+FUqhHQtIMTCv1p/ZS33+sVqbNoz1b8wTttkF1u6DmvQq55eqmQWQZJA2D3Cuyuh/69L8WlcSzuiMBWo8EHTZkslj8dBoqLS5qaHWJ9bpFPmk1yTEPZFYrHKzefTK8sJ2abFNUnbNGDRXU3pZ8SnLbxSgzZGJ+XZaLYtTvh4sENfrJ9MHPckyiKT8In+wwvQ7/nix8kAA3BhPLOQfeb8mF5w/qqfDqieMQsprYQ04dJ7zDm6PPrn7yO+eDe37Y9SPKlQn7RTFJEswaKjL3NNR8G6ZCJHyU00A/dw1ytlUN2BKBTtcGopo5fYQSkOhVpRuGYWtEdfzP00Zb9YK2ELuGjrCee7rFdOw35qJu0MDmAOc2pP5LlZnOF9NmStNNC/FLpYldu2KNMs8C0OmU/QfR+0rqf+54DYuIoFUm9jmnXkeSZtPUgqLdi83Mhq7K6K2rl4C45PtHomtReu6m2rdeOilrPbJfmIeTFtsaM94nm8loBlpVmE3MDhhIB1b35QsAqVkXoYs32gHx4pSKGfggNTP4ETWeMwEI9TdJRqZDqg1hMMSOzoGKMcpLxXAVohIbI6c2InputToRFkY17/fGCIhiWwYgim/hJeO5dhsGbDuMBKctn9P0EevDOPKo0Upgdcwv6ec8vMfH28liWchv4hd8ohx0HjmEo5tvDBtrOgHeQQriSgikq2Ln39/85Dt/lWX+ij3jZAI9EVcDjxnlEj0lj4R7X6eLbvszziEk1SOLmYAm5wtfsuJUaO36tFfk8d8w/ghdfxJtU86meE7J3ouMfErYUDRLhZhJ6VIruRK6CfjEQZLRH9xdsgyv1cs8xIC9v2aFZJPiW7D/Yh7PxQ+ak5k2/EpalYOgJ9N5n2fIGRhPTChyFydX10CC5FQgsi5wTBtKnpRcXcWcEgCTKGFeHYxTnFIaYrLogOOYzKrk6ylWqC/T/U+p47wQP4GoUAIvXq44URbqH9Qkd7vfPBserF/0RZkXfVmrsr5LskXBiS+8cZzejhEAqmk5WcPpO3j66fTN6ZnrfTsYkA5jfrmpxpvvqxqHWMEI+Klii0pxBlof8RcZrxOWFeffwG+YZPLlCp+gF7XX++aN+2U7JMqfzaCwWJUJVwGtSuw34pACWEFG7gt+eOk+cUVkDCrQfeLC+hSfNML4IY/j3gITavHeQTbVmKqYEkRU24vQsLNTu75gTArYgVIpxcV7aPGDbJAsQYFKYKMrUHeZZCAgDAfEUiowGkGkMhFKbXaBH/K80hSTPqsWJt/c024ucaF9Mzx4Vo//j4sPrVhhJO6SqLx+CXyUHQFDWMqYRMdd3VwCZ7xc5kVJP745IAaqPAa3FexXwOXSBc4ZNDc+zSEN0BrJcvhvFcZWZ74ga1LRJ+bbRlyUF2xmI/g4+vu+hCLC6pduQITJL76FicjyB4xfDr14k3zvvlxVLHxNEwXfqahQLb+x16j2AKhlFKXKyBkc6hTy0sBl8ceV+moYQWO7WANUxUwAID6/XAkegrrYFxkwFeyhg/YZgXv/7fPx80MXI7xc492i++vTZ+7L69s5rDMo9fIF6r55/7uOaJ4AAMKZAjNfEosKJ4sEPsBJcILf1Yc95nlit+TNB86S4iLVFaZpLvJRAEylMX6dk02nBVC0uywn4j3sAwvUscKXl3ipkWcPgIf2Ekuwmv6liAVE38Ur/DrJw+La+MhvEDz0LpkwwvgLE9UwDaBRKNpkc7BA/ADrMsoT3L7YlBs9rF1R+tdJdnfgcpp60S0MNjxBfam7TOfhQpMoKIqIS0l/iPxLdMcUA30bhbhACm03WzGvghnFGtswnURwYNmEah7eNXFB0aKBS6FwKTAsAnzFgzCeIMlMXCGzogXI2v4XE2CZqZKIgOLvXQXVkJIEall+5SN6Pp9k6SToM8MToEQjgveJZkDqB5IXEBflA1aAXbvIZrHxkktf5eHiOpkUUvStyK6vCAAeiQe8VKGC2A53zK+/iOSmK+wQNm0bv7xhZUWbiEYhTYS1si6WcaJfvj6VMlhS3VWZRgDkOCukIdLiUOwhtso1zKWD30VQlQ+PtL62GF8bBtdHzv0ieJSFtSuNq+8XRgAUZRcpMd2qoecB1rOeSJtszQ773ggBzy6XSFpC7KZBlrGRPEvOaRnshoNQseeGJvS3R6BqBrdQ7+DYU3S6Kt/nFadtFim0jlByDWRW1SNHIEJvZIawvdrNFVd9EWC2PUzKtSFfOEpSlBMOpajhf/zP/3MlKlFCLbcBGpBguCCob4KLcnwTLrxdUyzdogYZ83ii/PsiEH3iRigd2oZWiOmqZlYSylq2Rz/MjmyyEF5xyr0Rq8PkNUHT4NdzRRAWd8SqMUP/NNqmAmSOSckHSeYXSetJqvF54xIh3Si3XG4GLhOfMFZSS754acJqTcr+tfM644tnWNNpSbpGNIDFrC20uJ1ZPC3RTaUQKUxTvHSM8z7t0XHUn4fpEjh9FRbKlxGoeD6QkaAiPuSwdSiUS64ohDq8BCvKZDZTvuUYAYjiRzGsLF/Aogc2RVF/Ft0qM0ZH8TMcGY8HwJM9rqWUv5CTLuFt8YBHf2pynswEPyCnTlWbzpwhBlIOJ2Wn6DLLTLO2fo4srpzaf0+cKkKgbKK7pYLvnJKRHyuB6ayzpNgS0Bmc6ILUbnisuY37fP+KL+Y4t8klhQWDGRfOorSPoTusWB2cu1TkNxxnN50m/xOGvDXXsiquMXJGFQ8M77eMmF7LfIbJrjvDb7tCd1DEQZTdpZi2ZEyhpVTmhq5aJGO6++I9p1oXzZe0FOqvJWU0PpjhxMSWKpkr5jbUUzKa3Zf+MEKfrgL7eC57FLg9EW6KcrKwSQ52tWvXp9NmN52XUmg1DvgA0Lytahr4UV1sQ8sAQ/VYXy005FNMj1EK5Tg31LVZt9kum+SVd37DAg86UsGmy3eSgpiS9Da7wTUghwM1TfEtWtqTGgCFQ4x6ipGreG1hIqFZjFSvpT+u5ttIytcYaYaBYz3F2ErUH/jxg+vBaMDDpTbs9ISQu2h4VZvr9Y9uJXcM9bsNkJcC99nB6NnhaDAYuU/ckVisU1fFqsthGV7Gs+yuc/DseXc0OLiH4zQyqzGp/9G9s/NUV+LIvSBoz1FURUev6NwYDApm2Ro2sxky0zPXVGO1mMDDWwSLn03Amsl8JYQaKwWkBiEydY3MxrayIAkgX+lq9CUTQIhNguTChAQ8ESSphPEswgkTZ0jUhBmKr2P4h64YcFvj8IRhqgFW/BunvE8B1egWAj07OEcryvNzVDrCv7DP38TCCplNNmXYQpGfe8MRhLRiYgz4Weu/4qPV6cN0dTDFjwxED2tOGxA/sAWVyXck2LSrHw7ke9k2JuzmKu4I8XA1xOhNVdLMEzySki+/F6oO+lJbSZ68wRijksEd6TcANQlJ/ZDeFp4rLzTHRkH+JqStMVrvaWbTJKLllg/Ko5H9oxDI2hhqbUcwiH+7EUnz/KI5b7Z7Uj0170zZM3HDocgAaOVOlgunIKi5J2oJ65WyVNgLFy029kdwYjVtVaRJCvBrC2DNwEUGORM5tGZLbAOOzL8uY3GUxvu/ORtO+bu7XFQGOrsZK6JLgRWQ1ZKo+tnmC2EcNM1Irw3DsI1NGXfgzdISKHCxWBhuNVrrno+eDSw3vAzBuoZa2uUabH/UMGSCSq0mToaDlAVitSQvdOeIRvHd1lpz42y0TQF0rWkRm2YkcoB0WqpvwJsJaeNIa/D/q4anDYWmwZ9Zb9uhdYPloDpS5srtUko3UV85Vspb/LCQV5fMkO5w+w5nnN0NbSlN1tAy8Z9/Yic9myulGtiLpODUskW17bb1DdW+ba63GBvAqZnmuSeEYrSfYkcZNEcHNk0iNHmskuigu1+QGMHpVkliopAOGmQUkAopnwvFJrQC+1NBXJ5jppE9vWk8W1fQkZJ/1+1tyznC0gDe87IO8Iu0gKIb7e2ePKuT4qBTnS08Pgx0TFGg0iJ4HV0+FkqGelpeVCvcpTZTFOoiOfBLBLrN+Lh2h/lRIwxXdQgwGxKWmPm8zOO4oxQiIucKGd8WtYCdpPNgdSeQyrgia7xBqGRZEN+3KTN3sdttqjJ1jV9TS/lblZRt2gtEoPKRqFatN+x2ax/NJezpGgAoCzOF5xMaiEDrpym4Ycif+3k8F0Z1cFbUjgPrN8IDh7PWNaib9wiD31yIceJB17R5LdH2sZSHRqlpGRxw/PxKl07CriIANRYaAeCZ7DfOvqmxrk26rj/+LPVx22ybM2kMIc008ujfY7bppkVMNops2GdtjvERCCKZL+fGfHuNKCw89xV9XuBYfcFZN9a9PMZVE+98maV/1LbuqVPBlllq4RBUpoVaXglfMeQRMnKbDFo7JC3piqrbrwE0EeGrwIXJpXD1ZgiC8/rB+ssvSSEJRCKfFxI9RbQuah4EMkYFExQc1qSn3FWe3ZXXbEx8TfY7hXTxJFUHV6UZ81u41maWhYLZrrzrdx0qg3tZyPj3YWA26jW3Ehuf24VukdNtplv9vuyx7Kc5TVbaDzTa370NoonN4lrF1KSu6UuzNSQHvFQtygxNmjiNsqAAa+AfDILf48g30Aeggna+LCNWqUYWeYa347ZGMCQom1/WjWs+pW9FzimpUmE71z7brH5KX8NGNHJIh+08cdga41PKFv9kfjESIeGjT+mx1DapdyLqzxgNzceVhRZbeEh/XPohEMaOfl4wID2Cl24a324Vz0aLbeF1Z7G0AHwZVNnIi/PhRRAwylZfgpWLViN4csPCgwsgUvZbEG8O4M08nMifhxe1tg7rasGGhTfOtRarWowimxxv5S7CxppuLunR5o+wg7W1oBpRRlCLbmsteAJnt1HqSMq/01OEQFTOK77y86Dx8yrb9MrzgxsjqQUtI+GbsA7SmcqOjAQQw4jc54pV7Gl5choZVayrWk4CX2XaqLl9HrgYzYMwd7LNA97jbVo7ojEjBDYGqLNzdTlnlWX7igGsOZY0Wl9apy2KP2vakMyJJ9OFH21L+Kpy/v7PnjTYqpK/x/phki1lcEelB3nFukPaNn3M7WYbllWDp4f6UG+XWbn7wcaxUYExqVvS6rgebbRpv1P3Lf/yR18DsRebZGyBVGvKnGg5kdGjseVJnMyElzOZjKgYrnjpMUfjV7SvOnJg8+UMF2QhkUaCDNBdB/a7BK1MZMieEITclJJOaZYHv8/5XZoDtZ/mvvT5vQqdihRT15LiJYy0OxccKcGgOaj6K2BQUYrFCCckq+Owo7GEg6leCs5k7FQ0bCpJpQFyc+o1WdzT7mm7piJKsEq0WxegPLysFTMgiWbTfVXtAMEANx8gtqn5NihD5FJEi2brOmwI8L+PFuL30UR8Jt1+MU3Elzlo1NbCFz1WtOpL1CbHu4ydOFpNKDUi2WCQ+AXtEbW1S7fogYUutBv3mo7KyNYgOvzCgLdD4FWD56s+kOXfSgdFaKNl3ErebNAL6OYlOgpwwkfgXbco8FLOPMoI3KdYmpirbkm6ev+3rJyNWwEyr43LSk51Vz1tWl7bzTPJaDrEYCdE4U5gEa0oZrAhQNTm6+WG+UqmOnxLlE1zRV0vS7Sl23SGO3zWvICoWysNWnyBraJjFQ9edhLEU6YHdHYlt0IrNC3g2dAaam7LWH7GJdXzpvUEjrmeRrBuZcZijGsakG01HKu4U30BX0hu0lZW2+k+g55/C/XsZHCy4z325yt37IeK8a9X4bi4jmczqeTL5nMQM/VI7FoYyZP7eIJJV1qjRNLF5xFne8Tjmn7LCsen2zJc9FlHI72tYQTZyJUZnHDfLTNOLI+WadNpMsHUuoh64YhYJCQKI9ctMO0LlxW4S/M15R6yCB/QdjPQMyerwXdj7pM74jA7PfztetV3kLeWaItduKOVi0MPJfuXSdrHnO6oFshhzcChbibOiwKL7oXnAgdGHzGZIpUuyNcMeu2JxOp4mdgBMB6A7Wp5vfii0fRqCUv0IikrlvKtrhDKs8u4pn6iBUeKrp5AS0gFYkh2C0OBgLeZyloCA3BEkUCznWVIwni2aTGRRHy8k7FIeK+idl1vtZYBKZLI7XYteZzawoYOLGFDjfApOwQNNe6HyRZiLKnKXe0LEtof7Vck1ONi+96+IqD90WofsN8f/VO0Xrv/BI8b4O86kyY22ye0xsi4uja7X9Vnd4ucIwBYMwCID3pYddSeNAZJmC+7dizJ4UKjIgNwt0ElbT0lXUcoOT5sTWiz0nAL27Sb+mhO3hoJQyiAx5fPD0kzVrUFb0W25XpMPMNcIc8tdeHtDnVxktEg+/mhDyBE6B6BTBXKh9MO4N5LnrYuWXOKUiLevduGWhO8wHcLeFFqI/h8wgcGY3IQJvpyY7fbyTefbKRX1P0ls6BTI80aQU5dc/9g2nBWOeZBOB/BDmixC9ywJLjV7qaouhoGeztAdBsbrcQVy0QIbovPgTXYXn2z0T38msZoekkDO8XWa8Oss3uDATR600wYxHod7aaGeky3sGhFDnIARtcIZ2hvn2HgAo5kGupWXDX7q2olH3SNtJfcp7oHk/Zpb+dpMTuiha1CbsciFmwHt15TutqoqiVvDnbZumeXrXsUAhAUM3F8f6FrdalGI/KOWICCeAJXOkkV17P43v91maGzqdYAQek2vXoEuLr0KIVHa3BTG0Vi/drgf+0AS2ZDPUwvXsTT5YwQovhykbisiVRaaJYiC3Tfkrd/QtAkj3wNrlWwJI85HDCEwtElyREnT+Zh/uD864/HwinnEh2+MK95RVHKtlNmyTCyLpDHFtpe6j4fhmAlYpOakf+K4hpr13M/wGuWCJopDGUNjwMZK6PLggSHHl4wfaQg63+CAfhz/EDRqFEnn2aanKvAUQWMRPdnzHyCdQp0Ug4ouXu6nM0k0FdZmsJwn6lsOxZoUzeHRfjfVsliTWoyV9KIUfKiTjF2zZkUWYrrTdKoHrscSprsZ7vWhlczS3RIpSya+I2jzshZKepdHzkfP/6J4goh4cKnjmi6LhM1EIL9Zfgt7C+63nMnvDROY6DiG6hoKeYn15Q99yEuVUJzvHKgiLLy9mfnuLAi3negEuTYkqBvz/Ikw5zar5BMbiijj3dtF9dh+kBH+ntbHOSAxIsqxDivOuSZm+IcB3zPTGHM5buKM2ohj62BqBtpUGwh4ozhZbRMTBlzLei4zkk7Zw+LuJF/1jMIp9vg2eynKU7/ZlhhdgDDW2B4hzm1QswyjJ8EGDj1AlMM2rLp6fsPF93sFfzFc+sx1yA2ye0Dy6Fo7Ngft/cKuA/26eIJWZlQx9qSR8m+8JgEAcUyNkibKm6J0NiGyanAxHOHroFN/cRGHhgKBxH2ebTXomH8th4UW1xefbkR0fvPwDePAFFNQ1XZis/rXfHB8dGyGugpCJx6TgMxKHjlRymblpeYSPYvRiZZWP1jVt8oNnM+OvzWCNs/lSFZRyuEtR6tzMUKL5ocY+3KhMAqBLdYZr+Z1+7v7x8jQCH2CImod/oe+Do8PCAngoFBYUmtNMybwC7/7EDVw9/UVhWiTpAbBQelR9UZuWnp4eLN7hr7rBmlvhqoRlx6jcEd2QRhOSfmoqw05BTTXK6OdUuERXSRExVVHuKIXOlFRQWeA84r6FrQ+Q2gqdIkmyngUA2BY71GrI+dA+B321ssWowbqd5u5hk75mJ8ZPoFXjITFH9TVEx37qttk0Cx+33rZq1+qw3x3pq0INCGa9ctnam1FjpdxsOs/ALFKsRedbgr+KhUkI0kBw3x0sK16yl4tueeRasGHjC1SjFnBx6LUi3JHvvjmjYi6HZN7YYz37WjZW5oyrvmUWm4Gnl7VMSgtv4gikY6nUpAjR5IOHVUrqq6yN3nNDkUhoO66OtpKlvTgn0VHFKKY5XNS7aP+TXMNGHVG5U5abSTfgYnaCGyGMq0mkKk0f2Bqww9HuEjTdD7nLFFhrDXp8yaLGanxBRixtrTOWymBgpETA7MGJwMdxGpYuF4c55TRUGh25skW+Lko1eYsMFhB7kaVGhJXoqn8R3m7POdd/Arv8NhxdcUFMepkmKQCOpMKI9pcR1G2R3KfI3kHV+O53wuI5GY6AylU6G2mYc0XOAqQCqFifj9VWDlIb81i8lWgvlS6Uy+REoT+9nFgoFcQFurNhvWl9yuy4Y3y3Mb/dHu/+WJ8KLZvgw0u9LaGFVTru+kIz1hCzc0EsmwFImOBGWsN/kqf7GO/x47/kXNuMmQXi4CwvSxsSqkyTwTAwySoKPHDXljkD33di7drjncBwcVZcpWGVZCyu/trjdlK7HoFyqZXBvL0e/XqVrWl0bX+OzSE2eXBCVtgh/RspXm+DIYHAVwGLlVzA04DhW0I5kZYI6Uevcqgw2YG8GrAy0bGu3XvhhA257+J5k6RogowivEd34uOClgdpvARtVjxbQEqqWhoShdpV2bobLyLZawVVKyt2kpeHM9mwXtsnz1gXYVIEKRyxpuKUI2pHpHIBbmMQbeiarcSPTFCfMYPpbZEs7S0WeleMOzvZnkTbnX7XLI0HOZ7XKQMFOo6Pmr5D4h85mda6R5wQGp2jKYeS2pyjzXFSZweqYmCbEWo2FrplbNJ7SNkdCQyfThYXltDSdYzhcBvvLR23BcLIGc7zv0gp+fuD4UcVXh3W2BPHsmepWBHoB5g+z5YKDey4DT+AVRkMS7JReYw1oYoUVQFP1e5KFnOwBi5gkFoReHF5EOi0lepsERmoyff/g3pml/j8C9BRGS9RdifVIJCh8YYngrisrdg94/UEw88qvCVlBJjjR7hwv6HQmcDGZPRmwlKyNisgQSl5AR6o9cIcQyq9vtI6MJb7MkwiQCysQJIZKiHeVfvG8ie4YjYknA+ZczjOGDd5vkWErmaJxJQBr7+3IEt/lJScWKUKls1+j8J2lWhJG4puCwg/xRMegvpOQQtBmQyk6/4dQYkU6/FSeq7lfhXBglV+hpJ9U1DEz0ZG1XGcumffR203T4KD+pbyJ+tvadxRQTJZBTyEekI153d0jPtictimKLC86eZgQUW720W+UB3vN5t1cyicih18O5nPVuF0WPU9q7Xq0nI/QZlL1Y7wkv7e+XCZzwcDfnpNCwqooJkGc5YlYgaT1y0uU8hhJMIWQHTe4eIL4vMtoAeaXQ/RZuN9pNd+0KvTaiIt8otRrksNJwA+/Fyz0Ypa+U0UXv1llO75yX6krUOXj5z8Mj1kzEk+vM2X/7bgxcY/+IjEmcwRGwCoaBFYXV04EG4B/OFTBZp/dr4rh/+UjfR4L9uAZggDo+fXv86uz0lxMT/NeOLirwxn8Zhzlym2yZy4Bh8zC/iXPMgndHUcvwbA3jeUlhadHmwd/D0aHYgH/oaOhyIRh9E+/w7sZx+18rRv3m+O3xjyeve+/ffTjrnJ+PigXsHKOLi3/8odt3Vleofu+ffzr/dHHR9/b3vT8MSZ2MYdD+MFy7ABCnxOnlKYZkzmA+EIUeZmqlDDUUSHf/D+l+ffidf/wDhAXYeyM0mVRhbcdjRGT80+nHs/FYQDx3einAWOw7F1hLM+nCtmhbwM99EBv2HZHU13FtHXQ1LBrVl9GjqhPe1SR/OHn17u2r059OXu/vASFWSR+MHrleReWUB9p19y0GGyJqat0W5dwVRqxsvUpkX13Gfzdot9wwbInYAQt2wOsspz3rNpaZ7nANlyImqUpQ7FN54XrVR83bVU7ZMzhvpwYXNXOUfUZEhsd1UFn49Bv2N5cgPMxR4JXqUf83sjIljQhP0mTGuYE5YtzTZ4OL9Z5mtCn5nIts1TWnkZIgYl2ejC7bxHUwDTEvdLZM6UmhgmB0XOYkjcqoNNJ5Qb2AAO/S7ZmyrXzUIPBfs98Mvab2Ph8doAkDy4QgrCBB4qwuFzLQKYiM25yKt7uFSCPOmmtBi6sqedvU/VWRrCl+FKF0RHZ47Jjtz2/gmCj8yjm+k0eNjLMbLdpTM1xult7GOYU8eFfFy63cGsSgdS/04HcDW6yFZK4PHCLoaSfBrfHvOdb9lnE8cop8oo2AkS87n2wZ1u8JNfJBaozshij8ZjTrR4wgYKSFGK6NYItDA1lc3WohTJpHrjpntMRsoGjTO0dsIIGN7pZjTDfTyd2/vHr/86dO8ak7+lQ86XyKnnRdD+2aoMwbMzuUNQ5DlTILzqrAGtGVp9vdEvCufhDVgBieXTJeiKdFDEbo2vhhMezrODW0Ec2xgoJkw11orvSYt8rdadyoqJbtfHvUC8soF08Q+qfiGxjqbzrng953/gUON9bF8T7dNN4cM09Y6MBITeFIZhn0HePjmdjJQQS0zkfBhcTukcjxGOFc0pOdKHbXThAQMdWIIOzJE+sisTuKfaU7itW31oE/kDnuqONBCzFpPsb04YVuwleDVYTzxSwm3Ujw5uTsmJhax8IHn7g+wBPMKM3uGq5T8oqqcqnBk08FvuJ9pu5J1dNdELRq1EfSunQ3qokazRtsSIdoV+SsXOwMRq6+4xCZacHhpfH1WvfyMpQ5GmBdqbMDG5GBVATirVMUlQHg1OOlI0szuyGMPfja5RvYO5F7AJ3IJeo9UlQY1UTvPFmEaqsfijxLIBwK0olO5+0kJL0EcVMI2vaHSre/mJRBB0H2h/F33X4nKr9hTqrD6Xa/GQ5kAxq/hVfk308fPQCl+CpnCRijry6QJGnlaGFVy43l5I0rzB0UrhQ38dwaVJxdcxu0yP/CSl7kz5P+UGJ5iKkTEICnqEDaIL2TFDnYQjMSvCCI8KGg2+EgSm6JBvmz9+3zQxJ9ruE4apaAR+/pc/oIwwffoEqhf5QupkauRiQCaKueXdFd4dt1VOmdqEEiFWtx+ry+rsojDlh8Sz0stp67GmbaR+zBujDlbqWG4HhJIuQae3DhUu/sIPBt1+jsGkMUiGFb2MAjIyXB5iAYVBwXVhOu6VAuUi01i22MG6nQXhZA+APGrNodh3q2gK6K3zfebdHL5RdYQxUWTQlxHs+xwiOFRJjOIlitrVmw58WG/Ne0E914t0bALzh2XRwRzPObCxrK20eJK5wTfXyTcMAGBMTzwB/cRv4F4sONlxU8eei2gFymOG2uV7VJwLSfRqSfal71VAtV6X7fbPprmSDILZy/clt/RZUDn6hvkyLBqwHMQeqIlJakSii1uDEiiyDH6S4MCxNFdcw+FYJOz+yzjhXRMpNq9RsxXCqRd6cTr3naVSj9mjwmR444P+2QP+HX5NGevr/qkhHUb/PvrUYESeNXndR6HAyg1dvPGDyttni1qfqGNbBDbHYtizdJyyAbNMXmio3oUQm2RBwh0EhPRjYkUoN19O72O5QU+JunvC3rn3hvtnBJKsRyjBzzfkdH4BsJE6WYCq6Mecp7vindaB7ztsDwxD1JLmWhFFpnKVXAhLcVQ66HeKd0ihV8WF/oa08MYyTXnufywXKkVp/nQiPuqCNL9NUX7JUM28ULVfaouzbbMbKuaJCbgelNFClJ6mi6v6oGGIe0+mfkD6dr58fv0YMt2hcx7PGZMzqLKPbcMVt8e2yumRdGfyE+0xjIJw1DFjTdUbvgWQvLj/H49aQV/LazMVuFy06+llQp0uHXc8xcHaNqRRjvBTgo3p7qhgMniKyS2RyONCrYwkgTDtmZkfdI+b0WGbIsRqZHZIZ37RzzUmW2W+AVHnncL0x5wCKZyeia3c8Lx+CuPskgAp/2R59EGAFs9tP+ukWX8q3FFIk0b2S/VY/YUGlxH+Wuy+5pF2tjUDgMq7LYsdwW8lRvIR2Y65sEhmDkoglsrwa11mQczjDyhrbhf4C+9viqC55QaCq4C7TknMsH2t0pfcNlVpLFzDwrY65SxLNpjz149DxZJadsLKgqnJxjBxZEJC15KYgDXn788oYzrXEGraKE9p2MPX0pyyHZJC/CyQ1mWMcJ1pxGm3rSxvDtme6d8koiu6k5WLqoKo5pBGWI3L4Ug2olsTlO/+uOSPvr0r0TZv/uKumiVoeodlz5M48us2zWMZ2/mLK79apI6GMQSrbUVrJLA8CGfFdmQY2uxhh/eMxR05ZkNUZNitQ179+9+6neSp3djcnAycLN6tiFbB40rqy9t/S0cpLbzDB5iZut1c36NLM4W24eMk7QG/iq3gdzaaFwrS0smQstkCztqJ3fHWj8DplytkANanjlAZXfCm8seB8uZ2V3B0Ey4TZ9tFa6J0DVNQkpiajR5InOZjfrJer+6ogWQlLoSex0UT/AboAUjWKIJ69tx6/evXl/fIYRHsc/fo/HWI5lLsqi3NMo++r9z1yQBH1RkiSHRlE6BSBcQ5qrcwZNG9iWVVlLhUcZlNmFulvNOBm9yKBULoYX5Whc9KK72yZ3tFn/oFMXwxXGum1WJp8bNGtr9NnNEbWOfms4LeWhKboKY1n1NGjrKd4MC3sGurRleWRz1LXWIWA7os3x6qowbe1+9Z8zlKjJ/sJjKAmxRhs1OYodUKorJ9olPDhLLpIWYcmW4C/fFvXo0XHwsJWj/9dSMpsgBrsm/lqba53tBSVfkfO4Hj2mm3ttGeV2TqH22XnkHpFDbvf8cbtmkWxN0IiCBjMTZYdCpuKaybSZWM8WhtJmvoMQWlMsVq2uGgYxNTMYAQedpQfymFCLAgc05bOdcEcDVwW1NA6hrvliLKdLegBsSuJtFem2n0K2gjTPr2pwLIdYNCTfDs+UbYXHkj6lYx6uqNGYfO8NdmmGfCXYNZHcC0V+0KKysI58sjGqtSLmCAO0w5FDWim9zdBmuq9nGi3YmplDimwGlGY9ZeMvVANwiMK4D0wHwiVchvNpGnZJnBNx6kJrMiLIkeM+kZSotS2IlEz7z0cHzwYX3e66u0PeRrz9aTMJti8X0s1vs4SXysCGTe85YAYnYbQVbokLt1mJ/7krTWOE6jhuX3l0nNGKP5rE249vm+j2x4Y/jcSBiU3vgJWi0kyo/zmbug4Jisnq7HP8Sp4alVsPxZvCwzwKdEyc6Azru911q/D3+Zvd47LMfoHNfiPJYGcWGGe4cQLhKsb5kU1y3V1PDm3+TkdfRtzaJeOlkX1WGQp32m5iRJZKbcC92gRYDrcLe15KsZgxoNbbrPwBtf2cndJY02YGyo8nJ68JL+IkljSUzYxnlTjNstye5h7cPjVpfNd2zD/aawsgDRBrSa4shoOvwpSd/BEqWviLwN5op4mxVGYPuunKLBo3rsbgZWXDCIg2S8DLRhBx3JNE2S2mjWfssa4MR2XaXK6lYXc/n9Vvg2G1wVvyUzaC9UtdqrTcnrovsP8vqTMvaDpfup56ix1Qb4ddVY0sSMWYsDmk7JNmcEQeTxgdGI0z/bcAJDqL0aA0zB+Q2jrunevxUhXHPxQDp6MpM48OdAAo4H4RTH3EYK9VNG1bbvXO29zZa/OgXjFdVN3a23QK4+buF0ZrRxtSx8d3n5H4to5+g4xUOA9Lx1Rh0TE1e82QHxUfSlL0HBtlheQc9wuTS4XeJafb1fkRLj+TQcV3XZGAVyuhMSz83ky4G2rohxJvM3lDxYgQpFa+9kFUrthWfNfYRxqciu6uR/a8csog18acesC6bKvOovEiRyQplI4sSjXdEqetLV2XBnhTbrcWvFtT4bXhyDcUeJM/BxFRw9F1jUZFsryq3WYGvT1TCUcZ/MzyZlo/Ez6Ipj0ztMHmTf16EVQKWtwunCv9zdMLFTKKX+h6XhgfdtPtPhleCOUYv1DKMSHfoRfv3mPO1nouejwfSI/fejr6ev4CoQnRvI7JD/J6IYJlJAvvamGJjSE9N4ItpwGobBH4yYmfgtqluFkIWF6UTETIQvmqcbpqOqu0pM62+FFv7dRjziBtXvT6qRFzJ1Aydrykw6A7l/EkXIrQLyxoK+91jvlC8QRj7dgqz3zmgIgjnxZjXEQONoLyUjznC9t8S8dv5X9zEVhH3KsCsW2eM6ZaWdhm56+J0zsapOj0D6suuOIYspuT7srmHk2WLXEl4AzIwSQIgc8HL+rtvM4M/tQIhvibWFSNI1Wu6cSWuoIvaa9rzOng4L+Ewz2G4xjO2O2srsEYXNfOGP7/VdM+tF984TRaaK6drRxdLh+mYrTckFA2jF/LgtIt45SYEZc9FkUBMobUkZGvW2B42mJskwtFErTRrsltEYnaGtl0fX3k3MQPgZRSyJhWXX0fXtS3ZyyLIt88gbXNdqT+PLyvxlEmgWdjrip3duWKRSFGsZHqfOe++Z71lMJ8tLtDs5rI2UwL+sVb85URX72jzTThX7DxyWLZHF5lOai1KUyNl/F2gPaBk0kNdwRiHw972vQ2sF9jXCDnGu9iMvJAB04U572ifJihmzua6oh8d9B6QR7TwBdn8VU4edA+UFySMg/TggP/YOARgNiDI0WxnEziojiqNYti1uukoIB0MqDBIs7RTFDaS8/i23jmlBOMtkcim8hVFM8efMvY+BzlAVUQKIUh6iPt8KLWdNsZ0LKsn9eXtTBe0l4fyNWuvTvEdxhxXn/57MJAEGc9qOvyTZqwMQs4w3h6esMKNhkaugHqbADXitZ/FLTe/a2dRKGI3rkp7JAPizgQSRA084HdOB4fxDiLtjrS1ntAEkpQwcYyvCurn0f6QbKRzltk896ZZbd0uyHgbe+ayLYqicGKpp7wWk9BvUk7QTnBdpU0k+g+qIl/KPkJwa8hOB6Zm3AVnEGYO0X3o4tubU9cPPxOOl2ZBTq+a1m/7ZcaqPtRxNWqut1ZbatSuG9R3H6k9OpOq8e/1CgTy9zu7oRF5W7Q7r8kFXpWqBu9mLS6u/kJNOpbc4vg4Ldn/1T990T3PLMD9eS0Oznni1W+2T+fk9dkKQiVuvuG5jDyeC8WTWtjJgEzvUEaA62cHigFVNtHI8S/gbnzorWWTUW+LdllHVZ71st5OAncZwejZ4ejwWDkPnFHwouQvQxh/gsfJIDoMp5ld52DZ8+7o8HB/dptJCAl8pGyvVzFsXlcgpV/BPt9HAV8q4iP+LZKLIM/ACVPVfMKWoNjRcT7WbHvOfvLS1ipy9HBgT843Me29TOBDtKwIgUxaMzciMqgN62WXttTtNylwa9+80+9+Kv3P0uC7yrKZ9tI6BT2wcx5fBDgCZTWorCoOjhnY6iLAFBRr8zbWfVLfa/nGzUXm1nMSGFaJwnDrAsmZsNF70H9pvczb0SONuyBHCNGFjDjvGw94pna/rkJqx76hGt7LRtXd681S87PabFc8CmWtgR2E0kuE5BwHqS4O3JW4omVgWuZD4eITkiGRlQVzosASya/AiyK2D8WOR3f4y9KgnAVuLeLYlLOxL5TLC+DcIFR38bwSLUAEt5qwwY+j1xPWnFrwWUWARSlKlweNh4y88XZZFAyl2SH6dLyPitsb4U1MwmPwIBrjdvKk0XzI8qzXfMjKsjFb0dXmiB4Ipoe3WEA6QM0t3WwaLJt8DRvm/yqqKbxw8mb49O3r08+tIHUUsI+Yg4wL9vj2xK7xCPaqc3q9nncYebasKNtuRW3lkp86ba5Fo/Swqc6WKTQwlHCLx9WCxuXisXgyYlWG6tmZUr34HicphuGHGP433Qs150CMErTDHXEQeg6TRt7KitT9xV+VvBfNLZnMLCr0ANtLfRU7ZWY7wHfCHpuBGyZ1ZDhntmQYYc3FUGAKwn3tm1gxThZwIoTb62P9r6pEEQ16NoikS1oZ5kaaFwbLXDEHTBD2OkKWMG2XgHbW2GatAxF++1v1QzFSQJ4Y/owHgO88ZhOTmNxIuM9ZO//AVj5Dec='
_EMBEDDED_VPSCTL_SHA256 = 'a515c0f777fd89537c8bbab23173e715249a4a5d169800b467976c8cf538663c'

def _is_kvm_vpsctl(path: str) -> bool:
    """Accept only the exact integrity-checked KVM controller bundled with this bot."""
    try:
        payload = Path(path).read_bytes()
        text = payload.decode('utf-8', errors='replace')
        return (
            all(marker in text for marker in KVM_CONTROLLER_MARKERS)
            and hashlib.sha256(payload).hexdigest() == _EMBEDDED_VPSCTL_SHA256
        )
    except Exception:
        return False

def _ensure_embedded_kvm_vpsctl() -> Optional[str]:
    """Install the hash-verified embedded KVM controller outside the seven-file bundle.

    Only /usr/local/sbin/vpsctl (or an explicit VPSCTL_PATH) is managed here; no source
    sidecar is created beside bot.py. Existing non-KVM controller files are preserved.
    """
    preferred = VPSCTL_PATH if VPSCTL_PATH and os.path.isabs(VPSCTL_PATH) else '/usr/local/sbin/vpsctl'
    candidates = list(dict.fromkeys([preferred, '/usr/local/sbin/vpsctl', '/usr/local/bin/vpsctl']))
    for raw_target in candidates:
        target = Path(raw_target)
        if target.is_file() and _is_kvm_vpsctl(str(target)):
            return str(target.resolve())
        try:
            payload = zlib.decompress(base64.b64decode(_EMBEDDED_VPSCTL_ZLIB_B64.encode('ascii'), validate=True))
            if hashlib.sha256(payload).hexdigest() != _EMBEDDED_VPSCTL_SHA256:
                raise RuntimeError('embedded KVM controller integrity check failed')
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                backup = target.with_name(f"{target.name}.legacy-{int(time.time())}")
                try:
                    target.replace(backup)
                except OSError:
                    # Never truncate/overwrite an existing file if it cannot be safely preserved.
                    continue
            temp = target.with_name(f".{target.name}.rgnodes-{os.getpid()}.tmp")
            try:
                temp.write_bytes(payload)
                os.chmod(temp, 0o755)
                os.replace(temp, target)
            finally:
                try:
                    temp.unlink()
                except FileNotFoundError:
                    pass
            if _is_kvm_vpsctl(str(target)):
                logger.warning('Installed hash-verified embedded KVM vpsctl at %s.', target)
                return str(target.resolve())
        except Exception as exc:
            logger.debug('KVM controller install attempt failed for %s: %s', target, exc)
    logger.error('Could not install the embedded KVM controller; run setup.sh as root and verify /usr/local/sbin is writable.')
    return None

def _find_kvm_vpsctl() -> Optional[str]:
    """Return a trusted KVM controller or safely install the embedded copy."""
    for candidate in VPSCTL_CANDIDATES:
        if candidate and Path(candidate).is_file() and _is_kvm_vpsctl(candidate):
            return str(Path(candidate).resolve())
    return _ensure_embedded_kvm_vpsctl()

# Custom Discord emoji names/codes. Upload your preferred animated emojis to your
# server and set these to the exact custom emoji name (or full <:name:id>/<a:name:id>).
# Emoji.gg currently documents real IDs such as `online` and `StatusOnline`; all other
# names below are safe local names you can create yourself. Unicode remains the fallback.
CUSTOM_EMOJI_NAMES = {
    # Defaults intentionally match the names in the operator's supplied emoji screenshots.
    # Resolution is case-insensitive; existing guild emoji are reused and never replaced.
    'online': os.getenv('EMOJI_ONLINE', 'StatusOnline'),
    'status': os.getenv('EMOJI_STATUS', 'StatusOnline'),
    'offline': os.getenv('EMOJI_OFFLINE', 'StatusOffline'),
    'error': os.getenv('EMOJI_ERROR', 'StatusOffline'),
    'vps': os.getenv('EMOJI_VPS', 'logo'),
    'deploy': os.getenv('EMOJI_DEPLOY', 'fire1'),
    'rocket': os.getenv('EMOJI_ROCKET', 'boost'),
    'server': os.getenv('EMOJI_SERVER', 'logo'),
    'cpu': os.getenv('EMOJI_CPU', 'Cpu'),
    'ram': os.getenv('EMOJI_RAM', 'RAM'),
    'disk': os.getenv('EMOJI_DISK', 'SSD'),
    'network': os.getenv('EMOJI_NETWORK', 'dc'),
    'docker': os.getenv('EMOJI_DOCKER', 'mc'),
    'ssh': os.getenv('EMOJI_SSH', 'tsu'),
    'ports': os.getenv('EMOJI_PORTS', 'tsu'),
    'password': os.getenv('EMOJI_PASSWORD', 'verified'),
    'reinstall': os.getenv('EMOJI_REINSTALL', 'refresh'),
    'renew': os.getenv('EMOJI_RENEW', 'date'),
    'start': os.getenv('EMOJI_START', 'greenarrow'),
    'stop': os.getenv('EMOJI_STOP', 'offline'),
    'stats': os.getenv('EMOJI_STATS', 'good'),
    'refresh': os.getenv('EMOJI_REFRESH', 'arrow1'),
    'delete': os.getenv('EMOJI_DELETE', 'wong'),
    'success': os.getenv('EMOJI_SUCCESS', 'verified'),
    'warning': os.getenv('EMOJI_WARNING', 'warning'),
    'install': os.getenv('EMOJI_INSTALL', 'fs'),
    'uninstall': os.getenv('EMOJI_UNINSTALL', 'wong'),
    'loading': os.getenv('EMOJI_LOADING', 'fire1'),
    'maintenance': os.getenv('EMOJI_MAINTENANCE', 'ann'),
    'pinggy': os.getenv('EMOJI_PINGGY', 'dc'),
    'pinggy_offline': os.getenv('EMOJI_PINGGY_OFFLINE', 'StatusOffline'),
    'user': os.getenv('EMOJI_USER', 'user'),
    'owner': os.getenv('EMOJI_OWNER', 'owner'),
    'staff': os.getenv('EMOJI_STAFF', 'staff'),
    'moderator': os.getenv('EMOJI_MODERATOR', 'mod'),
    'verified': os.getenv('EMOJI_VERIFIED', 'verified'),
    'coin': os.getenv('EMOJI_COIN', 'coin'),
    'money': os.getenv('EMOJI_MONEY', 'money'),
    'gift': os.getenv('EMOJI_GIFT', 'gift'),
    'boost': os.getenv('EMOJI_BOOST', 'boost'),
    'boostplan': os.getenv('EMOJI_BOOSTPLAN', 'boostplan'),
    'booster': os.getenv('EMOJI_BOOSTER', 'booster'),
    'date': os.getenv('EMOJI_DATE', 'date'),
    'bell': os.getenv('EMOJI_BELL', 'bell'),
    'announcement': os.getenv('EMOJI_ANNOUNCEMENT', 'ann'),
    'google': os.getenv('EMOJI_GOOGLE', 'google'),
    'youtube': os.getenv('EMOJI_YOUTUBE', 'yt'),
    'discord': os.getenv('EMOJI_DISCORD', 'dc'),
    'minecraft': os.getenv('EMOJI_MINECRAFT', 'mc'),
    'portal': os.getenv('EMOJI_PORTAL', 'portal'),
    'fire': os.getenv('EMOJI_FIRE', 'fire'),
    'logo': os.getenv('EMOJI_LOGO', 'logo'),
    'winner': os.getenv('EMOJI_WINNER', 'winner'),
    'legit': os.getenv('EMOJI_LEGIT', 'legit'),
    # Additional pre-existing emoji names visible in the operator screenshots.
    'hi': os.getenv('EMOJI_HI', 'hi'),
    'moneyy': os.getenv('EMOJI_MONEYY', 'moneyy'),
    'gift2': os.getenv('EMOJI_GIFT2', 'gift2'),
    'gift1': os.getenv('EMOJI_GIFT1', 'gift1'),
    'rolesss': os.getenv('EMOJI_ROLESSS', 'rolesss'),
    'funny': os.getenv('EMOJI_FUNNY', 'funny'),
    'dollar': os.getenv('EMOJI_DOLLAR', 'dollar'),
    'happy': os.getenv('EMOJI_HAPPY', 'happy'),
    'wong': os.getenv('EMOJI_WONG', 'wong'),
    'right': os.getenv('EMOJI_RIGHT', 'right'),
    'arrow1': os.getenv('EMOJI_ARROW1', 'arrow1'),
    'rgnodes_logo': os.getenv('EMOJI_RGNODES_LOGO', 'rgnodes_logo'),
    'bedrock': os.getenv('EMOJI_BEDROCK', 'bedrock'),
    'fs': os.getenv('EMOJI_FS', 'fs'),
    'cools': os.getenv('EMOJI_COOLS', 'cools'),
    'dev': os.getenv('EMOJI_DEV', 'dev'),
    'gsupport': os.getenv('EMOJI_GSUPPORT', 'gsupport'),
    'greenarrow': os.getenv('EMOJI_GREENARROW', 'greenarrow'),
    'win1': os.getenv('EMOJI_WIN1', 'win1'),
    'win2': os.getenv('EMOJI_WIN2', 'win2'),
    'win3': os.getenv('EMOJI_WIN3', 'win3'),
    'time': os.getenv('EMOJI_TIME', 'time'),
    'book': os.getenv('EMOJI_BOOK', 'book'),
    'tsu': os.getenv('EMOJI_TSU', 'tsu'),
    'ssd': os.getenv('EMOJI_SSD', 'SSD'),
    'cpu_chip': os.getenv('EMOJI_CPU', 'Cpu'),
    'ram_chip': os.getenv('EMOJI_RAM', 'RAM'),
    'statusonline': os.getenv('EMOJI_ONLINE', 'StatusOnline'),
    'statusoffline': os.getenv('EMOJI_OFFLINE', 'StatusOffline'),
    'os_ubuntu': os.getenv('EMOJI_OS_UBUNTU', 'ubantu'),
    'os_debian': os.getenv('EMOJI_OS_DEBIAN', 'dabien'),
    'os_alpine': os.getenv('EMOJI_OS_ALPINE', 'alpine'),
    'os_centos7': os.getenv('EMOJI_OS_CENTOS7', 'centos7'),
}

# Equivalent names are lookup-only fallbacks. The bot never uploads an alias when one of
# these existing server emoji is available; configured .env names remain the preferred names.
CUSTOM_EMOJI_ALIASES = {
    'online': ('online', 'statusonline'), 'status': ('online', 'statusonline'),
    'offline': ('offline', 'statusoffline'), 'error': ('offline', 'statusoffline', 'wong', 'wrong'),
    'vps': ('server', 'vps'), 'deploy': ('fire', 'fs'), 'rocket': ('winner', 'fire1'),
    'server': ('vps', 'bedrock'), 'cpu': ('cpu', 'cpu_chip'), 'cpu_chip': ('cpu', 'cpu_chip'),
    'ram': ('ram', 'ram_chip'), 'ram_chip': ('ram', 'ram_chip'), 'disk': ('ssd', 'disk'), 'ssd': ('disk', 'ssd'),
    'network': ('discord', 'network'), 'docker': ('docker',), 'ssh': ('ssh', 'tsu'), 'ports': ('ports', 'tsu'),
    'password': ('password', 'verified'), 'reinstall': ('refresh', 'right'), 'renew': ('time', 'calendar'),
    'start': ('right', 'online'), 'stop': ('offline', 'statusoffline'), 'stats': ('good', 'stats'),
    'refresh': ('right', 'refresh'), 'delete': ('wrong', 'wong'), 'success': ('right', 'online'),
    'warning': ('cools',), 'install': ('install', 'winner'), 'uninstall': ('wrong', 'wong'),
    'maintenance': ('warning', 'bell'), 'pinggy': ('discord', 'network'),
    'pinggy_offline': ('offline', 'statusoffline'), 'announcement': ('bell', 'announcement'),
    'google': ('google',), 'youtube': ('youtube',), 'discord': ('discord',), 'minecraft': ('minecraft',),
    'portal': ('portal',), 'fire': ('fire1',), 'logo': ('rgnodes_logo',),
    'os_ubuntu': ('ubantu', 'ubuntu'), 'os_debian': ('dabien', 'debian'),
    'os_alpine': ('alpine', 'alpinelinux'), 'os_centos7': ('centos7', 'centos_stream', 'centos'),
    'os_rocky': ('rocky', 'rockylinux'), 'os_alma': ('alma', 'almalinux'), 'os_fedora': ('fedora',),
    'coin': ('money', 'dollar'), 'money': ('moneyy', 'dollar'), 'gift': ('gift1', 'gift2'),
    'boost': ('booster', 'boostplan'), 'user': ('rolesss',), 'owner': ('staff',),
    'moderator': ('mod',), 'verified': ('legit',),
}

# VPS Expiration Settings
DEFAULT_VPS_EXPIRATION_DAYS = max(1, env_int('DEFAULT_VPS_EXPIRATION_DAYS', '30'))
EXPIRATION_WARNING_DAYS = max(0, env_int('EXPIRATION_WARNING_DAYS', '3'))
EXPIRATION_AUTO_SUSPEND = env_bool('EXPIRATION_AUTO_SUSPEND', True)
EXPIRATION_CHECK_INTERVAL = max(60, min(86400, env_int('EXPIRATION_CHECK_INTERVAL', '900')))

# Public self-service VPS policy. IP-per-account enforcement requires a verified public
# website/signup session; Discord gateway events do not expose a member's IP address.
PUBLIC_VPS_ENABLED = env_bool('PUBLIC_VPS_ENABLED', True)
PUBLIC_VPS_MAX_RAM = max(1, min(MAX_VPS_RAM_GB, env_int('PUBLIC_VPS_MAX_RAM', '6')))
PUBLIC_VPS_MAX_CPU = max(1, min(MAX_VPS_CPU, env_int('PUBLIC_VPS_MAX_CPU', '2')))
PUBLIC_VPS_MAX_DISK = max(VPS_MIN_DISK_GB, min(VPS_MAX_DISK_GB, env_int('PUBLIC_VPS_MAX_DISK', '20')))
PUBLIC_VPS_EXPIRY_DAYS = max(1, env_int('PUBLIC_VPS_EXPIRY_DAYS', '5'))
PUBLIC_VPS_MAX_PER_USER = max(1, env_int('PUBLIC_VPS_MAX_PER_USER', '1'))
PUBLIC_VPS_MAX_PER_IP = max(1, env_int('PUBLIC_VPS_MAX_PER_IP', '1'))
PUBLIC_VPS_REQUIRE_VERIFICATION = env_bool('PUBLIC_VPS_REQUIRE_VERIFICATION', False)
PUBLIC_VPS_GLOBAL_LIMIT = max(1, env_int('PUBLIC_VPS_GLOBAL_LIMIT', '100'))
PUBLIC_VPS_RENEWAL_ENABLED = env_bool('PUBLIC_VPS_RENEWAL_ENABLED', True)
PUBLIC_VPS_RENEWAL_DAYS = max(1, env_int('PUBLIC_VPS_RENEWAL_DAYS', '2'))
PUBLIC_VPS_RENEWAL_WINDOW_DAYS = max(0, env_int('PUBLIC_VPS_RENEWAL_WINDOW_DAYS', '1'))
PUBLIC_VPS_COOLDOWN_HOURS = max(0, env_int('PUBLIC_VPS_COOLDOWN_HOURS', '24'))
PUBLIC_VPS_REQUIRE_ACCOUNT_AGE = max(0, env_int('PUBLIC_VPS_REQUIRE_ACCOUNT_AGE', '3'))
PUBLIC_VPS_PROCESSOR_NAME = (os.getenv('PUBLIC_VPS_PROCESSOR_NAME') or 'RGNODES™ Reliable').strip()
PUBLIC_VPS_HOSTNAME = VPS_HOSTNAME

# Command token bucket: refill one token every RATE_LIMIT_COOLDOWN seconds, burst is bounded.
RATE_LIMIT_COOLDOWN = max(0.1, min(60.0, env_float('RATE_LIMIT_COOLDOWN', '2')))
RATE_LIMIT_BURST = max(1, min(100, env_int('RATE_LIMIT_BURST', '5')))
RATE_LIMIT_MAX_VIOLATIONS = max(1, min(100, env_int('RATE_LIMIT_MAX_VIOLATIONS', '5')))
RATE_LIMIT_ABUSE_TIMEOUT = max(5, min(86400, env_int('RATE_LIMIT_ABUSE_TIMEOUT', '120')))
_RATE_LIMIT_STATE: Dict[int, Dict[str, float]] = {}


# SSH Configuration
SSH_FIX_SCRIPT = None  # Deprecated; configure_ssh uses an sshd_config.d drop-in.


# OS Options for VPS Creation and Reinstall
OS_OPTIONS = [
    {"label": "Ubuntu 26.04 LTS · Resolute Raccoon", "value": "ubuntu:26.04", "emoji": ":ubantu:", "emoji_key": "os_ubuntu"},
    {"label": "Ubuntu 24.04 LTS · Noble Numbat", "value": "ubuntu:24.04", "emoji": ":ubantu:", "emoji_key": "os_ubuntu"},
    {"label": "Ubuntu 22.04 LTS · Jammy Jellyfish", "value": "ubuntu:22.04", "emoji": ":ubantu:", "emoji_key": "os_ubuntu"},
    {"label": "Ubuntu 20.04 LTS · Legacy", "value": "ubuntu:20.04", "emoji": ":ubantu:", "emoji_key": "os_ubuntu"},
    {"label": "Debian 13 · Trixie", "value": "images:debian/13", "emoji": ":debian:", "emoji_key": "os_debian"},
    {"label": "Debian 12 · Bookworm", "value": "images:debian/12", "emoji": ":debian:", "emoji_key": "os_debian"},
    {"label": "Debian 11 · Bullseye · Legacy", "value": "images:debian/11", "emoji": ":debian:", "emoji_key": "os_debian"},
    {"label": "Alpine 3.24", "value": "alpine:3.24", "emoji": ":alpine:", "emoji_key": "os_alpine"},
    {"label": "CentOS 10", "value": "centos-stream:10", "emoji": ":centos:", "emoji_key": "os_centos7"},
]


# Configure logging to file and console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(str(BASE_DIR / 'bot.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(f'{BOT_NAME.lower()}_vps_bot')

# Prevent accidental duplicate Discord gateway sessions.
PROCESS_LOCK_HANDLE = None
try:
    import fcntl
    _lock_path = Path(__file__).resolve().parent / 'bot-process.lock'
    PROCESS_LOCK_HANDLE = open(_lock_path, 'a+', encoding='utf-8')
    fcntl.flock(PROCESS_LOCK_HANDLE.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    print('Another RGNODES™ bot process is already running; exiting.', file=sys.stderr)
    raise SystemExit(1)
except Exception as _lock_error:
    print(f'Warning: bot process lock unavailable: {_lock_error}', file=sys.stderr)

# ═══════════════════════════════════════════════════════════════════════════
# ROBUST SQLITE DATABASE SYSTEM - PERSISTENT + CRASH SAFE + SILENT SAVES
# ═══════════════════════════════════════════════════════════════════════════

import atexit
from pathlib import Path

# Persistent data lives OUTSIDE the git checkout (default /var/lib/rgnodes-vps/data), so
# deleting and re-cloning /root/Bot2 can never wipe the database, DB backups or VPS backups.
# Override with RGNODES_DATA_DIR. If that directory cannot be created (non-root dev machine),
# the bot falls back to the old behaviour of keeping data beside bot.py.
BASE_DIR = Path(__file__).resolve().parent
_data_dir_env = os.getenv('RGNODES_DATA_DIR', '').strip()
DATA_DIR = Path(_data_dir_env) if _data_dir_env else Path(os.getenv('RGNODES_VPS_ROOT', '/var/lib/rgnodes-vps')) / 'data'
try:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(DATA_DIR, 0o700)
    if not os.access(DATA_DIR, os.W_OK):
        raise PermissionError(str(DATA_DIR))
except OSError as _data_dir_exc:
    print(f'[RGNODES] WARNING: cannot use persistent data dir {DATA_DIR} ({_data_dir_exc}); using {BASE_DIR}', file=sys.stderr)
    DATA_DIR = BASE_DIR

DB_FILE = str(DATA_DIR / "vps.db")
DB_BACKUP_DIR = DATA_DIR / "db_backups"
DB_LOCK = threading.RLock()

DB_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
VPS_BACKUP_DIR = DATA_DIR / VPS_BACKUP_DIR_NAME
VPS_BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def _migrate_legacy_data() -> None:
    """One-time, non-destructive import of data from the old in-repo layout.

    The legacy files are COPIED (SQLite online-backup API for the DB) and never deleted.
    Nothing is migrated if the new database already exists.
    """
    if DATA_DIR == BASE_DIR:
        return
    legacy_db = BASE_DIR / 'vps.db'
    if legacy_db.is_file() and not Path(DB_FILE).exists():
        try:
            src = sqlite3.connect(str(legacy_db), timeout=30)
            try:
                dst = sqlite3.connect(DB_FILE)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
            finally:
                src.close()
            os.chmod(DB_FILE, 0o600)
            print(f'[RGNODES] Migrated legacy database {legacy_db} -> {DB_FILE} (original kept).', file=sys.stderr)
        except Exception as exc:
            try:
                Path(DB_FILE).unlink()
            except OSError:
                pass
            print(f'[RGNODES] WARNING: legacy database migration failed: {exc}', file=sys.stderr)
    for legacy_dir, new_dir in ((BASE_DIR / 'db_backups', DB_BACKUP_DIR), (BASE_DIR / VPS_BACKUP_DIR_NAME, VPS_BACKUP_DIR)):
        try:
            if legacy_dir.is_dir() and legacy_dir.resolve() != new_dir.resolve():
                for item in legacy_dir.iterdir():
                    target = new_dir / item.name
                    if item.is_file() and not target.exists():
                        shutil.copy2(item, target)
        except Exception as exc:
            print(f'[RGNODES] WARNING: could not copy legacy backups from {legacy_dir}: {exc}', file=sys.stderr)


_migrate_legacy_data()


def get_db():
    """Open a reliable SQLite connection for persistent bot data."""
    conn = sqlite3.connect(
        DB_FILE,
        timeout=30.0,
        check_same_thread=False,
    )
    conn.row_factory = sqlite3.Row

    # WAL is configured once during init_db(). These settings are safe
    # for concurrent reads and writes and avoid unnecessary lock errors.
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("PRAGMA synchronous=FULL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA wal_autocheckpoint=1000")
    return conn


def backup_database():
    """Create a consistent SQLite backup without noisy console output."""
    try:
        if not os.path.exists(DB_FILE):
            return

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = DB_BACKUP_DIR / f"vps_backup_{timestamp}.db"

        with DB_LOCK:
            source = get_db()
            try:
                destination = sqlite3.connect(str(backup_path))
                try:
                    source.backup(destination)
                finally:
                    destination.close()
            finally:
                source.close()

        # Preserve all historical database backups. Retention/cleanup must be an
        # explicit administrator action; a bot upgrade must never delete backups.
    except Exception as e:
        logger.error(f"Database backup failed: {e}")


def detect_local_node_location() -> str:
    """Best-effort one-time region lookup for Local Node; never blocks startup for long.

    The request exposes the host's public egress IP to the geo provider. It runs only when
    the local node has no meaningful saved location and has strict connect/read timeouts.
    """
    if str(os.getenv('NODE_LOCATION_AUTO_DETECT', 'true')).strip().lower() not in {'0','false','no','off'}:
        try:
            response = requests.get(
                'https://ipapi.co/json/',
                headers={'User-Agent': 'RGNODES-Node-Location/9.4.2'},
                timeout=(1.0, 1.5),
            )
            if response.status_code == 200:
                data = response.json()
                if isinstance(data, dict) and not data.get('error'):
                    city = str(data.get('city') or '').strip()
                    region = str(data.get('region') or data.get('region_code') or '').strip()
                    country = str(data.get('country_name') or data.get('country') or '').strip()
                    parts = [x for x in (city, region, country) if x]
                    if parts:
                        return ', '.join(parts)[:100]
        except (requests.RequestException, ValueError, TypeError, AttributeError):
            pass
    # No outward HTTP fallback: use the configured system timezone when geo lookup is offline.
    try:
        timezone = Path('/etc/timezone').read_text(encoding='utf-8', errors='ignore').strip()
        if timezone and len(timezone) <= 80:
            return f'{timezone} (timezone fallback)'
    except OSError:
        pass
    return 'Auto-detected (location unavailable)'


def ensure_node_schema_columns(cur) -> None:
    """Migrate legacy node tables before queries reference newer node fields."""
    columns_needed = {
        'location': 'location TEXT',
        'total_vps': 'total_vps INTEGER DEFAULT 100',
        'tags': "tags TEXT DEFAULT '[]'",
        'api_key': 'api_key TEXT',
        'url': 'url TEXT',
        'is_local': 'is_local INTEGER DEFAULT 0',
        'created_at': 'created_at TEXT',
        'last_updated': 'last_updated TEXT',
    }
    cur.execute('PRAGMA table_info(nodes)')
    existing = {row[1] for row in cur.fetchall()}
    for column, ddl in columns_needed.items():
        if column not in existing:
            cur.execute(f'ALTER TABLE nodes ADD COLUMN {ddl}')
            existing.add(column)


def ensure_local_node_record(cur) -> None:
    """Create one Local Node safely, refresh placeholder locations, and handle legacy name collisions."""
    cur.execute('SELECT id, location FROM nodes WHERE is_local = 1 ORDER BY id LIMIT 1')
    local_node = cur.fetchone()
    if local_node is None:
        local_name = 'Node - i'
        suffix = 1
        while cur.execute('SELECT 1 FROM nodes WHERE name = ?', (local_name,)).fetchone():
            suffix += 1
            local_name = f'Local Node (Host {suffix})'
        local_location = detect_local_node_location()
        cur.execute("INSERT INTO nodes (name, location, total_vps, tags, api_key, url, is_local) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (local_name, local_location, LOCAL_NODE_SLOTS, json.dumps(['local', 'kvm', 'qemu']), None, None, 1))
    else:
        # Keep the Local Node capacity operator-configurable without changing remote-node limits.
        cur.execute('UPDATE nodes SET total_vps=?, last_updated=CURRENT_TIMESTAMP WHERE id=? AND COALESCE(total_vps, 0) != ?',
                    (LOCAL_NODE_SLOTS, int(local_node[0]), LOCAL_NODE_SLOTS))
        if str(local_node[1] or '').strip().lower() in {'', 'local', 'unknown', 'auto-detected (location unavailable)'}:
            local_location = detect_local_node_location()
            cur.execute('UPDATE nodes SET location=?, last_updated=CURRENT_TIMESTAMP WHERE id=?', (local_location, int(local_node[0])))


def init_db():
    """Create/migrate every persistent table and verify database integrity."""
    with DB_LOCK:
        conn = get_db()
        try:
            if os.path.exists(DB_FILE):
                backup_database()
            # Configure WAL once instead of running journal_mode=WAL on every
            # connection. Repeated journal changes can cause lock errors.
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=FULL")
            conn.execute("PRAGMA foreign_keys=ON")

            cur = conn.cursor()

            cur.execute("""
                CREATE TABLE IF NOT EXISTS admins (
                    user_id TEXT PRIMARY KEY,
                    added_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cur.execute(
                "INSERT OR IGNORE INTO admins (user_id) VALUES (?)",
                (str(MAIN_ADMIN_ID),),
            )
            for configured_admin_id in CONFIG_ADMIN_IDS:
                cur.execute(
                    "INSERT OR IGNORE INTO admins (user_id) VALUES (?)",
                    (configured_admin_id,),
                )

            cur.execute("""
                CREATE TABLE IF NOT EXISTS nodes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL,
                    location TEXT,
                    total_vps INTEGER,
                    tags TEXT DEFAULT '[]',
                    api_key TEXT,
                    url TEXT,
                    is_local INTEGER DEFAULT 0,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    last_updated TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Migrate before the first query against fields introduced by newer releases.
            # Local registration is idempotent and protects against a legacy remote name collision.
            ensure_node_schema_columns(cur)
            ensure_local_node_record(cur)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS vps (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    node_id INTEGER NOT NULL DEFAULT 1,
                    container_name TEXT UNIQUE NOT NULL,
                    ram TEXT NOT NULL,
                    cpu TEXT NOT NULL,
                    storage TEXT NOT NULL,
                    config TEXT NOT NULL,
                    os_version TEXT DEFAULT 'ubuntu:22.04',
                    status TEXT DEFAULT 'stopped',
                    suspended INTEGER DEFAULT 0,
                    whitelisted INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    shared_with TEXT DEFAULT '[]',
                    suspension_history TEXT DEFAULT '[]',
                    expiration_date TEXT DEFAULT NULL,
                    root_password TEXT DEFAULT NULL,
                    last_modified TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (node_id) REFERENCES nodes(id)
                )
            """)

            # Safe migrations for databases created by older bot versions.
            # SQLite does not permit non-constant defaults on ALTER TABLE ADD COLUMN,
            # so timestamp columns are added without a default and then backfilled.
            def ensure_column(table: str, column: str, ddl: str):
                cur.execute(f"PRAGMA table_info({table})")
                existing = {row[1] for row in cur.fetchall()}
                if column not in existing:
                    cur.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")

            ensure_column("nodes", "last_updated", "last_updated TEXT")
            ensure_column("vps", "os_version", "os_version TEXT DEFAULT 'ubuntu:22.04'")
            ensure_column("vps", "product_type", "product_type TEXT DEFAULT 'KVM'")
            cur.execute("UPDATE vps SET product_type = 'DOCKER' WHERE LOWER(COALESCE(config, '')) LIKE 'docker vps%' AND COALESCE(product_type, 'KVM') != 'DOCKER'")
            ensure_column("vps", "node_id", "node_id INTEGER DEFAULT 1")
            ensure_column("vps", "expiration_date", "expiration_date TEXT DEFAULT NULL")
            ensure_column("vps", "root_password", "root_password TEXT DEFAULT NULL")
            ensure_column("vps", "last_modified", "last_modified TEXT")
            ensure_column("vps", "pinggy_host", "pinggy_host TEXT DEFAULT NULL")
            ensure_column("vps", "pinggy_port", "pinggy_port INTEGER")
            ensure_column("vps", "pinggy_url", "pinggy_url TEXT DEFAULT NULL")
            ensure_column("vps", "pinggy_pid", "pinggy_pid INTEGER")
            ensure_column("vps", "pinggy_started_at", "pinggy_started_at TEXT DEFAULT NULL")
            ensure_column("vps", "bandwidth_gb", "bandwidth_gb INTEGER DEFAULT 50")
            ensure_column("vps", "bandwidth_used_bytes", "bandwidth_used_bytes INTEGER DEFAULT 0")
            ensure_column("vps", "bandwidth_cycle_start", "bandwidth_cycle_start TEXT DEFAULT NULL")
            ensure_column("vps", "bandwidth_last_rx_bytes", "bandwidth_last_rx_bytes INTEGER DEFAULT 0")
            ensure_column("vps", "bandwidth_last_tx_bytes", "bandwidth_last_tx_bytes INTEGER DEFAULT 0")
            ensure_column("vps", "bandwidth_last_sample_at", "bandwidth_last_sample_at TEXT DEFAULT NULL")
            ensure_column("vps", "ssh_ready", "ssh_ready INTEGER DEFAULT 0")
            # Inert legacy SSHX columns may remain in older SQLite databases; clear stale URLs once.
            cur.execute("PRAGMA table_info(vps)")
            _vps_columns = {row[1] for row in cur.fetchall()}
            if {"sshx_url", "sshx_started_at"}.issubset(_vps_columns):
                cur.execute("UPDATE vps SET sshx_url=NULL, sshx_started_at=NULL WHERE sshx_url IS NOT NULL OR sshx_started_at IS NOT NULL")
            # Stable, concurrency-safe user-facing VPS ID. Kept separate from SQLite row id.
            ensure_column("vps", "vmid", "vmid INTEGER")
            cur.execute("""
                CREATE TABLE IF NOT EXISTS vps_vmid_sequence (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    reserved_at TEXT NOT NULL
                )
            """)
            cur.execute("UPDATE vps SET vmid = id WHERE vmid IS NULL")
            cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_vps_vmid ON vps(vmid)")
            max_vmid = int(cur.execute("SELECT COALESCE(MAX(vmid), 0) FROM vps").fetchone()[0] or 0)
            seq_row = cur.execute("SELECT seq FROM sqlite_sequence WHERE name = 'vps_vmid_sequence'").fetchone()
            current_seq = int(seq_row[0]) if seq_row and seq_row[0] is not None else 0
            if max_vmid > current_seq:
                if seq_row is None:
                    cur.execute("INSERT INTO vps_vmid_sequence (reserved_at) VALUES (CURRENT_TIMESTAMP)")
                cur.execute("UPDATE sqlite_sequence SET seq = ? WHERE name = 'vps_vmid_sequence'", (max_vmid,))
            cur.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    last_modified TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            for key, value in (
                ("cpu_threshold", "90"),
                ("ram_threshold", "90"),
                ("maintenance", "off"),
                ("logs_channel_id", "0"),
                ("motd_text", DEFAULT_MOTD_TEXT),
                ("bandwidth_gb", str(VPS_BANDWIDTH_GB)),
            ):
                cur.execute(
                    "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                    (key, value),
                )

            cur.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kind TEXT NOT NULL,
                    action TEXT NOT NULL,
                    detail TEXT DEFAULT '',
                    user_id TEXT,
                    node_id INTEGER,
                    vps_container TEXT,
                    created_at TEXT NOT NULL
                )
            """)
            cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_logs_vps ON audit_logs(vps_container, created_at)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_logs_node ON audit_logs(node_id, created_at)")

            # Reward statistics are per-guild and persistent. Automatic invite
            # attribution is only recorded when Discord exposes exactly one new
            # invite-use delta; ambiguous joins are deliberately not guessed.
            cur.execute("""
                CREATE TABLE IF NOT EXISTS user_reward_stats (
                    guild_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    invites INTEGER NOT NULL DEFAULT 0,
                    boosts INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (guild_id, user_id)
                )
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS reward_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    delta INTEGER NOT NULL,
                    detail TEXT DEFAULT '',
                    actor_id TEXT,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cur.execute("CREATE INDEX IF NOT EXISTS idx_reward_events_lookup ON reward_events(guild_id, event_type, user_id, created_at)")

            cur.execute("""
                CREATE TABLE IF NOT EXISTS port_allocations (
                    user_id TEXT PRIMARY KEY,
                    allocated_ports INTEGER DEFAULT 0,
                    last_modified TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS port_forwards (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    vps_container TEXT NOT NULL,
                    vps_port INTEGER NOT NULL,
                    host_port INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    last_modified TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Legacy installations may have older port tables. The tables must
            # exist before ALTER TABLE migrations are applied. SQLite also does
            # not allow non-constant defaults on ALTER TABLE ADD COLUMN.
            ensure_column("port_allocations", "last_modified", "last_modified TEXT")
            ensure_column("port_forwards", "last_modified", "last_modified TEXT")

            # Backfill timestamp columns for migrated rows.
            cur.execute("UPDATE nodes SET last_updated = COALESCE(last_updated, CURRENT_TIMESTAMP)")
            cur.execute("UPDATE vps SET last_modified = COALESCE(last_modified, CURRENT_TIMESTAMP)")
            cur.execute("UPDATE vps SET bandwidth_gb = COALESCE(bandwidth_gb, ?)", (VPS_BANDWIDTH_GB,))
            cur.execute("UPDATE vps SET ssh_ready = CASE WHEN COALESCE(TRIM(root_password), '') <> '' THEN 1 ELSE COALESCE(ssh_ready, 0) END")
            cur.execute("UPDATE vps SET bandwidth_used_bytes = COALESCE(bandwidth_used_bytes, 0)")
            cur.execute("UPDATE vps SET bandwidth_cycle_start = COALESCE(bandwidth_cycle_start, CURRENT_TIMESTAMP)")
            cur.execute("UPDATE vps SET bandwidth_last_rx_bytes = COALESCE(bandwidth_last_rx_bytes, 0)")
            cur.execute("UPDATE vps SET bandwidth_last_tx_bytes = COALESCE(bandwidth_last_tx_bytes, 0)")
            cur.execute("UPDATE vps SET bandwidth_last_sample_at = bandwidth_last_sample_at")
            cur.execute("UPDATE port_allocations SET last_modified = COALESCE(last_modified, CURRENT_TIMESTAMP)")
            cur.execute("UPDATE port_forwards SET last_modified = COALESCE(last_modified, CURRENT_TIMESTAMP)")

            # Repair orphaned VPS node references left by older/deleted nodes.
            local_row = cur.execute("SELECT id FROM nodes WHERE is_local = 1 ORDER BY id LIMIT 1").fetchone()
            if local_row:
                local_node_id = int(local_row[0])
                cur.execute("UPDATE vps SET node_id = ? WHERE node_id IS NULL OR node_id NOT IN (SELECT id FROM nodes)", (local_node_id,))

            # Repair old node tag values that may have been double-encoded.
            cur.execute("SELECT id, tags FROM nodes")
            for row in cur.fetchall():
                raw = row["tags"]
                try:
                    parsed = json.loads(raw or "[]")
                    if isinstance(parsed, str):
                        parsed = json.loads(parsed)
                    if not isinstance(parsed, list):
                        parsed = []
                except (TypeError, ValueError, json.JSONDecodeError):
                    parsed = []
                cur.execute(
                    "UPDATE nodes SET tags = ? WHERE id = ?",
                    (json.dumps(parsed), row["id"]),
                )

            conn.commit()

            # SQLite integrity check. This does not modify user data.
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            if integrity != "ok":
                raise sqlite3.DatabaseError(
                    f"SQLite integrity check failed: {integrity}"
                )
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def get_setting(key: str, default: Any = None):
    with DB_LOCK:
        conn = get_db()
        try:
            row = conn.execute(
                "SELECT value FROM settings WHERE key = ?", (key,)
            ).fetchone()
            return row[0] if row else default
        finally:
            conn.close()


def set_setting(key: str, value: str):
    with DB_LOCK:
        conn = get_db()
        try:
            conn.execute("""
                INSERT INTO settings (key, value, last_modified)
                VALUES (?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(key) DO UPDATE SET
                    value = excluded.value,
                    last_modified = CURRENT_TIMESTAMP
            """, (key, value))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def get_nodes() -> List[Dict]:
    with DB_LOCK:
        conn = get_db()
        try:
            rows = conn.execute("SELECT * FROM nodes ORDER BY id").fetchall()
            nodes = []
            for row in rows:
                node = dict(row)
                try:
                    tags = json.loads(node.get("tags") or "[]")
                    if isinstance(tags, str):
                        tags = json.loads(tags)
                    node["tags"] = tags if isinstance(tags, list) else []
                except (TypeError, ValueError, json.JSONDecodeError):
                    node["tags"] = []
                node["is_local"] = int(node.get("is_local", 1)) == 1
                nodes.append(node)
            return nodes
        finally:
            conn.close()


def get_node(node_id: int) -> Optional[Dict]:
    with DB_LOCK:
        conn = get_db()
        try:
            row = conn.execute(
                "SELECT * FROM nodes WHERE id = ?", (node_id,)
            ).fetchone()
            if not row:
                return None
            node = dict(row)
            try:
                tags = json.loads(node.get("tags") or "[]")
                if isinstance(tags, str):
                    tags = json.loads(tags)
                node["tags"] = tags if isinstance(tags, list) else []
            except (TypeError, ValueError, json.JSONDecodeError):
                node["tags"] = []
            node["is_local"] = int(node.get("is_local", 1)) == 1
            return node
        finally:
            conn.close()


def _decode_vps_row(row) -> Dict[str, Any]:
    vps = dict(row)
    try:
        vps["shared_with"] = json.loads(vps.get("shared_with") or "[]")
        if not isinstance(vps["shared_with"], list):
            vps["shared_with"] = []
    except (TypeError, ValueError, json.JSONDecodeError):
        vps["shared_with"] = []

    try:
        vps["suspension_history"] = json.loads(
            vps.get("suspension_history") or "[]"
        )
        if not isinstance(vps["suspension_history"], list):
            vps["suspension_history"] = []
    except (TypeError, ValueError, json.JSONDecodeError):
        vps["suspension_history"] = []

    vps["suspended"] = bool(vps.get("suspended", 0))
    vps["whitelisted"] = bool(vps.get("whitelisted", 0))
    vps["os_version"] = vps.get("os_version") or "ubuntu:22.04"
    product_type = str(vps.get("product_type") or "").strip().upper()
    if product_type not in {"KVM", "DOCKER"}:
        product_type = "DOCKER" if str(vps.get("config") or "").strip().lower().startswith("docker vps") else "KVM"
    vps["product_type"] = product_type
    vps["pinggy_host"] = vps.get("pinggy_host") or None
    try:
        vps["pinggy_port"] = int(vps.get("pinggy_port") or 0) or None
    except (TypeError, ValueError):
        vps["pinggy_port"] = None
    vps["pinggy_url"] = vps.get("pinggy_url") or None
    try:
        vps["pinggy_pid"] = int(vps.get("pinggy_pid") or 0) or None
    except (TypeError, ValueError):
        vps["pinggy_pid"] = None
    vps["pinggy_started_at"] = vps.get("pinggy_started_at") or None
    # RGNODES fixed plan: every managed VPS has exactly 50 GB/month.
    vps["bandwidth_gb"] = VPS_BANDWIDTH_GB
    try:
        vps["bandwidth_used_bytes"] = max(0, int(vps.get("bandwidth_used_bytes") or 0))
    except (TypeError, ValueError):
        vps["bandwidth_used_bytes"] = 0
    vps["bandwidth_cycle_start"] = vps.get("bandwidth_cycle_start") or datetime.now().isoformat()
    for _bw_key in ("bandwidth_last_rx_bytes", "bandwidth_last_tx_bytes"):
        try:
            vps[_bw_key] = max(0, int(vps.get(_bw_key) or 0))
        except (TypeError, ValueError):
            vps[_bw_key] = 0
    vps["bandwidth_last_sample_at"] = vps.get("bandwidth_last_sample_at") or None
    vps["ssh_ready"] = bool(vps.get("ssh_ready", 0))
    try:
        vps["vmid"] = int(vps.get("vmid") or vps.get("id") or 0)
    except (TypeError, ValueError):
        vps["vmid"] = 0
    raw_expiration = vps.get("expiration_date")
    if raw_expiration:
        try:
            datetime.fromisoformat(str(raw_expiration))
        except (TypeError, ValueError):
            logger.warning(f"Invalid expiration_date for {vps.get('container_name')}; clearing corrupt value")
            vps["expiration_date"] = None
    return vps


def get_vps_by_id(vps_id: int) -> Optional[Dict]:
    with DB_LOCK:
        conn = get_db()
        try:
            row = conn.execute(
                "SELECT * FROM vps WHERE id = ?", (vps_id,)
            ).fetchone()
            return _decode_vps_row(row) if row else None
        finally:
            conn.close()


def get_current_vps_count(node_id: int) -> int:
    with DB_LOCK:
        conn = get_db()
        try:
            return conn.execute(
                "SELECT COUNT(*) FROM vps WHERE node_id = ?", (node_id,)
            ).fetchone()[0]
        finally:
            conn.close()


def get_vps_data() -> Dict[str, List[Dict[str, Any]]]:
    with DB_LOCK:
        conn = get_db()
        try:
            rows = conn.execute("SELECT * FROM vps ORDER BY id").fetchall()
            data: Dict[str, List[Dict[str, Any]]] = {}
            for row in rows:
                vps = _decode_vps_row(row)
                user_id = str(vps["user_id"])
                data.setdefault(user_id, []).append(vps)
            return data
        finally:
            conn.close()


def reserve_vps_vmid() -> int:
    """Reserve a globally unique persistent VPS ID."""
    with DB_LOCK:
        conn = get_db()
        try:
            cur = conn.cursor()
            cur.execute("INSERT INTO vps_vmid_sequence (reserved_at) VALUES (CURRENT_TIMESTAMP)")
            vmid = int(cur.lastrowid)
            conn.commit()
            return vmid
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def get_admins() -> List[str]:
    with DB_LOCK:
        conn = get_db()
        try:
            rows = conn.execute(
                "SELECT user_id FROM admins ORDER BY user_id"
            ).fetchall()
            return [str(row["user_id"]) for row in rows]
        finally:
            conn.close()


def save_vps_data():
    """
    Persist the complete in-memory VPS state.

    Important:
    - UPSERT is based on container_name (UNIQUE), not the in-memory id.
    - This fixes the old 'UPDATE affected 0 rows' problem where data could
      disappear after restart.
    - One transaction writes the whole VPS state atomically.
    - No normal save-success messages are printed to the console.
    """
    with DB_LOCK:
        conn = get_db()
        try:
            cur = conn.cursor()
            cur.execute("BEGIN IMMEDIATE")

            for user_id, vps_list in list(vps_data.items()):
                for vps in list(vps_list):
                    container_name = str(vps.get("container_name") or "").strip()
                    if not container_name:
                        raise ValueError("Cannot persist VPS without container_name")

                    shared_json = json.dumps(
                        vps.get("shared_with", []),
                        ensure_ascii=False,
                    )
                    history_json = json.dumps(
                        vps.get("suspension_history", []),
                        ensure_ascii=False,
                    )
                    vmid = int(vps.get("vmid") or 0)
                    if vmid <= 0:
                        cur.execute("INSERT INTO vps_vmid_sequence (reserved_at) VALUES (CURRENT_TIMESTAMP)")
                        vmid = int(cur.lastrowid)
                        vps["vmid"] = vmid

                    cur.execute("""
                        INSERT INTO vps (
                            user_id, node_id, container_name, ram, cpu, storage,
                            config, product_type, os_version, status, suspended, whitelisted,
                            created_at, shared_with, suspension_history,
                            expiration_date, root_password, last_modified, vmid,
                            pinggy_host, pinggy_port, pinggy_url, pinggy_pid, pinggy_started_at,
                            bandwidth_gb, bandwidth_used_bytes, bandwidth_cycle_start,
                            bandwidth_last_rx_bytes, bandwidth_last_tx_bytes, bandwidth_last_sample_at
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(container_name) DO UPDATE SET
                            user_id = excluded.user_id,
                            node_id = excluded.node_id,
                            ram = excluded.ram,
                            cpu = excluded.cpu,
                            storage = excluded.storage,
                            config = excluded.config,
                            product_type = excluded.product_type,
                            os_version = excluded.os_version,
                            status = excluded.status,
                            suspended = excluded.suspended,
                            whitelisted = excluded.whitelisted,
                            created_at = excluded.created_at,
                            shared_with = excluded.shared_with,
                            suspension_history = excluded.suspension_history,
                            expiration_date = excluded.expiration_date,
                            root_password = excluded.root_password,
                            vmid = excluded.vmid,
                            pinggy_host = excluded.pinggy_host,
                            pinggy_port = excluded.pinggy_port,
                            pinggy_url = excluded.pinggy_url,
                            pinggy_pid = excluded.pinggy_pid,
                            pinggy_started_at = excluded.pinggy_started_at,
                            bandwidth_gb = excluded.bandwidth_gb,
                            bandwidth_used_bytes = excluded.bandwidth_used_bytes,
                            bandwidth_cycle_start = excluded.bandwidth_cycle_start,
                            bandwidth_last_rx_bytes = excluded.bandwidth_last_rx_bytes,
                            bandwidth_last_tx_bytes = excluded.bandwidth_last_tx_bytes,
                            bandwidth_last_sample_at = excluded.bandwidth_last_sample_at,
                            last_modified = CURRENT_TIMESTAMP
                    """, (
                        str(user_id),
                        int(vps.get("node_id", 1)),
                        container_name,
                        str(vps.get("ram", "0GB")),
                        str(vps.get("cpu", "0")),
                        str(vps.get("storage", "0GB")),
                        str(vps.get("config", "Custom")),
                        str(vps.get("product_type") or ("DOCKER" if str(vps.get("config") or "").lower().startswith("docker vps") else "KVM")),
                        str(vps.get("os_version", "ubuntu:22.04")),
                        str(vps.get("status", "stopped")),
                        1 if vps.get("suspended", False) else 0,
                        1 if vps.get("whitelisted", False) else 0,
                        str(vps.get("created_at") or datetime.now().isoformat()),
                        shared_json,
                        history_json,
                        vps.get("expiration_date"),
                        vps.get("root_password"),
                        vmid,
                        vps.get("pinggy_host"),
                        vps.get("pinggy_port"),
                        vps.get("pinggy_url"),
                        vps.get("pinggy_pid"),
                        vps.get("pinggy_started_at"),
                        VPS_BANDWIDTH_GB,
                        int(vps.get("bandwidth_used_bytes") or 0),
                        vps.get("bandwidth_cycle_start") or datetime.now().isoformat(),
                        int(vps.get("bandwidth_last_rx_bytes") or 0),
                        int(vps.get("bandwidth_last_tx_bytes") or 0),
                        vps.get("bandwidth_last_sample_at"),
                    ))

                    row = cur.execute(
                        "SELECT id FROM vps WHERE container_name = ?",
                        (container_name,),
                    ).fetchone()
                    if row:
                        vps["id"] = row[0]

            conn.commit()
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error(f"Database error while saving VPS data: {e}", exc_info=True)
            raise
        finally:
            conn.close()


def save_vps_data_immediate() -> bool:
    """Persist VPS data immediately and report whether persistence succeeded."""
    try:
        save_vps_data()
        return True
    except Exception as e:
        logger.error(f"Critical VPS database save failed: {e}")
        backup_database()
        return False


def save_admin_data():
    """Persist administrator data atomically."""
    with DB_LOCK:
        conn = get_db()
        try:
            cur = conn.cursor()
            cur.execute("BEGIN IMMEDIATE")

            # Keep the main admin in the database as well.
            admin_ids = {str(x) for x in admin_data.get("admins", [])}
            admin_ids.add(str(MAIN_ADMIN_ID))

            cur.execute("DELETE FROM admins")
            cur.executemany(
                "INSERT INTO admins (user_id) VALUES (?)",
                [(admin_id,) for admin_id in sorted(admin_ids)],
            )
            conn.commit()

            # Keep in-memory state consistent with the database.
            admin_data["admins"] = sorted(admin_ids)
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error(f"Database error while saving admin data: {e}", exc_info=True)
            raise
        finally:
            conn.close()


def save_admin_data_immediate():
    try:
        save_admin_data()
    except Exception as e:
        logger.error(f"Critical admin database save failed: {e}")
        backup_database()


def get_user_allocation(user_id: str) -> int:
    with DB_LOCK:
        conn = get_db()
        try:
            row = conn.execute(
                "SELECT allocated_ports FROM port_allocations WHERE user_id = ?",
                (str(user_id),),
            ).fetchone()
            return int(row[0]) if row else 0
        finally:
            conn.close()


def ensure_user_port_allocation(user_id: str) -> int:
    """Create the default quota only when no quota row exists; preserve explicit zero quotas."""
    user_id = str(user_id)
    with DB_LOCK:
        conn = get_db()
        try:
            row = conn.execute("SELECT allocated_ports FROM port_allocations WHERE user_id = ?", (user_id,)).fetchone()
            if row is not None:
                return int(row[0] or 0)
            quota = max(0, int(DEFAULT_PORT_QUOTA))
            conn.execute(
                "INSERT INTO port_allocations (user_id, allocated_ports, last_modified) VALUES (?, ?, CURRENT_TIMESTAMP)",
                (user_id, quota),
            )
            conn.commit()
            return quota
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def get_user_used_ports(user_id: str) -> int:
    with DB_LOCK:
        conn = get_db()
        try:
            return conn.execute(
                # Port 22 is the reserved management-access mapping for SSH/SFTP/Web SSH.
                # It must not consume the user's optional application-port quota.
                "SELECT COUNT(*) FROM port_forwards WHERE user_id = ? AND vps_port != 22",
                (str(user_id),),
            ).fetchone()[0]
        finally:
            conn.close()


def allocate_ports(user_id: str, amount: int):
    with DB_LOCK:
        conn = get_db()
        try:
            conn.execute("""
                INSERT INTO port_allocations (user_id, allocated_ports, last_modified)
                VALUES (?, MAX(0, ?), CURRENT_TIMESTAMP)
                ON CONFLICT(user_id) DO UPDATE SET
                    allocated_ports = MAX(0, port_allocations.allocated_ports + excluded.allocated_ports),
                    last_modified = CURRENT_TIMESTAMP
            """, (str(user_id), int(amount)))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def deallocate_ports(user_id: str, amount: int):
    with DB_LOCK:
        conn = get_db()
        try:
            conn.execute("""
                INSERT INTO port_allocations (user_id, allocated_ports, last_modified)
                VALUES (?, 0, CURRENT_TIMESTAMP)
                ON CONFLICT(user_id) DO UPDATE SET
                    allocated_ports = MAX(0, port_allocations.allocated_ports - ?),
                    last_modified = CURRENT_TIMESTAMP
            """, (str(user_id), int(amount)))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def _host_port_in_use(host_port: int) -> bool:
    """Return True when a TCP or UDP listener already occupies the port."""
    for sock_type, proto_name in ((socket.SOCK_STREAM, "tcp"), (socket.SOCK_DGRAM, "udp")):
        s = socket.socket(socket.AF_INET, sock_type)
        try:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(("0.0.0.0", host_port))
        except OSError:
            return True
        finally:
            s.close()
    return False


def get_available_host_port(node_id: int) -> Optional[int]:
    """Allocate a host port that is absent from DB and currently free on the node."""
    with DB_LOCK:
        conn = get_db()
        try:
            rows = conn.execute("""
                SELECT host_port FROM port_forwards
                WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id = ?)
            """, (node_id,)).fetchall()
            used_ports = {int(row[0]) for row in rows}
        finally:
            conn.close()

    low = max(1024, PORT_HOST_MIN)
    high = min(65535, max(low, PORT_HOST_MAX))
    candidates = list(range(low, high + 1))
    random.shuffle(candidates)
    node = get_node(node_id) or {}
    local_probe = bool(node.get('is_local'))
    for port in candidates[: min(len(candidates), 2000)]:
        if port in used_ports:
            continue
        if local_probe and _host_port_in_use(port):
            continue
        return port
    return None


async def create_port_forward(user_id: str, container: str, vps_port: int, node_id: int) -> Optional[int]:
    """Reserve a public guest port and reconcile managed guest-UFW rules when available.

    Direct/bridge mode maps the guest-owned public IP 1:1. NAT mode reserves a unique
    host port and configures tagged host DNAT to the guest's private DHCP address.
    """
    user_id=str(user_id); container=str(container).strip()
    try: vps_port=int(vps_port)
    except (TypeError,ValueError): return None
    if not container or not (1<=vps_port<=65535): return None
    async with PORT_OPERATION_LOCK:
        node_mode=await get_node_network_mode(node_id)
        endpoints=await detect_public_endpoints(node_id,container)
        public_v4=str(endpoints.get('ipv4') or '').strip()
        if REAL_PUBLIC_IPV4_REQUIRED and not public_v4:
            raise RuntimeError('Cannot reserve a public port: no real public endpoint was detected. In direct/bridge mode configure provider-routed guest IPv4; in NAT mode configure the node host public IPv4 and AUTO_DETECT_PUBLIC_IP=true.')
        with DB_LOCK:
            conn=get_db()
            try:
                duplicate=conn.execute('SELECT host_port FROM port_forwards WHERE vps_container = ? AND vps_port = ?', (container,vps_port)).fetchone()
                duplicate_port = int(duplicate[0]) if duplicate else None
            finally: conn.close()
        if duplicate_port is not None:
            # Never await while holding DB_LOCK; another coroutine may need this lock.
            await execute_vpsctl_compat(container, f'port-add {shlex.quote(container)} {duplicate_port} {vps_port} --proto tcp', node_id=node_id, timeout=90)
            return duplicate_port
        # SSH (guest port 22) is mandatory management access, not a customer-added
        # application port. Reserve it even when the user's optional port quota is zero.
        if vps_port != 22:
            allocated=ensure_user_port_allocation(user_id); used=get_user_used_ports(user_id)
            if allocated<=0 or used>=allocated:
                logger.warning('Port quota exhausted for user %s: %s/%s',user_id,used,allocated); return None
        if node_mode not in {'direct','bridge','nat'}:
            raise RuntimeError(f'Unsupported KVM network mode for public port exposure: {node_mode}')
        host_port = get_available_host_port(node_id) if node_mode == 'nat' else vps_port
        if not host_port:
            raise RuntimeError('No free host port is available in PORT_HOST_MIN..PORT_HOST_MAX. Increase the configured range or release an unused port.')
        with DB_LOCK:
            conn=get_db()
            try:
                conn.execute('INSERT INTO port_forwards (user_id, vps_container, vps_port, host_port, created_at, last_modified) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)',(user_id,container,vps_port,host_port,datetime.now().isoformat()))
                conn.commit()
            except Exception:
                conn.rollback(); raise
            finally: conn.close()
        try:
            await execute_vpsctl_compat(container, f'port-add {shlex.quote(container)} {host_port} {vps_port} --proto tcp', node_id=node_id, timeout=90)
        except Exception:
            # Roll back only this newly inserted port record; do not touch the VPS disk/data.
            with DB_LOCK:
                conn=get_db()
                try:
                    conn.execute('DELETE FROM port_forwards WHERE user_id = ? AND vps_container = ? AND vps_port = ?', (user_id,container,vps_port)); conn.commit()
                except Exception:
                    conn.rollback(); raise
                finally: conn.close()
            raise
        return host_port

async def remove_port_forward(forward_id: int, requester_id: Optional[str] = None, is_admin: bool = False) -> tuple[bool, Optional[str]]:
    async with PORT_OPERATION_LOCK:
        with DB_LOCK:
            conn=get_db()
            try:
                row=conn.execute('SELECT user_id, vps_container, host_port, vps_port FROM port_forwards WHERE id = ?', (int(forward_id),)).fetchone()
            finally: conn.close()
        if not row: return False,None
        owner_id=str(row[0]); container=str(row[1]); host_port=int(row[2]); vps_port=int(row[3])
        if not is_admin and str(requester_id)!=owner_id: return False,owner_id
        try:
            node_id=find_node_id_for_container(container)
            operation_result = await execute_vpsctl_compat(container, f'port-remove {shlex.quote(container)} {host_port} --guest-port {vps_port} --proto tcp', node_id=node_id, timeout=90)
            if isinstance(operation_result, dict) and operation_result.get('status') == 'pending-reconcile':
                logger.warning('Guest firewall removal pending; keeping DB row for reconciliation: %s:%s', container, vps_port)
                return False, owner_id
        except Exception as exc:
            # Refuse to report successful removal when a managed guest firewall could not
            # be reconciled. The persistent DB row remains available for retry.
            logger.warning('Guest port removal could not be verified for %s:%s: %s',container,vps_port,exc)
            return False,owner_id
        with DB_LOCK:
            conn=get_db()
            try:
                conn.execute('DELETE FROM port_forwards WHERE id = ?', (int(forward_id),)); conn.commit()
            except Exception:
                conn.rollback(); raise
            finally: conn.close()
        return True,owner_id

def get_user_forwards(user_id: str) -> List[Dict]:
    with DB_LOCK:
        conn = get_db()
        try:
            rows = conn.execute("SELECT * FROM port_forwards WHERE user_id = ? ORDER BY created_at DESC", (str(user_id),)).fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()


async def recreate_port_forwards(container_name: str, node_id_override: Optional[int] = None) -> int:
    """Reconcile persisted public guest ports and migrate legacy host-port mappings safely."""
    node_id=int(node_id_override or find_node_id_for_container(container_name))
    node_mode=await get_node_network_mode(node_id)
    with DB_LOCK:
        conn=get_db()
        try:
            rows=conn.execute(
                "SELECT id, vps_port, host_port FROM port_forwards WHERE vps_container = ?",
                (container_name,),
            ).fetchall()
            updates=[]; snapshots=[]
            for row in rows:
                row_id=int(row[0]); vps_port=int(row[1]); host_port=int(row[2])
                if node_mode in {'direct','bridge'} and host_port != vps_port:
                    updates.append((vps_port,row_id))
                    host_port=vps_port
                snapshots.append((vps_port, host_port))
            if updates:
                conn.executemany("UPDATE port_forwards SET host_port = ?, last_modified = CURRENT_TIMESTAMP WHERE id = ?", updates)
                conn.commit()
        finally:
            conn.close()
    if snapshots:
        for vps_port, host_port in snapshots:
            try:
                await execute_vpsctl_compat(container_name, f'port-add {shlex.quote(container_name)} {host_port} {vps_port} --proto tcp', node_id=node_id, timeout=60)
            except Exception as exc:
                logger.debug('Guest firewall reconciliation deferred for %s:%s: %s',container_name,vps_port,exc)
    return len(snapshots)

# Container stats with multi-node
async def get_container_stats(container_name: str, node_id: Optional[int] = None) -> Dict:
    """Return normalized KVM VPS statistics for legacy callers."""
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    try:
        raw = await execute_vpsctl('compat', 'stats', container_name, node_id=node_id, timeout=45)
        data = raw if isinstance(raw, dict) else json.loads(str(raw or '{}'))
        return {
            'status': str(data.get('status','unknown')).lower(),
            'cpu': float(data.get('cpu') or 0.0),
            'ram': data.get('ram') or {'used':0,'total':0,'pct':0.0},
            'disk': data.get('disk','Unknown'),
            'uptime': data.get('uptime','Unknown'),
            'public_ipv4': data.get('public_ipv4'),
            'limits': {'ram_gb': data.get('ram_limit_gb'), 'cpu': data.get('cpu_limit'), 'disk_gb': data.get('disk_limit_gb')},
            'ram_current_gb': data.get('ram_current_gb') or data.get('ram',{}).get('total',0),
            'cpu_current': data.get('cpu_current') or 1,
            'disk_used_bytes': data.get('disk_used_bytes') or 0,
        }
    except Exception as exc:
        logger.debug(f'KVM VPS status failed for {container_name}: {exc}')
        return {'status':'unknown','cpu':0.0,'ram':{'used':0,'total':0,'pct':0.0},'disk':'Unknown','uptime':'Unknown'}


async def get_container_status(container_name: str, node_id: Optional[int] = None):
    stats = await get_container_stats(container_name, node_id)
    return stats['status']

async def get_container_cpu(container_name: str, node_id: Optional[int] = None):
    stats = await get_container_stats(container_name, node_id)
    return f"{stats['cpu']:.1f}%"

async def get_container_cpu_pct(container_name: str, node_id: Optional[int] = None):
    stats = await get_container_stats(container_name, node_id)
    return stats['cpu']

async def get_container_memory(container_name: str, node_id: Optional[int] = None):
    stats = await get_container_stats(container_name, node_id)
    ram = stats['ram']
    return f"{ram['used']}/{ram['total']} MB ({ram['pct']:.1f}%)"

async def get_container_ram_pct(container_name: str, node_id: Optional[int] = None):
    stats = await get_container_stats(container_name, node_id)
    return stats['ram']['pct']

async def get_container_addresses(container_name: str, node_id: Optional[int] = None) -> Dict[str, List[str]]:
    """Return actual guest IPv4 and globally-scoped IPv6 addresses."""
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    result: Dict[str, List[str]] = {"ipv4": [], "ipv6": []}
    try:
        v4 = await execute_vpsctl_compat(container_name, f"exec {container_name} -- ip -4 -o addr show scope global", timeout=20, node_id=node_id)
        for line in str(v4 or '').splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[2] == 'inet':
                addr = parts[3].split('/',1)[0]
                if addr and addr not in result['ipv4'] and not addr.startswith('127.'):
                    result['ipv4'].append(addr)
    except Exception as e:
        logger.debug(f'IPv4 discovery failed for {container_name}: {e}')
    try:
        v6 = await execute_vpsctl_compat(container_name, f"exec {container_name} -- ip -6 -o addr show scope global", timeout=20, node_id=node_id)
        for line in str(v6 or '').splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[2] == 'inet6':
                addr = parts[3].split('/',1)[0]
                if addr and addr not in result['ipv6'] and addr != '::1' and not addr.lower().startswith('fe80:'):
                    result['ipv6'].append(addr)
    except Exception as e:
        logger.debug(f'IPv6 discovery failed for {container_name}: {e}')
    return result

async def get_container_networks(container_name: str, node_id: Optional[int] = None) -> Dict[str, str]:
    """Backward-compatible IPv4 interface map."""
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    try:
        output = await execute_vpsctl_compat(container_name, f"exec {container_name} -- ip -4 -o addr show scope global", timeout=20, node_id=node_id)
        networks: Dict[str, str] = {}
        for line in str(output or '').splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[2] == 'inet':
                interface = parts[1].rstrip(':')
                addr = parts[3].split('/',1)[0]
                if interface != 'lo' and addr and not addr.startswith('127.'):
                    networks[interface] = addr
        return networks
    except Exception as e:
        logger.debug(f'Failed to get IPv4 networks for {container_name}: {e}')
        return {}

NODE_NETWORK_MODE_CACHE: Dict[int, tuple[str, float]] = {}


async def discover_node_public_endpoints(node_id: int) -> Dict[str, str]:
    """Discover the selected node's real public endpoint, preferring its authenticated agent."""
    def valid(value: str, version: int) -> bool:
        try:
            ip = ipaddress.ip_address(str(value).strip())
            return (
                ip.version == version and ip.is_global and not ip.is_multicast
                and not ip.is_reserved and not ip.is_unspecified
                and not ip.is_loopback and not ip.is_link_local
            )
        except Exception:
            return False

    node = get_node(int(node_id)) or {}
    # Remote discovery must use the selected VPS node, not the Discord bot host.
    if not node.get('is_local'):
        base = str(node.get('url') or '').rstrip('/')
        api_key = str(node.get('api_key') or '')
        if base and api_key:
            try:
                response = await asyncio.to_thread(
                    requests.get, base + '/api/get_access_info',
                    headers={'X-API-Key': api_key}, timeout=7,
                )
                response.raise_for_status()
                data = response.json()
                v4 = str(data.get('public_ipv4') or '').strip()
                v6 = str(data.get('public_ipv6') or '').strip()
                if valid(v4, 4) or valid(v6, 6):
                    return {
                        'ipv4': v4 if valid(v4, 4) else '',
                        'ipv6': v6 if valid(v6, 6) else '',
                    }
            except Exception as exc:
                logger.warning(
                    'Remote node public endpoint API failed for node %s (%s); trying controller fallback.',
                    node_id, type(exc).__name__,
                )

    # Ask the selected node's controller as a second, node-local source.
    # Never fall back to the Discord bot host's public IP for a remote VPS node:
    # that creates a valid-looking but incorrect SSH endpoint and breaks access.
    controller_error = None
    try:
        data = await execute_vpsctl_compat('', 'host-public-ip', node_id=int(node_id), timeout=12)
        candidate = str(data.get('ipv4') or '').strip() if isinstance(data, dict) else ''
        if valid(candidate, 4):
            return {'ipv4': candidate, 'ipv6': ''}
    except Exception as exc:
        controller_error = type(exc).__name__
        logger.debug('Node controller public IPv4 lookup failed for node %s: %s', node_id, controller_error)

    if not node.get('is_local'):
        raise RuntimeError(
            f"Could not verify the public endpoint of remote node {node.get('name', node_id)}. "
            "The bot will not substitute its own public IP. Update that node with the matching "
            "node.sh from this release, verify its saved API URL/API key, and set "
            "RGNODES_PUBLIC_IPV4 in /etc/rgnodes/node-agent.env if automatic detection is unavailable. "
            f"Controller lookup: {controller_error or 'no valid node IPv4 returned'}."
        )

    v4 = str(PUBLIC_IPV4 or '').strip()
    v6 = str(PUBLIC_IPV6 or '').strip()
    if not valid(v4, 4):
        v4 = ''
    if not valid(v6, 6):
        v6 = ''
    if AUTO_DETECT_PUBLIC_IP and not v4:
        for url in ('https://api4.ipify.org', 'https://ipv4.icanhazip.com'):
            try:
                response = await asyncio.to_thread(requests.get, url, timeout=5)
                response.raise_for_status()
                candidate = response.text.strip()
                if valid(candidate, 4):
                    v4 = candidate
                    break
            except Exception:
                continue
    if AUTO_DETECT_PUBLIC_IP and not v6:
        try:
            response = await asyncio.to_thread(requests.get, 'https://api6.ipify.org', timeout=5)
            response.raise_for_status()
            candidate = response.text.strip()
            if valid(candidate, 6):
                v6 = candidate
        except Exception:
            pass
    return {'ipv4': v4, 'ipv6': v6}


async def get_node_network_mode(node_id: int) -> str:
    """Read the actual network mode from the selected node, not the bot host's .env."""
    node=get_node(int(node_id)) or {}
    if node.get('is_local'):
        return KVM_NETWORK_MODE
    cached=NODE_NETWORK_MODE_CACHE.get(int(node_id))
    if cached and cached[1] > time.monotonic():
        return cached[0]
    base=str(node.get('url') or '').rstrip('/')
    if not base:
        raise RuntimeError(f"Remote node {node.get('name',node_id)} has no API URL. Re-register it with !node edit and a valid HTTPS/base URL.")
    try:
        response=await asyncio.to_thread(
            requests.get, base+'/api/get_access_info',
            headers={'X-API-Key':str(node.get('api_key') or '')}, timeout=5,
        )
        response.raise_for_status()
        payload=response.json()
        mode=str(payload.get('network_mode') or '').strip().lower()
        if mode not in {'direct','bridge','nat'}:
            raise RuntimeError('Remote node did not report a supported network_mode; rerun node.sh to update its agent.')
        NODE_NETWORK_MODE_CACHE[int(node_id)]=(mode,time.monotonic()+45)
        return mode
    except Exception as exc:
        logger.warning('Could not verify network mode for remote node %s: %s',node.get('name',node_id),type(exc).__name__)
        raise RuntimeError(
            f"Cannot safely determine the network mode for remote node {node.get('name',node_id)}. "
            "Update that node with the matching node.sh from this VPS-Pro release, then restart rgnodes-node-agent. "
            "The bot will not guess direct/bridge/NAT because a wrong guess can break SSH and port forwarding."
        ) from exc


async def detect_public_endpoints(node_id: int, vps_name: Optional[str] = None) -> Dict[str, str]:
    """Return real public endpoints. For a VPS, only advertise the guest's own global IPs."""
    def valid_v4(value: str) -> bool:
        try:
            import ipaddress
            ip=ipaddress.ip_address(value.strip())
            return (ip.version==4 and ip.is_global and not ip.is_multicast
                    and not ip.is_reserved and not ip.is_unspecified
                    and not ip.is_loopback and not ip.is_link_local)
        except Exception:
            return False
    def valid_v6(value: str) -> bool:
        try:
            import ipaddress
            ip=ipaddress.ip_address(value.strip())
            return (ip.version==6 and ip.is_global and not ip.is_multicast
                    and not ip.is_reserved and not ip.is_unspecified
                    and not ip.is_loopback and not ip.is_link_local)
        except Exception:
            return False

    if vps_name:
        node_mode=await get_node_network_mode(node_id)
        if node_mode == 'nat':
            # NAT mode exposes a *shared node host IPv4 + unique forwarded port*.
            # This is intentionally not described as a guest-owned public address.
            endpoints = await discover_node_public_endpoints(node_id)
            return {'ipv4': endpoints.get('ipv4', ''), 'ipv6': ''}
        try:
            addresses=await get_container_addresses(vps_name,node_id)
            v4=next((x for x in addresses.get('ipv4',[]) if valid_v4(x)), '')
            v6=next((x for x in addresses.get('ipv6',[]) if valid_v6(x)), '')
            if v4 or v6:
                return {'ipv4':v4,'ipv6':v6}
        except Exception as exc:
            logger.debug('VPS public endpoint discovery failed for %s: %s',vps_name,exc)
        return {'ipv4':'','ipv6':''}

    return await discover_node_public_endpoints(node_id)


def format_public_ssh_access(endpoints: Dict[str, str], ssh_port: Optional[int]) -> Dict[str, str]:
    result = {"ipv4": str(endpoints.get("ipv4") or ""), "ipv6": str(endpoints.get("ipv6") or ""), "ssh_ipv4": "", "ssh_ipv6": ""}
    try:
        port = int(ssh_port or 0)
    except (TypeError, ValueError):
        port = 0
    if port and result["ipv4"]:
        result["ssh_ipv4"] = "ssh root@{} -p {}".format(result["ipv4"], port)
    if port and result["ipv6"]:
        result["ssh_ipv6"] = "ssh -6 root@[{}] -p {}".format(result["ipv6"], port)
    return result


async def get_vps_ssh_endpoint(owner_id: str, container_name: str, node_id: int):
    """Return the real public host and working port for this VPS's node network mode."""
    mode=await get_node_network_mode(node_id)
    endpoints=await detect_public_endpoints(node_id,container_name)
    host=str(endpoints.get('ipv4') or '').strip()
    if not host and not IPV4_SSH_ONLY:
        host=str(endpoints.get('ipv6') or '').strip()
    if not host:
        if mode=='nat':
            raise RuntimeError('The node public IPv4 could not be auto-detected. Set PUBLIC_IPV4 or enable AUTO_DETECT_PUBLIC_IP on the node and check outbound HTTPS.')
        raise RuntimeError('The VPS does not have a verified guest public IP. A provider-routed IPv4/IPv6 or routed public subnet is required for direct/bridge mode.')
    if mode in {'direct','bridge'}:
        port=22
    else:
        # Always call create_port_forward, even if SQLite already has a row. The
        # controller's port-add operation is idempotent and restores lost iptables
        # DNAT/FORWARD rules after host or node-agent restarts.
        port=await create_port_forward(str(owner_id),str(container_name),22,int(node_id))
    if not port:
        raise RuntimeError('Could not reserve or reconcile the SSH mapping. Check the node API, public IPv4, NAT forwarding, and host/provider firewall.')
    return host,int(port),mode,endpoints


async def ensure_vps_ssh_access(owner_id: str, vps: Dict[str, Any], *, repair: bool = True) -> Dict[str, Any]:
    """Verify guest sshd and actively reconcile the public SSH mapping before sharing credentials."""
    container = str(vps.get('container_name') or '').strip()
    if not container:
        raise RuntimeError('The VPS database record has no container name.')
    if bool(vps.get('suspended', False)):
        raise RuntimeError('This VPS is suspended; access is disabled until it is renewed or unsuspended.')
    node_id = int(vps.get('node_id', 1))
    stats = await asyncio.wait_for(get_container_stats(container, node_id), timeout=30)
    if str(stats.get('status') or '').lower() != 'running':
        raise RuntimeError('The VPS is not running. Start it first, then retry access.')

    password = str(vps.get('root_password') or '').strip()
    if not password:
        password = generate_strong_password()
        vps['root_password'] = password
        save_vps_data_immediate()

    # Do not trust only the saved ssh_ready flag. Verify the actual guest daemon,
    # effective password/root policy and listening socket through QEMU Guest Agent.
    probe_script = """set -eu
SSHD=$(command -v sshd || true)
[ -n \"$SSHD\" ] || { echo SSHD_MISSING; exit 10; }
\"$SSHD\" -t
EFFECTIVE=$(\"$SSHD\" -T -C user=root,addr=127.0.0.1,localport=22 2>/dev/null)
printf '%s\\n' \"$EFFECTIVE\" | grep -qx 'passwordauthentication yes'
printf '%s\\n' \"$EFFECTIVE\" | grep -qx 'permitrootlogin yes'
printf '%s\\n' "$EFFECTIVE" | grep -Eq '^subsystem sftp '
ss -lntH 2>/dev/null | awk '$4 ~ /:(22)$/ {ok=1} END {exit ok?0:1}'
echo SSH_ACCESS_OK
"""
    guest_ok = False
    if bool(vps.get('ssh_ready')) and password:
        try:
            probe = await _exec_guest_bash(container, node_id, probe_script, timeout=25)
            guest_ok = 'SSH_ACCESS_OK' in str(probe)
        except Exception as exc:
            logger.info('SSH verification requested repair for %s (%s).', container, type(exc).__name__)

    if not guest_ok:
        if not repair:
            raise RuntimeError('The SSH daemon is not verified as ready inside this VPS. Run !repair-access to repair it.')
        ok, detail = await asyncio.wait_for(configure_ssh(container, node_id, password), timeout=135)
        if not ok:
            detail_text = str(detail or 'SSH configuration failed')[:260]
            raise RuntimeError(f'Could not configure SSH inside the VPS: {detail_text}. Check guest package/network readiness and QEMU Guest Agent.')
        vps['root_password'] = password
        vps['ssh_ready'] = True
        save_vps_data_immediate()

    host, port, mode, endpoints = await asyncio.wait_for(
        get_vps_ssh_endpoint(str(owner_id), container, node_id), timeout=90
    )
    if not host or not int(port or 0):
        raise RuntimeError('SSH daemon is ready, but no real public SSH endpoint/forwarded port was verified. Check node public IPv4 and provider inbound firewall.')
    if mode == 'nat':
        # The bot can verify its managed NAT rule operation. The provider security
        # group must separately permit PORT_HOST_MIN..PORT_HOST_MAX.
        vps['ssh_access_pending'] = False
        vps.pop('ssh_access_error_type', None)
        vps['ssh_host_port'] = int(port)
        vps['ssh_host'] = host
        save_vps_data_immediate()
    return {'host': host, 'port': int(port), 'mode': mode, 'endpoints': endpoints, 'password': password}


async def get_container_network_counters(container_name: str, node_id: Optional[int] = None) -> tuple[int, int]:
    """Return aggregate RX/TX byte counters for non-loopback guest interfaces."""
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    script = r'''set +e
rx=0; tx=0
while IFS= read -r line; do
  iface=${line%%:*}
  rest=${line#*:}
  iface=$(echo "$iface" | xargs)
  [ -n "$iface" ] || continue
  [ "$iface" = "lo" ] && continue
  read -r -a f <<< "$rest"
  [ "${#f[@]}" -ge 9 ] || continue
  [[ "${f[0]}" =~ ^[0-9]+$ ]] || continue
  [[ "${f[8]}" =~ ^[0-9]+$ ]] || continue
  rx=$((rx + f[0])); tx=$((tx + f[8]))
done < /proc/net/dev
printf '%s %s\n' "$rx" "$tx"
'''
    output = await _exec_guest_bash(container_name, node_id, script, timeout=20)
    parts = str(output or '').strip().split()
    if len(parts) < 2:
        raise RuntimeError("Guest network counters unavailable")
    return max(0, int(parts[0])), max(0, int(parts[1]))


def _human_bytes(n: int) -> str:
    n = float(max(0, int(n))); units = ['B','KB','MB','GB','TB','PB']; i = 0
    while n >= 1024 and i < len(units)-1:
        n /= 1024; i += 1
    return f'{n:.1f} {units[i]}' if i else f'{int(n)} B'


async def get_container_network_usage(container_name: str, node_id: Optional[int] = None) -> tuple[str, str]:
    """Return aggregate RX/TX byte counters as readable strings."""
    try:
        rx, tx = await get_container_network_counters(container_name, node_id)
        return _human_bytes(rx), _human_bytes(tx)
    except Exception:
        return 'N/A', 'N/A'


async def get_container_docker_status(container_name: str, node_id: Optional[int] = None) -> str:
    """Report the actual Docker state instead of claiming Docker is ready from guest hardening alone."""
    try:
        out = await _exec_guest_bash(
            container_name,
            node_id,
            """set +e
if ! command -v docker >/dev/null 2>&1; then
  printf 'UNINSTALLED\n'
  exit 0
fi
if docker info >/dev/null 2>&1; then
  printf 'READY\n'
elif systemctl is-active --quiet docker 2>/dev/null; then
  printf 'DAEMON_WAIT\n'
else
  printf 'STOPPED\n'
fi
""",
            timeout=25,
        )
        state = str(out or '').strip().splitlines()[-1:]
        state = state[0] if state else 'UNKNOWN'
        return {
            'READY': '🐳 Ready',
            'DAEMON_WAIT': ':loading: Starting',
            'STOPPED': '⭕ Stopped',
            'UNINSTALLED': '🙅 Not Installed',
        }.get(state, '🤷 Unknown')
    except Exception:
        return '📌 Unavailable'


async def ensure_docker_ready(container_name: str, node_id: int, strict: bool = False) -> bool:
    """Install Docker Engine for supported guest families and verify the live daemon."""
    script = r"""set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive
verify() { command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1 && docker version --format '{{.Server.Version}}' >/dev/null 2>&1; }
if verify; then printf 'READY\n'; exit 0; fi

if command -v apt-get >/dev/null 2>&1; then
  apt-get update -qq
  apt-get install -y ca-certificates curl gnupg >/dev/null
  if ! apt-cache show docker.io >/dev/null 2>&1 || ! apt-get install -y docker.io >/dev/null 2>&1; then
    install -m 0755 -d /etc/apt/keyrings
    . /etc/os-release
    curl -fsSL "https://download.docker.com/linux/$ID/gpg" | gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg
    arch="$(dpkg --print-architecture)"
    codename="${VERSION_CODENAME:-stable}"
    printf 'deb [arch=%s signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/%s %s stable\n' "$arch" "$ID" "$codename" > /etc/apt/sources.list.d/docker.list
    apt-get update -qq
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >/dev/null
  fi
  systemctl enable --now docker >/dev/null 2>&1 || service docker start >/dev/null 2>&1 || true
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y ca-certificates curl dnf-plugins-core >/dev/null
  . /etc/os-release
  case "${ID:-}" in
    fedora) repo_url='https://download.docker.com/linux/fedora/docker-ce.repo' ;;
    rocky|almalinux|rhel|centos) repo_url='https://download.docker.com/linux/centos/docker-ce.repo' ;;
    *) printf 'UNSUPPORTED_RPM_DISTRIBUTION\n'; exit 23 ;;
  esac
  curl -fsSL "$repo_url" -o /etc/yum.repos.d/docker-ce.repo
  dnf makecache -y >/dev/null
  dnf install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >/dev/null
  systemctl enable --now docker
elif command -v apk >/dev/null 2>&1; then
  apk add --no-cache docker
  rc-update add docker default >/dev/null 2>&1 || true
  rc-service docker start >/dev/null 2>&1 || true
else
  printf 'UNSUPPORTED_PACKAGE_MANAGER\n'; exit 21
fi

if ! command -v dockerd >/dev/null 2>&1; then printf 'UNINSTALLED\n'; exit 22; fi
if ! docker info >/dev/null 2>&1; then
  if [ -f /etc/alpine-release ] && command -v rc-service >/dev/null 2>&1; then
    rc-service docker restart >/dev/null 2>&1 || rc-service docker start >/dev/null 2>&1 || true
  elif command -v systemctl >/dev/null 2>&1; then
    systemctl restart docker >/dev/null 2>&1 || systemctl start docker >/dev/null 2>&1 || true
  fi
fi
for _ in $(seq 1 40); do if verify; then printf 'READY\n'; exit 0; fi; sleep 1; done
printf 'NOT_READY\n'; exit 24
"""
    try:
        output = await _exec_guest_bash(container_name, node_id, script, timeout=300)
        ready = str(output or '').strip().splitlines()[-1:] == ['READY']
        if strict and not ready:
            raise RuntimeError(f'Docker Engine installation/readiness verification failed inside {container_name}.')
        return ready
    except Exception:
        if strict:
            raise
        logger.exception('Optional Docker install failed for %s', container_name)
        return False

async def get_container_disk(container_name: str, node_id: Optional[int] = None):
    stats = await get_container_stats(container_name, node_id)
    return stats['disk']

async def get_container_uptime(container_name: str, node_id: Optional[int] = None):
    stats = await get_container_stats(container_name, node_id)
    return stats['uptime']

def get_uptime():
    """Get system uptime - cross-platform compatible"""
    try:
        import platform
        system = platform.system()
        
        if system == "Windows":
            try:
                result = subprocess.run(['net', 'statistics', 'server'], 
                                      capture_output=True, text=True, timeout=5)
                output = result.stdout
                for line in output.split('\n'):
                    if 'Statistics since' in line:
                        return line.strip()
                return "Unknown"
            except:
                # Fallback: use wmic
                try:
                    result = subprocess.run(['wmic', 'os', 'get', 'lastbootuptime'], 
                                          capture_output=True, text=True, timeout=5)
                    return result.stdout.strip() if result.stdout else "Unknown"
                except:
                    return "Unknown"
        else:
            # Linux/Unix: Use uptime command
            result = subprocess.run(['uptime'], capture_output=True, text=True, timeout=5)
            return result.stdout.strip()
    except Exception as e:
        logger.debug(f"Error getting uptime: {e}")
        return "Unknown"

# Try to detect default storage pool or use common defaults
def get_default_storage_pool():
    return os.getenv('DEFAULT_STORAGE_POOL', 'kvm-public') or 'kvm-public'

DEFAULT_STORAGE_POOL = get_default_storage_pool()

async def resolve_storage_pool(node_id: int) -> str:
    return DEFAULT_STORAGE_POOL

# ─────────────────────────────────────────────────────────────────────────────
# RGNODES core policy / deployment helpers
# ─────────────────────────────────────────────────────────────────────────────
def is_admin_user(user_or_member: int | str | object) -> bool:
    obj = user_or_member
    uid = str(getattr(obj, "id", obj))
    if uid == str(MAIN_ADMIN_ID) or uid in set(CONFIG_OWNER_IDS) or uid in {str(x) for x in admin_data.get("admins", [])} or uid in set(CONFIG_ADMIN_IDS):
        return True
    perms = getattr(obj, "guild_permissions", None)
    return bool(perms is not None and getattr(perms, "administrator", False))


def maintenance_enabled() -> bool:
    return str(get_setting("maintenance", "off")).strip().lower() == "on"


def maintenance_applies_to_user(user_id: int | str) -> bool:
    """Maintenance is user-facing; administrators remain fully operational."""
    return maintenance_enabled() and not is_admin_user(user_id)


def user_has_vps(user_id: int | str) -> bool:
    return bool(vps_data.get(str(user_id), []))


def public_vps_count() -> int:
    return sum(len(items) for items in vps_data.values())


def public_vps_access_error(member: discord.Member, *, admin_override: bool = False) -> Optional[str]:
    """Return a clear policy denial for public self-service deploy, or None when allowed."""
    if admin_override:
        return None
    if not PUBLIC_VPS_ENABLED:
        return 'Public VPS creation is currently disabled.'
    owned_count = len(vps_data.get(str(member.id), []))
    if owned_count >= PUBLIC_VPS_MAX_PER_USER:
        return f'Your account reached the public VPS limit ({PUBLIC_VPS_MAX_PER_USER}).'
    if public_vps_count() >= PUBLIC_VPS_GLOBAL_LIMIT:
        return f'The public VPS pool reached its global limit ({PUBLIC_VPS_GLOBAL_LIMIT}). Please try again later.'
    if PUBLIC_VPS_REQUIRE_ACCOUNT_AGE > 0:
        created_at = getattr(member, 'created_at', None)
        if created_at is not None:
            age_days = (datetime.now(timezone.utc) - created_at.astimezone(timezone.utc)).total_seconds() / 86400
            if age_days < PUBLIC_VPS_REQUIRE_ACCOUNT_AGE:
                return f'Discord account must be at least {PUBLIC_VPS_REQUIRE_ACCOUNT_AGE} days old to claim a public VPS.'
    if PUBLIC_VPS_REQUIRE_VERIFICATION:
        if not VPS_USER_ROLE_ID:
            return 'Public VPS verification is enabled, but VPS_USER_ROLE_ID is not configured.'
        roles = getattr(member, 'roles', []) or []
        if not any(int(getattr(role, 'id', 0) or 0) == int(VPS_USER_ROLE_ID) for role in roles):
            return 'You need the configured VPS verification role before creating a public VPS.'
    return None



def find_vps_record(reference: str | int):
    """Resolve a VPS by container name or numeric persistent VPS ID."""
    wanted = str(reference).strip()
    numeric_id = int(wanted) if wanted.isdigit() else None
    for uid, items in vps_data.items():
        for idx, vps in enumerate(items):
            same_name = str(vps.get("container_name")) == wanted
            same_id = numeric_id is not None and (
                int(vps.get("id", -1) or -1) == numeric_id
                or int(vps.get("vmid", -1) or -1) == numeric_id
            )
            if same_name or same_id:
                return str(uid), idx, vps
    return None, None, None

def suspended_due_to_expiration(vps: Dict[str, Any]) -> bool:
    """Return True only when the latest suspension was caused by expiration."""
    if not vps.get("suspended"):
        return False
    history = vps.get("suspension_history") or []
    if not isinstance(history, list) or not history:
        return False
    latest = history[-1]
    if not isinstance(latest, dict):
        return False
    by = str(latest.get("by") or "").lower()
    reason = str(latest.get("reason") or "").lower()
    return "expiration" in by or "expired" in reason or "expiration" in reason



async def ensure_vps_image_remote(remote: str, node_id: int) -> None:
    """Compatibility no-op retained for legacy callers; VPS images are downloaded cloud images."""
    return None

async def _image_matches(node_id: int, remote: str, terms: list[str]) -> list[str]:
    return []

async def resolve_vps_image(os_value: str, node_id: int) -> str:
    """Resolve the selector value to one of the KVM controller's verified cloud image IDs."""
    raw = str(os_value or '').strip().lower()
    aliases = {
        'ubuntu:focal':'ubuntu:20.04', 'ubuntu:jammy':'ubuntu:22.04',
        'ubuntu:noble':'ubuntu:24.04', 'ubuntu:resolute':'ubuntu:26.04',
        'ubuntu/focal':'ubuntu:20.04', 'ubuntu/jammy':'ubuntu:22.04',
        'ubuntu/noble':'ubuntu:24.04', 'ubuntu/resolute':'ubuntu:26.04',
        'images:ubuntu/20.04':'ubuntu:20.04', 'images:ubuntu/22.04':'ubuntu:22.04',
        'images:ubuntu/24.04':'ubuntu:24.04', 'images:ubuntu/26.04':'ubuntu:26.04',
        'images:debian/11':'debian:11', 'images:debian/12':'debian:12', 'images:debian/13':'debian:13',
        'alpine:3.24.3':'alpine:3.24', 'rockylinux:9':'rocky:9', 'rockylinux:10':'rocky:10',
        'almalinux:9':'alma:9', 'almalinux:10':'alma:10', 'centos:10':'centos-stream:10',
    }
    resolved = aliases.get(raw, raw)
    supported = {
        'ubuntu:20.04','ubuntu:22.04','ubuntu:24.04','ubuntu:26.04',
        'debian:11','debian:12','debian:13','alpine:3.24',
        'rocky:9','rocky:10','alma:9','alma:10','centos-stream:10','fedora:45',
    }
    if resolved not in supported:
        raise RuntimeError(f'Unsupported VPS OS image: {os_value}. Select one of the 14 listed KVM cloud images.')
    return resolved

def friendly_os_label(os_value: str) -> str:
    """Human-readable label for every supported KVM cloud image."""
    labels = {
        'ubuntu:20.04':'Ubuntu 20.04 LTS (Legacy)', 'ubuntu:22.04':'Ubuntu 22.04 LTS',
        'ubuntu:24.04':'Ubuntu 24.04 LTS', 'ubuntu:26.04':'Ubuntu 26.04 LTS',
        'debian:11':'Debian 11 (Legacy)', 'debian:12':'Debian 12', 'debian:13':'Debian 13',
        'alpine:3.24':'Alpine Linux 3.24', 'rocky:9':'Rocky Linux 9', 'rocky:10':'Rocky Linux 10',
        'alma:9':'AlmaLinux 9', 'alma:10':'AlmaLinux 10',
        'centos-stream:10':'CentOS Stream 10', 'fedora:45':'Fedora Cloud 45',
        'images:debian/11':'Debian 11 (Legacy)', 'images:debian/12':'Debian 12', 'images:debian/13':'Debian 13',
    }
    return labels.get(str(os_value or 'Unknown').strip().lower(), str(os_value or 'Unknown'))

def location_flag(location: str) -> str:
    flags = {"India": "🇮🇳", "Singapore": "🇸🇬", "Bangladesh": "🇧🇩", "USA": "🇺🇸"}
    return flags.get(str(location or "").strip(), "🌐")


async def auto_fit_vps_resources(node_id: int, requested_ram_gb: int, requested_cpu: int, requested_disk_gb: int) -> tuple[int, int, int, str]:
    """Derive a safe, non-overcommitting VPS plan from live node capacity.

    RAM is capped at MAX_VPS_RAM_GB (hard ceiling 22 GiB by default) and is
    reduced to what the host can safely provide after its reserve. CPU is capped
    to the configured maximum and the host's protected CPU reserve. Disk remains
    the requested value because KVM uses sparse-backed qcow2 disks; the
    normal admission check still enforces real free-space reserve.
    """
    requested_ram_gb = max(MIN_VPS_RAM_GB, min(MAX_VPS_RAM_GB, int(requested_ram_gb)))
    requested_cpu = max(1, min(MAX_VPS_CPU, int(requested_cpu)))
    requested_disk_gb = max(5, int(requested_disk_gb))
    if not AUTO_RESOURCE_ALLOCATION:
        return requested_ram_gb, requested_cpu, requested_disk_gb, "Automatic resource fitting is disabled."

    stats = await get_host_stats(node_id)
    total = int(stats.get('ram_bytes_total') or 0)
    available = int(stats.get('ram_bytes_available') or max(0, total - int(stats.get('ram_bytes_used') or 0)))
    allocated = sum(
        _parse_gb(v.get('ram', '0GB'), 0)
        for items in vps_data.values() for v in items
        if int(v.get('node_id', 1)) == int(node_id) and not bool(v.get('suspended', False))
    )
    safe_bytes = max(0, available - int(HOST_RAM_RESERVE_GB * 1024**3))
    share_bytes = max(0, int(total * MAX_DEPLOY_RAM_SHARE) - int(allocated * 1024**3)) if total else safe_bytes
    fit_ram = min(requested_ram_gb, MAX_VPS_RAM_GB, safe_bytes // 1024**3, share_bytes // 1024**3)
    if fit_ram < MIN_VPS_RAM_GB:
        fit_ram = 0

    cpu_total = int(stats.get('cpu_count') or 0)
    allocated_cpu = sum(
        _parse_cpu(v.get('cpu', 0), 0)
        for items in vps_data.values() for v in items
        if int(v.get('node_id', 1)) == int(node_id) and not bool(v.get('suspended', False))
    )
    cpu_budget = max(0, int(cpu_total * HOST_VCPU_OVERCOMMIT_RATIO) - max(0, env_int('HOST_CPU_RESERVE', '1')) - allocated_cpu) if cpu_total else requested_cpu
    fit_cpu = min(requested_cpu, MAX_VPS_CPU, cpu_budget)
    if fit_cpu < 1:
        fit_cpu = 0

    if not fit_ram or not fit_cpu:
        return 0, 0, requested_disk_gb, (
            f"The node has insufficient safe headroom for a new VPS. "
            f"Requested up to {requested_ram_gb} GiB / {requested_cpu} CPU, "
            f"but the protected host budget cannot provide at least {MIN_VPS_RAM_GB} GiB / 1 CPU."
        )
    reason = (
        f"Auto-fit enabled • allocated {allocated} GiB RAM / {allocated_cpu} CPU on node • "
        f"selected {fit_ram} GiB RAM / {fit_cpu} CPU • hard RAM ceiling {MAX_VPS_RAM_GB} GiB."
    )
    return fit_ram, fit_cpu, requested_disk_gb, reason


async def check_node_capacity_for_vps(node_id: int, ram_gb: int, cpu_cores: int, disk_gb: int) -> tuple[bool, str]:
    """Conservative admission control: protect the main host from RAM/CPU/disk exhaustion."""
    node=get_node(node_id)
    if not node: return False,f"Node {node_id} not found."
    try: stats=await asyncio.wait_for(get_host_stats(node_id),timeout=15)
    except Exception as exc: return False, safe_error_summary("Node health check", exc)
    cpu=float(stats.get('cpu') or 0.0); ram_pct=float(stats.get('ram') or 0.0)
    total=int(stats.get('ram_bytes_total') or 0); available=int(stats.get('ram_bytes_available') or max(0,total-int(stats.get('ram_bytes_used') or 0)))
    disk_free=int(stats.get('disk_free') or 0)
    if total:
        requested=int(float(ram_gb)*(1024**3)); reserve=int(HOST_RAM_RESERVE_GB*(1024**3)); max_guest=int(total*MAX_DEPLOY_RAM_SHARE)
        allocated_ram=sum(_parse_gb(v.get("ram", "0GB"), 0) for items in vps_data.values() for v in items if int(v.get("node_id", 1))==int(node_id) and not bool(v.get("suspended", False)))
        allocated_bytes=allocated_ram*(1024**3)
        if requested>max_guest or allocated_bytes+requested+reserve>max_guest:
            return False,f"Host RAM allocation guard blocked deployment: allocated {allocated_ram} GiB + requested {ram_gb} GiB exceeds the safe host budget. {HOST_PROVIDER_NAME} is protected."
        if available < requested+reserve:
            return False,f"Host safety guard blocked deployment: available RAM {available/(1024**3):.1f} GiB; requested {ram_gb} GiB + reserve {HOST_RAM_RESERVE_GB:.1f} GiB."
        if ram_pct > 100.0-MIN_HOST_RAM_FREE_PCT_DEPLOY:
            return False,f"Host RAM is {ram_pct:.1f}% used. Deployment is paused until at least {MIN_HOST_RAM_FREE_PCT_DEPLOY:.0f}% RAM is free."
    cpu_total=int(stats.get('cpu_count') or 0)
    if cpu_total:
        allocated_cpu=sum(_parse_cpu(v.get("cpu", 0), 0) for items in vps_data.values() for v in items if int(v.get("node_id", 1))==int(node_id) and not bool(v.get("suspended", False)))
        if allocated_cpu+int(cpu_cores) > max(1,int(cpu_total*HOST_VCPU_OVERCOMMIT_RATIO)-max(0,env_int('HOST_CPU_RESERVE','1'))):
            return False,f"Host CPU allocation guard blocked deployment: allocated {allocated_cpu} cores + requested {cpu_cores} cores would consume the protected CPU reserve."
    if cpu>=HOST_CPU_MAX_DEPLOY_PCT:
        return False,f"Host CPU is {cpu:.1f}% used. Deployment is paused below {HOST_CPU_MAX_DEPLOY_PCT:.0f}% to protect {HOST_PROVIDER_NAME}."
    if disk_free:
        disk_reserve_bytes=int(HOST_DISK_RESERVE_GB*(1024**3))
        requested_disk_bytes=int(float(disk_gb)*(1024**3))
        allocated_disk=sum(_parse_gb(v.get('storage','0GB'),0) for items in vps_data.values() for v in items if int(v.get('node_id',1))==int(node_id) and not bool(v.get('suspended',False)))
        disk_total=int(stats.get('disk_total') or 0)
        if disk_total and (allocated_disk + float(disk_gb))*(1024**3) + disk_reserve_bytes > disk_total:
            return False,f"Host disk allocation guard blocked deployment: allocated {allocated_disk} GiB + requested {disk_gb} GiB exceeds the protected host budget."
        if disk_free < requested_disk_bytes + disk_reserve_bytes:
            return False,f"Host disk safety guard blocked deployment: only {disk_free/(1024**3):.1f} GiB free; request {disk_gb} GiB + reserve {HOST_DISK_RESERVE_GB:.1f} GiB."
    return True,f"Host healthy • CPU {cpu:.1f}% • RAM {ram_pct:.1f}% • disk reserve active • {HOST_PROVIDER_NAME}."

async def check_node_capacity_for_start(node_id: int, container_name: str, ram_gb: int, cpu_cores: int) -> tuple[bool, str]:
    """Preflight a START operation without double-counting the stopped target VPS."""
    node=get_node(node_id)
    if not node:
        return False, f"VPS Node {node_id} not found."
    try:
        stats=await asyncio.wait_for(get_host_stats(node_id), timeout=12)
    except Exception as exc:
        return False, safe_error_summary("Host health check", exc)
    cpu=float(stats.get('cpu') or 0.0)
    total=int(stats.get('ram_bytes_total') or 0)
    available=int(stats.get('ram_bytes_available') or max(0,total-int(stats.get('ram_bytes_used') or 0)))
    if total:
        requested=int(float(ram_gb)*(1024**3))
        reserve=int(HOST_RAM_RESERVE_GB*(1024**3))
        if available < requested + reserve:
            return False, f"Start blocked to protect {HOST_PROVIDER_NAME}: only {available/(1024**3):.1f} GiB RAM is available; VPS needs {ram_gb} GiB plus {HOST_RAM_RESERVE_GB:.1f} GiB reserve."
        if float(stats.get('ram') or 0.0) > 100.0-MIN_HOST_RAM_FREE_PCT_DEPLOY:
            return False, f"Start blocked: host RAM is {float(stats.get('ram') or 0.0):.1f}% used."
    if cpu >= HOST_CPU_MAX_DEPLOY_PCT:
        return False, f"Start blocked: host CPU is {cpu:.1f}% used. {HOST_PROVIDER_NAME} safety threshold is {HOST_CPU_MAX_DEPLOY_PCT:.0f}%."
    cpu_total=int(stats.get('cpu_count') or 0)
    if cpu_total:
        allocated=0
        for items in vps_data.values():
            for v in items:
                if int(v.get('node_id',1)) != int(node_id) or bool(v.get('suspended',False)):
                    continue
                if str(v.get('container_name')) == str(container_name):
                    continue
                if str(v.get('status','')).lower() == 'running':
                    allocated += _parse_cpu(v.get('cpu',0),0)
        if allocated + int(cpu_cores) > max(1,int(cpu_total*HOST_VCPU_OVERCOMMIT_RATIO)-max(0,env_int('HOST_CPU_RESERVE','1'))):
            return False, f"Start blocked by CPU allocation guard: {allocated} running cores + {cpu_cores} requested would exceed the protected host CPU reserve."
    return True, f"Host start preflight passed • CPU {cpu:.1f}% • RAM available {available/(1024**3):.1f} GiB."


async def wait_for_guest_agent(container_name: str, node_id: int, timeout: Optional[int] = None) -> None:
    """Wait for QEMU Guest Agent before any guest-side configuration is attempted."""
    deadline = time.monotonic() + max(60, int(timeout or GUEST_BOOTSTRAP_TIMEOUT))
    last_error = 'Guest Agent has not replied yet.'
    while time.monotonic() < deadline:
        try:
            result = await execute_vpsctl_compat(container_name, f"agent-ping {shlex.quote(container_name)}", node_id=node_id, timeout=20)
            if isinstance(result, dict) and result.get('ready') is True:
                return
            if result is True or str(result).strip().lower() in {'true', 'ready', 'ok'}:
                return
            last_error = str(result)[:300]
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            last_error = f"{type(exc).__name__}: {str(exc)[:220]}"
        await asyncio.sleep(5)
    raise RuntimeError(f"VPS booted, but QEMU Guest Agent did not become ready within {max(60, int(timeout or GUEST_BOOTSTRAP_TIMEOUT))} seconds. The VM is kept for recovery; check cloud-init and the qemu-guest-agent service. Last probe: {last_error}")


DEPLOYMENT_STAGES = [
    "Receiving VPS ID",
    "Checking KVM / QEMU",
    "Creating VPS Container",
    "Applying Resource",
    "Booting VPS",
    "Configure Package",
    "🐳 Docker Ready",
    "Fixing systemctl",
    "Register In Bot Database",
    "Installing SSH + Password",
    "Making Public Real IPv4",
    "Creating SSH",
    "Creating PINGGY",
    "Final Full Check and Repair",
    "Finished",
]
_DEPLOY_SPINNER_FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")
_DEPLOY_WAVE_FRAMES = ("▂", "▃", "▄", "▅", "▆", "▇", "█")
_DEPLOY_BOUNCE_FRAMES = ("⠁", "⠂", "⠄", "⡀", "⢀", "⠠", "⠐", "⠈")

def wave_bar(value: float, maximum: float = 100.0, length: int = 14, *, tick: int = 0) -> str:
    """Lightweight travelling-wave progress bar inspired by the uploaded animation reference."""
    try:
        pct = 0.0 if float(maximum) <= 0 else max(0.0, min(100.0, float(value) / float(maximum) * 100.0))
    except (TypeError, ValueError, OverflowError):
        pct = 0.0
    filled = max(0, min(length, int(round(pct / 100.0 * length))))
    head = _DEPLOY_WAVE_FRAMES[int(tick) % len(_DEPLOY_WAVE_FRAMES)]
    body = "█" * max(0, filled - 1)
    return f"`{body}{head if filled else '░'}{'░' * max(0, length - filled)}` `{pct:5.1f}%`"

def deployment_beat(tick: int = 0) -> str:
    """Animated status marker used by deployment cards."""
    return _DEPLOY_BOUNCE_FRAMES[int(tick) % len(_DEPLOY_BOUNCE_FRAMES)]


async def send_progress(
    progress_message: discord.Message,
    title: str,
    step: int,
    total: int,
    detail: str,
    *,
    active_index: Optional[int] = None,
    frame: int = 0,
    failed: bool = False,
    vps_name: str = "rgnodes-vps",
):
    """Update the persistent colorless deployment card with an animated, truthful checklist."""
    total = max(1, int(total))
    completed = max(0, min(int(step), total))
    stages = DEPLOYMENT_STAGES if total == len(DEPLOYMENT_STAGES) else [f"Deployment step {i + 1}" for i in range(total)]
    if active_index is None:
        active_index = min(completed, total - 1)
    active_index = max(0, min(int(active_index), total - 1))
    spinner = _DEPLOY_SPINNER_FRAMES[int(frame) % len(_DEPLOY_SPINNER_FRAMES)]
    pct = int((completed / total) * 100)
    filled = int(20 * completed / total)
    static_bar = "▰" * filled + "▱" * (20 - filled)
    moving = ["▱"] * 9
    moving[int(frame) % len(moving)] = "▰"
    animated_bar = "".join(moving)
    checklist = []
    for idx, stage in enumerate(stages):
        if idx < completed:
            marker = resolve_custom_emoji('success', '✅')
        elif failed and idx == active_index:
            marker = resolve_custom_emoji('warning', '❌')
        elif idx == active_index and completed < total:
            marker = resolve_custom_emoji('install', spinner)
        else:
            marker = "▫️"
        checklist.append(f"{marker} {stage}")
    detail_text = truncate_text(detail, 1100)
    description = (
        f"**VPS:** `{truncate_text(vps_name, 80)}`\n"
        f"`[{static_bar}]` **{pct}%** · `{completed}/{total} stages complete`\n"
        f"{wave_bar(completed, total, 14, tick=frame)}  {deployment_beat(frame)} {spinner} **{truncate_text(title, 120)}**\n\n"
        f"{chr(10).join(checklist)}\n\n"
        f"{detail_text}"
    )
    embed = create_info_embed(f"{spinner} Deploying VPS", description)
    try:
        await progress_message.edit(embed=embed, view=None, allowed_mentions=discord.AllowedMentions.none())
    except Exception as exc:
        logger.warning('Could not update public VPS deployment progress message %s: %s', getattr(progress_message, 'id', 'unknown'), type(exc).__name__)


async def run_deployment_stage(
    progress_message: discord.Message,
    stage_index: int,
    detail: str,
    operation,
    vps_name: str,
):
    """Run one real stage while animating the same durable Discord message until it finishes."""
    total = len(DEPLOYMENT_STAGES)
    stage_name = DEPLOYMENT_STAGES[stage_index]
    await send_progress(
        progress_message, stage_name, stage_index, total, detail,
        active_index=stage_index, frame=0, vps_name=vps_name,
    )
    task = asyncio.create_task(operation(), name=f"rgnodes_deploy_stage_{stage_index + 1}")
    frame = 1
    try:
        while not task.done():
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=1.35)
            except asyncio.TimeoutError:
                await send_progress(
                    progress_message, stage_name, stage_index, total,
                    f"{detail}\n\nLive check in progress. This stage is not marked complete until its operation returns.",
                    active_index=stage_index, frame=frame, vps_name=vps_name,
                )
                frame += 1
        result = await task
    except asyncio.CancelledError:
        task.cancel()
        raise
    except Exception as exc:
        await send_progress(
            progress_message, stage_name, stage_index, total,
            f"Stage failed safely ({type(exc).__name__}). The deployment has stopped at this checkpoint; see the diagnostic log for details.",
            active_index=stage_index, frame=frame, failed=True, vps_name=vps_name,
        )
        raise
    await send_progress(
        progress_message, stage_name, stage_index + 1, total,
        f"✅ Stage verified: {detail}",
        active_index=min(stage_index + 1, total - 1), frame=frame, vps_name=vps_name,
    )
    return result




async def _background_start_pinggy(container_name: str, node_id: int):
    try:
        info = await asyncio.wait_for(start_pinggy_session(container_name, node_id), timeout=120)
        if info:
            logger.info("Pinggy background bootstrap connected for %s; endpoint omitted from logs", container_name)
        else:
            logger.warning("Pinggy background bootstrap did not produce an endpoint for %s; repair loop will retry.", container_name)
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        logger.warning("Pinggy background bootstrap failed for %s: %s", container_name, exc)


async def safe_guest_install(container_name: str, node_id: int):
    """Fast post-boot baseline only; package/tunnel work is deferred to repair workers.

    This function is intentionally kept below the remote node-agent timeout budget so
    creating a VPS cannot fail merely because apt mirrors or tunnel providers are slow.
    """
    await set_guest_hostname(container_name, node_id, VPS_HOSTNAME)
    try:
        await install_anti_mining_guard(container_name, node_id)
    except Exception as exc:
        logger.debug("Anti-mining guard deferred for %s: %s", container_name, exc)
    try:
        await apply_guest_motd(container_name, node_id)
    except Exception as exc:
        logger.debug("MOTD setup deferred for %s: %s", container_name, exc)

async def protection_repair_task():
    """Ensure all currently-running managed VPS have the anti-mining guard installed.

    This repairs VPS created by older bot versions without starting stopped instances.
    The regular Start/Reinstall/Deploy flows also install the guard.
    """
    await bot.wait_until_ready()
    await asyncio.sleep(30)
    while not bot.is_closed():
        try:
            for owner_id, vps_list in list(vps_data.items()):
                for vps in list(vps_list):
                    if bool(vps.get('suspended', False)):
                        continue
                    container = str(vps.get('container_name') or '').strip()
                    if not container:
                        continue
                    node_id = int(vps.get('node_id', 1))
                    try:
                        if str(vps.get('status', 'stopped')).lower() != 'running':
                            continue
                        await install_anti_mining_guard(container, node_id)
                    except asyncio.CancelledError:
                        raise
                    except Exception as e:
                        logger.debug(f"Protection repair skipped for {container}: {e}")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(f"Protection repair task failed: {e}", exc_info=True)
        await asyncio.sleep(12 * 3600)


async def guest_baseline_repair_task():
    """Periodically repair only missing guest baseline dependencies on running VPS."""
    await bot.wait_until_ready()
    await asyncio.sleep(90)
    required = "bash sudo curl ip ss ps python3 test"
    while not bot.is_closed():
        try:
            for _owner_id, items in list(vps_data.items()):
                for vps in list(items):
                    if bool(vps.get('suspended', False)):
                        continue
                    container = str(vps.get('container_name') or '').strip()
                    if not container:
                        continue
                    node_id = int(vps.get('node_id', 1))
                    try:
                        if str(vps.get('status', 'stopped')).lower() != 'running':
                            continue
                        probe = await _exec_guest_bash(
                            container,
                            node_id,
                            "if [ -e /etc/systemd/system/rgnodes-sshx.service ] || [ -e /etc/cron.d/rgnodes-sshx ] || [ -e /var/lib/rgnodes/sshx.supervisor.pid ] || command -v sshx >/dev/null 2>&1; then if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then systemctl stop rgnodes-sshx.service >/dev/null 2>&1 || true; systemctl disable rgnodes-sshx.service >/dev/null 2>&1 || true; fi; oldpid=$(cat /var/lib/rgnodes/sshx.supervisor.pid 2>/dev/null || true); case \"$oldpid\" in ''|*[!0-9]*) ;; *) kill -TERM \"$oldpid\" 2>/dev/null || true ;; esac; pkill -x sshx >/dev/null 2>&1 || true; rm -f /etc/systemd/system/rgnodes-sshx.service /etc/cron.d/rgnodes-sshx /usr/local/sbin/rgnodes-sshx-supervisor /usr/local/bin/sshx /usr/bin/sshx /root/.local/bin/sshx /root/.cargo/bin/sshx /var/lib/rgnodes/sshx.url /var/lib/rgnodes/sshx.pid /var/lib/rgnodes/sshx-direct.pid /var/lib/rgnodes/sshx.supervisor.pid /var/lib/rgnodes/sshx.log /var/lib/rgnodes/sshx-tty.log /var/lib/rgnodes/sshx-supervisor.log /var/lib/rgnodes/sshx-install.log; if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then systemctl daemon-reload >/dev/null 2>&1 || true; fi; fi; missing=''; for c in bash sudo curl ip ss ps python3; do command -v \"$c\" >/dev/null 2>&1 || missing=\"$missing $c\"; done; test -d /etc/ssh/sshd_config.d || missing=\"$missing sshd-config-dir\"; if [ -n \"$missing\" ]; then printf 'MISSING:%s\\n' \"$missing\"; else printf 'OK\\n'; fi",
                            timeout=25,
                        )
                        if str(probe).strip().startswith('MISSING:'):
                            logger.warning(f"Guest baseline repair required for {container}: {probe.strip()}")
                            await bootstrap_vps_guest(container, node_id)
                            await install_anti_mining_guard(container, node_id)
                            await recreate_port_forwards(container, node_id_override=node_id)
                        # Existing VPS created by older versions also receive the current MOTD.
                        try:
                            await apply_guest_motd(container, node_id)
                        except Exception as motd_exc:
                            logger.debug(f"MOTD baseline repair skipped for {container}: {motd_exc}")
                    except asyncio.CancelledError:
                        raise
                    except Exception as e:
                        logger.debug(f"Guest baseline repair skipped for {container}: {e}")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(f"Guest baseline repair task failed: {e}", exc_info=True)
        await asyncio.sleep(18 * 3600)

async def access_repair_task():
    """Periodically reconcile SSH guest readiness and persisted NAT forwards for running VPSs."""
    await bot.wait_until_ready()
    await asyncio.sleep(45)
    while not bot.is_closed():
        try:
            candidates = []
            for owner_id, items in list(vps_data.items()):
                for vps in list(items):
                    if bool(vps.get("suspended", False)):
                        continue
                    container = str(vps.get("container_name") or "").strip()
                    if not container:
                        continue
                    if str(vps.get("status", "stopped")).lower() != "running":
                        continue
                    forwards = [
                        f for f in get_user_forwards(str(owner_id))
                        if str(f.get("vps_container")) == container
                        and int(f.get("vps_port", 0) or 0) == 22
                    ]
                    # SQLite records do not prove that host DNAT/FORWARD rules survived
                    # a node reboot or firewall reload. Replay idempotent port-add for
                    # every running VPS on each bounded repair pass.
                    needs_forward = True
                    needs_ssh = not bool(vps.get("ssh_ready", False))
                    if needs_forward or needs_ssh:
                        candidates.append((str(owner_id), vps, needs_forward, needs_ssh))
            sem = asyncio.Semaphore(MAX_BACKGROUND_REPAIR_CONCURRENCY)
            async def repair_one(owner_id, vps, needs_forward, needs_ssh):
                container = str(vps.get("container_name")); node_id = int(vps.get("node_id", 1))
                async with sem:
                    if needs_ssh:
                        password = str(vps.get("root_password") or generate_strong_password())
                        try:
                            ok, result = await asyncio.wait_for(configure_ssh(container, node_id, password), timeout=105)
                            if ok:
                                vps["root_password"] = password
                                vps["ssh_ready"] = True
                                try:
                                    await apply_guest_motd(container, node_id)
                                except Exception:
                                    pass
                                save_vps_data_immediate()
                            else:
                                logger.debug("SSH repair not ready for %s: %s", container, result)
                        except Exception as exc:
                            logger.debug("SSH repair skipped for %s: %s", container, exc)
                    if needs_forward:
                        try:
                            port = await asyncio.wait_for(create_port_forward(owner_id, container, 22, node_id), timeout=75)
                            if port:
                                vps["ssh_access_pending"] = False
                                vps.pop("ssh_access_error_type", None)
                                save_vps_data_immediate()
                                logger.info("🔧 Repaired SSH port-forward for %s: host %s -> guest 22", container, port)
                        except Exception as exc:
                            logger.debug("SSH port-forward repair skipped for %s: %s", container, exc)
            for start_idx in range(0, len(candidates), 10):
                await asyncio.gather(*(repair_one(*x) for x in candidates[start_idx:start_idx+10]), return_exceptions=True)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error("Access repair task failed: %s", exc, exc_info=True)
        await asyncio.sleep(ACCESS_REPAIR_INTERVAL)


async def tunnel_repair_task():
    """Keep Pinggy healthy without probing every VPS with expensive KVM VPS stats."""
    await bot.wait_until_ready()
    await asyncio.sleep(30)
    sem = asyncio.Semaphore(MAX_BACKGROUND_REPAIR_CONCURRENCY)
    async def repair_one(vps):
        if bool(vps.get('suspended', False)) or str(vps.get('status','stopped')).lower() != 'running':
            return
        container = str(vps.get('container_name') or '').strip()
        if not container:
            return
        node_id = int(vps.get('node_id', 1))
        async with sem:
            if PINGGY_ENABLED and PINGGY_AUTO_START:
                try:
                    _, _, ok = await asyncio.wait_for(get_pinggy_session_info(container, node_id), timeout=12)
                    if not ok:
                        await asyncio.wait_for(start_pinggy_session(container, node_id), timeout=120)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    logger.debug("Pinggy repair skipped for %s: %s", container, exc)
    while not bot.is_closed():
        try:
            all_vps = [vps for items in list(vps_data.values()) for vps in list(items)]
            for batch_start in range(0, len(all_vps), 10):
                await asyncio.gather(*(repair_one(v) for v in all_vps[batch_start:batch_start+10]), return_exceptions=True)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error("Tunnel repair task failed: %s", exc, exc_info=True)
        await asyncio.sleep(TUNNEL_REPAIR_INTERVAL)

async def expiration_monitor_task():
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            await check_vps_expiration()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(f"Expiration monitor failed: {e}", exc_info=True)
        await asyncio.sleep(EXPIRATION_CHECK_INTERVAL)

# Discord bot setup MUST exist before any @bot.event/@bot.command decorator is evaluated.
# This placement fixes startup NameError when Python reaches the first decorator.
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

def current_command_prefix() -> str:
    try:
        value = str(get_setting('command_prefix', PREFIX) or PREFIX).strip()
        return value if value and len(value) <= 5 and not any(ch.isspace() for ch in value) else PREFIX
    except Exception:
        return PREFIX


def resolve_command_prefix(_bot, _message):
    # Prefix commands and both Discord mention formats are supported at the same time.
    # The stored prefix is read per message, so !change-prefix takes effect immediately.
    prefixes = [current_command_prefix()]
    user = getattr(_bot, 'user', None)
    if user is not None:
        prefixes.extend((f'<@{user.id}> ', f'<@!{user.id}> '))
    return tuple(dict.fromkeys(prefixes))

bot = commands.Bot(command_prefix=resolve_command_prefix, intents=intents, help_command=None)


@bot.command(name='prefix', aliases=['myprefix'])
async def show_prefix_command(ctx):
    prefix = current_command_prefix()
    mention = f"<@{bot.user.id}>" if bot.user else '@Bot'
    await ctx.send(embed=create_info_embed('⌨️ Bot Prefix', f"Current prefix: `{prefix}`\nYou can also run commands by mentioning me: `{mention} help` or `{mention} ping`.\nAsk `prefix` in this channel to see this again."), allowed_mentions=discord.AllowedMentions.none())


@bot.listen('on_message')
async def prefix_hint_response(message: discord.Message):
    """Answer common English questions about the active command prefix."""
    if getattr(message.author, 'bot', False):
        return
    text = re.sub(r'\s+', ' ', str(getattr(message, 'content', '') or '').strip().casefold())
    questions = {
        'prefix', 'prefix?', 'what is prefix', 'what is the prefix',
        'what is your prefix', "what's your prefix", "what's the prefix",
        'which prefix', 'which is the prefix', 'what prefix do you use',
        'what is your command prefix', 'bot prefix', 'bot prefix?',
        'tell me the prefix', 'show the prefix', 'command prefix',
    }
    question_words = ('what', 'which', 'your', 'use', 'tell', 'show', 'is', 'the')
    asks_prefix = (
        text in questions
        or ('prefix' in text and ('?' in text or any(word in text.split() for word in question_words)))
    )
    if not asks_prefix or len(text) > 160:
        return
    prefix = current_command_prefix()
    mention = f"<@{bot.user.id}>" if bot.user else '@Bot'
    try:
        await message.reply(
            f"My current command prefix is `{prefix}`. You can also mention me to run a command, for example `{mention} help` or `{mention} ping`.",
            mention_author=False,
            allowed_mentions=discord.AllowedMentions.none(),
        )
    except discord.HTTPException:
        logger.debug('Could not send prefix hint in channel %s', getattr(message.channel, 'id', 'unknown'))

# Invite usage snapshots are in-memory only; the actual reward totals are in SQLite.
INVITE_USE_CACHE: Dict[int, Dict[str, int]] = {}


def get_reward_stats(guild_id: int | str, user_id: int | str) -> Dict[str, int]:
    with DB_LOCK:
        conn = get_db()
        try:
            row = conn.execute(
                "SELECT invites, boosts FROM user_reward_stats WHERE guild_id = ? AND user_id = ?",
                (str(guild_id), str(user_id)),
            ).fetchone()
            return {"invites": int(row[0]) if row else 0, "boosts": int(row[1]) if row else 0}
        finally:
            conn.close()


def change_reward_count(guild_id: int | str, user_id: int | str, kind: str, delta: int,
                        detail: str = "", actor_id: int | str | None = None) -> Dict[str, int]:
    kind = str(kind).strip().lower()
    if kind not in {"invites", "boosts"}:
        raise ValueError("Reward type must be invites or boosts")
    delta = int(delta)
    column = "invites" if kind == "invites" else "boosts"
    with DB_LOCK:
        conn = get_db()
        try:
            conn.execute(
                "INSERT OR IGNORE INTO user_reward_stats (guild_id, user_id, invites, boosts) VALUES (?, ?, 0, 0)",
                (str(guild_id), str(user_id)),
            )
            conn.execute(
                f"UPDATE user_reward_stats SET {column} = MAX(0, {column} + ?), updated_at = CURRENT_TIMESTAMP WHERE guild_id = ? AND user_id = ?",
                (delta, str(guild_id), str(user_id)),
            )
            conn.execute(
                "INSERT INTO reward_events (guild_id, user_id, event_type, delta, detail, actor_id) VALUES (?, ?, ?, ?, ?, ?)",
                (str(guild_id), str(user_id), kind, delta, str(detail)[:300], str(actor_id) if actor_id is not None else None),
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    return get_reward_stats(guild_id, user_id)


async def refresh_guild_invite_snapshot(guild: discord.Guild) -> None:
    try:
        me = guild.me
        if me is None or not me.guild_permissions.manage_guild:
            return
        invites = await guild.invites()
        INVITE_USE_CACHE[guild.id] = {str(inv.code): int(inv.uses or 0) for inv in invites}
    except (discord.Forbidden, discord.HTTPException):
        logger.info("Invite tracking unavailable in guild %s (Manage Server permission/API access required).", guild.id)
    except Exception as exc:
        logger.debug("Invite cache refresh failed for guild %s: %s", guild.id, type(exc).__name__)


# Bot events
async def runtime_self_repair_task():
    """Low-risk startup repair: sync DB status and restore security/ports."""
    await bot.wait_until_ready()
    await asyncio.sleep(15)
    try:
        for _owner_id, items in list(vps_data.items()):
            for vps in list(items):
                container = str(vps.get('container_name') or '').strip()
                if not container:
                    continue
                node_id = int(vps.get('node_id', 1))
                try:
                    stats = await asyncio.wait_for(get_container_stats(container, node_id), timeout=12)
                    actual = str(stats.get('status', 'unknown')).lower()
                    if actual in {'running', 'stopped'} and actual != str(vps.get('status', 'stopped')).lower():
                        vps['status'] = actual
                        save_vps_data_immediate()
                    if actual == 'running' and not bool(vps.get('suspended', False)):
                        await install_anti_mining_guard(container, node_id)
                        await recreate_port_forwards(container, node_id_override=node_id)
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    logger.debug(f'Runtime self-repair skipped for {container}: {e}')
    except asyncio.CancelledError:
        raise
    except Exception as e:
        logger.error(f'Runtime self-repair failed: {e}', exc_info=True)


def _sanitize_command_for_audit(ctx) -> str:
    try:
        content = str(getattr(getattr(ctx, "message", None), "content", "") or "").strip()
    except Exception:
        content = ""
    if not content:
        return f"{PREFIX}{getattr(getattr(ctx, 'command', None), 'qualified_name', 'unknown')}"
    # Never put obvious secrets/passwords/tokens into the persistent audit log.
    content = re.sub(r'(?i)(password|passwd|token|api[_-]?key|secret)\s+\S+', r'\1 [REDACTED]', content)
    content = content[:700]
    return content

@bot.event
async def on_command_completion(ctx):
    try:
        cmd = getattr(ctx, "command", None)
        cmd_name = getattr(cmd, "qualified_name", None)
        if not cmd_name:
            return
        root_cmd = str(cmd_name).split()[0].lower()
        if root_cmd in AUDIT_NOISY_COMMANDS:
            return
        container = None; node_id = None
        raw_ref = None
        for key, value in getattr(ctx, "kwargs", {}).items():
            if value is None:
                continue
            if isinstance(value, int) and 'node' in key.lower():
                node_id = value
            elif isinstance(value, str) and ('vps' in key.lower() or 'container' in key.lower() or key.lower() in {'reference','container_name'}):
                raw_ref = value
        if raw_ref:
            _, _, vps = find_vps_record(raw_ref)
            if vps:
                container = str(vps.get('container_name'))
                node_id = int(vps.get('node_id', node_id or 1))
        detail = f"Executed by {getattr(ctx.author, 'display_name', ctx.author)} in {getattr(ctx.channel, 'mention', '#channel')}. Command: `{_sanitize_command_for_audit(ctx)}`"
        await record_audit_event("command", f"Command Completed • {PREFIX}{cmd_name}", detail, user_id=ctx.author.id, node_id=node_id, vps_container=container)
    except Exception:
        pass

async def bandwidth_accounting_task():
    """Persist RX+TX accounting for each running VPS with low host overhead."""
    await bot.wait_until_ready()
    await asyncio.sleep(45)
    while not bot.is_closed():
        try:
            vps_items = [v for items in list(vps_data.values()) for v in list(items)
                         if str(v.get("status", "")).lower() == "running" and not v.get("suspended") and v.get("container_name")]
            sem = asyncio.Semaphore(2)

            async def sample(vps):
                container = str(vps.get("container_name")); node_id = int(vps.get("node_id", 1))
                async with sem:
                    try:
                        rx, tx = await get_container_network_counters(container, node_id)
                    except Exception as exc:
                        logger.debug("Bandwidth sample failed for %s: %s", container, exc)
                        return
                now = datetime.now()
                try:
                    start_dt = datetime.fromisoformat(str(vps.get("bandwidth_cycle_start")))
                    reset = (start_dt.year, start_dt.month) != (now.year, now.month)
                except Exception:
                    reset = True
                last_rx = max(0, int(vps.get("bandwidth_last_rx_bytes") or 0))
                last_tx = max(0, int(vps.get("bandwidth_last_tx_bytes") or 0))
                last_sample = vps.get("bandwidth_last_sample_at")
                first_baseline = (
                    last_rx == 0
                    and last_tx == 0
                    and int(vps.get('bandwidth_used_bytes') or 0) == 0
                )
                # Guest counters reset on reboot/interface recreation; never create negative usage.
                if first_baseline:
                    delta_rx = 0
                    delta_tx = 0
                else:
                    delta_rx = rx if rx < last_rx else rx - last_rx
                    delta_tx = tx if tx < last_tx else tx - last_tx
                used = 0 if reset else max(0, int(vps.get("bandwidth_used_bytes") or 0))
                used += delta_rx + delta_tx
                vps["bandwidth_gb"] = VPS_BANDWIDTH_GB
                vps["bandwidth_used_bytes"] = used
                vps["bandwidth_last_rx_bytes"] = rx
                vps["bandwidth_last_tx_bytes"] = tx
                vps["bandwidth_last_sample_at"] = now.isoformat()
                if reset:
                    vps["bandwidth_cycle_start"] = now.isoformat()
                with DB_LOCK:
                    conn = get_db()
                    try:
                        conn.execute(
                            "UPDATE vps SET bandwidth_gb=?, bandwidth_used_bytes=?, bandwidth_cycle_start=?, bandwidth_last_rx_bytes=?, bandwidth_last_tx_bytes=?, bandwidth_last_sample_at=?, last_modified=CURRENT_TIMESTAMP WHERE container_name=?",
                            (VPS_BANDWIDTH_GB, used, vps.get("bandwidth_cycle_start"), rx, tx, vps.get("bandwidth_last_sample_at"), container),
                        )
                        conn.commit()
                    finally:
                        conn.close()

            # Process in small batches: the semaphore limits active samples, while batching
            # avoids constructing thousands of pending coroutine tasks on large installations.
            for batch_start in range(0, len(vps_items), 20):
                batch = vps_items[batch_start:batch_start + 20]
                await asyncio.gather(*(sample(v) for v in batch), return_exceptions=True)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.debug("Bandwidth accounting task failed: %s", exc)
        await asyncio.sleep(BANDWIDTH_SAMPLE_INTERVAL)


async def audit_channel_health_task():
    """Clear a stale/deleted log-channel ID so audit logging never loops on a dead target."""
    await bot.wait_until_ready()
    await asyncio.sleep(60)
    while not bot.is_closed():
        try:
            channel_id = _audit_channel_id()
            if channel_id:
                channel = bot.get_channel(channel_id)
                if channel is None:
                    try:
                        channel = await bot.fetch_channel(channel_id)
                    except (discord.NotFound, discord.Forbidden):
                        set_audit_channel_id(0)
                        logger.warning("Configured audit log channel %s is unavailable; disabled it.", channel_id)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.debug("Audit channel health check failed: %s", exc)
        await asyncio.sleep(900)


async def node_log_health_task():
    await bot.wait_until_ready()
    await asyncio.sleep(20)
    while not bot.is_closed():
        try:
            if _audit_channel_id():
                for node in get_nodes():
                    node_id = int(node.get('id'))
                    try:
                        stats = await asyncio.wait_for(get_host_stats(node_id), timeout=12)
                        cpu = float(stats.get('cpu') or 0.0)
                        ram = float(stats.get('ram') or 0.0)
                        vps_count = sum(1 for items in vps_data.values() for v in items if int(v.get('node_id', 1)) == node_id)
                        total = int(stats.get('ram_bytes_total') or 0)
                        avail = int(stats.get('ram_bytes_available') or 0)
                        memory = f"{avail/(1024**3):.1f} GiB free / {total/(1024**3):.1f} GiB total" if total else "N/A"
                        await record_audit_event("node", "Node Health Snapshot", f"CPU `{cpu:.1f}%` • RAM `{ram:.1f}%` • {memory} • Managed VPS `{vps_count}` • Processor `{HOST_PROCESSOR_NAME}` • Provider `{HOST_PROVIDER_NAME}`.", node_id=node_id)
                    except Exception as exc:
                        await record_audit_event("error", "Node Health Check Failed", safe_error_summary("Node health check", exc), node_id=node_id)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.debug("Node log health task failed: %s", exc)
        await asyncio.sleep(LOG_HEALTH_INTERVAL)

async def adaptive_vps_resource_scaler_task():
    """Increase live VPS RAM/CPU only when workload needs it, within pre-admitted ceilings."""
    await bot.wait_until_ready()
    await asyncio.sleep(30)
    while not bot.is_closed():
        if RESOURCE_AUTOSCALE_ENABLED:
            try:
                snapshot=[(str(uid),dict(v)) for uid,items in vps_data.items() for v in items]
            except Exception:
                snapshot=[]
            for owner_id,vps in snapshot[:200]:
                if vps.get('suspended'): continue
                name=str(vps.get('container_name') or '')
                node_id=int(vps.get('node_id',1) or 1)
                if not name: continue
                try:
                    stats=await asyncio.wait_for(get_container_stats(name,node_id),timeout=18)
                    if str(stats.get('status','')).lower()!='running': continue
                    limits=stats.get('limits') or {}
                    max_ram=int(limits.get('ram_gb') or _parse_gb(vps.get('ram','1GB'),1))
                    max_cpu=int(limits.get('cpu') or _parse_cpu(vps.get('cpu',1),1))
                    current_ram=max(1,int(stats.get('ram_current_gb') or stats.get('ram',{}).get('total') or 1))
                    current_cpu=max(1,int(stats.get('cpu_current') or 1))
                    ram_pct=float(stats.get('ram',{}).get('pct') or 0.0)
                    cpu_pct=float(stats.get('cpu') or 0.0)
                    if ram_pct >= RESOURCE_SCALE_UP_RAM_THRESHOLD and current_ram < max_ram:
                        desired=min(max_ram,current_ram+1)
                        await execute_vpsctl_compat(name,f'config set {name} limits.memory.current {desired*1024}MB',node_id=node_id,timeout=45)
                        logger.info('Auto-scaled VPS %s RAM %s->%s GiB',name,current_ram,desired)
                    if cpu_pct >= RESOURCE_SCALE_UP_CPU_THRESHOLD and current_cpu < max_cpu:
                        desired_cpu=min(max_cpu,current_cpu+1)
                        await execute_vpsctl_compat(name,f'config set {name} limits.cpu.current {desired_cpu}',node_id=node_id,timeout=45)
                        logger.info('Auto-scaled VPS %s CPU %s->%s',name,current_cpu,desired_cpu)
                    current_disk=max(1,int(stats.get('disk_current_gb') or _parse_gb(vps.get('storage','10GB'),10)))
                    max_disk=max(current_disk,int(stats.get('disk_limit_gb') or _parse_gb(vps.get('storage','10GB'),10)))
                    disk_pct=float(stats.get('disk_pct') or 0.0)
                    if disk_pct >= RESOURCE_SCALE_UP_DISK_THRESHOLD and current_disk < max_disk:
                        desired_disk=min(max_disk,current_disk+RESOURCE_SCALE_UP_DISK_STEP_GB)
                        await execute_vpsctl_compat(name,f'config device set {name} root size={desired_disk}GB',node_id=node_id,timeout=90)
                        # Grow the guest filesystem only after the virtual disk expansion succeeds.
                        grow_script=r'''set +e
ROOT_DEV=$(findmnt -n -o SOURCE / 2>/dev/null || echo /dev/vda1)
ROOT_FSTYPE=$(findmnt -n -o FSTYPE / 2>/dev/null || echo ext4)
if command -v growpart >/dev/null 2>&1; then
  case "$ROOT_DEV" in
    /dev/vda[0-9]*|/dev/sda[0-9]*|/dev/nvme0n1p[0-9]*)
      BASE=$(printf '%s' "$ROOT_DEV" | sed -E 's/p?[0-9]+$//')
      NUM=$(printf '%s' "$ROOT_DEV" | sed -E 's/.*p?([0-9]+)$/\1/')
      growpart "$BASE" "$NUM" >/dev/null 2>&1 || true
      ;;
  esac
fi
case "$ROOT_FSTYPE" in
  ext2|ext3|ext4) resize2fs "$ROOT_DEV" >/dev/null 2>&1 || true ;;
  xfs) xfs_growfs / >/dev/null 2>&1 || true ;;
  btrfs) btrfs filesystem resize max / >/dev/null 2>&1 || true ;;
esac
'''
                        await _exec_guest_bash(name,node_id,grow_script,timeout=90)
                        logger.info('Auto-expanded VPS %s disk %s->%s GiB (%.1f%% used)',name,current_disk,desired_disk,disk_pct)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    logger.debug('Adaptive resource scaler skipped %s: %s',name,exc)
        await asyncio.sleep(RESOURCE_AUTOSCALE_INTERVAL)



# --- restored global policy constants ---
ANSI_RE = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
PINGGY_ENDPOINT_RE = re.compile(r'(?:https?://)?([A-Za-z0-9.-]*pinggy[^\s:/]*)(?::(\d{2,6}))?')
MAINTENANCE_SAFE_COMMANDS = {
    'ping','uptime','about','help','quickhelp','manage','status','vps-log','vps-logs','bandwidth'
}

# --- deep runtime bootstrap / persistence state ---
# init_db() MUST run before any get_setting()/get_vps_data() call.
# Otherwise a fresh/legacy database can fail during module import with:
# sqlite3.OperationalError: no such table: settings
try:
    init_db()
except Exception as db_init_error:
    logger.error(f"Fatal database initialization error: {db_init_error}", exc_info=True)
    raise

def _load_threshold_setting(key: str, env_name: str, default: int = 90) -> int:
    fallback = env_int(env_name, default)
    try:
        raw = get_setting(key, os.getenv(env_name, str(default)))
        value = int(str(raw).strip())
    except (TypeError, ValueError, sqlite3.Error):
        logger.warning("Invalid persisted resource threshold %r; using environment/default value", key)
        value = fallback
    return max(0, min(100, value))

CPU_THRESHOLD = _load_threshold_setting('cpu_threshold', 'CPU_THRESHOLD', 90)
RAM_THRESHOLD = _load_threshold_setting('ram_threshold', 'RAM_THRESHOLD', 90)
MAX_VPS_DISK_GB = VPS_MAX_DISK_GB

vps_data = get_vps_data()
admin_data = {"admins": get_admins()}
if str(MAIN_ADMIN_ID) not in admin_data["admins"]:
    admin_data["admins"].append(str(MAIN_ADMIN_ID))
    try:
        save_admin_data()
    except Exception:
        logger.exception("Could not persist the configured main admin during startup")

ACTIVE_DEPLOYMENTS = set()
EXPIRATION_WARNING_SENT = set()
EXPIRATION_EXPIRED_NOTICE_SENT = set()
PORT_OPERATION_LOCK = asyncio.Lock()
TUNNEL_OPERATION_LOCKS = {}
DEPLOY_NODE_LOCKS = {}
AUDIT_CHANNEL_SEND_LOCK = asyncio.Lock()
status_task_handle = None
expiration_task_handle = None
protection_task_handle = None
tunnel_repair_task_handle = None
access_repair_task_handle = None
resource_monitor_active = True



class RGNODESMaintenanceError(commands.CheckFailure):
    """Raised when a normal-user command is blocked by maintenance mode."""

# --- restored stable helper: RGNODESView ---
class RGNODESView(discord.ui.View):
    """Base view with a safe Discord UI error response."""
    async def on_error(self, interaction: discord.Interaction, error: Exception, item):
        error_id = secrets.token_hex(4).upper()
        logger.error(
            "Discord UI callback failed [%s] item=%s: %s",
            error_id, getattr(item, "custom_id", None) or getattr(item, "label", type(item).__name__), error, exc_info=True
        )
        message = "The requested action could not be completed right now. No destructive operation was continued. Please try again."
        if is_admin_user(getattr(interaction, "user", None)):
            message += f"\n\n**Error ID:** `{error_id}`\n**Error type:** `{type(error).__name__}`"
        else:
            message += f"\n\n**Error ID:** `{error_id}`"
        try:
            embed=create_error_embed("⚠️ Action Failed", message)
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=embed, ephemeral=True)
            else:
                await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception:
            logger.exception("Unable to deliver UI error response [%s]", error_id)


# --- restored stable helper: _publish_log_bundle ---
async def _publish_log_bundle(channel, embed, content: str, filename: str) -> None:
    """Publish an operational log embed plus a bounded text attachment.

    Discord embeds are intentionally small; the attachment preserves a useful
    complete snapshot without flooding the channel with many messages.
    """
    if channel is None or not hasattr(channel, "send"):
        return
    content = str(content or "No log output.")
    # Keep attachment comfortably below Discord's message/attachment limits and
    # avoid dumping unbounded guest logs to the host or Discord.
    content = content[-90000:]
    payload = io.BytesIO(content.encode("utf-8", errors="replace"))
    file = discord.File(payload, filename=str(filename)[:80])
    await channel.send(embed=embed, file=file, allowed_mentions=discord.AllowedMentions.none())


# --- restored stable helper: _audit_channel_id ---
def _audit_channel_id() -> int:
    try:
        return int(get_setting("logs_channel_id", "0") or 0)
    except (TypeError, ValueError):
        return 0


# --- restored stable helper: set_audit_channel_id ---
def set_audit_channel_id(channel_id: Optional[int]) -> None:
    set_setting("logs_channel_id", str(int(channel_id or 0)))


# --- restored stable helper: get_motd_text ---
def get_motd_text() -> str:
    return str(get_setting("motd_text", DEFAULT_MOTD_TEXT) or "").replace("\\n", "\n").strip()[:1200]


# --- restored stable helper: record_audit_event ---
async def record_audit_event(kind: str, action: str, detail: str = "", user_id: Optional[int | str] = None,
                             node_id: Optional[int] = None, vps_container: Optional[str] = None,
                             announce: bool = True) -> None:
    safe_detail = str(detail or "").strip()[:1800]
    safe_kind = str(kind or "system").strip()[:32]
    safe_action = str(action or "event").strip()[:120]
    try:
        with DB_LOCK:
            conn = get_db()
            try:
                conn.execute(
                    "INSERT INTO audit_logs (kind, action, detail, user_id, node_id, vps_container, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (safe_kind, safe_action, safe_detail, str(user_id) if user_id is not None else None,
                     int(node_id) if node_id is not None else None,
                     str(vps_container)[:120] if vps_container else None,
                     datetime.now().isoformat()),
                )
                conn.execute("DELETE FROM audit_logs WHERE id NOT IN (SELECT id FROM audit_logs ORDER BY id DESC LIMIT 2000)")
                conn.commit()
            finally:
                conn.close()
    except Exception as exc:
        logger.warning("Audit log persistence failed: %s", exc)
        return
    if not announce:
        return
    channel_id = _audit_channel_id()
    if not channel_id:
        return
    try:
        channel = bot.get_channel(channel_id)
        if channel is None:
            channel = await bot.fetch_channel(channel_id)
        if not hasattr(channel, "send"):
            return
        icon = {"vps": "🖥️", "node": "🧩", "command": "⌘", "system": "⚙️", "security": "🛡️", "error": "🚨"}.get(safe_kind, "📝")
        embed = create_info_embed(f"{icon} {safe_action}", safe_detail or "No additional details.")
        if node_id is not None:
            add_field(embed, "Node", f"`{node_id}`", True)
        if vps_container:
            add_field(embed, "VPS", f"`{vps_container}`", True)
        if user_id is not None:
            add_field(embed, "User", f"`{user_id}`", True)
        embed.set_footer(text=f"{HOST_PROVIDER_NAME} • RGNODES™ audit log")
        async with AUDIT_CHANNEL_SEND_LOCK:
            await channel.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
    except Exception as exc:
        logger.debug("Could not publish audit log to channel %s: %s", channel_id, exc)


# --- restored stable helper: get_recent_audit_logs ---
def get_recent_audit_logs(limit: int = 20, *, vps_container: Optional[str] = None, node_id: Optional[int] = None) -> list[dict]:
    limit = max(1, min(100, int(limit)))
    clauses = []
    params: list = []
    if vps_container:
        clauses.append("vps_container = ?"); params.append(str(vps_container))
    if node_id is not None:
        clauses.append("node_id = ?"); params.append(int(node_id))
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    params.append(limit)
    with DB_LOCK:
        conn = get_db()
        try:
            rows = conn.execute(f"SELECT kind, action, detail, user_id, node_id, vps_container, created_at FROM audit_logs{where} ORDER BY id DESC LIMIT ?", params).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()


# --- restored stable helper: _safe_fromiso ---
def _safe_fromiso(value: str) -> datetime:
    try:
        return datetime.fromisoformat(value)
    except Exception:
        return datetime.max


# --- restored stable helper: _parse_gb ---
def _parse_gb(value: Any, default: int) -> int:
    try:
        return max(1, int(float(str(value).strip().lower().replace('gb', '').strip())))
    except (TypeError, ValueError):
        return int(default)


# --- restored stable helper: _parse_cpu ---
def _parse_cpu(value: Any, default: int) -> int:
    try:
        return max(1, int(float(str(value).strip())))
    except (TypeError, ValueError):
        return int(default)


# --- restored stable helper: status_presence_task ---
async def status_presence_task():
    while not bot.is_closed():
        try:
            created, total_slots, running, expired = get_presence_counts()
            if maintenance_enabled():
                activity = f"🔧 Under Maintenance Mode"
            else:
                activity = f"🖥️ {created}/{total_slots} | 🟢 {running} Running | ⏰ {expired} Expired"
            await bot.change_presence(activity=discord.Game(name=activity))
        except Exception as e:
            logger.debug(f"Presence update failed: {e}")
        await asyncio.sleep(30)


# --- restored stable helper: truncate_text ---


# --- restored stable helper: generate_strong_password ---
def generate_strong_password(length=16):
    """Generate a cryptographically strong password"""
    # Use mix of uppercase, lowercase, digits, and special characters
    charset = string.ascii_letters + string.digits + "!@#$%^&*"
    password = ''.join(secrets.choice(charset) for _ in range(length))
    return password


# --- restored stable helper: sanitize_username_for_container ---
def sanitize_username_for_container(username: str) -> str:
    """
    Sanitize usernames for the RGNODES VPS hostname/resource identifier.
    Only safe alphanumeric and hyphen characters are allowed.
    Replace underscores, spaces, and other invalid chars with hyphens.
    """
    # Replace underscores and spaces with hyphens
    sanitized = username.replace('_', '-').replace(' ', '-')
    # Remove any character that's not alphanumeric or hyphen
    sanitized = ''.join(c for c in sanitized if c.isalnum() or c == '-')
    # Ensure it does not start or end with a hyphen.
    sanitized = sanitized.strip('-').lower()
    # Discord usernames can theoretically contain only characters that are
    # removed above. Never allow an empty or leading-dash VPS instance name.
    sanitized = sanitized[:30] or 'user'
    return sanitized


# --- restored stable helper: get_vps_password ---
def get_vps_password(container_name):
    """Get password from VPS data"""
    for user_id, vps_list in vps_data.items():
        for vps in vps_list:
            if vps['container_name'] == container_name:
                return vps.get('root_password', None)
    return None


# --- restored stable helper: set_vps_password ---
def set_vps_password(container_name, password):
    """Set password for VPS"""
    for user_id, vps_list in vps_data.items():
        for vps in vps_list:
            if vps['container_name'] == container_name:
                vps['root_password'] = password
                save_vps_data_immediate()
                return True
    return False


# --- restored stable helper: _exec_guest_bash ---


# --- safe embedded RGNODES MOTD installer ---
def build_rgnodes_motd_profile_script(motd_text: str) -> str:
    """Build a POSIX-shell login banner without touching PAM, sshd, or system MOTD hooks."""
    custom_b64 = base64.b64encode(str(motd_text or "").replace("\x00", "").strip()[:1200].encode("utf-8")).decode("ascii")
    template = r"""#!/bin/sh
# RGNODES™ MOTD installer (safe embedded adaptation of the requested installer).
# This file is sourced by /etc/profile. It never edits PAM/sshd or disables distro MOTD hooks.
case "$-" in *i*) ;; *) return 0 2>/dev/null || exit 0 ;; esac
[ -t 1 ] || return 0 2>/dev/null || exit 0
if [ -z "${SSH_CONNECTION:-}${SSH_TTY:-}" ]; then return 0 2>/dev/null || exit 0; fi
[ "${RGNODES_MOTD_SHOWN:-0}" = 1 ] && return 0 2>/dev/null || :
RGNODES_MOTD_SHOWN=1
export RGNODES_MOTD_SHOWN

GREEN=$(printf '\033[38;5;82m')
CYAN=$(printf '\033[38;5;51m')
BLUE=$(printf '\033[38;5;39m')
MAGENTA=$(printf '\033[38;5;213m')
YELLOW=$(printf '\033[38;5;220m')
GRAY=$(printf '\033[38;5;245m')
RESET=$(printf '\033[0m')

HOSTNAME_VALUE=$(hostname 2>/dev/null || uname -n 2>/dev/null || printf 'unknown')
OS_VALUE=$(sed -n 's/^PRETTY_NAME=//p' /etc/os-release 2>/dev/null | head -n 1 | sed 's/^"//;s/"$//')
[ -n "$OS_VALUE" ] || OS_VALUE=$(uname -s 2>/dev/null || printf 'Linux')
KERNEL_VALUE=$(uname -r 2>/dev/null || printf 'N/A')
UPTIME_VALUE=$(uptime -p 2>/dev/null | sed 's/^up //' || true)
[ -n "$UPTIME_VALUE" ] || UPTIME_VALUE=$(uptime 2>/dev/null | sed 's/^[^,]*up /up /' | cut -c1-80 || printf 'N/A')

cpu_usage() {
    [ -r /proc/stat ] || { printf 'N/A'; return; }
    set -- $(awk 'NR==1 {t=$2+$3+$4+$5+$6+$7+$8+$9; i=$5+$6; printf "%.0f %.0f",t,i}' /proc/stat 2>/dev/null)
    t1=${1:-0}; i1=${2:-0}
    sleep 0.1 2>/dev/null || true
    set -- $(awk 'NR==1 {t=$2+$3+$4+$5+$6+$7+$8+$9; i=$5+$6; printf "%.0f %.0f",t,i}' /proc/stat 2>/dev/null)
    t2=${1:-0}; i2=${2:-0}
    dt=$((t2-t1)); di=$((i2-i1))
    if [ "$dt" -gt 0 ] 2>/dev/null; then
        pct=$(((dt-di)*100/dt)); [ "$pct" -lt 0 ] && pct=0; [ "$pct" -gt 100 ] && pct=100
        printf '%s%%' "$pct"
    else printf 'N/A'; fi
}
CPU_VALUE=$(cpu_usage 2>/dev/null || printf 'N/A')
MEM_VALUE=$(awk '/^MemTotal:/ {t=$2} /^MemAvailable:/ {a=$2} END {if (t>0) {u=t-a; if(u<0)u=0; printf "%d/%d MB (%d%%)",u/1024,t/1024,u*100/t} else print "N/A"}' /proc/meminfo 2>/dev/null)
[ -n "$MEM_VALUE" ] || MEM_VALUE='N/A'
DISK_VALUE=$(df -h / 2>/dev/null | awk 'NR==2 {printf "%s / %s (%s)",$3,$2,$5}')
[ -n "$DISK_VALUE" ] || DISK_VALUE='N/A'
IP_VALUE=$(hostname -I 2>/dev/null | awk '{$1=$1; print $1}')
[ -n "$IP_VALUE" ] || IP_VALUE=$(ip -4 -o addr show scope global 2>/dev/null | awk 'NR==1 {split($4,a,"/"); print a[1]}')
[ -n "$IP_VALUE" ] || IP_VALUE='N/A'
USER_COUNT=$(who 2>/dev/null | wc -l | tr -d ' ')
PROC_COUNT=$(ps -e 2>/dev/null | wc -l | awk '{print ($1>0 ? $1-1 : 0)}')

printf '\n%s' "$MAGENTA"
printf '%s\n' '██████╗  ██████╗ ███╗   ██╗ ██████╗ ██████╗ ███████╗███████╗™'
printf '%s\n' '██╔══██╗██╔════╝ ████╗  ██║██╔══██╗██╔══██╗██╔════╝██╔════╝'
printf '%s\n' '██████╔╝██║  ██╗ ██╔██╗ ██║██║  ██║██║  ██║█████╗  ╚█████╗ '
printf '%s\n' '██╔══██╗██║  ╚██╗██║╚██╗██║██║  ██║██║  ██║██╔══╝  ╚═══██╗ '
printf '%s\n' '██║  ██║╚██████╔╝██║ ╚████║╚█████╔╝██████╔╝███████╗██████╔╝'
printf '%s\n' '╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚══╝ ╚════╝ ╚═════╝ ╚══════╝╚═════╝  '
printf '%s\n' "$RESET"
printf '%s\n' "${GREEN}🚀 Welcome to RGNODES™ VPS${RESET}"
printf '%s\n' "${BLUE}High Performance • Secure • Reliable${RESET}"
printf '%s\n' "${GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
printf '%s%-18s%s %s\n' "$CYAN" 'Hostname:' "$RESET" "$HOSTNAME_VALUE"
printf '%s%-18s%s %s\n' "$CYAN" 'OS:' "$RESET" "$OS_VALUE"
printf '%s%-18s%s %s\n' "$CYAN" 'Kernel:' "$RESET" "$KERNEL_VALUE"
printf '%s%-18s%s %s\n' "$CYAN" 'Uptime:' "$RESET" "$UPTIME_VALUE"
printf '%s%-18s%s %s\n' "$CYAN" 'CPU Usage:' "$RESET" "$CPU_VALUE"
printf '%s%-18s%s %s\n' "$CYAN" 'Memory:' "$RESET" "$MEM_VALUE"
printf '%s%-18s%s %s\n' "$CYAN" 'Disk:' "$RESET" "$DISK_VALUE"
printf '%s%-18s%s %s\n' "$CYAN" 'Processes:' "$RESET" "$PROC_COUNT"
printf '%s%-18s%s %s\n' "$CYAN" 'Users:' "$RESET" "$USER_COUNT"
printf '%s%-18s%s %s\n' "$CYAN" 'IP:' "$RESET" "$IP_VALUE"
printf '%s\n' "${GRAY}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
CUSTOM_MOTD_B64='@@CUSTOM_MOTD_B64@@'
if command -v base64 >/dev/null 2>&1 && [ -n "$CUSTOM_MOTD_B64" ]; then
    CUSTOM_MOTD=$(printf '%s' "$CUSTOM_MOTD_B64" | base64 -d 2>/dev/null || true)
    if [ -n "$CUSTOM_MOTD" ]; then printf '%s\n' "$CUSTOM_MOTD"; fi
fi
printf '%s\n' "${GREEN}Official Website:${RESET}  https://www.rrgnodes.bond"
printf '%s\n' "${GREEN}Discord:${RESET}  https://discord.gg/wJ5D5MHkUA"
printf '%s\n' "${GREEN}Status Page:${RESET}  https://status.rgnodes.bond"
printf '%s\n\n' "${MAGENTA}RGNODES™ — Free Reliable Hosting 📌${RESET}"
"""
    return template.replace('@@CUSTOM_MOTD_B64@@', custom_b64)


async def apply_guest_motd(container_name: str, node_id: int, motd_text: Optional[str] = None) -> bool:
    """Install the safe RGNODES login MOTD, preserving PAM/sshd and distro hooks.

    The upstream installer currently edits PAM, disables distro update-motd hooks and
    deletes /etc/motd. The embedded equivalent provides the same branded system summary
    without executing mutable remote code or altering authentication configuration.
    """
    text = str(motd_text if motd_text is not None else get_motd_text() or "").replace("\x00", "").strip()[:1200]
    try:
        # Remove only files managed by this bot. Never erase the distro's /etc/motd.
        if not text:
            remote = "rm -f -- /etc/profile.d/00-rgnodes-motd.sh /etc/profile.d/99-rgnodes-motd.sh; printf 'MOTD_CLEARED\\n'"
            out = await _exec_guest_bash(container_name, node_id, remote, timeout=30)
            return "MOTD_CLEARED" in str(out or "")

        if AUTO_MOTD_INSTALLER and MOTD_INSTALL_COMMAND:
            # This is an explicit operator-owned guest command from .env. Run it once per
            # command fingerprint; never download or inspect its source in the control bot.
            command = MOTD_INSTALL_COMMAND
            if len(command) > 1000 or any(ch in command for ch in ('\x00', '\r', '\n')):
                logger.error('Configured MOTD_INSTALL_COMMAND is invalid; use one single-line command (max 1000 chars).')
                return False
            command_b64 = base64.b64encode(command.encode('utf-8')).decode('ascii')
            command_fingerprint = hashlib.sha256(command.encode('utf-8')).hexdigest()[:16]
            sentinel = f'/var/lib/rgnodes/.motd-command-{command_fingerprint}.done'
            remote = f"""set -Eeuo pipefail
command -v base64 >/dev/null 2>&1 || {{ echo 'MOTD installer needs base64' >&2; exit 20; }}
install -d -m 0755 /var/lib/rgnodes
if [ -f {shlex.quote(sentinel)} ]; then printf 'MOTD_COMMAND_ALREADY_DONE\\n'; exit 0; fi
cmd="$(printf '%s' '{command_b64}' | base64 -d)"
# Execute exactly the configured command in the guest's Bash; output is not sent to Discord.
bash -lc "$cmd"
touch {shlex.quote(sentinel)}
chmod 0644 {shlex.quote(sentinel)}
printf 'MOTD_COMMAND_INSTALLED\\n'
"""
            out = await _exec_guest_bash(container_name, node_id, remote, timeout=MOTD_INSTALL_TIMEOUT)
            return any(marker in str(out or '') for marker in ('MOTD_COMMAND_ALREADY_DONE', 'MOTD_COMMAND_INSTALLED'))

        if AUTO_MOTD_INSTALLER:
            installer = build_rgnodes_motd_profile_script(text)
            encoded_script = base64.b64encode(installer.encode("utf-8")).decode("ascii")
            profile_path = "/etc/profile.d/99-rgnodes-motd.sh"
            remote = f"""set -Eeuo pipefail
command -v base64 >/dev/null 2>&1 || {{ echo 'MOTD install failed: base64 is required' >&2; exit 20; }}
install -d -m 0755 /etc/profile.d
umask 022
tmp="$(mktemp /etc/profile.d/.99-rgnodes-motd.sh.XXXXXX)"
trap 'rm -f -- "$tmp"' EXIT
printf '%s' '{encoded_script}' | base64 -d > "$tmp"
sh -n "$tmp"
chmod 0644 "$tmp"
if [ -f {shlex.quote(profile_path)} ] && cmp -s "$tmp" {shlex.quote(profile_path)}; then
  rm -f -- "$tmp"
else
  mv -f -- "$tmp" {shlex.quote(profile_path)}
fi
# Clean only the bot's legacy profile hook to avoid duplicate banners.
rm -f -- /etc/profile.d/00-rgnodes-motd.sh
trap - EXIT
printf 'RGNODES_MOTD_INSTALLED_SAFE\\n'
"""
            out = await _exec_guest_bash(container_name, node_id, remote, timeout=45)
            return "RGNODES_MOTD_INSTALLED_SAFE" in str(out or "")

        # Compatibility mode: update /etc/motd, but let PAM render it when available.
        b64 = base64.b64encode(text.encode("utf-8")).decode("ascii")
        profile_path = "/etc/profile.d/00-rgnodes-motd.sh"
        remote = f"""set -Eeuo pipefail
install -d -m 0755 /etc/profile.d
printf '%s' '{b64}' | base64 -d > /etc/motd
chmod 0644 /etc/motd
rm -f -- /etc/profile.d/99-rgnodes-motd.sh
if grep -RqsE '^[[:space:]]*[^#].*pam_motd\\.so' /etc/pam.d 2>/dev/null; then
  rm -f -- {shlex.quote(profile_path)}
  printf 'MOTD_READY_PAM\\n'
else
  cat > {shlex.quote(profile_path)} <<'RGNODES_MOTD_EOF'
#!/bin/sh
case "$-" in *i*) ;; *) return 0 2>/dev/null || exit 0 ;; esac
if [ -n "${{SSH_CONNECTION:-}}${{SSH_TTY:-}}" ] && [ -t 1 ] && [ -r /etc/motd ]; then cat /etc/motd; fi
RGNODES_MOTD_EOF
  chmod 0644 {shlex.quote(profile_path)}
  printf 'MOTD_READY_PROFILE\\n'
fi
"""
        out = await _exec_guest_bash(container_name, node_id, remote, timeout=45)
        out_text = str(out or "")
        return "MOTD_READY_PAM" in out_text or "MOTD_READY_PROFILE" in out_text
    except Exception as exc:
        logger.warning("MOTD apply failed for %s: %s", container_name, exc)
        return False


# --- restored stable helper: apply_motd_to_all_running_vps ---
async def apply_motd_to_all_running_vps() -> tuple[int, int]:
    ok = failed = 0
    sem = asyncio.Semaphore(2)
    async def one(vps):
        nonlocal ok, failed
        if str(vps.get("status", "")).lower() != "running" or vps.get("suspended"):
            return
        async with sem:
            try:
                if await apply_guest_motd(str(vps.get("container_name")), int(vps.get("node_id", 1))):
                    ok += 1
                else:
                    failed += 1
            except Exception:
                failed += 1
    items = [v for owner_items in list(vps_data.values()) for v in list(owner_items)]
    for start in range(0, len(items), 20):
        await asyncio.gather(*(one(v) for v in items[start:start + 20]), return_exceptions=True)
    return ok, failed


# --- restored stable helper: configure_ssh ---
async def configure_ssh(container_name, node_id, password):
    """Configure root/password SSH deterministically and verify the effective daemon config."""
    script = rf'''set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive
mkdir -p /etc/ssh/sshd_config.d /run/sshd /var/log
[ -f /etc/ssh/sshd_config ] || touch /etc/ssh/sshd_config
[ -f /etc/ssh/sshd_config.rgnodes-original ] || cp -a /etc/ssh/sshd_config /etc/ssh/sshd_config.rgnodes-original 2>/dev/null || true
# Some cloud images ship PasswordAuthentication no / AuthenticationMethods publickey.
# OpenSSH uses the first obtained value, so this file must be lexically first.
IS_ALPINE=0
[ -f /etc/alpine-release ] && IS_ALPINE=1
if [ "$IS_ALPINE" -eq 1 ]; then
  grep -q '^Include /etc/ssh/sshd_config.d/\*.conf' /etc/ssh/sshd_config || sed -i '1i Include /etc/ssh/sshd_config.d/*.conf' /etc/ssh/sshd_config
fi
cat > /etc/ssh/sshd_config.d/00-rgnodes-access.conf <<'EOF'
Port 22
AddressFamily any
ListenAddress 0.0.0.0
ListenAddress ::
PasswordAuthentication yes
KbdInteractiveAuthentication yes
ChallengeResponseAuthentication yes
PubkeyAuthentication yes
PermitRootLogin yes
MaxAuthTries 6
MaxSessions 50
TCPKeepAlive yes
ClientAliveInterval 60
ClientAliveCountMax 6
PermitEmptyPasswords no
PrintMotd yes
PrintLastLog yes
Subsystem sftp internal-sftp
EOF
if [ "$IS_ALPINE" -ne 1 ]; then printf 'UsePAM yes\n' >> /etc/ssh/sshd_config.d/00-rgnodes-access.conf; fi
# If the distribution keeps a global AuthenticationMethods/PasswordAuthentication before Include,
# comment just those auth overrides; retain unrelated vendor configuration.
for cfg in /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf; do
  [ -f "$cfg" ] || continue
  [ "$cfg" = /etc/ssh/sshd_config.d/00-rgnodes-access.conf ] && continue
  sed -i -E 's/^[[:space:]]*(PasswordAuthentication|KbdInteractiveAuthentication|ChallengeResponseAuthentication|PubkeyAuthentication|PermitRootLogin|AuthenticationMethods)[[:space:]].*$/# RGNODES neutralized: &/' "$cfg" 2>/dev/null || true
done
printf '%s:%s\n' root {shlex.quote(password)} | chpasswd
passwd -u root >/dev/null 2>&1 || true
usermod -U root >/dev/null 2>&1 || true
chage -M -1 root >/dev/null 2>&1 || true
SSHD=$(command -v sshd || true)
if [ -z "$SSHD" ]; then
  install_pkg() {{
    case "$1" in
      apt)
        apt-get install -y --no-install-recommends openssh-server openssh-client >/dev/null 2>&1 && return 0
        apt-get update -qq >/dev/null 2>&1 || true
        apt-get install -y --no-install-recommends openssh-server openssh-client >/dev/null 2>&1 || return 1
        ;;
      dnf) dnf install -y openssh-server openssh-clients >/dev/null 2>&1 || return 1 ;;
      yum) yum install -y openssh-server openssh-clients >/dev/null 2>&1 || return 1 ;;
      apk) apk add --no-cache openssh >/dev/null 2>&1 || return 1 ;;
      zypper) zypper --non-interactive install -y openssh >/dev/null 2>&1 || return 1 ;;
      *) return 1 ;;
    esac
  }}
  if command -v apt-get >/dev/null 2>&1; then install_pkg apt || true
  elif command -v dnf >/dev/null 2>&1; then install_pkg dnf || true
  elif command -v yum >/dev/null 2>&1; then install_pkg yum || true
  elif command -v apk >/dev/null 2>&1; then install_pkg apk || true
  elif command -v zypper >/dev/null 2>&1; then install_pkg zypper || true
  fi
  SSHD=$(command -v sshd || true)
fi
[ -n "$SSHD" ] || {{ echo 'SSH_SERVER_NOT_READY'; exit 12; }}
chmod 600 /etc/ssh/sshd_config /etc/ssh/sshd_config.d/00-rgnodes-access.conf 2>/dev/null || true
# Restore any MOTD lines disabled by older RGNODES releases. We now rely on distro PAM
# when available and only install a shell fallback when PAM has no pam_motd module.
for cfg in /etc/pam.d/sshd /etc/pam.d/common-session /etc/pam.d/common-session-noninteractive; do
  [ -f "$cfg" ] || continue
  sed -i 's/^# RGNODES disabled duplicate MOTD: //' "$cfg" 2>/dev/null || true
done
$SSHD -t
EFFECTIVE=$($SSHD -T -C user=root,addr=127.0.0.1,localport=22,host=$(hostname -f 2>/dev/null || hostname) 2>/dev/null || true)
printf '%s\n' "$EFFECTIVE" | grep -Eq '^passwordauthentication yes$' || {{ echo 'PASSWORD_AUTH_NOT_EFFECTIVE'; exit 13; }}
printf '%s\n' "$EFFECTIVE" | grep -Eq '^kbdinteractiveauthentication yes$' || {{ echo 'KBD_AUTH_NOT_EFFECTIVE'; exit 14; }}
printf '%s\n' "$EFFECTIVE" | grep -Eq '^permitrootlogin yes$' || {{ echo 'ROOT_LOGIN_NOT_EFFECTIVE'; exit 15; }}
printf '%s\n' "$EFFECTIVE" | grep -Eq '^printmotd yes$' || {{ echo 'PRINT_MOTD_NOT_EFFECTIVE'; exit 16; }}
if command -v systemctl >/dev/null 2>&1 && [ "$(cat /proc/1/comm 2>/dev/null)" = "systemd" ]; then
  systemctl daemon-reload >/dev/null 2>&1 || true
  systemctl enable ssh >/dev/null 2>&1 || systemctl enable sshd >/dev/null 2>&1 || true
  systemctl restart ssh >/dev/null 2>&1 || systemctl restart sshd >/dev/null 2>&1 || true
elif command -v rc-service >/dev/null 2>&1; then
  rc-service sshd restart >/dev/null 2>&1 || rc-service ssh restart >/dev/null 2>&1 || rc-service sshd start >/dev/null 2>&1 || true
elif command -v service >/dev/null 2>&1; then
  service ssh restart >/dev/null 2>&1 || service sshd restart >/dev/null 2>&1 || service ssh start >/dev/null 2>&1 || true
fi
if ! ss -lntH 2>/dev/null | awk '$4 ~ /:(22)$/ {{ok=1}} END {{exit ok?0:1}}'; then
  mkdir -p /run/sshd
  nohup $SSHD -D >/var/log/rgnodes-sshd.log 2>&1 &
  sleep 2
fi
ss -lntH 2>/dev/null | awk '$4 ~ /:(22)$/ {{ok=1}} END {{exit ok?0:1}}'
printf 'SSH_READY\n'
'''
    try:
        output=await _exec_guest_bash(container_name,node_id,script,timeout=105)
        if 'SSH_READY' not in str(output): raise RuntimeError('SSH readiness check did not pass inside the VPS.')
        set_vps_password(container_name,password)
        return True,password
    except Exception as e:
        logger.error(f"Failed to configure SSH for {container_name}: {e}",exc_info=True)
        return False,str(e)


# --- restored stable helper: set_guest_hostname ---
async def set_guest_hostname(container_name: str, node_id: int, hostname: str = VPS_HOSTNAME):
    safe = re.sub(r'[^A-Za-z0-9.-]', '-', hostname).strip('.-') or 'rgnodes-vps'
    script = f"""set -e
printf '%s\\n' {shlex.quote(safe)} > /etc/hostname
(hostnamectl set-hostname {shlex.quote(safe)} 2>/dev/null || hostname {shlex.quote(safe)} || true)
sed -i -E '/^[[:space:]]*127\\.0\\.1\\.1[[:space:]]+/d' /etc/hosts 2>/dev/null || true
printf '127.0.1.1 %s\\n' {shlex.quote(safe)} >> /etc/hosts
"""
    return await _exec_guest_bash(container_name, node_id, script, timeout=60)


# --- restored stable helper: bootstrap_vps_guest ---
async def bootstrap_vps_guest(container_name: str, node_id: int):
    """Install the lightweight RGNODES baseline; heavy virtualization is never installed automatically."""
    script = r'''set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a
if command -v apt-get >/dev/null 2>&1; then
  for attempt in 1 2 3 4; do apt-get update -qq && break; sleep $((attempt*2)); done
  apt-get install -y --no-install-recommends bash coreutils grep sed gawk sudo openssh-server openssh-client curl ca-certificates iproute2 iputils-ping procps net-tools python3 python3-pip
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y bash coreutils grep sed gawk sudo openssh-server openssh-clients curl ca-certificates iproute iputils procps-ng net-tools python3 python3-pip
elif command -v yum >/dev/null 2>&1; then
  yum install -y bash coreutils grep sed gawk sudo openssh-server openssh-clients curl ca-certificates iproute iputils procps net-tools python3 python3-pip
elif command -v apk >/dev/null 2>&1; then
  apk add --no-cache bash coreutils grep sed gawk sudo openssh curl ca-certificates iproute2 iputils procps net-tools python3 py3-pip
else
  echo 'SUPPORTED_PACKAGE_MANAGER_NOT_FOUND' >&2
  exit 20
fi
mkdir -p /etc/ssh/sshd_config.d /run/sshd /var/lib/rgnodes
command -v sshd >/dev/null 2>&1 || { echo 'SSH_SERVER_MISSING' >&2; exit 21; }
printf 'BASELINE_READY\n'
'''
    await _exec_guest_bash(container_name,node_id,script,timeout=GUEST_BOOTSTRAP_TIMEOUT)


# --- restored stable helper: install_anti_mining_guard ---
async def install_anti_mining_guard(container_name: str, node_id: int):
    """Install conservative best-effort anti-cryptomining protection in every VPS."""
    if not ANTI_MINING_ENABLED:
        return
    script = r'''set +u
cat > /usr/local/sbin/rgnodes-mining-guard <<'GUARD'
#!/usr/bin/env bash
set +e
MINER_NAMES='^(xmrig|xmrig-proxy|xmr-stak|cpuminer|cpuminer-multi|minerd|ccminer|cgminer|bfgminer|nbminer|lolminer|t-rex|ethminer|nanominer|rigel|gminer|teamredminer|phoenixminer)$'
for proc in /proc/[0-9]*; do
  pid=${proc##*/}
  [ "$pid" = "$$" ] && continue
  [ -r "$proc/cmdline" ] || continue
  [ -r "$proc/comm" ] || continue
  comm=$(tr -d '\0\n' < "$proc/comm" 2>/dev/null)
  cmd=$(tr '\0' ' ' < "$proc/cmdline" 2>/dev/null)
  lower_comm=$(printf '%s' "$comm" | tr '[:upper:]' '[:lower:]')
  lower_cmd=$(printf '%s' "$cmd" | tr '[:upper:]' '[:lower:]')
  suspicious=0
  printf '%s\n' "$lower_comm" | grep -Eq "$MINER_NAMES" && suspicious=1
  printf '%s\n' "$lower_cmd" | grep -Eq '(^|[[:space:]])(stratum\+tcp|stratum\+ssl|ethashstratum|nicehash)([^[:alnum:]_-]|$)' && suspicious=1
  [ "$suspicious" -eq 1 ] || continue
  case "$lower_cmd" in
    *rgnodes-mining-guard*|*/sshd*|*/systemd*|*/init*|*cloud-init*|*apt*|*dpkg*) continue ;;
  esac
  kill -TERM "$pid" 2>/dev/null || true
  sleep 0.25
  kill -KILL "$pid" 2>/dev/null || true
  logger -t rgnodes-mining-guard "Blocked suspected cryptominer pid=$pid comm=$comm" 2>/dev/null || true
done
GUARD
chmod 0755 /usr/local/sbin/rgnodes-mining-guard
if command -v systemctl >/dev/null 2>&1; then
  cat > /etc/systemd/system/rgnodes-mining-guard.service <<'EOF2'
[Unit]
Description=RGNODES Anti-Mining Protection
After=multi-user.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/rgnodes-mining-guard
EOF2
  cat > /etc/systemd/system/rgnodes-mining-guard.timer <<'EOF2'
[Unit]
Description=RGNODES Anti-Mining Protection Timer

[Timer]
OnBootSec=30s
OnUnitActiveSec=30s
AccuracySec=5s
Persistent=true
Unit=rgnodes-mining-guard.service

[Install]
WantedBy=timers.target
EOF2
  systemctl daemon-reload >/dev/null 2>&1 || true
  systemctl enable --now rgnodes-mining-guard.timer >/dev/null 2>&1 || true
else
  mkdir -p /etc/cron.d
  printf '*/1 * * * * root /usr/local/sbin/rgnodes-mining-guard >/dev/null 2>&1\n' > /etc/cron.d/rgnodes-mining-guard
  chmod 0644 /etc/cron.d/rgnodes-mining-guard
fi
/usr/local/sbin/rgnodes-mining-guard >/dev/null 2>&1 || true
'''
    try:
        await _exec_guest_bash(container_name, node_id, script, timeout=45)
    except Exception as e:
        logger.warning(f"Anti-mining guard installation skipped for {container_name}: {e}")


# --- restored stable helper: _run_tunnel_control ---
async def _run_tunnel_control(container_name: str, node_id: int, action: str, tunnel_name: str, timeout: int = 60):
    '''Start/restart exactly one tunnel supervisor.

    Some VPS cloud images provide a `systemctl` client even when systemd is not PID 1, so the
    real init process is detected before systemd is used. Non-systemd guests get
    a direct supervisor plus a cron @reboot fallback.
    '''
    if action not in {"start", "restart"}:
        raise ValueError("Unsupported tunnel control action")
    if tunnel_name != "pinggy":
        raise ValueError("Unsupported tunnel name")
    sup = f"/usr/local/sbin/rgnodes-{tunnel_name}-supervisor"
    service = f"rgnodes-{tunnel_name}.service"
    log = f"/var/lib/rgnodes/{tunnel_name}-supervisor.log"
    supervisor_pid_file = f"/var/lib/rgnodes/{tunnel_name}.supervisor.pid"
    cron_file = f"/etc/cron.d/rgnodes-{tunnel_name}"
    command = r'''set +e
systemd_ok=false
[ -d /run/systemd/system ] && [ "$(cat /proc/1/comm 2>/dev/null)" = "systemd" ] && systemd_ok=true
SUP="__SUP__"
SERVICE="__SERVICE__"
LOG="__LOG__"
SUPPID="__SUPPID__"
CRON_FILE="__CRON_FILE__"
is_alive() {
  pid=$(cat "$SUPPID" 2>/dev/null | head -n1)
  [ -n "$pid" ] && kill -0 "$pid" >/dev/null 2>&1
}
start_bg() {
  is_alive && return 0
  mkdir -p "$(dirname "$LOG")"
  nohup "$SUP" >>"$LOG" 2>&1 </dev/null &
  sleep 1
}
stop_bg() {
  pid=$(cat "$SUPPID" 2>/dev/null | head -n1)
  if [ -n "$pid" ] && kill -0 "$pid" >/dev/null 2>&1; then
    kill -TERM "$pid" >/dev/null 2>&1 || true
    for _ in 1 2 3 4 5; do
      sleep 1
      kill -0 "$pid" >/dev/null 2>&1 || break
    done
    kill -KILL "$pid" >/dev/null 2>&1 || true
  fi
  rm -f "$SUPPID"
}
if [ "$systemd_ok" = true ]; then
  systemctl daemon-reload >/dev/null 2>&1 || true
  if [ "__ACTION__" = "restart" ]; then
    systemctl restart "$SERVICE" >/dev/null 2>&1 || true
  else
    systemctl start "$SERVICE" >/dev/null 2>&1 || true
  fi
  systemctl enable "$SERVICE" >/dev/null 2>&1 || true
else
  stop_bg
  start_bg
fi
if [ "$systemd_ok" = true ] && ! systemctl is-active --quiet "$SERVICE" >/dev/null 2>&1; then
  start_bg
fi
if [ "$systemd_ok" != true ]; then
  start_bg
  mkdir -p /etc/cron.d
  printf 'SHELL=/bin/sh\nPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n@reboot root %s >>%s 2>&1\n' "$SUP" "$LOG" > "$CRON_FILE"
  chmod 0644 "$CRON_FILE" 2>/dev/null || true
  if command -v service >/dev/null 2>&1; then
    service cron start >/dev/null 2>&1 || service crond start >/dev/null 2>&1 || true
  elif command -v cron >/dev/null 2>&1; then
    pgrep -x cron >/dev/null 2>&1 || nohup cron >/dev/null 2>&1 &
  elif command -v crond >/dev/null 2>&1; then
    pgrep -x crond >/dev/null 2>&1 || nohup crond >/dev/null 2>&1 &
  fi
fi
if is_alive; then
  printf 'TUNNEL_CONTROL_DONE\n'
else
  printf 'TUNNEL_CONTROL_FAILED\n'
fi
'''.replace('__ACTION__', action).replace('__SUP__', sup).replace('__SERVICE__', service).replace('__LOG__', log).replace('__CRON_FILE__', cron_file).replace('__SUPPID__', supervisor_pid_file)
    return await _exec_guest_bash(container_name, node_id, command, timeout=timeout)


# --- restored stable helper: _get_tunnel_lock ---
def _get_tunnel_lock(container_name: str, tunnel_name: str) -> asyncio.Lock:
    key = f"{container_name}:{tunnel_name}"
    lock = TUNNEL_OPERATION_LOCKS.get(key)
    if lock is None:
        lock = asyncio.Lock()
        TUNNEL_OPERATION_LOCKS[key] = lock
    return lock


# --- restored stable helper: _get_deploy_node_lock ---
def _get_deploy_node_lock(node_id: int) -> asyncio.Lock:
    key = int(node_id)
    lock = DEPLOY_NODE_LOCKS.get(key)
    if lock is None:
        lock = asyncio.Lock()
        DEPLOY_NODE_LOCKS[key] = lock
    return lock


# --- restored stable helper: parse_pinggy_endpoint ---
def parse_pinggy_endpoint(output: str) -> tuple[Optional[str], Optional[int], Optional[str]]:
    """Parse current Pinggy TCP endpoint formats robustly."""
    cleaned = ANSI_RE.sub('', str(output or ''))
    for text in [cleaned] + re.findall(r"tcp://[^\s`'<>]+", cleaned, flags=re.IGNORECASE):
        m = PINGGY_ENDPOINT_RE.search(text)
        if m:
            host = m.group(1).rstrip('.,);]')
            try:
                port = int(m.group(2))
            except ValueError:
                continue
            if 1 <= port <= 65535:
                return host, port, f"tcp://{host}:{port}"
    host_m = re.search(r"([A-Za-z0-9][A-Za-z0-9.-]*(?:pinggy(?:-free)?|pinggy-free)\.(?:link|online))", cleaned, re.I)
    port_m = re.search(r"\b([1-9]\d{2,4})\b", cleaned)
    if host_m and port_m:
        host = host_m.group(1)
        port = int(port_m.group(1))
        if 1 <= port <= 65535:
            return host, port, f"tcp://{host}:{port}"
    return None, None, None


# --- restored stable helper: _install_tunnel_supervisors_unlocked ---
async def _install_tunnel_supervisors_unlocked(container_name: str, node_id: int) -> None:
    """Install the lightweight Pinggy supervisor (serialized wrapper below)."""
    safe_host = re.sub(r"[^A-Za-z0-9.-]", "", PINGGY_HOST).strip('.') or "free.pinggy.io"
    safe_port = max(1, min(65535, int(PINGGY_SSH_PORT)))
    safe_remote_port = max(0, min(65535, int(PINGGY_REMOTE_PORT)))
    script = r"""set +e
export DEBIAN_FRONTEND=noninteractive
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
D=/var/lib/rgnodes
mkdir -p /usr/local/sbin "$D"

install_pkg() {
  pkgs="$*"
  [ -n "$pkgs" ] || return 0
  if command -v apt-get >/dev/null 2>&1; then
    # Avoid repeated apt index downloads on every tunnel health check.
    apt-get install -y --no-install-recommends $pkgs >/dev/null 2>&1 || {
      apt-get update -qq >/dev/null 2>&1 || true
      apt-get install -y --no-install-recommends $pkgs >/dev/null 2>&1 || true
    }
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache $pkgs >/dev/null 2>&1 || true
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y $pkgs >/dev/null 2>&1 || true
  elif command -v yum >/dev/null 2>&1; then
    yum install -y $pkgs >/dev/null 2>&1 || true
  elif command -v zypper >/dev/null 2>&1; then
    zypper --non-interactive install -y $pkgs >/dev/null 2>&1 || true
  fi
}
command -v ssh >/dev/null 2>&1 || install_pkg openssh-client
command -v ssh >/dev/null 2>&1 || install_pkg openssh-clients
command -v curl >/dev/null 2>&1 || install_pkg curl
command -v curl >/dev/null 2>&1 || command -v wget >/dev/null 2>&1 || install_pkg wget
command -v script >/dev/null 2>&1 || install_pkg util-linux
command -v flock >/dev/null 2>&1 || true


cat > /usr/local/sbin/rgnodes-pinggy-supervisor <<'EOF_PINGGY'
#!/usr/bin/env bash
set +e
D=/var/lib/rgnodes
LOG="$D/pinggy.log"
INFO="$D/pinggy.info"
PID="$D/pinggy.pid"
SUPPID="$D/pinggy.supervisor.pid"
KEY="$D/pinggy_ed25519"
HOST="__PINGGY_HOST__"
PORT="__PINGGY_PORT__"
REMOTE_PORT="__PINGGY_REMOTE_PORT__"
LOCK="$D/pinggy.lock"
mkdir -p "$D"
printf '%s\n' "$$" > "$SUPPID"
exec 8>"$LOCK"
if command -v flock >/dev/null 2>&1; then flock -n 8 || exit 0; fi
extract_endpoint() {
  sed -E $'s/\\x1B\\[[0-9;]*[[:alpha:]]//g' "$LOG" 2>/dev/null | \
    grep -Eo '(tcp://)?[A-Za-z0-9][A-Za-z0-9.-]*(pinggy(-free)?|pinggy-free)\\.(link|online):[0-9]{2,5}' | head -n1 || true
}
trap 'rm -f "$PID" "$SUPPID"' EXIT INT TERM
while true; do
  if [ -f "$LOG" ] && [ "$(wc -c < "$LOG" 2>/dev/null || echo 0)" -gt 2097152 ]; then
    tail -c 524288 "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG" 2>/dev/null || true
  fi
  : > "$INFO"
  connected=0
  # If the account allows a reserved port, request it first. Free Pinggy commonly assigns
  # a random public port, so retry with port 0 if the fixed request is rejected.
  for requested_port in "$REMOTE_PORT" 0; do
    if [ "$requested_port" = "0" ]; then forward="0:127.0.0.1:22"; else forward="$requested_port:127.0.0.1:22"; fi
    : > "$LOG"
    (printf '\n' | ssh -T \
        -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        -o UpdateHostkeys=no \
        -o ServerAliveInterval=30 \
        -o ServerAliveCountMax=3 \
        -o TCPKeepAlive=yes \
        -o ExitOnForwardFailure=yes \
        -o ConnectTimeout=15 \
        -o ConnectionAttempts=2 \
        -o PreferredAuthentications=keyboard-interactive,password \
        -o PubkeyAuthentication=no \
        -o PasswordAuthentication=yes \
        -o KbdInteractiveAuthentication=yes \
        -N \
        -p "$PORT" -R "$forward" "tcp@$HOST" >"$LOG" 2>&1) &
    child=$!
    printf '%s\n' "$child" > "$PID"
    for _ in $(seq 1 30); do
      sleep 1
      endpoint=$(extract_endpoint)
      if [ -n "$endpoint" ]; then
        case "$endpoint" in tcp://*) ;; *) endpoint="tcp://$endpoint" ;; esac
        printf '%s\n' "$endpoint" > "$INFO"
        connected=1
        break
      fi
      kill -0 "$child" >/dev/null 2>&1 || break
    done
    if [ "$connected" -eq 1 ]; then
      wait "$child" >/dev/null 2>&1 || true
      break
    fi
    kill "$child" >/dev/null 2>&1 || true
    wait "$child" >/dev/null 2>&1 || true
    rm -f "$PID"
    [ "$requested_port" = "0" ] && break
  done
  rm -f "$PID"
  sleep 4
done
EOF_PINGGY
chmod 0755 /usr/local/sbin/rgnodes-pinggy-supervisor

if [ -d /run/systemd/system ] && [ "$(cat /proc/1/comm 2>/dev/null)" = "systemd" ]; then
  cat > /etc/systemd/system/rgnodes-pinggy.service <<'EOF_UNIT'
[Unit]
Description=RGNODES Pinggy SSH Tunnel Supervisor
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
ExecStart=/usr/local/sbin/rgnodes-pinggy-supervisor
Restart=always
RestartSec=3
KillMode=control-group
[Install]
WantedBy=multi-user.target
EOF_UNIT
  systemctl daemon-reload >/dev/null 2>&1 || true
  systemctl enable rgnodes-pinggy.service >/dev/null 2>&1 || true
else
  mkdir -p /etc/cron.d
  printf '%s\n' '@reboot root /usr/local/sbin/rgnodes-pinggy-supervisor >>/var/lib/rgnodes/pinggy-supervisor.log 2>&1' > /etc/cron.d/rgnodes-pinggy
  chmod 0644 /etc/cron.d/rgnodes-pinggy 2>/dev/null || true
fi
printf 'TUNNEL_SUPERVISORS_READY\n'
""".replace('__PINGGY_HOST__', safe_host).replace('__PINGGY_PORT__', str(safe_port)).replace('__PINGGY_REMOTE_PORT__', str(safe_remote_port))
    await _exec_guest_bash(container_name, node_id, script, timeout=180)


# --- restored stable helper: install_tunnel_supervisors ---
async def install_tunnel_supervisors(container_name: str, node_id: int) -> None:
    """Serialize tunnel bootstrap per VPS to avoid package-manager/systemd races."""
    key = (str(container_name), int(node_id))
    lock = TUNNEL_SETUP_LOCKS.get(key)
    if lock is None:
        lock = asyncio.Lock()
        TUNNEL_SETUP_LOCKS[key] = lock
    async with lock:
        await _install_tunnel_supervisors_unlocked(container_name, node_id)


# --- restored stable helper: start_pinggy_session ---
async def start_pinggy_session(container_name: str, node_id: int) -> Optional[dict]:
    """Restart Pinggy's durable supervisor and return the fresh public TCP endpoint."""
    if not PINGGY_ENABLED:
        return None
    lock = _get_tunnel_lock(container_name, "pinggy")
    async with lock:
        try:
            await install_tunnel_supervisors(container_name, node_id)
            await _exec_guest_bash(container_name, node_id, "rm -f /var/lib/rgnodes/pinggy.info /var/lib/rgnodes/pinggy.pid", timeout=10)
            await _run_tunnel_control(container_name, node_id, "restart", "pinggy", timeout=50)
            poll_script = r'''set +e
for _ in $(seq 1 60); do
  info=$(cat /var/lib/rgnodes/pinggy.info 2>/dev/null || true)
  if printf '%s' "$info" | grep -Eq '(tcp://)?[A-Za-z0-9][A-Za-z0-9.-]*(pinggy(-free)?|pinggy-free)\\.(link|online):[0-9]{2,5}'; then
    printf '%s\n' "$info"
    exit 0
  fi
  sleep 1
done
printf 'PINGGY_TIMEOUT\n'
tail -n 30 /var/lib/rgnodes/pinggy.log 2>/dev/null || true
exit 0
'''
            output = await _exec_guest_bash(container_name, node_id, poll_script, timeout=min(max(TUNNEL_START_TIMEOUT, 90), 120))
            host, port, url = parse_pinggy_endpoint(str(output or ''))
            if not (host and port):
                logger.warning(f'Pinggy endpoint was not produced for {container_name}: {str(output)[-1800:]}')
                return None
            result = {'host': host, 'port': port, 'url': url}
            for items in vps_data.values():
                for vps in items:
                    if str(vps.get('container_name')) == str(container_name):
                        vps['pinggy_host'] = host
                        vps['pinggy_port'] = port
                        vps['pinggy_url'] = url
                        vps['pinggy_started_at'] = datetime.now().isoformat()
                        try:
                            pid_out = await _exec_guest_bash(container_name, node_id, 'cat /var/lib/rgnodes/pinggy.pid 2>/dev/null || true', timeout=10)
                            vps['pinggy_pid'] = int(str(pid_out).strip()) if str(pid_out).strip().isdigit() else None
                        except Exception:
                            vps['pinggy_pid'] = None
                        save_vps_data_immediate()
                        break
            return result
        except Exception as e:
            logger.warning(f'Pinggy session failed for {container_name}: {e}', exc_info=True)
            return None


# --- restored stable helper: get_pinggy_session_info ---
async def get_pinggy_session_info(container_name: str, node_id: int) -> tuple[Optional[str], Optional[int], bool]:
    script = r'''set +e
systemd_ok=false
[ -d /run/systemd/system ] && [ "$(cat /proc/1/comm 2>/dev/null)" = "systemd" ] && systemd_ok=true
active=false
if [ "$systemd_ok" = true ] && systemctl is-active --quiet rgnodes-pinggy.service; then active=true; fi
sup_pid=$(cat /var/lib/rgnodes/pinggy.supervisor.pid 2>/dev/null | head -n1)
if [ -n "$sup_pid" ] && kill -0 "$sup_pid" >/dev/null 2>&1; then active=true; fi
pid=$(cat /var/lib/rgnodes/pinggy.pid 2>/dev/null | head -n1)
if [ -n "$pid" ] && kill -0 "$pid" >/dev/null 2>&1; then active=true; fi
printf '%s\n' "$active"
cat /var/lib/rgnodes/pinggy.info 2>/dev/null || true
'''
    try:
        output = await _exec_guest_bash(container_name, node_id, script, timeout=20)
        lines = [x.strip() for x in str(output or '').splitlines() if x.strip()]
        active = bool(lines and lines[0].lower() == 'true')
        host, port, _ = parse_pinggy_endpoint('\n'.join(lines[1:]))
        return host, port, active and bool(host and port)
    except Exception:
        return None, None, False


# --- restored stable helper: _png_rgba ---
def _png_rgba(width: int, height: int, pixels: bytearray) -> bytes:
    """Encode RGBA pixels to a tiny dependency-free PNG."""
    import struct, zlib
    raw = bytearray()
    stride = width * 4
    for y in range(height):
        raw.append(0)
        raw.extend(pixels[y * stride:(y + 1) * stride])
    def chunk(kind: bytes, data: bytes) -> bytes:
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data) & 0xffffffff)
    header = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', header) + chunk(b'IDAT', zlib.compress(bytes(raw), 9)) + chunk(b'IEND', b'')


# --- restored stable helper: _draw_disc ---
def _draw_disc(pix: bytearray, size: int, cx: int, cy: int, r: int, rgba):
    rr = r * r
    for y in range(max(0, cy-r), min(size, cy+r+1)):
        for x in range(max(0, cx-r), min(size, cx+r+1)):
            if (x-cx)*(x-cx) + (y-cy)*(y-cy) <= rr:
                i = (y*size+x)*4
                pix[i:i+4] = bytes(rgba)


# --- restored stable helper: _draw_rect ---
def _draw_rect(pix: bytearray, size: int, x0: int, y0: int, x1: int, y1: int, rgba):
    for y in range(max(0,y0), min(size,y1+1)):
        for x in range(max(0,x0), min(size,x1+1)):
            i=(y*size+x)*4
            pix[i:i+4]=bytes(rgba)


# --- restored stable helper: _draw_line ---
def _draw_line(pix: bytearray, size: int, x0: int, y0: int, x1: int, y1: int, width: int, rgba):
    steps=max(abs(x1-x0),abs(y1-y0),1)
    for n in range(steps+1):
        x=round(x0+(x1-x0)*n/steps); y=round(y0+(y1-y0)*n/steps)
        _draw_disc(pix,size,x,y,max(1,width//2),rgba)


# --- restored stable helper: _builtin_emoji_gif ---
def _builtin_emoji_gif(key: str, size: int = 96) -> bytes | None:
    """Create a tiny animated emoji when Pillow is available; return None otherwise."""
    try:
        from PIL import Image, ImageDraw
        import io
        size=max(64,min(96,int(size)))
        frames=[]
        for phase in (0,1,0,2):
            img=Image.new('RGBA',(size,size),(0,0,0,0))
            draw=ImageDraw.Draw(img)
            scale=1.0 + phase*0.035
            r=int(size*0.40*scale); cx=cy=size//2
            bg={
                'online':(46,204,113,255),'status':(46,204,113,255),'success':(46,204,113,255),'start':(46,204,113,255),'pinggy':(46,204,113,255),
                'offline':(231,76,60,255),'error':(231,76,60,255),'delete':(192,57,43,255),'stop':(231,76,60,255),'pinggy_offline':(231,76,60,255),
                'warning':(241,196,15,255),'maintenance':(231,76,60,255),'loading':(52,152,219,255),
                'vps':(155,89,182,255),'server':(52,73,94,255),'ssh':(127,140,141,255),'ports':(230,126,34,255),'password':(243,156,18,255),
            }.get(key,(52,152,219,255))
            draw.ellipse((cx-r,cy-r,cx+r,cy+r),fill=bg)
            rr=max(2,int(size*0.045))
            draw.ellipse((cx-int(size*.10),cy-int(size*.10),cx+int(size*.10),cy+int(size*.10)),fill=(255,255,255,255))
            draw.line((cx-int(size*.06),cy,cx+int(size*.10),cy),fill=bg,width=rr)
            frames.append(img)
        out=io.BytesIO(); frames[0].save(out,format='GIF',save_all=True,append_images=frames[1:],duration=180,loop=0,disposal=2,optimize=True)
        return out.getvalue()
    except Exception:
        return None


# --- restored stable helper: _builtin_emoji_png ---
def _builtin_emoji_png(key: str, size: int = 96) -> bytes:
    """Generate a compact, consistent server emoji without Pillow or image files."""
    size=max(64,min(128,int(size)))
    pix=bytearray(b'\x00'*(size*size*4)); cx=cy=size//2
    bg_map={
        'online':(46,204,113,255),'status':(46,204,113,255),'success':(46,204,113,255),'start':(46,204,113,255),'pinggy':(46,204,113,255),
        'offline':(231,76,60,255),'error':(231,76,60,255),'delete':(192,57,43,255),'stop':(231,76,60,255),'pinggy_offline':(231,76,60,255),
        'warning':(241,196,15,255),'maintenance':(231,76,60,255),'loading':(52,152,219,255),
        'vps':(155,89,182,255),'deploy':(52,152,219,255),'rocket':(52,152,219,255),'server':(52,73,94,255),
        'cpu':(26,188,156,255),'ram':(52,152,219,255),'disk':(149,165,166,255),'network':(22,160,133,255),
        'docker':(41,128,185,255),'ssh':(127,140,141,255),'ports':(230,126,34,255),'password':(243,156,18,255),
        'reinstall':(142,68,173,255),'renew':(39,174,96,255),'stats':(52,152,219,255),'refresh':(52,152,219,255),
    }
    bg=bg_map.get(key,(96,125,139,255)); white=(255,255,255,255)
    _draw_disc(pix,size,cx,cy,int(size*0.45),bg)
    if key in {'online','status','success','start','pinggy'}:
        _draw_disc(pix,size,cx,cy,int(size*0.18),white); _draw_disc(pix,size,cx,cy,int(size*0.08),bg)
    elif key in {'offline','error','delete','stop','pinggy_offline'}:
        w=max(4,int(size*.09)); _draw_line(pix,size,int(size*.32),int(size*.32),int(size*.68),int(size*.68),w,white); _draw_line(pix,size,int(size*.68),int(size*.32),int(size*.32),int(size*.68),w,white)
    elif key in {'warning','maintenance'}:
        _draw_rect(pix,size,int(size*.47),int(size*.30),int(size*.53),int(size*.58),white); _draw_disc(pix,size,cx,int(size*.68),max(2,int(size*.045)),white)
    elif key in {'vps','server','docker'}:
        _draw_rect(pix,size,int(size*.28),int(size*.31),int(size*.72),int(size*.69),white); _draw_rect(pix,size,int(size*.34),int(size*.39),int(size*.66),int(size*.45),bg); _draw_rect(pix,size,int(size*.34),int(size*.51),int(size*.66),int(size*.57),bg); _draw_disc(pix,size,int(size*.38),int(size*.62),3,white)
    elif key=='cpu':
        _draw_rect(pix,size,int(size*.34),int(size*.34),int(size*.66),int(size*.66),white); _draw_rect(pix,size,int(size*.29),int(size*.43),int(size*.33),int(size*.49),white); _draw_rect(pix,size,int(size*.67),int(size*.43),int(size*.71),int(size*.49),white)
    elif key=='ram':
        for y in (int(size*.36),int(size*.49),int(size*.62)): _draw_rect(pix,size,int(size*.29),y,int(size*.71),y+int(size*.07),white)
    elif key=='disk':
        _draw_disc(pix,size,cx,int(size*.48),int(size*.18),white); _draw_rect(pix,size,int(size*.30),int(size*.53),int(size*.70),int(size*.62),white); _draw_disc(pix,size,cx,int(size*.48),int(size*.07),bg)
    elif key in {'network','ports'}:
        a=(int(size*.35),int(size*.60)); b=(int(size*.63),int(size*.36)); c=(int(size*.66),int(size*.65)); _draw_line(pix,size,*a,*b,int(size*.05),white); _draw_line(pix,size,*b,*c,int(size*.05),white); _draw_disc(pix,size,*a,int(size*.10),white); _draw_disc(pix,size,*b,int(size*.10),white); _draw_disc(pix,size,*c,int(size*.10),white)
    elif key == 'ssh':
        _draw_disc(pix,size,cx,cy,int(size*.22),white); _draw_line(pix,size,int(size*.38),int(size*.50),int(size*.58),int(size*.50),int(size*.05),bg); _draw_line(pix,size,int(size*.50),int(size*.38),int(size*.50),int(size*.62),int(size*.05),bg)
    elif key=='password':
        _draw_disc(pix,size,int(size*.42),int(size*.47),int(size*.13),white); _draw_rect(pix,size,int(size*.48),int(size*.44),int(size*.70),int(size*.54),white)
    elif key=='refresh':
        _draw_line(pix,size,int(size*.35),int(size*.60),int(size*.35),int(size*.42),int(size*.07),white); _draw_line(pix,size,int(size*.35),int(size*.42),int(size*.50),int(size*.32),int(size*.07),white); _draw_line(pix,size,int(size*.65),int(size*.40),int(size*.65),int(size*.58),int(size*.07),white); _draw_line(pix,size,int(size*.65),int(size*.58),int(size*.50),int(size*.68),int(size*.07),white)
    elif key in {'rocket','deploy'}:
        _draw_line(pix,size,int(size*.36),int(size*.66),int(size*.60),int(size*.34),int(size*.10),white); _draw_disc(pix,size,int(size*.56),int(size*.44),int(size*.06),bg)
    elif key=='stats':
        _draw_rect(pix,size,int(size*.32),int(size*.54),int(size*.41),int(size*.68),white); _draw_rect(pix,size,int(size*.45),int(size*.43),int(size*.54),int(size*.68),white); _draw_rect(pix,size,int(size*.58),int(size*.32),int(size*.71),int(size*.68),white)
    elif key=='loading':
        _draw_disc(pix,size,cx,cy,int(size*.23),white); _draw_line(pix,size,cx,cy,int(size*.60),int(size*.42),int(size*.05),bg)
    elif key in {'renew','reinstall'}:
        _draw_line(pix,size,int(size*.33),int(size*.55),int(size*.48),int(size*.68),int(size*.08),white); _draw_line(pix,size,int(size*.48),int(size*.68),int(size*.70),int(size*.36),int(size*.08),white)
    else:
        _draw_disc(pix,size,cx,cy,int(size*.12),white)
    return _png_rgba(size,size,pix)


# --- stable helper: emoji name normalization and provisioning plan ---
def _emoji_markup_name(value: str) -> Optional[str]:
    """Return the name from a Discord custom emoji mention, if one was supplied."""
    match = re.fullmatch(r'<a?:([A-Za-z0-9_]{2,32}):\d+>', str(value or '').strip())
    return match.group(1) if match else None


def _emoji_candidate_names(key: str, configured: str) -> tuple[str, ...]:
    """Return preferred and equivalent existing names, preserving the configured name first."""
    raw = str(configured or '').strip()
    if not raw or _emoji_markup_name(raw):
        return ()
    if raw.startswith(':') and raw.endswith(':') and len(raw) > 2:
        raw = raw[1:-1].strip()
    values = [raw]
    values.extend(CUSTOM_EMOJI_ALIASES.get(str(key).casefold(), ()))
    result = []
    seen = set()
    for value in values:
        name = re.sub(r'[^A-Za-z0-9_]', '_', str(value or '').strip())[:32]
        folded = name.casefold()
        if len(name) >= 2 and folded not in seen:
            result.append(name)
            seen.add(folded)
    return tuple(result)


def _build_emoji_provision_plan(custom_names: dict, existing_names, available_slots: int):
    """Plan only missing unique uploads; return (plan, resolved names, missing count).

    Matching is case-insensitive and also checks semantic aliases. This pure helper makes
    the no-duplicate rule testable without connecting to Discord.
    """
    existing = {str(name).strip().casefold() for name in existing_names if str(name).strip()}
    planned_names = set(existing)
    resolved = {}
    plan = []
    missing_unique = []
    for key, configured in custom_names.items():
        raw = str(configured or '').strip()
        if not raw:
            continue
        markup = _emoji_markup_name(raw)
        if markup:
            resolved[str(key).casefold()] = raw
            continue
        candidates = _emoji_candidate_names(str(key), raw)
        existing_match = next((candidate for candidate in candidates if candidate.casefold() in existing), None)
        if existing_match:
            resolved[str(key).casefold()] = existing_match
            continue
        target = candidates[0] if candidates else ''
        if not target:
            continue
        folded = target.casefold()
        if folded in planned_names:
            resolved[str(key).casefold()] = target
            continue
        planned_names.add(folded)
        missing_unique.append((str(key), target))
        resolved[str(key).casefold()] = target
    slots = max(0, int(available_slots))
    plan = missing_unique[:slots]
    permitted_names = {name.casefold() for _key, name in plan}
    # Do not cache a not-yet-created emoji when the server has no free slot for it.
    for key, name in list(resolved.items()):
        if not _emoji_markup_name(name) and name.casefold() not in existing and name.casefold() not in permitted_names:
            resolved.pop(key, None)
    return plan, resolved, len(missing_unique)


# --- stable helper: auto_provision_server_emojis ---
async def auto_provision_server_emojis(guild: discord.Guild) -> Dict[str, Any]:
    """Reuse every available equivalent emoji and create only missing configured names.

    The authoritative guild emoji list is fetched before planning. If it cannot be fetched,
    provisioning fails closed so a transient Discord API/cache issue cannot create duplicates.
    """
    summary = {
        'created': 0, 'reused': 0, 'missing': 0, 'pending': 0,
        'available_slots': 0, 'skipped': 0, 'reason': 'disabled',
    }
    if not AUTO_CREATE_SERVER_EMOJIS:
        return summary
    async with EMOJI_PROVISION_LOCK:
        try:
            me = getattr(guild, 'me', None)
            if me is None and getattr(bot, 'user', None) is not None:
                me = guild.get_member(bot.user.id)
            if me is None and getattr(bot, 'user', None) is not None:
                try:
                    me = await guild.fetch_member(bot.user.id)
                except Exception:
                    me = None
            permissions = getattr(me, 'guild_permissions', None)
            can_manage = bool(
                getattr(permissions, 'manage_emojis_and_stickers', False)
                or getattr(permissions, 'manage_emojis', False)
            )
            if not can_manage:
                summary['reason'] = 'missing_manage_expressions_permission'
                logger.warning('Emoji auto-provision skipped for %s: grant Manage Expressions to the bot.', guild.name)
                _EMOJI_PROVISION_SUMMARY[int(guild.id)] = dict(summary)
                return summary
            try:
                fetched = await guild.fetch_emojis()
            except (discord.HTTPException, discord.Forbidden, asyncio.TimeoutError) as exc:
                summary['reason'] = 'emoji_list_unavailable'
                logger.warning(
                    'Emoji creation skipped for %s because the authoritative emoji list could not be fetched (%s).',
                    guild.name, type(exc).__name__,
                )
                _EMOJI_PROVISION_SUMMARY[int(guild.id)] = dict(summary)
                return summary

            existing = {str(e.name).casefold(): e for e in fetched}
            emoji_limit = max(0, int(getattr(guild, 'emoji_limit', 50)))
            available = max(0, emoji_limit - len(fetched))
            summary['available_slots'] = available
            plan, resolved_names, missing_count = _build_emoji_provision_plan(
                CUSTOM_EMOJI_NAMES, existing.keys(), available
            )
            summary['missing'] = missing_count
            summary['pending'] = max(0, missing_count - len(plan))
            summary['reused'] = sum(
                1 for name in resolved_names.values()
                if _emoji_markup_name(name) or name.casefold() in existing
            )

            # Cache existing matches first; this makes the existing custom emoji usable
            # immediately without waiting for uploads to complete.
            for key, name in resolved_names.items():
                if _emoji_markup_name(name):
                    _EMOJI_RESOLUTION_CACHE[key] = name
                else:
                    found = existing.get(name.casefold())
                    if found is not None:
                        _EMOJI_RESOLUTION_CACHE[key] = str(found)

            for key, safe_name in plan:
                folded = safe_name.casefold()
                # Another alias/key may already have created or resolved this name.
                if folded in existing:
                    emoji = existing[folded]
                    _EMOJI_RESOLUTION_CACHE[key.casefold()] = str(emoji)
                    continue
                if len(existing) >= emoji_limit:
                    summary['pending'] += 1
                    continue
                try:
                    animated_image = _builtin_emoji_gif(key)
                    try:
                        emoji = await guild.create_custom_emoji(
                            name=safe_name,
                            image=animated_image or _builtin_emoji_png(key),
                            reason=f'{BOT_NAME} automatic missing-emoji provisioning',
                        )
                    except discord.HTTPException as create_exc:
                        # A create request may have reached Discord even if the client saw an
                        # HTTP error. Re-fetch before any fallback/retry to prevent duplicates.
                        refresh_ok = False
                        try:
                            refreshed = await guild.fetch_emojis()
                            refresh_ok = True
                            refreshed_map = {str(e.name).casefold(): e for e in refreshed}
                            existing.update(refreshed_map)
                            if folded in refreshed_map:
                                emoji = refreshed_map[folded]
                            else:
                                status_code = getattr(create_exc, 'status', None)
                                if animated_image is None or status_code in {403, 429}:
                                    raise create_exc
                                # Static fallback only after Discord confirms the GIF was not
                                # created. Never retry if the refreshed state is uncertain.
                                emoji = await guild.create_custom_emoji(
                                    name=safe_name,
                                    image=_builtin_emoji_png(key),
                                    reason=f'{BOT_NAME} automatic static emoji fallback',
                                )
                        except Exception:
                            if not refresh_ok:
                                logger.warning('Emoji state is uncertain for %s in %s; no duplicate retry will be attempted.', safe_name, guild.name)
                            raise
                    existing[str(emoji.name).casefold()] = emoji
                    _EMOJI_RESOLUTION_CACHE[key.casefold()] = str(emoji)
                    # Resolve all configured keys which point at this same name.
                    for mapped_key, mapped_name in resolved_names.items():
                        if not _emoji_markup_name(mapped_name) and mapped_name.casefold() == folded:
                            _EMOJI_RESOLUTION_CACHE[mapped_key] = str(emoji)
                    summary['created'] += 1
                    await asyncio.sleep(1.1)
                except discord.Forbidden as exc:
                    summary['reason'] = 'missing_manage_expressions_permission'
                    logger.warning('Emoji auto-provision forbidden in %s: %s', guild.name, type(exc).__name__)
                    break
                except discord.HTTPException as exc:
                    summary['reason'] = 'discord_api_error'
                    retry_after = float(getattr(exc, 'retry_after', 3.0) or 3.0)
                    await asyncio.sleep(min(20.0, max(2.0, retry_after)))
                    logger.warning('Emoji creation failed for %s in %s (%s).', safe_name, guild.name, type(exc).__name__)
                except Exception as exc:
                    summary['reason'] = 'creation_error'
                    logger.warning('Emoji creation failed for %s (%s).', safe_name, type(exc).__name__)

            # Do a final authoritative refresh and repair cache entries for successfully
            # created emojis. No deletion/replacement operation exists in this workflow.
            try:
                final_emojis = await guild.fetch_emojis()
                final_index = {str(e.name).casefold(): e for e in final_emojis}
                for key, name in resolved_names.items():
                    if _emoji_markup_name(name):
                        _EMOJI_RESOLUTION_CACHE[key] = name
                    elif name.casefold() in final_index:
                        _EMOJI_RESOLUTION_CACHE[key] = str(final_index[name.casefold()])
                summary['available_slots'] = max(0, emoji_limit - len(final_emojis))
            except Exception:
                pass
            summary['pending'] = max(summary['pending'], max(0, summary['missing'] - summary['created']))
            if summary['reason'] == 'disabled':
                summary['reason'] = 'complete' if summary['pending'] == 0 else 'emoji_slots_or_api_limit'
            _EMOJI_PROVISION_SUMMARY[int(guild.id)] = dict(summary)
            logger.info(
                'Emoji sync for %s: created=%d, reused=%d, missing=%d, pending=%d, remaining_slots=%d, reason=%s',
                guild.name, summary['created'], summary['reused'], summary['missing'],
                summary['pending'], summary['available_slots'], summary['reason'],
            )
            return summary
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            summary['reason'] = 'unexpected_error'
            _EMOJI_PROVISION_SUMMARY[int(guild.id)] = dict(summary)
            logger.exception('Emoji auto-provision crashed for %s (%s)', getattr(guild, 'name', guild.id), type(exc).__name__)
            return summary


# --- stable helper: resolve_custom_emoji ---
def resolve_custom_emoji(key: str, fallback: str = '') -> str:
    """Return the configured or equivalent existing server emoji, else a Unicode fallback."""
    normalized_key = str(key or '').casefold()
    cached_markup = _EMOJI_RESOLUTION_CACHE.get(normalized_key)
    if cached_markup:
        return cached_markup
    raw = str(CUSTOM_EMOJI_NAMES.get(key, '') or '').strip()
    if _emoji_markup_name(raw):
        return raw
    try:
        emoji_index = {str(getattr(emoji, 'name', '')).casefold(): emoji for emoji in bot.emojis}
        for candidate in _emoji_candidate_names(key, raw):
            found = emoji_index.get(candidate.casefold())
            if found is not None:
                rendered = str(found)
                _EMOJI_RESOLUTION_CACHE[normalized_key] = rendered
                return rendered
    except Exception:
        pass
    return fallback


def os_option_emoji(option: Dict[str, Any]):
    """Use the configured server OS emoji when it exists; otherwise retain the Unicode fallback."""
    key = str(option.get('emoji_key', '') or '').strip()
    fallback = str(option.get('emoji', '') or '')
    return resolve_custom_emoji(key, fallback) if key else fallback


# --- restored stable helper: create_vps_card ---
def create_vps_card(vps, index):
    """Create a formatted VPS information card"""
    node = get_node(vps.get('node_id', 1))
    status_emoji = "🟢" if (vps.get('status') == 'running' and not vps.get('suspended')) else "🟡" if vps.get('suspended') else "🔴"
    node_emoji = "📍" if (node and node.get('is_local')) else "🌐"
    
    card = (
        f"**#{index}** `{vps['container_name']}`\n"
        f"{status_emoji} {vps.get('status', 'unknown').upper()}"
    )
    if vps.get('suspended'):
        card += " (SUSPENDED)"
    
    card += (
        f"\n⚙️ **Config:** {vps.get('config', 'Custom')}\n"
        f"💾 **RAM:** {vps['ram']} | **CPU:** {vps['cpu']} | **Disk:** {vps['storage']} | **Bandwidth:** {int(vps.get('bandwidth_gb') or VPS_BANDWIDTH_GB)}GB\n"
        f"{node_emoji} **Node:** {node['name'] if node else 'Unknown'}\n"
        f"⏰ **Expiration:** {format_expiration(vps)}"
    )
    return card


# --- restored stable helper: is_admin ---
def is_admin():
    async def predicate(ctx):
        if is_admin_user(ctx.author):
            return True
        raise commands.CheckFailure("You need RGNODES admin access or Discord Administrator permission to use this command.")
    return commands.check(predicate)


# --- restored stable helper: is_main_admin ---
def is_main_admin():
    async def predicate(ctx):
        if str(ctx.author.id) == str(MAIN_ADMIN_ID):
            return True
        raise commands.CheckFailure("Only the main admin can use this command.")
    return commands.check(predicate)


# --- restored stable helper: apply_internal_permissions ---
async def apply_internal_permissions(container_name: str, node_id: int):
    try:
        await asyncio.sleep(5)
        commands = [
            "mkdir -p /etc/sysctl.d/",
            "echo 'net.ipv4.ip_unprivileged_port_start=0' > /etc/sysctl.d/99-custom.conf",
            "echo 'net.ipv4.ping_group_range=0 2147483647' >> /etc/sysctl.d/99-custom.conf",
            "echo 'fs.inotify.max_user_watches=524288' >> /etc/sysctl.d/99-custom.conf",
            "echo 'kernel.unprivileged_userns_clone=1' >> /etc/sysctl.d/99-custom.conf",
            "sysctl -p /etc/sysctl.d/99-custom.conf || true"
        ]
        for cmd in commands:
            try:
                await execute_vpsctl_compat(container_name, f"exec {container_name} -- bash -c \"{cmd}\"", node_id=node_id)
            except Exception as cmd_error:
                logger.warning(f"Command failed in {container_name}: {cmd} - {cmd_error}")
        logger.info(f"Internal permissions applied to {container_name}")
    except Exception as e:
        logger.error(f"Failed to apply internal permissions to {container_name}: {e}")


# --- restored stable helper: get_or_create_vps_role ---
async def get_or_create_vps_role(guild):
    global VPS_USER_ROLE_ID

    me = guild.me
    if not me or not me.guild_permissions.manage_roles:
        return None

    role_name = f"{BOT_NAME} VPS User"

    # Try cached role
    if VPS_USER_ROLE_ID:
        role = guild.get_role(VPS_USER_ROLE_ID)
        if role and role < me.top_role:
            return role
        VPS_USER_ROLE_ID = None

    # Find by name
    role = discord.utils.get(guild.roles, name=role_name)
    if role:
        if role >= me.top_role:
            try:
                await role.delete(reason="Role above bot, recreating")
            except discord.Forbidden:
                return None
            role = None
        else:
            VPS_USER_ROLE_ID = role.id
            return role

    # Create safely below bot
    try:
        role = await guild.create_role(
            name=role_name,
            color=discord.Color.dark_purple(),
            permissions=discord.Permissions.none(),
            reason=f"{BOT_NAME} VPS User role"
        )
        await role.edit(position=me.top_role.position - 1)
        VPS_USER_ROLE_ID = role.id
        logger.info(f"Created VPS role: {role.id}")
        return role
    except Exception as e:
        logger.error(f"Failed to create VPS role: {e}")
        return None


# --- restored stable helper: get_host_cpu_usage ---
def get_host_cpu_usage():
    """Get host CPU usage - cross-platform compatible"""
    try:
        import platform
        system = platform.system()
        
        if system == "Windows":
            # Windows: Use wmic or psutil as fallback
            try:
                import psutil
                return psutil.cpu_percent(interval=1)
            except ImportError:
                # Fallback for Windows without psutil
                try:
                    result = subprocess.run(['wmic', 'os', 'get', 'TotalVisibleMemorySize'], 
                                          capture_output=True, text=True, timeout=5)
                    return 0.0  # Default value on Windows
                except:
                    return 0.0
        else:
            # Linux/Unix: Use mpstat or top
            if shutil.which("mpstat"):
                result = subprocess.run(['mpstat', '1', '1'], capture_output=True, text=True, timeout=10)
                output = result.stdout
                for line in output.split('\n'):
                    if 'all' in line and '%' in line:
                        parts = line.split()
                        idle = float(parts[-1])
                        return 100.0 - idle
            else:
                result = subprocess.run(['top', '-bn1'], capture_output=True, text=True, timeout=10)
                output = result.stdout
                for line in output.split('\n'):
                    if '%Cpu(s):' in line:
                        # Parse CPU line - format: %Cpu(s): us,sy,ni,id,wa,hi,si,st
                        cpu_data = line.split('%Cpu(s):')[1].strip()
                        parts = []
                        for item in cpu_data.split(','):
                            val = item.split()[0].strip()
                            try:
                                parts.append(float(val))
                            except ValueError:
                                parts.append(0.0)
                        
                        if len(parts) >= 8:
                            us = parts[0]
                            sy = parts[1]
                            ni = parts[2]
                            id_ = parts[3]
                            wa = parts[4]
                            hi = parts[5]
                            si = parts[6]
                            st = parts[7]
                            usage = us + sy + ni + wa + hi + si + st
                            return usage
            return 0.0
    except Exception as e:
        logger.debug(f"Error getting CPU usage: {e}")
        return 0.0


# --- restored stable helper: get_host_ram_usage ---
def get_host_ram_usage():
    """Get host RAM usage - cross-platform compatible"""
    try:
        import platform
        system = platform.system()
        
        if system == "Windows":
            # Windows: Use psutil or wmic
            try:
                import psutil
                mem = psutil.virtual_memory()
                return mem.percent
            except ImportError:
                # Fallback for Windows without psutil
                try:
                    result = subprocess.run(['wmic', 'OS', 'get', 'TotalVisibleMemorySize,FreePhysicalMemory'], 
                                          capture_output=True, text=True, timeout=5)
                    lines = result.stdout.strip().split('\n')
                    if len(lines) > 1:
                        values = lines[1].split()
                        if len(values) >= 2:
                            total = int(values[0])
                            free = int(values[1])
                            used = total - free
                            return (used / total * 100) if total > 0 else 0.0
                except:
                    pass
                return 0.0
        else:
            # Linux/Unix: Use free command
            result = subprocess.run(['free', '-m'], capture_output=True, text=True, timeout=10)
            lines = result.stdout.splitlines()
            if len(lines) > 1:
                mem = lines[1].split()
                total = int(mem[1])
                used = int(mem[2])
                return (used / total * 100) if total > 0 else 0.0
            return 0.0
    except Exception as e:
        logger.debug(f"Error getting RAM usage: {e}")
        return 0.0


# --- restored stable helper: get_host_stats ---
async def get_host_stats(node_id: int) -> Dict:
    """Low-overhead host capacity snapshot with a short cache per node."""
    node_id = int(node_id)
    now_mono = time.monotonic()
    cached = HOST_STATS_CACHE.get(node_id)
    if cached and (now_mono - cached[0]) < HOST_STATS_CACHE_TTL:
        return dict(cached[1])

    node = get_node(node_id)
    empty = {"cpu":0.0,"ram":0.0,"disk":"Unknown","ram_bytes_total":0,"ram_bytes_used":0,
             "ram_bytes_available":0,"disk_total":0,"disk_free":0,"cpu_count":0}
    if not node:
        return empty
    stats = empty
    try:
        if node.get('is_local'):
            try:
                import psutil
                vm = psutil.virtual_memory()
                du = psutil.disk_usage('/')
                # interval=None is non-blocking and keeps this path cheap.
                cpu = float(psutil.cpu_percent(interval=None))
                stats = {"cpu":cpu,"ram":float(vm.percent),
                         "disk":{"used":int(du.used),"total":int(du.total),"free":int(du.free),"percent":float(du.percent)},
                         "ram_bytes_total":int(vm.total),"ram_bytes_used":int(vm.used),"ram_bytes_available":int(vm.available),
                         "disk_total":int(du.total),"disk_free":int(du.free),"cpu_count":int(psutil.cpu_count() or 0)}
            except Exception:
                stats = empty
        else:
            response = await asyncio.to_thread(
                requests.get,
                str(node.get('url') or '').rstrip('/') + '/api/get_host_stats',
                headers={"X-API-Key": str(node.get('api_key') or '')},
                timeout=8,
            )
            response.raise_for_status()
            payload = response.json()
            disk = payload.get('disk') or {}
            total = int(payload.get('ram_bytes_total',0) or 0)
            used = int(payload.get('ram_bytes_used',0) or 0)
            stats = {"cpu":float(payload.get('cpu',0.0) or 0.0),"ram":float(payload.get('ram',0.0) or 0.0),
                     "disk":disk,"ram_bytes_total":total,"ram_bytes_used":used,
                     "ram_bytes_available":max(0,total-used),
                     "disk_total":int(disk.get('total',0) or 0) if isinstance(disk,dict) else 0,
                     "disk_free":int(disk.get('free',0) or 0) if isinstance(disk,dict) else 0,
                     "cpu_count":int(payload.get('cpu_count',0) or 0)}
    except Exception as exc:
        logger.debug("Host stats unavailable on %s: %s: %s", node.get('name'), type(exc).__name__, exc)
        stats = empty

    HOST_STATS_CACHE[node_id] = (time.monotonic(), dict(stats))
    return stats


# --- restored stable helper: check_vps_expiration ---
async def check_vps_expiration():
    """Suspend expired VPS and send warning DMs on the bot's own event loop."""
    now = datetime.now()
    warning_window = max(0, EXPIRATION_WARNING_DAYS) * 24 * 3600
    for user_id, vps_list in list(vps_data.items()):
        for vps in list(vps_list):
            raw = vps.get('expiration_date')
            if not raw:
                continue
            try:
                expiration_dt = datetime.fromisoformat(str(raw))
            except (TypeError, ValueError):
                logger.warning(f"Invalid expiration date for {vps.get('container_name')}: {raw!r}")
                continue

            container_name = vps.get('container_name')
            node_id = int(vps.get('node_id', 1))
            seconds_left = (expiration_dt - now).total_seconds()
            key = (str(container_name), str(raw))

            if seconds_left <= 0:
                if EXPIRATION_AUTO_SUSPEND and not vps.get('suspended', False):
                    try:
                        try:
                            await execute_vpsctl_compat(container_name, f"stop {container_name} --force", timeout=120, node_id=node_id)
                        except Exception as stop_error:
                            text_error = str(stop_error).lower()
                            if 'not running' not in text_error and 'already stopped' not in text_error:
                                raise
                        vps['status'] = 'stopped'
                        vps['suspended'] = True
                        history = vps.setdefault('suspension_history', [])
                        history.append({
                            'time': datetime.now().isoformat(),
                            'reason': f'Auto-suspended due to VPS expiration on {expiration_dt.strftime("%Y-%m-%d")}',
                            'by': 'Expiration Monitor',
                        })
                        save_vps_data_immediate()
                    except Exception as e:
                        logger.error(f"Failed to auto-suspend VPS {container_name}: {e}")
                        continue

                if key not in EXPIRATION_EXPIRED_NOTICE_SENT:
                    try:
                        owner = await bot.fetch_user(int(user_id))
                        dm = create_error_embed(
                            "VPS Expired and Suspended" if EXPIRATION_AUTO_SUSPEND else "VPS Expired",
                            f"Your VPS `{container_name}` has expired. " + ("It has been suspended." if EXPIRATION_AUTO_SUSPEND else "Auto-suspension is disabled by server policy.") + "\n\n"
                            f"Expiration: `{expiration_dt.strftime('%Y-%m-%d %H:%M:%S')}`\n"
                            f"Use `{PREFIX}renew` to request a {VPS_RENEWAL_DAYS}-day renewal.",
                        )
                        await owner.send(embed=dm)
                    except Exception as e:
                        logger.debug(f"Failed to notify expired VPS owner {user_id}: {e}")
                    finally:
                        EXPIRATION_EXPIRED_NOTICE_SENT.add(key)
                EXPIRATION_WARNING_SENT.discard(key)

            elif seconds_left <= warning_window and key not in EXPIRATION_WARNING_SENT:
                try:
                    owner = await bot.fetch_user(int(user_id))
                    hours = max(1, int(seconds_left // 3600))
                    dm = create_warning_embed(
                        "VPS Expiring Soon",
                        f"Your VPS `{container_name}` expires in approximately **{hours} hour(s)**.\n\n"
                        f"Expiration: `{expiration_dt.strftime('%Y-%m-%d %H:%M:%S')}`\n"
                        f"Use `{PREFIX}renew` during the final {RENEWAL_WINDOW_DAYS} days to add {VPS_RENEWAL_DAYS} days.",
                    )
                    await owner.send(embed=dm)
                    EXPIRATION_WARNING_SENT.add(key)
                except Exception as e:
                    logger.debug(f"Failed to send expiration warning to {user_id}: {e}")


# --- restored stable helper: resource_monitor ---
def resource_monitor():
    """Low-frequency host resource logger; expiration checks run on bot's event loop."""
    global resource_monitor_active
    while resource_monitor_active:
        try:
            for node in get_nodes():
                if not node.get('is_local'):
                    continue
                try:
                    stats = asyncio.run(get_host_stats(node['id']))
                    cpu = float(stats.get('cpu', 0.0) or 0.0)
                    ram = float(stats.get('ram', 0.0) or 0.0)
                    logger.info(f"Node {node['name']}: CPU {cpu:.1f}%, RAM {ram:.1f}%")
                    if cpu > CPU_THRESHOLD or ram > RAM_THRESHOLD:
                        logger.warning(
                            f"Node {node['name']} exceeded thresholds "
                            f"(CPU: {CPU_THRESHOLD}%, RAM: {RAM_THRESHOLD}%). Manual intervention required."
                        )
                except Exception as e:
                    logger.debug(f"Resource check failed for node {node.get('name')}: {e}")
            time.sleep(180)
        except Exception as e:
            logger.error(f"Error in resource monitor: {e}")
            time.sleep(180)


# --- restored stable helper: find_node_id_for_container ---
def find_node_id_for_container(container_name: str) -> int:
    with DB_LOCK:
        conn = get_db()
        try:
            row = conn.execute(
                "SELECT node_id FROM vps WHERE container_name = ?",
                (container_name,),
            ).fetchone()
            return int(row[0]) if row else 1
        finally:
            conn.close()


# --- colorless Discord embed layer ---
def truncate_text(text, max_length=1024):
    text = str(text if text is not None else '')
    if len(text) <= max_length:
        return text
    return text[:max(0, max_length - 3)] + '...'

def create_embed(title, description="", color=None):
    """Create a standard Discord embed without a custom accent colour."""
    embed = discord.Embed(
        title=truncate_text(title, 256),
        description=truncate_text(description, 4096),
        timestamp=datetime.now(),
    )
    if BOT_THUMBNAIL_URL:
        embed.set_thumbnail(url=BOT_THUMBNAIL_URL)
    footer = f"⚡ {BOT_NAME} • {BOT_DEVELOPER} • v{BOT_VERSION}"
    embed.set_footer(text=footer, icon_url=BOT_ICON_URL or None)
    return embed

def add_field(embed, name, value, inline=False):
    embed.add_field(name=f"➤ {name}", value=truncate_text(value, 1024), inline=inline)
    return embed

def _safe_diagnostic_text(error, limit=900):
    """Redact common secrets/tunnel URLs before writing a useful failure reason to service logs."""
    value = str(error if error is not None else 'Unknown failure')
    # URLs are removed first so a hostname containing a word such as "secret" cannot be
    # mistaken for a CLI flag and leave misleading noise in the final diagnostic.
    value = re.sub(r'(?i)https?://[^\s/]*pinggy[^\s/]*/[^\s<>`]*', '[TUNNEL_URL_REDACTED]', value)
    value = re.sub(r'(?i)tcp://[^\s<>`]+', '[TUNNEL_ENDPOINT_REDACTED]', value)
    value = re.sub(r'(?i)discord(?:app)?\.com/api/webhooks/[^\s<>`]+', '[DISCORD_WEBHOOK_REDACTED]', value)
    value = re.sub(r'(?i)(token|api[_ -]?key|password|passwd|secret|authorization)(\s*[=:]\s*)[^\s,;]+', r'\1\2[REDACTED]', value)
    # Also redact CLI-style secrets which may appear in a subprocess/remote-agent error string.
    value = re.sub(r"""(?i)(--?(?:password|passwd|token|api[-_]?key|secret|authorization)(?:=|\s+))(?:(?:'[^']*')|(?:"[^"]*")|[^\s,;]+)""", r"\1[REDACTED]", value)
    value = re.sub(r'(?i)(?:Bot\s+)?[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{10,}', '[TOKEN_REDACTED]', value)
    return truncate_text(value.replace('\x00',' '), limit)


def safe_error_summary(operation, error=None, trace_id=None):
    """Safe Discord-facing failure summary without exception text or response payloads."""
    action = str(operation or "Operation").strip()[:120]
    error_name = type(error).__name__ if isinstance(error, BaseException) else "UnknownError"
    trace = f" Diagnostic ID: `{trace_id}`." if trace_id else ''
    return f"{action} failed ({error_name}). Sensitive details were hidden; an administrator can search service logs using the diagnostic ID.{trace}"


def create_success_embed(title, description=""):
    return create_embed(title, description)

def create_error_embed(title, description=""):
    return create_embed(title, description)

def create_info_embed(title, description=""):
    return create_embed(title, description)

def create_warning_embed(title, description=""):
    return create_embed(title, description)

def create_progress_bar(value, max_value=100, length=15):
    try:
        pct = max(0, min(100, int(float(value) / float(max_value or 1) * 100)))
    except Exception:
        pct = 0
    filled = int(length * pct / 100)
    return f"{'▰'*filled}{'▱'*(length-filled)} `{pct}%`"


# --- KVM/QEMU execution backend ---
def _local_kvm_ready() -> bool:
    """Low-cost readiness probe used only during selection/status, never from a polling loop."""
    if not Path('/dev/kvm').exists():
        return False
    virsh = shutil.which('virsh')
    if not virsh:
        return False
    try:
        result = subprocess.run(
            [virsh, '-c', 'qemu:///system', 'list', '--all'],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=3, check=False,
        )
        return result.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def _preferred_deployment_node_id() -> int:
    """Choose a usable node: configured pin, then ready local, then registered remote."""
    nodes = get_nodes()
    local_nodes = sorted((n for n in nodes if bool(n.get('is_local'))), key=lambda n: int(n.get('id') or 0))
    remote_nodes = [n for n in nodes if not bool(n.get('is_local'))]
    local_ready = bool(local_nodes) and _local_kvm_ready()

    if DEFAULT_NODE_ID > 0:
        for node in nodes:
            if int(node.get('id') or 0) != DEFAULT_NODE_ID:
                continue
            if bool(node.get('is_local')) and not local_ready:
                logger.warning('Configured Local Node ID %s is not KVM-ready; selecting a registered remote node if available.', DEFAULT_NODE_ID)
                break
            return DEFAULT_NODE_ID

    if local_ready:
        # Local IDs are database-generated and need not equal 1.
        return int(local_nodes[0]['id'])
    if remote_nodes:
        candidates = remote_nodes
    elif local_nodes:
        raise RuntimeError('Local Node is registered but KVM/libvirt is not ready, and no remote node is registered. Enable host KVM in setup or run the admin command `-node create` to add a remote node.')
    else:
        raise RuntimeError('No VPS node is configured. The Local Node is created automatically; verify KVM/libvirt or run the admin command `-node create` for a remote node.')

    def score(node):
        name = str(node.get('name') or '').strip().lower().replace('_', ' ').replace('-', ' ')
        location = str(node.get('location') or '').strip().lower()
        exact_node1 = name.split() in (['node', '1'], ['node', '01'])
        singapore = 'singapore' in location or 'asia/singapore' in location
        return (0 if exact_node1 else 1, 0 if singapore else 1, int(node.get('id') or 0))

    return int(sorted(candidates, key=score)[0]['id'])


def _resolve_execution_node_id(container_name: str = '') -> int:
    """Respect a VPS's persisted node mapping; otherwise honor the configured local/remote policy."""
    if container_name:
        try:
            with DB_LOCK:
                conn = get_db()
                try:
                    row = conn.execute('SELECT node_id FROM vps WHERE container_name = ?', (str(container_name),)).fetchone()
                finally:
                    conn.close()
            if row and row[0] is not None:
                return int(row[0])
        except Exception as exc:
            logger.warning('Could not resolve existing VPS node mapping (%s); using configured default node.', type(exc).__name__)
    return _preferred_deployment_node_id()


async def execute_vpsctl_compat(container_name: str, command: str, timeout: int = 300, node_id: Optional[int] = None):
    """Execute one RGNODES KVM VPS compat command locally or through an authenticated node agent."""
    if node_id is None:
        node_id = _resolve_execution_node_id(container_name)
    node = get_node(node_id)
    if not node:
        raise RuntimeError(f"Node {node_id} not found")
    command = str(command or '').strip()
    if not command:
        raise ValueError('VPS controller command cannot be empty')
    if node.get('is_local'):
        controller = _find_kvm_vpsctl()
        if not controller:
            raise RuntimeError('KVM controller executable is missing or invalid. Run `sudo bash setup.sh --repair-controller` from the matching seven-file release directory (or `sudo bash setup.sh` for a full install). The installer verifies the embedded SHA-256 and preserves the old controller; unsupported legacy controller formats are rejected.')
        argv = [sys.executable, controller, 'compat', command]
        try:
            proc = await asyncio.create_subprocess_exec(*argv, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                proc.kill(); await proc.wait()
                raise asyncio.TimeoutError(f'VPS operation timed out after {timeout}s')
        except FileNotFoundError as exc:
            raise RuntimeError(f'Python/controller executable unavailable: {controller}') from exc
        out = stdout.decode(errors='replace').strip() if stdout else ''
        err = stderr.decode(errors='replace').strip() if stderr else ''
        if proc.returncode != 0:
            detail = err or out or 'controller returned a failure'
            legacy_controller_markers = ('Failed getting remote image info', 'requested image couldn', 'unsupported OS image')
            if any(marker.lower() in detail.lower() for marker in legacy_controller_markers):
                detail = ('The installed VPS controller or selected cloud image is incompatible. '
                          'Run setup.sh --repair-controller from the matching release directory and choose a supported OS. '
                          f'Original controller error: {detail[:900]}')
            raise RuntimeError(f'Local VPS operation failed: {detail}')
        # Controller compat emits JSON for structured operations and plain text for a few reads.
        if out:
            try:
                payload=json.loads(out)
                if isinstance(payload, dict) and payload.get('error'):
                    raise RuntimeError(str(payload['error']))
                if isinstance(payload, (dict,list)):
                    return payload
            except json.JSONDecodeError:
                pass
        return out if out else True

    url = str(node.get('url') or '').rstrip('/') + '/api/execute'
    api_key = str(node.get('api_key') or '')
    if not url or not api_key:
        raise RuntimeError(f"Remote node {node.get('name', node_id)!r} is missing URL/API key")
    remote_controller = str(node.get('vpsctl_path') or '/usr/local/sbin/vpsctl')
    # Quote the compat payload as one shell argument; remote agent should execute only the node's fixed command policy.
    full_command = f"{shlex.quote(remote_controller)} compat {shlex.quote(command)}"
    try:
        response = await asyncio.to_thread(requests.post, url, json={'command': full_command}, headers={'X-API-Key': api_key}, timeout=timeout)
    except requests.exceptions.Timeout as exc:
        raise RuntimeError(f"Remote VPS operation timed out on {node.get('name', node_id)} after {timeout}s") from exc
    except requests.exceptions.RequestException as exc:
        raise RuntimeError(f"Remote node {node.get('name', node_id)} is unreachable: {exc}") from exc
    if response.status_code != 200:
        try:
            payload=response.json(); detail=payload.get('detail') or payload.get('error') or payload.get('stderr') or payload
        except Exception:
            detail=response.text
        raise RuntimeError(f"Remote VPS operation failed on {node.get('name', node_id)} (HTTP {response.status_code}): {str(detail)[:1500]}")
    try: payload=response.json()
    except Exception as exc: raise RuntimeError(f"Remote node {node.get('name', node_id)} returned invalid JSON") from exc
    rc=int(payload.get('returncode', payload.get('return_code',0)) or 0)
    if rc != 0:
        raise RuntimeError(f"Remote VPS operation failed on {node.get('name', node_id)}: {str(payload.get('stderr') or payload.get('error') or 'command failed')[:1600]}")
    out=str(payload.get('stdout') or '')
    try:
        parsed=json.loads(out)
        if isinstance(parsed, (dict,list)): return parsed
    except Exception:
        pass
    return out if out else True

async def execute_vpsctl(subcommand: str, action: str, container_name: str, timeout: int = 300, node_id: Optional[int] = None):
    """Compatibility wrapper used by legacy stats callers; never invokes a container backend; only KVM/QEMU VPS operations are supported."""
    if subcommand == 'compat':
        return await execute_vpsctl_compat(container_name, action, timeout=timeout, node_id=node_id)
    raise RuntimeError(f'Unsupported VPS controller mode: {subcommand}')

async def _exec_guest_bash(container_name: str, node_id: int, script: str, timeout: int = 120):
    payload = str(script or '').strip()
    if not payload:
        return ''
    return await execute_vpsctl_compat(container_name, f"exec {shlex.quote(container_name)} -- bash -lc {shlex.quote(payload)}", timeout=timeout, node_id=node_id)

async def apply_vps_performance_profile(container_name: str, node_id: int, ram_mb: int, cpu: int) -> None:
    """KVM-specific ceiling policy. Runtime starts small; max CPU/RAM stay admitted and bounded."""
    ram_mb=max(1024,min(VPS_MAX_RAM_GB*1024,int(ram_mb)))
    cpu=max(1,min(VPS_MAX_CPU,int(cpu)))
    await execute_vpsctl_compat(container_name, f'config set {shlex.quote(container_name)} limits.memory.max {ram_mb}MB', node_id=node_id, timeout=60)
    await execute_vpsctl_compat(container_name, f'config set {shlex.quote(container_name)} limits.cpu.max {cpu}', node_id=node_id, timeout=60)

async def apply_vps_vm_config(container_name: str, node_id: int) -> bool:
    """KVM VM config is defined atomically by vpsctl; this hook is intentionally non-destructive."""
    return True


async def auto_save_task():
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            await asyncio.sleep(AUTOSAVE_INTERVAL)
            save_vps_data()
            save_admin_data()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error('Background database save failed: %s', exc, exc_info=True)


def _cleanup_orphaned_rgnodes_temp_files(max_files: int = 32) -> int:
    """Delete only stale atomic-write temp files owned by this app; never clean OS /tmp."""
    removed = 0
    now = time.time()
    try:
        candidates = list(DATA_DIR.iterdir())
    except OSError:
        return 0
    for path in candidates:
        if removed >= max(1, min(64, int(max_files))):
            break
        if path.is_symlink() or not path.is_file():
            continue
        match = re.fullmatch(r"\..+\.rgnodes-(\d+)\.tmp", path.name)
        if not match:
            continue
        try:
            if now - path.stat(follow_symlinks=False).st_mtime < 3600:
                continue
            pid = int(match.group(1))
            if pid > 0:
                try:
                    os.kill(pid, 0)
                    continue  # A live process may still be writing this temp file.
                except ProcessLookupError:
                    pass
                except PermissionError:
                    continue
                except OSError:
                    continue
            path.unlink()
            removed += 1
        except OSError:
            continue
    return removed


def _opportunistic_sqlite_maintenance() -> bool:
    """Run inexpensive SQLite housekeeping only when the DB lock is immediately available."""
    if not DB_LOCK.acquire(blocking=False):
        return False
    conn = None
    try:
        conn = get_db()
        conn.execute("PRAGMA optimize")
        # PASSIVE never waits on readers/writers and is safer for a busy production bot.
        conn.execute("PRAGMA wal_checkpoint(PASSIVE)")
        return True
    except sqlite3.Error as exc:
        logger.debug("SQLite housekeeping deferred (%s).", type(exc).__name__)
        return False
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
        DB_LOCK.release()


async def resource_housekeeping_task():
    """Five-minute low-load cleanup; preserve kernel caches, VM disks, logs and backups."""
    await bot.wait_until_ready()
    while not bot.is_closed():
        await asyncio.sleep(300)
        try:
            now_mono = time.monotonic()
            stale_cache_after = max(60.0, HOST_STATS_CACHE_TTL * 10.0)
            stale_nodes = [node_id for node_id, (stamp, _value) in list(HOST_STATS_CACHE.items())
                           if now_mono - float(stamp) > stale_cache_after]
            for node_id in stale_nodes:
                HOST_STATS_CACHE.pop(node_id, None)

            # Login attempts use monotonic timestamps. Drop only entries outside their
            # five-minute rate-limit window; this never removes active sessions.
            attempts = globals().get("_WEB_TERMINAL_LOGIN_ATTEMPTS")
            if isinstance(attempts, dict):
                for remote, stamps in list(attempts.items()):
                    active = [float(stamp) for stamp in stamps if now_mono - float(stamp) < 300.0]
                    if active:
                        attempts[remote] = active
                    else:
                        attempts.pop(remote, None)

            active_locks = set()
            for items in list(vps_data.values()):
                if not isinstance(items, (list, tuple)):
                    continue
                for vps in list(items):
                    if not isinstance(vps, dict):
                        continue
                    name = str(vps.get('container_name') or '').strip()
                    if not name:
                        continue
                    try:
                        node_id = int(vps.get('node_id', 1) or 1)
                    except (TypeError, ValueError):
                        continue  # Bad legacy records must not abort the entire cleanup pass.
                    active_locks.add((name, node_id))
            for key, lock in list(TUNNEL_SETUP_LOCKS.items()):
                if key not in active_locks and not lock.locked():
                    TUNNEL_SETUP_LOCKS.pop(key, None)

            removed = await asyncio.to_thread(_cleanup_orphaned_rgnodes_temp_files)
            # Avoid an expensive global cache flush: OS page cache improves VM/image I/O.
            try:
                gc.collect(0)
            except Exception:
                pass
            sqlite_ok = await asyncio.to_thread(_opportunistic_sqlite_maintenance)
            if stale_nodes or removed or sqlite_ok:
                logger.debug("Housekeeping complete: stale_node_cache=%d orphan_tmp=%d sqlite_maintenance=%s", len(stale_nodes), removed, sqlite_ok)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("Five-minute housekeeping skipped (%s).", type(exc).__name__)

def cleanup_on_shutdown():
    try:
        save_vps_data()
        save_admin_data()
    except Exception as exc:
        logger.error('Final database save failed: %s', exc, exc_info=True)
        try: backup_database()
        except Exception: pass

# Registered only after the function exists (registering earlier raised NameError at import).
atexit.register(cleanup_on_shutdown)

def get_presence_counts():
    created=sum(len(items) for items in vps_data.values())
    running=sum(1 for items in vps_data.values() for v in items if str(v.get('status','')).lower()=='running' and not v.get('suspended',False))
    expired=sum(1 for items in vps_data.values() for v in items if v.get('expiration_date') and _safe_fromiso(str(v['expiration_date'])) <= datetime.now())
    total_slots=sum(max(0,int(n.get('total_vps') or 0)) for n in get_nodes()) or max(created,1)
    return created,total_slots,running,expired

def format_expiration(vps):
    raw=vps.get('expiration_date')
    if not raw: return '🔵 No expiration'
    try: days=(_safe_fromiso(str(raw))-datetime.now()).days
    except Exception: return '⚠️ Invalid expiration'
    if days<0: return f'🔴 **EXPIRED** (`{abs(days)}d ago`)'
    if days<=EXPIRATION_WARNING_DAYS: return f'🟡 **EXPIRING** (`{days}d left`)'
    return f'🟢 **ACTIVE** (`{days}d left`)'

# -------------------- RGNODES™ OpenSSH Web Terminal --------------------
# Localhost only by design. Remote devices should use SSH port-forwarding rather than exposing
# a root-capable browser terminal directly to the Internet.
_WEB_TERMINAL_RUNNER = None
_WEB_TERMINAL_START_TASK = None
_WEB_TERMINAL_TOKEN_CACHE = None
_WEB_TERMINAL_SESSIONS: Dict[str, float] = {}
_WEB_TERMINAL_SESSION_SCOPES: Dict[str, Dict[str, Any]] = {}
_WEB_TERMINAL_SESSION_IPS: Dict[str, str] = {}
_WEB_TERMINAL_SCOPED_TOKENS: Dict[str, Dict[str, Any]] = {}
_WEB_TERMINAL_LOGIN_ATTEMPTS: Dict[str, List[float]] = {}
_WEB_TERMINAL_ACTIVE_SESSIONS = set()
WEBSSH_TICKET_TTL = max(300, min(3600, env_int('WEBSSH_TICKET_TTL', '1800')))

_WEB_TERMINAL_HTML = r'''<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>RGNODES™ OpenSSH Terminal</title>
<style>
:root{color-scheme:dark;--bg:#101216;--panel:#191d24;--line:#343b46;--text:#e8edf4;--muted:#9aa5b4;--accent:#a8e7b3;--danger:#ffb4a8}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;min-height:100vh;display:flex;flex-direction:column}
header{padding:16px clamp(14px,3vw,30px);border-bottom:1px solid var(--line);display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;background:#15181e}.brand{font-weight:750;letter-spacing:.02em}.sub{color:var(--muted);font-size:.84rem}main{width:min(1200px,100%);margin:0 auto;padding:clamp(12px,3vw,24px);flex:1;display:flex;flex-direction:column;gap:14px}
.card{border:1px solid var(--line);background:var(--panel);border-radius:14px;padding:clamp(13px,2.5vw,22px);box-shadow:0 8px 26px #0002}h1{font-size:1.15rem;margin:0 0 6px}p{margin:5px 0 14px;color:var(--muted)}label{display:flex;flex-direction:column;gap:6px;font-size:.85rem;color:var(--muted);min-width:0}
input,button,textarea{font:inherit;border:1px solid var(--line);border-radius:9px;padding:11px 12px;background:#101319;color:var(--text);min-width:0}input:focus,textarea:focus{outline:2px solid #9eb6a3;outline-offset:1px}button{cursor:pointer;font-weight:650;background:#252b34}button:disabled{opacity:.45;cursor:not-allowed}.row{display:grid;grid-template-columns:minmax(0,2fr) minmax(90px,.7fr) minmax(110px,1fr) auto;gap:10px;align-items:end}.login-row{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end}.hint{font-size:.82rem;color:var(--muted);overflow-wrap:anywhere}.notice{color:var(--danger);min-height:1.3em}.hidden{display:none!important}.terminal{min-height:40vh;max-height:60vh;overflow:auto;background:#07090c;border:1px solid #303843;border-radius:10px;padding:12px;color:#d8f0dc;font:13px/1.45 ui-monospace,SFMono-Regular,Consolas,monospace;white-space:pre-wrap;overflow-wrap:anywhere}.terminal-input{width:100%;font:13px/1.45 ui-monospace,SFMono-Regular,Consolas,monospace;border-radius:0 0 10px 10px;border-top:0;background:#07090c;color:#e8f6eb;resize:vertical;min-height:44px}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.status{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;color:var(--muted);font-size:.84rem}.safe{border-left:3px solid var(--accent);padding-left:10px}footer{padding:14px;text-align:center;color:var(--muted);font-size:.8rem}
@media(max-width:760px){.row{grid-template-columns:1fr 1fr}.row label:first-child{grid-column:1/-1}.row button{min-height:44px}.login-row{grid-template-columns:1fr}.terminal{min-height:34vh;max-height:48vh}.card{border-radius:11px}}
</style></head><body>
<header><div><div class="brand">RGNODES™ OpenSSH Terminal</div><div class="sub">Secure browser SSH client</div></div><div class="sub" id="topStatus">Locked</div></header>
<main>
<section class="card" id="loginCard"><h1>Terminal access</h1><p>Paste the one-time token sent by the VPS bot. Operator master tokens remain private; normal VPS tickets are restricted to one endpoint.</p><form id="loginForm" class="login-row"><label>Access token<input id="token" type="password" autocomplete="current-password" required minlength="20" placeholder="Paste the local terminal token"></label><button type="submit">Unlock terminal</button></form><div class="notice" id="loginNotice"></div><div class="hint">Keep this page private. SSH credentials are typed directly into the remote SSH session and are not saved by this web page.</div></section>
<section class="card hidden" id="terminalCard"><h1>Connect to an SSH host</h1><p class="safe">Only use systems you own or are authorized to administer. Host input is validated and passed as an argument to the local OpenSSH client; no shell command is constructed.</p>
<form id="connectForm" class="row"><label>Host / IP<input id="host" required maxlength="253" autocomplete="url" placeholder="203.0.113.10 or server.example.com"></label><label>SSH port<input id="port" type="number" min="1" max="65535" value="22" required></label><label>Username<input id="username" maxlength="32" value="root" required autocomplete="username"></label><button id="connectButton" type="submit">Connect SSH</button></form>
<div class="status"><span id="connectionStatus">Not connected</span><span>Private key: host user's SSH config · Password prompt supported</span></div><pre class="terminal" id="screen" role="log" aria-live="polite">RGNODES™ OpenSSH Terminal
Type a host above and press Connect SSH.
</pre><textarea class="terminal-input" id="keyboard" rows="1" spellcheck="false" autocomplete="off" autocapitalize="off" autocorrect="off" placeholder="Tap here, then type into the remote shell (Enter sends; Ctrl+C interrupts)"></textarea>
<div class="actions"><button type="button" id="ctrlC">Ctrl+C</button><button type="button" id="ctrlD">Ctrl+D</button><button type="button" id="clear">Clear screen</button><button type="button" id="disconnect">Disconnect</button><button type="button" id="logout">Lock terminal</button></div><div class="notice" id="terminalNotice"></div></section>
</main><footer>RGNODES™ · OpenSSH · HTTPS through a loopback-only reverse proxy</footer>
<script>
const $=id=>document.getElementById(id);let ws=null,unlocked=false;
function status(s){$('topStatus').textContent=s;$('connectionStatus').textContent=s}
function output(s){const pre=$('screen');pre.textContent+=s;if(pre.textContent.length>50000)pre.textContent=pre.textContent.slice(-40000);pre.scrollTop=pre.scrollHeight}
function send(v){if(ws&&ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(v));else $('terminalNotice').textContent='Connect to an SSH session first.'}
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('loginNotice').textContent='Checking token…';try{const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:$('token').value})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Access denied');unlocked=true;$('token').value='';$('loginCard').classList.add('hidden');$('terminalCard').classList.remove('hidden');$('loginNotice').textContent='';if(d.scope){$('host').value=d.scope.host;$('port').value=d.scope.port;$('username').value=d.scope.username;$('host').readOnly=true;$('port').readOnly=true;$('username').readOnly=true;$('screen').textContent='Restricted to VPS '+d.scope.vps+'\n';status('VPS-scoped token · endpoint locked')}else{status('Operator terminal unlocked · no SSH connection')}$('host').focus()}catch(e){$('loginNotice').textContent=e.message||'Access denied';$('token').select()}});
$('connectForm').addEventListener('submit',e=>{e.preventDefault();if(!unlocked)return;closeSocket();$('terminalNotice').textContent='';$('connectButton').disabled=true;$('screen').textContent='Starting OpenSSH…\n';let scheme=location.protocol==='https:'?'wss:':'ws:';ws=new WebSocket(scheme+'//'+location.host+'/ws');ws.binaryType='arraybuffer';ws.onopen=()=>{send({type:'connect',host:$('host').value.trim(),port:Number($('port').value),username:$('username').value.trim(),cols:100,rows:28});status('Connecting…')};ws.onmessage=e=>{if(e.data instanceof ArrayBuffer){let t=new TextDecoder().decode(e.data);t=t.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').replace(/\x1b\][^\x07]*(?:\x07|\x1b\\)/g,'');output(t)}else{try{const m=JSON.parse(e.data);if(m.type==='status'){output('\n'+m.data+'\n');status(m.data);if(m.done)$('connectButton').disabled=false}else if(m.type==='error'){$('terminalNotice').textContent=m.data;output('\n[ERROR] '+m.data+'\n');$('connectButton').disabled=false}}catch{output(e.data)}}};ws.onerror=()=>{$('terminalNotice').textContent='WebSocket error. Check the local service and SSH host.';$('connectButton').disabled=false};ws.onclose=()=>{$('connectButton').disabled=false;if($('connectionStatus').textContent.startsWith('Connected'))status('Disconnected')}});
function closeSocket(){if(ws){try{ws.close()}catch{}ws=null}$('connectButton').disabled=false}
$('keyboard').addEventListener('input',e=>{const value=e.target.value;if(value){send({type:'input',data:value});e.target.value=''}});
$('keyboard').addEventListener('keydown',e=>{const controls={Enter:'\r',Backspace:'\x7f',Tab:'\t',ArrowUp:'\x1b[A',ArrowDown:'\x1b[B',ArrowRight:'\x1b[C',ArrowLeft:'\x1b[D',Escape:'\x1b'};let data=controls[e.key];if(e.ctrlKey&&e.key.toLowerCase()==='c')data='\x03';else if(e.ctrlKey&&e.key.toLowerCase()==='d')data='\x04';else if(e.ctrlKey&&e.key.toLowerCase()==='z')data='\x1a';else if(e.ctrlKey&&e.key.toLowerCase()==='l')data='\x0c';if(data!==undefined){e.preventDefault();send({type:'input',data})}});
$('ctrlC').onclick=()=>send({type:'input',data:'\x03'});$('ctrlD').onclick=()=>send({type:'input',data:'\x04'});$('clear').onclick=()=>{$('screen').textContent=''};$('disconnect').onclick=()=>{closeSocket();status('Disconnected')};$('logout').onclick=async()=>{closeSocket();try{await fetch('/api/logout',{method:'POST'})}catch{}unlocked=false;$('terminalCard').classList.add('hidden');$('loginCard').classList.remove('hidden');status('Locked')};window.addEventListener('resize',()=>send({type:'resize',cols:Math.max(40,Math.floor(window.innerWidth/9)),rows:28}));
</script></body></html>'''


def issue_web_ssh_ticket(user_id: str, vps_name: str, host: str, port: int, username: str = "root") -> str:
    """Issue one-use, time-limited browser SSH credentials bound to a single VPS endpoint."""
    host = str(host or "").strip().strip("[]")
    username = str(username or "root").strip()
    port = int(port)
    try:
        parsed_ip = ipaddress.ip_address(host)
        if not parsed_ip.is_global:
            raise ValueError("Web SSH target must be a globally routable IP address.")
    except ValueError:
        if not re.fullmatch(r"(?i)(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*", host):
            raise ValueError("Web SSH target host is invalid.")
    if not 1 <= port <= 65535 or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9._-]{0,31}", username):
        raise ValueError("Web SSH target port or username is invalid.")
    if len(_WEB_TERMINAL_SCOPED_TOKENS) >= 256:
        now = time.monotonic()
        for key, item in list(_WEB_TERMINAL_SCOPED_TOKENS.items()):
            if float(item.get("expires", 0)) <= now:
                _WEB_TERMINAL_SCOPED_TOKENS.pop(key, None)
        if len(_WEB_TERMINAL_SCOPED_TOKENS) >= 256:
            raise RuntimeError("Too many active Web SSH tickets. Retry after an earlier ticket expires.")
    ticket = secrets.token_urlsafe(36)
    digest = hashlib.sha256(ticket.encode("utf-8")).hexdigest()
    _WEB_TERMINAL_SCOPED_TOKENS[digest] = {
        "user_id": str(user_id), "vps_name": str(vps_name), "host": host,
        "port": port, "username": username, "expires": time.monotonic() + WEBSSH_TICKET_TTL,
    }
    return ticket


def _load_web_terminal_secret() -> tuple[str, str]:
    # Load or generate the private terminal token.
    global _WEB_TERMINAL_TOKEN_CACHE
    if _WEB_TERMINAL_TOKEN_CACHE:
        return _WEB_TERMINAL_TOKEN_CACHE
    if WEB_TERMINAL_TOKEN:
        if len(WEB_TERMINAL_TOKEN) < 32:
            raise RuntimeError("WEB_TERMINAL_TOKEN must be at least 32 characters; unset it to create a private token file.")
        _WEB_TERMINAL_TOKEN_CACHE = (WEB_TERMINAL_TOKEN, ".env")
        return _WEB_TERMINAL_TOKEN_CACHE
    token_path = DATA_DIR / "web_terminal.token"
    try:
        token_path.parent.mkdir(parents=True, exist_ok=True)
        if token_path.is_symlink():
            raise RuntimeError("The web terminal token path must not be a symbolic link.")
        if token_path.exists():
            if not token_path.is_file():
                raise RuntimeError("The web terminal token path is not a regular file.")
            token = token_path.read_text(encoding="utf-8").strip()
            if len(token) >= 32:
                os.chmod(token_path, 0o600)
                _WEB_TERMINAL_TOKEN_CACHE = (token, str(token_path))
                return _WEB_TERMINAL_TOKEN_CACHE
            raise RuntimeError("The existing terminal token file is invalid; remove it and restart to generate a new token.")
        token = secrets.token_urlsafe(48)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        fd = os.open(token_path, flags, 0o600)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(token + "\n")
                handle.flush()
                os.fsync(handle.fileno())
        except Exception:
            try:
                os.unlink(token_path)
            except OSError:
                pass
            raise
        os.chmod(token_path, 0o600)
        _WEB_TERMINAL_TOKEN_CACHE = (token, str(token_path))
        return _WEB_TERMINAL_TOKEN_CACHE
    except OSError as exc:
        raise RuntimeError(f"Could not safely create/read the terminal token file ({type(exc).__name__}).") from exc


def _web_terminal_session_ok(request) -> bool:
    sid = request.cookies.get("rgnodes_terminal_session", "")
    expiry = _WEB_TERMINAL_SESSIONS.get(sid)
    if not expiry:
        return False
    now = time.monotonic()
    if expiry <= now:
        _WEB_TERMINAL_SESSIONS.pop(sid, None)
        _WEB_TERMINAL_SESSION_SCOPES.pop(sid, None)
        _WEB_TERMINAL_SESSION_IPS.pop(sid, None)
        return False
    _WEB_TERMINAL_SESSIONS[sid] = now + WEB_TERMINAL_SESSION_TTL
    return True


async def _web_terminal_root(_request):
    if aiohttp_web is None:
        raise RuntimeError("aiohttp web support is unavailable")
    template_path = BASE_DIR / "webssh.html"
    try:
        if template_path.is_file() and not template_path.is_symlink():
            page = template_path.read_text(encoding="utf-8")
        else:
            page = _WEB_TERMINAL_HTML
    except (OSError, UnicodeError):
        page = _WEB_TERMINAL_HTML
    page = page.replace("__BOT_NAME__", html_lib.escape(str(BOT_NAME)))
    page = page.replace("__BOT_VERSION__", html_lib.escape(str(BOT_VERSION)))
    return aiohttp_web.Response(text=page, content_type="text/html", charset="utf-8", headers={"Cache-Control": "no-store"})


async def _web_terminal_login(request):
    if aiohttp_web is None:
        raise RuntimeError("aiohttp web support is unavailable")
    remote = str(request.remote or "unknown")
    try:
        peer = ipaddress.ip_address(remote.split("%", 1)[0])
        if peer.is_loopback:
            forwarded = str(request.headers.get("X-Forwarded-For", "")).split(",", 1)[0].strip()
            if forwarded:
                remote = ipaddress.ip_address(forwarded).compressed
    except ValueError:
        remote = "invalid-proxy-peer"
    now = time.monotonic()
    recent = [t for t in _WEB_TERMINAL_LOGIN_ATTEMPTS.get(remote, []) if now - t < 300]
    if len(recent) >= 8:
        _WEB_TERMINAL_LOGIN_ATTEMPTS[remote] = recent
        return aiohttp_web.json_response({"error": "Too many attempts. Wait five minutes."}, status=429)
    _WEB_TERMINAL_LOGIN_ATTEMPTS[remote] = recent + [now]
    # Bound the cache even if many distinct source addresses attempt bad logins.
    if len(_WEB_TERMINAL_LOGIN_ATTEMPTS) > 1024:
        for candidate, stamps in list(_WEB_TERMINAL_LOGIN_ATTEMPTS.items()):
            active = [stamp for stamp in stamps if now - stamp < 300]
            if active:
                _WEB_TERMINAL_LOGIN_ATTEMPTS[candidate] = active
            else:
                _WEB_TERMINAL_LOGIN_ATTEMPTS.pop(candidate, None)
        if len(_WEB_TERMINAL_LOGIN_ATTEMPTS) > 2048:
            for candidate in list(_WEB_TERMINAL_LOGIN_ATTEMPTS)[:len(_WEB_TERMINAL_LOGIN_ATTEMPTS) - 2048]:
                _WEB_TERMINAL_LOGIN_ATTEMPTS.pop(candidate, None)
    try:
        body = await request.json()
        supplied = str(body.get("token", ""))[:512]
    except Exception:
        supplied = ""
    scope = None
    if supplied:
        supplied_hash = hashlib.sha256(supplied.encode("utf-8")).hexdigest()
        ticket_item = _WEB_TERMINAL_SCOPED_TOKENS.get(supplied_hash)
        if ticket_item and float(ticket_item.get("expires", 0)) > now:
            scope = dict(ticket_item)
            # One-time ticket: it cannot be replayed to create multiple sessions.
            _WEB_TERMINAL_SCOPED_TOKENS.pop(supplied_hash, None)
        else:
            try:
                expected, _token_source = _load_web_terminal_secret()
            except Exception as exc:
                logger.error("Web terminal token initialization failed: %s", type(exc).__name__)
                return aiohttp_web.json_response({"error": "Terminal authentication is not configured safely."}, status=503)
            if not supplied or not secrets.compare_digest(supplied, expected):
                return aiohttp_web.json_response({"error": "Invalid or expired terminal token."}, status=401)
    else:
        return aiohttp_web.json_response({"error": "A terminal token is required."}, status=401)
    _WEB_TERMINAL_LOGIN_ATTEMPTS.pop(remote, None)
    for old_sid, expiry in list(_WEB_TERMINAL_SESSIONS.items()):
        if expiry <= now:
            _WEB_TERMINAL_SESSIONS.pop(old_sid, None)
            _WEB_TERMINAL_SESSION_SCOPES.pop(old_sid, None)
            _WEB_TERMINAL_SESSION_IPS.pop(old_sid, None)
    if len(_WEB_TERMINAL_SESSIONS) >= WEB_TERMINAL_MAX_SESSIONS:
        return aiohttp_web.json_response({"error": "The terminal session limit is reached. Log out unused sessions first."}, status=429)
    if sum(1 for ip in _WEB_TERMINAL_SESSION_IPS.values() if ip == remote) >= WEB_TERMINAL_SESSIONS_PER_IP:
        return aiohttp_web.json_response({"error": "This IP address already has the maximum number of terminal sessions."}, status=429)
    sid = secrets.token_urlsafe(36)
    _WEB_TERMINAL_SESSIONS[sid] = now + WEB_TERMINAL_SESSION_TTL
    _WEB_TERMINAL_SESSION_IPS[sid] = remote
    if scope:
        _WEB_TERMINAL_SESSION_SCOPES[sid] = scope
    response_data = {"ok": True}
    if scope:
        response_data["scope"] = {"host": scope["host"], "port": scope["port"], "username": scope["username"], "vps": scope["vps_name"]}
    response = aiohttp_web.json_response(response_data)
    forwarded_proto = str(request.headers.get("X-Forwarded-Proto", "")).split(",", 1)[0].strip().lower()
    request_host = str(request.host or "").split(":", 1)[0].lower()
    secure_cookie = forwarded_proto == "https" or (WEB_TERMINAL_SCHEME == "https" and request_host == WEB_TERMINAL_HOST)
    response.set_cookie("rgnodes_terminal_session", sid, httponly=True, secure=secure_cookie, samesite="Strict", max_age=WEB_TERMINAL_SESSION_TTL, path="/")
    return response


async def _web_terminal_logout(request):
    if aiohttp_web is None:
        raise RuntimeError("aiohttp web support is unavailable")
    sid = request.cookies.get("rgnodes_terminal_session", "")
    _WEB_TERMINAL_SESSIONS.pop(sid, None)
    _WEB_TERMINAL_SESSION_SCOPES.pop(sid, None)
    _WEB_TERMINAL_SESSION_IPS.pop(sid, None)
    response = aiohttp_web.json_response({"ok": True})
    response.del_cookie("rgnodes_terminal_session", path="/")
    return response


async def _web_terminal_websocket(request):
    if aiohttp_web is None:
        raise RuntimeError("aiohttp web support is unavailable")
    if not _web_terminal_session_ok(request):
        return aiohttp_web.Response(status=401, text="Login required")
    session_id = request.cookies.get("rgnodes_terminal_session", "")
    session_scope = _WEB_TERMINAL_SESSION_SCOPES.get(session_id)
    ws = aiohttp_web.WebSocketResponse(heartbeat=25, max_msg_size=4096, autoclose=True, autoping=True)
    await ws.prepare(request)
    process = None
    master_fd = None
    reader_task = None
    active_key = None
    try:
        async for message in ws:
            if message.type == aiohttp_web.WSMsgType.ERROR:
                break
            if message.type != aiohttp_web.WSMsgType.TEXT:
                continue
            try:
                payload = json.loads(message.data)
            except (TypeError, ValueError):
                await ws.send_str(json.dumps({"type": "error", "data": "Invalid terminal message."}))
                continue
            action = str(payload.get("type", ""))
            if action == "ping":
                await ws.send_str(json.dumps({"type": "pong", "client_ts": payload.get("client_ts")}))
                continue
            if action == "connect":
                if process is not None:
                    await ws.send_str(json.dumps({"type": "error", "data": "A session is already connected on this socket."}))
                    continue
                if len(_WEB_TERMINAL_ACTIVE_SESSIONS) >= WEB_TERMINAL_MAX_SESSIONS:
                    await ws.send_str(json.dumps({"type": "error", "data": "Terminal session limit reached. Close another session first."}))
                    continue
                host = str(payload.get("host", "")).strip().strip("[]")
                username = str(payload.get("username", "root")).strip()
                try:
                    port = int(payload.get("port", 22))
                except (TypeError, ValueError):
                    port = 0
                try:
                    ipaddress.ip_address(host)
                    host_valid = True
                except ValueError:
                    host_valid = bool(re.fullmatch(r"(?i)(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*", host))
                if not host_valid or not (1 <= port <= 65535) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9._-]{0,31}", username):
                    await ws.send_str(json.dumps({"type": "error", "data": "Invalid host, port, or username."}))
                    continue
                if session_scope:
                    scoped_host = str(session_scope.get("host", "")).strip().strip("[]").casefold()
                    if host.casefold() != scoped_host or port != int(session_scope.get("port", 0)) or username != str(session_scope.get("username", "root")):
                        await ws.send_str(json.dumps({"type": "error", "data": "This one-time ticket is restricted to its assigned VPS endpoint."}))
                        continue
                ssh_binary = shutil.which("ssh")
                if not ssh_binary:
                    await ws.send_str(json.dumps({"type": "error", "data": "OpenSSH client binary is missing on the RGNODES host."}))
                    continue
                slave_fd = None
                try:
                    import fcntl, pty, signal, struct, termios
                    master_fd, slave_fd = pty.openpty()
                    cols = max(40, min(240, int(payload.get("cols", 100) or 100)))
                    rows = max(12, min(80, int(payload.get("rows", 28) or 28)))
                    fcntl.ioctl(slave_fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
                    argv = [
                        ssh_binary, "-tt", "-p", str(port),
                        "-o", "BatchMode=no", "-o", "StrictHostKeyChecking=accept-new",
                        "-o", f"ConnectTimeout={WEB_TERMINAL_CONNECT_TIMEOUT}", "-o", "ServerAliveInterval=30",
                        "-o", "ServerAliveCountMax=3", "-o", "ForwardAgent=no",
                        "-o", "ForwardX11=no", "-o", "ClearAllForwardings=yes",
                        "-o", "PermitLocalCommand=no", "-o", "LogLevel=ERROR", "--", f"{username}@{host}",
                    ]
                    process = await asyncio.create_subprocess_exec(
                        *argv, stdin=slave_fd, stdout=slave_fd, stderr=slave_fd, start_new_session=True,
                    )
                    os.close(slave_fd)
                    os.set_blocking(master_fd, False)
                    active_key = f"{id(ws)}:{process.pid}"
                    _WEB_TERMINAL_ACTIVE_SESSIONS.add(active_key)
                    await ws.send_str(json.dumps({"type": "status", "data": f"Connected to local OpenSSH client · {username}@{host}:{port}. Authenticate in the terminal prompt."}))

                    async def _pump_pty():
                        loop = asyncio.get_running_loop()
                        while not ws.closed:
                            future = loop.create_future()
                            def _ready():
                                if future.done():
                                    return
                                try:
                                    chunk = os.read(master_fd, 4096)
                                except BlockingIOError:
                                    # PTY readiness can race another event; retry without ending SSH.
                                    chunk = None
                                except OSError:
                                    chunk = b""
                                if not future.done():
                                    future.set_result(chunk)
                            try:
                                loop.add_reader(master_fd, _ready)
                                chunk = await future
                            finally:
                                loop.remove_reader(master_fd)
                            if chunk is None:
                                continue
                            if chunk:
                                try:
                                    await ws.send_bytes(chunk)
                                except Exception:
                                    break
                            else:
                                break
                        try:
                            code = await process.wait()
                            if not ws.closed:
                                await ws.send_str(json.dumps({"type": "status", "data": f"SSH process ended (exit {code}).", "done": True}))
                        except Exception:
                            pass

                    reader_task = asyncio.create_task(_pump_pty(), name=f"rgnodes_web_ssh_{process.pid}")
                except Exception as exc:
                    if slave_fd is not None:
                        try:
                            os.close(slave_fd)
                        except OSError:
                            pass
                    if master_fd is not None:
                        try:
                            os.close(master_fd)
                        except OSError:
                            pass
                        master_fd = None
                    await ws.send_str(json.dumps({"type": "error", "data": f"Could not start OpenSSH ({type(exc).__name__})."}))
                continue
            if action == "input":
                if master_fd is None:
                    await ws.send_str(json.dumps({"type": "error", "data": "Connect to an SSH host first."}))
                    continue
                data = payload.get("data", "")
                if isinstance(data, str) and len(data) <= 2048:
                    try:
                        os.write(master_fd, data.encode("utf-8", errors="replace"))
                    except OSError:
                        await ws.send_str(json.dumps({"type": "status", "data": "SSH input channel closed.", "done": True}))
                continue
            if action == "resize" and master_fd is not None:
                try:
                    import fcntl, signal, struct, termios
                    cols = max(40, min(240, int(payload.get("cols", 100) or 100)))
                    rows = max(12, min(80, int(payload.get("rows", 28) or 28)))
                    fcntl.ioctl(master_fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
                    if process is not None:
                        os.killpg(process.pid, signal.SIGWINCH)
                except Exception:
                    pass
    finally:
        if reader_task is not None and not reader_task.done():
            reader_task.cancel()
            try:
                await reader_task
            except BaseException:
                pass
        if process is not None and process.returncode is None:
            try:
                import signal
                os.killpg(process.pid, signal.SIGTERM)
                await asyncio.wait_for(process.wait(), timeout=3)
            except Exception:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except Exception:
                    pass
                try:
                    await process.wait()
                except Exception:
                    pass
        if master_fd is not None:
            try:
                os.close(master_fd)
            except OSError:
                pass
        if active_key:
            _WEB_TERMINAL_ACTIVE_SESSIONS.discard(active_key)
    return ws


async def start_web_terminal_server():
    # Start the local terminal without coupling failures to Discord gateway startup.
    global _WEB_TERMINAL_RUNNER
    if not WEB_TERMINAL_ENABLED:
        logger.info("RGNODES web terminal is disabled by configuration.")
        return
    if _WEB_TERMINAL_RUNNER is not None:
        return
    if aiohttp_web is None:
        logger.warning("RGNODES web terminal is enabled but aiohttp is unavailable; install requirements.txt to enable it.")
        return
    try:
        _token, token_source = _load_web_terminal_secret()
        @aiohttp_web.middleware
        async def _security_middleware(request, handler):
            remote = str(request.remote or "")
            try:
                remote_ip = ipaddress.ip_address(remote.split("%", 1)[0])
                if remote_ip.version == 6 and remote_ip.ipv4_mapped:
                    remote_ip = remote_ip.ipv4_mapped
                if not remote_ip.is_loopback:
                    return aiohttp_web.Response(status=403, text="Loopback access only")
            except ValueError:
                return aiohttp_web.Response(status=403, text="Loopback access only")
            from urllib.parse import urlparse
            host_header = str(request.headers.get("Host", "")).strip().lower()
            domain_host = WEB_TERMINAL_HOST
            domain_port = WEB_TERMINAL_ORIGIN_PORT
            allowed_hosts = {domain_host, f"{domain_host}:{domain_port}"}
            allowed_hosts.update({"localhost", f"localhost:{WEB_TERMINAL_PORT}", "127.0.0.1", f"127.0.0.1:{WEB_TERMINAL_PORT}", "[::1]", f"[::1]:{WEB_TERMINAL_PORT}"})
            if host_header not in allowed_hosts:
                return aiohttp_web.Response(status=421, text="Host not allowed")
            origin = request.headers.get("Origin")
            if origin:
                parsed = urlparse(origin)
                origin_host = (parsed.hostname or "").lower()
                origin_port = parsed.port or (443 if parsed.scheme == "https" else 80)
                domain_origin = parsed.scheme == WEB_TERMINAL_SCHEME and origin_host == WEB_TERMINAL_HOST and origin_port == WEB_TERMINAL_ORIGIN_PORT
                local_origin = parsed.scheme == "http" and origin_host in {"localhost", "127.0.0.1", "::1"} and origin_port == WEB_TERMINAL_PORT
                if not (domain_origin or local_origin):
                    return aiohttp_web.Response(status=403, text="Origin not allowed")
            response = await handler(request)
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["Referrer-Policy"] = "no-referrer"
            response.headers["Cache-Control"] = "no-store"
            websocket_scheme = 'wss' if WEB_TERMINAL_SCHEME == 'https' else 'ws'
            response.headers["Content-Security-Policy"] = (
                "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com; "
                "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://unpkg.com; font-src 'self' data: https://cdn.jsdelivr.net https://unpkg.com; "
                f"connect-src 'self' {websocket_scheme}://{WEB_TERMINAL_HOST} ws://localhost:{WEB_TERMINAL_PORT} ws://127.0.0.1:{WEB_TERMINAL_PORT}; "
                "img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
            )
            return response

        app = aiohttp_web.Application(middlewares=[_security_middleware], client_max_size=16384)
        app.router.add_get("/", _web_terminal_root)
        app.router.add_post("/api/login", _web_terminal_login)
        app.router.add_post("/api/logout", _web_terminal_logout)
        app.router.add_get("/ws", _web_terminal_websocket)
        runner = aiohttp_web.AppRunner(app, access_log=None, shutdown_timeout=3)
        await runner.setup()
        site = aiohttp_web.TCPSite(runner, "127.0.0.1", WEB_TERMINAL_PORT, reuse_address=True)
        await site.start()
        _WEB_TERMINAL_RUNNER = runner
        logger.info("RGNODES™ OpenSSH Terminal listening on loopback port %d; public endpoint %s requires HTTPS reverse proxy.", WEB_TERMINAL_PORT, WEB_TERMINAL_PUBLIC_URL)
        logger.info("Web terminal access token source: %s (token contents are never logged).", token_source)
    except Exception as exc:
        logger.error("RGNODES web terminal did not start (%s). The Discord bot will continue safely.", type(exc).__name__)


@bot.event
async def on_ready():
    global status_task_handle, expiration_task_handle, protection_task_handle, tunnel_repair_task_handle
    global _WEB_TERMINAL_START_TASK
    logger.info(f'{bot.user} has connected to Discord!')
    logger.info(f'{BOT_NAME} Bot is ready!')
    for _guild in list(bot.guilds):
        await refresh_guild_invite_snapshot(_guild)

    if WEB_TERMINAL_ENABLED and _WEB_TERMINAL_RUNNER is None:
        # on_ready can fire more than once during gateway reconnects. Retain the startup
        # task handle so only one coroutine can bind the loopback port at a time.
        if _WEB_TERMINAL_START_TASK is None or _WEB_TERMINAL_START_TASK.done():
            _WEB_TERMINAL_START_TASK = bot.loop.create_task(
                start_web_terminal_server(), name="rgnodes_openssh_web_terminal"
            )

    if status_task_handle is None or status_task_handle.done():
        status_task_handle = bot.loop.create_task(status_presence_task(), name="rgnodes_presence_task")
    if not any(task.get_name() == 'auto_save_task' for task in asyncio.all_tasks()):
        bot.loop.create_task(auto_save_task(), name="auto_save_task")
    if expiration_task_handle is None or expiration_task_handle.done():
        expiration_task_handle = bot.loop.create_task(expiration_monitor_task(), name="rgnodes_expiration_task")
    if protection_task_handle is None or protection_task_handle.done():
        protection_task_handle = bot.loop.create_task(protection_repair_task(), name="rgnodes_protection_task")
    if tunnel_repair_task_handle is None or tunnel_repair_task_handle.done():
        tunnel_repair_task_handle = bot.loop.create_task(tunnel_repair_task(), name="rgnodes_tunnel_repair_task")
    global access_repair_task_handle
    if access_repair_task_handle is None or access_repair_task_handle.done():
        access_repair_task_handle = bot.loop.create_task(access_repair_task(), name="rgnodes_access_repair_task")
    if not any(task.get_name() == "rgnodes_runtime_repair_task" for task in asyncio.all_tasks()):
        bot.loop.create_task(runtime_self_repair_task(), name="rgnodes_runtime_repair_task")
    if not any(task.get_name() == "rgnodes_guest_repair_task" for task in asyncio.all_tasks()):
        bot.loop.create_task(guest_baseline_repair_task(), name="rgnodes_guest_repair_task")
    if not any(task.get_name() == "rgnodes_node_log_health_task" for task in asyncio.all_tasks()):
        bot.loop.create_task(node_log_health_task(), name="rgnodes_node_log_health_task")
    if not any(task.get_name() == "rgnodes_audit_channel_health_task" for task in asyncio.all_tasks()):
        bot.loop.create_task(audit_channel_health_task(), name="rgnodes_audit_channel_health_task")
    if not any(task.get_name() == "rgnodes_bandwidth_accounting_task" for task in asyncio.all_tasks()):
        bot.loop.create_task(bandwidth_accounting_task(), name="rgnodes_bandwidth_accounting_task")
    if RESOURCE_AUTOSCALE_ENABLED and not any(task.get_name() == "rgnodes_adaptive_scaler_task" for task in asyncio.all_tasks()):
        bot.loop.create_task(adaptive_vps_resource_scaler_task(), name="rgnodes_adaptive_scaler_task")
    if _audit_channel_id():
        bot.loop.create_task(record_audit_event("system", "Bot Ready", f"{BOT_NAME} connected • {HOST_PROVIDER_NAME} • {HOST_PROCESSOR_NAME}.", announce=True), name="rgnodes_ready_audit")
    if not any(task.get_name() == "rgnodes_housekeeping_task" for task in asyncio.all_tasks()):
        bot.loop.create_task(resource_housekeeping_task(), name="rgnodes_housekeeping_task")
    if AUTO_CREATE_SERVER_EMOJIS:
        active_task_names = {task.get_name() for task in asyncio.all_tasks()}
        for guild in list(bot.guilds):
            task_name = f"rgnodes_emoji_provision_{guild.id}"
            if task_name not in active_task_names:
                bot.loop.create_task(auto_provision_server_emojis(guild), name=task_name)
                active_task_names.add(task_name)



class RGNODESRateLimitError(commands.CheckFailure):
    def __init__(self, retry_after: int):
        self.retry_after = max(1, int(retry_after))
        super().__init__(f'Rate limit exceeded. Retry in {self.retry_after} seconds.')


async def rgnodes_command_rate_limit(ctx):
    """Per-user token bucket for prefix commands; administrators are exempt."""
    if is_admin_user(ctx.author):
        return True
    uid = int(ctx.author.id)
    now = time.monotonic()
    state = _RATE_LIMIT_STATE.setdefault(uid, {'tokens': float(RATE_LIMIT_BURST), 'updated': now, 'violations': 0.0, 'blocked_until': 0.0})
    if now < state.get('blocked_until', 0.0):
        raise RGNODESRateLimitError(int(state['blocked_until'] - now) + 1)
    elapsed = max(0.0, now - state.get('updated', now))
    state['tokens'] = min(float(RATE_LIMIT_BURST), state.get('tokens', float(RATE_LIMIT_BURST)) + elapsed / RATE_LIMIT_COOLDOWN)
    state['updated'] = now
    if state['tokens'] >= 1.0:
        state['tokens'] -= 1.0
        state['violations'] = max(0.0, state.get('violations', 0.0) - 0.25)
        return True
    state['violations'] = state.get('violations', 0.0) + 1.0
    if state['violations'] >= RATE_LIMIT_MAX_VIOLATIONS:
        state['blocked_until'] = now + RATE_LIMIT_ABUSE_TIMEOUT
        raise RGNODESRateLimitError(RATE_LIMIT_ABUSE_TIMEOUT)
    retry = max(1, int((1.0 - state['tokens']) * RATE_LIMIT_COOLDOWN) + 1)
    raise RGNODESRateLimitError(retry)


@bot.check
async def rgnodes_maintenance_command_gate(ctx):
    if not maintenance_enabled() or is_admin_user(getattr(ctx, "author", None)):
        return True
    name = str(getattr(getattr(ctx, "command", None), "name", "") or "").lower()
    if name in MAINTENANCE_SAFE_COMMANDS:
        return True
    raise RGNODESMaintenanceError()

@bot.event
async def on_guild_join(guild: discord.Guild):
    await refresh_guild_invite_snapshot(guild)
    if AUTO_CREATE_SERVER_EMOJIS:
        try:
            await auto_provision_server_emojis(guild)
        except Exception as exc:
            logger.warning(f"Initial emoji provisioning failed for {guild.name}: {exc}")


@bot.event
async def on_member_join(member: discord.Member):
    """Attribute invite rewards only when exactly one invite gained a use."""
    guild = member.guild
    before = INVITE_USE_CACHE.get(guild.id)
    try:
        invites = await guild.invites()
        after = {str(inv.code): int(inv.uses or 0) for inv in invites}
        INVITE_USE_CACHE[guild.id] = after
        if before is None:
            return
        used = [inv for inv in invites if after.get(str(inv.code), 0) > before.get(str(inv.code), 0)]
        if len(used) != 1:
            return
        inviter = getattr(used[0], "inviter", None)
        if inviter is None or int(inviter.id) == int(member.id):
            return
        change_reward_count(guild.id, inviter.id, "invites", 1,
                            detail=f"Joined member {member.id} via invite {used[0].code}")
    except (discord.Forbidden, discord.HTTPException):
        # Invite tracking needs Manage Server; joining still works when unavailable.
        return
    except Exception as exc:
        logger.warning("Invite reward attribution failed in guild %s: %s", guild.id, type(exc).__name__)


@bot.event
async def on_member_update(before: discord.Member, after: discord.Member):
    had_boost = getattr(before, "premium_since", None) is not None
    has_boost = getattr(after, "premium_since", None) is not None
    if had_boost == has_boost:
        return
    try:
        change_reward_count(after.guild.id, after.id, "boosts", 1 if has_boost else -1,
                            detail="Became a server booster" if has_boost else "Server boost ended")
    except Exception as exc:
        logger.warning("Boost reward accounting failed: %s", type(exc).__name__)


@bot.event
async def on_member_remove(member: discord.Member):
    if getattr(member, "premium_since", None) is not None:
        try:
            change_reward_count(member.guild.id, member.id, "boosts", -1, detail="Booster left the server")
        except Exception as exc:
            logger.warning("Booster departure accounting failed: %s", type(exc).__name__)


bot.add_check(rgnodes_command_rate_limit)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, RGNODESRateLimitError):
        try:
            await ctx.reply(embed=create_warning_embed('Command Cooldown', f'Please slow down and retry in **{error.retry_after} seconds**.'), mention_author=False, delete_after=min(15, error.retry_after))
        except Exception:
            pass
        return
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(embed=create_error_embed("Missing Argument", f"Please check command usage with `{PREFIX}help`."))
    elif isinstance(error, commands.BadArgument):
        await ctx.send(embed=create_error_embed("Invalid Argument", "Please check your input and try again."))
    elif isinstance(error, commands.CommandInvokeError) and isinstance(error.original, asyncio.TimeoutError):
        await ctx.send(embed=create_warning_embed("⏱️ Operation Timed Out", "The interactive setup wizard expired after 3 minutes. No new VPS/node was created by the timed-out prompt."))
    elif isinstance(error, RGNODESMaintenanceError):
        await ctx.send(embed=create_error_embed("🔶 Under Maintenance", "🔶 **Under Maintenance**\n🛠️ **Service maintenance in progress**\n\nNormal user VPS actions are temporarily unavailable. Administrators remain fully operational."))
    elif isinstance(error, commands.BotMissingPermissions):
        missing = ", ".join(str(p).replace('_', ' ').title() for p in getattr(error, "missing_permissions", [])[:10]) or "required Discord permissions"
        await ctx.send(embed=create_error_embed("🛡️ Bot Permission Missing", f"I need: **{missing}** in this channel/server. Use `{PREFIX}permissions` to audit the current channel."))
    elif isinstance(error, commands.MissingPermissions):
        missing = ", ".join(str(p).replace('_', ' ').title() for p in getattr(error, "missing_permissions", [])[:10]) or "required permissions"
        await ctx.send(embed=create_error_embed("🛡️ Permission Denied", f"Your Discord account is missing: **{missing}**."))
    elif isinstance(error, commands.NoPrivateMessage):
        await ctx.send(embed=create_error_embed("Server Only", "This command must be used inside a Discord server."))
    elif isinstance(error, commands.CommandOnCooldown):
        await ctx.send(embed=create_warning_embed("⏳ Slow Down", f"Please wait **{error.retry_after:.1f}s** before using this command again."))
    elif isinstance(error, commands.MaxConcurrencyReached):
        await ctx.send(embed=create_warning_embed("⏳ Operation Busy", "This action is already running. Please wait for the current operation to finish."))
    elif isinstance(error, commands.DisabledCommand):
        await ctx.send(embed=create_warning_embed("Command Disabled", "This command is temporarily disabled."))
    elif isinstance(error, commands.CheckFailure):
        error_msg = str(error) if str(error) else "You need RGNODES admin access or the required permission to use this command."
        await ctx.send(embed=create_error_embed("Access Denied", error_msg))
    elif isinstance(error, discord.NotFound):
        await ctx.send(embed=create_error_embed("Error", "The requested resource was not found. Please try again."))
    else:
        command_name = getattr(getattr(ctx, 'command', None), 'qualified_name', 'unknown')
        error_type = type(error.original if isinstance(error, commands.CommandInvokeError) else error).__name__
        # Exception strings may contain private tunnel URLs, API payloads, or credentials.
        # Keep channel-visible audit data generic; do not echo exception text to Discord.
        logger.error("Command error in %s (%s)", command_name, error_type)
        try:
            await record_audit_event(
                "error", f"Command Failed • {command_name}",
                f"The command failed with {error_type}. Detailed exception text was suppressed to protect secrets.",
                user_id=getattr(ctx.author, 'id', None), announce=True
            )
        except Exception:
            pass
        await ctx.send(embed=create_error_embed(
            "⚠️ Command Failed",
            "The command could not be completed. Please try again; the incident was logged automatically. Sensitive technical details are hidden."
        ))

# Bot commands

@bot.command(name='ping')
async def ping(ctx, node_name: str = None):
    """Check bot latency or a named node's API response."""
    if node_name:
        node = next((n for n in get_nodes() if str(n.get('id')) == str(node_name) or str(n.get('name', '')).lower() == str(node_name).lower()), None)
        if not node:
            await ctx.send(embed=create_error_embed("Node Not Found", f"No node matches `{node_name}`.")); return
        started = time.perf_counter()
        status = await get_node_status(int(node['id']))
        elapsed_ms = round((time.perf_counter() - started) * 1000)
        embed = create_info_embed(f"🌐 Node Ping • {node['name']}", f"**Node:** `{node['name']}` (`{node['id']}`)\n**Status:** {status}\n**API response:** `{elapsed_ms} ms` (includes network round-trip)")
        await ctx.send(embed=embed)
        return
    latency = round(bot.latency * 1000)
    embed = create_success_embed("🏓 Pinged!", "Bot is responding.")
    add_field(embed, "Latency", f"`{latency}ms`", inline=True)
    add_field(embed, "Status", "✅ Online", inline=True)
    add_field(embed, "Bot", f"`{BOT_NAME} v{BOT_VERSION}`", inline=True)
    await ctx.send(embed=embed)

@bot.command(name='uptime')
async def uptime(ctx, node_name: str = None):
    if not node_name:
        await ctx.send(embed=create_info_embed("Host Uptime", get_uptime()))
        return
    node = next((n for n in get_nodes() if str(n.get('id')) == str(node_name) or str(n.get('name', '')).lower() == str(node_name).lower()), None)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"No node matches `{node_name}`.")); return
    if node.get('is_local'):
        uptime_text = get_uptime()
    else:
        # The current authenticated remote-agent API does not expose a verified
        # host-uptime field; avoid substituting bot uptime or guessing.
        status = await get_node_status(int(node['id']))
        uptime_text = f"Remote node is reachable ({status}), but its current agent API does not expose host uptime."
    await ctx.send(embed=create_info_embed(f"⏱️ Node Uptime • {node['name']}", uptime_text))

@bot.command(name='thresholds')
@is_admin()
async def thresholds(ctx):
    embed = create_info_embed("Resource Thresholds", f"**CPU:** {CPU_THRESHOLD}%\n**RAM:** {RAM_THRESHOLD}%")
    await ctx.send(embed=embed)

@bot.command(name='set-threshold')
@is_admin()
async def set_threshold(ctx, cpu: int, ram: int):
    global CPU_THRESHOLD, RAM_THRESHOLD
    if not (0 <= cpu <= 100 and 0 <= ram <= 100):
        await ctx.send(embed=create_error_embed("Invalid Thresholds", "CPU and RAM thresholds must be between 0 and 100."))
        return
    CPU_THRESHOLD = cpu
    RAM_THRESHOLD = ram
    set_setting('cpu_threshold', str(cpu))
    set_setting('ram_threshold', str(ram))
    embed = create_success_embed("Thresholds Updated", f"**CPU:** {cpu}%\n**RAM:** {ram}%")
    await ctx.send(embed=embed)

@bot.command(name='set-status')
@is_admin()
async def set_status(ctx, activity_type: str, *, name: str):
    types = {
        'playing': discord.ActivityType.playing,
        'watching': discord.ActivityType.watching,
        'listening': discord.ActivityType.listening,
        'streaming': discord.ActivityType.streaming,
    }
    if activity_type.lower() not in types:
        await ctx.send(embed=create_error_embed("Invalid Type", "Valid types: playing, watching, listening, streaming"))
        return
    await bot.change_presence(activity=discord.Activity(type=types[activity_type.lower()], name=name))
    embed = create_success_embed("Status Updated", f"Set to {activity_type}: {name}")
    await ctx.send(embed=embed)

@bot.command(name="myvps")
async def my_vps(ctx):
    user_id = str(ctx.author.id)
    vps_list = vps_data.get(user_id, [])

    # ─── No VPS Case ───────────────────────────────────────────
    if not vps_list:
        embed = create_error_embed(
            "❌ No VPS Found",
            f"You don’t have any **{BOT_NAME} VPS** yet."
        )
        embed.add_field(
            name="🚀 Quick Actions",
            value=(
                f"• `{PREFIX}Deploy` Create Your Free VPS\n"
                f"• Contact an admin to request a VPS For Extra Resources"
            ),
            inline=False
        )
        await ctx.send(embed=embed)
        return

    # ─── Embed ────────────────────────────────────────────────
    embed = create_info_embed(
        title="🖥️ My VPS Dashboard",
        description="Your personal VPS overview"
    )

    total_vps = len(vps_list)
    running = suspended = whitelisted = 0
    vps_cards = []

    # ─── VPS Processing ───────────────────────────────────────
    for i, vps in enumerate(vps_list, start=1):
        node = get_node(vps.get("node_id"))
        node_name = node["name"] if node else "Unknown"

        config = vps.get("config", "Custom")
        ram = vps.get("ram", "0GB")
        cpu = vps.get("cpu", "0")
        storage = vps.get("storage", "0GB")

        if vps.get("suspended"):
            status = "⛔ SUSPENDED"
            suspended += 1
        elif vps.get("status") == "running":
            status = "🟢 RUNNING"
            running += 1
        else:
            status = "🔴 STOPPED"

        if vps.get("whitelisted"):
            whitelisted += 1

        # Build VPS card
        card = (
            f"**{i}.** `{vps['container_name']}`\n"
            f"{status} • `{config}`\n"
            f"⚙️ `{ram}` RAM • `{cpu}` CPU • `{storage}` Disk\n"
            f"📍 Node: `{node_name}`"
        )
        
        # Add expiration info if set
        if vps.get('expiration_date'):
            expiration_dt = datetime.fromisoformat(vps['expiration_date'])
            days_remaining = (expiration_dt - datetime.now()).days
            
            if days_remaining < 0:
                expiration_badge = "🔴 EXPIRED"
            elif days_remaining <= EXPIRATION_WARNING_DAYS:
                expiration_badge = "🟡 EXPIRING"
            else:
                expiration_badge = "🟢 ACTIVE"
            
            card += f"\n⏰ {expiration_badge} • Expires: `{expiration_dt.strftime('%Y-%m-%d')}`"
        
        vps_cards.append(card)

    # ─── Row 1 : Summary ──────────────────────────────────────
    embed.add_field(
        name="📊 Summary",
        value=(
            f"🖥️ `{total_vps}` VPS\n"
            f"🟢 `{running}` Running\n"
            f"⛔ `{suspended}` Suspended\n"
            f"✅ `{whitelisted}` Whitelisted"
        ),
        inline=True
    )

    embed.add_field(
        name="⚡ Quick Actions",
        value=(
            f"`{PREFIX}manage`\n"
            f"`{PREFIX}reinstall`\n"
            f"`{PREFIX}status`"
        ),
        inline=True
    )

    embed.add_field(
        name="🧭 Tip",
        value="Use **manage** to control your VPS",
        inline=True
    )

    # ─── VPS Cards (Full Width) ───────────────────────────────
    vps_text = "\n\n".join(vps_cards)
    for i in range(0, len(vps_text), 1024):
        embed.add_field(
            name="🖥️ Your VPS",
            value=vps_text[i:i + 1024],
            inline=False
        )

    embed.set_footer(text=f"⚡ RGNODES™ • VPS Controller")
    embed.timestamp = ctx.message.created_at

    await ctx.send(embed=embed)



class DeployTypeView(RGNODESView):
    """Choose a KVM VPS or a KVM VM with Docker Engine installed in its guest."""
    def __init__(self, user: discord.Member, ctx, expiry_days: int = None, ram: int = None, cpu: int = None, disk: int = None):
        super().__init__(timeout=300)
        self.user, self.ctx = user, ctx
        self.ram = max(1, int(ram if ram is not None else DEFAULT_VPS_RAM_GB))
        self.cpu = max(1, int(cpu if cpu is not None else DEFAULT_VPS_CPU))
        self.disk = max(VPS_MIN_DISK_GB, int(disk if disk is not None else DEFAULT_VPS_STORAGE_GB))
        self.expiry_days = expiry_days if expiry_days and expiry_days > 0 else DEFAULT_VPS_EXPIRATION_DAYS
        self.select = discord.ui.Select(
            placeholder="Choose your VPS type", min_values=1, max_values=1, row=0,
            options=[discord.SelectOption(label="KVM VPS", value="KVM", description="Full virtual machine running on KVM/QEMU", emoji="🖥️")]
            + ([discord.SelectOption(label="Docker VPS", value="DOCKER", description="KVM virtual machine with Docker Engine installed and verified", emoji="🐳")] if DOCKER_VPS_ENABLED else []),
        )
        self.select.callback = self.select_type
        self.add_item(self.select)

    async def select_type(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the command author can use this deployment selector."), ephemeral=True)
            return
        if user_has_vps(self.user.id):
            await interaction.response.send_message(embed=create_error_embed("VPS Limit Reached", f"{self.user.mention} already has a VPS. Limit: 1."), ephemeral=True)
            return
        product_type = str(self.select.values[0]).strip().upper()
        if product_type not in {"KVM", "DOCKER"} or (product_type == "DOCKER" and not DOCKER_VPS_ENABLED):
            await interaction.response.send_message(embed=create_error_embed("Invalid VPS Type", "That VPS type is disabled or unsupported. Choose an available product."), ephemeral=True)
            return
        self.select.disabled = True
        type_label = "Docker VPS" if product_type == "DOCKER" else "KVM VPS"
        docker_note = (
            "Docker Engine will be installed and its daemon must pass live verification before deployment succeeds."
            if product_type == "DOCKER"
            else f"Guest Docker follows DOCKER_INSTALL_ON_DEPLOY ({'enabled' if DOCKER_INSTALL_ON_DEPLOY else 'disabled'})."
        )
        embed = create_info_embed(
            f"{':docker:' if product_type == 'DOCKER' else '🖥️'} {type_label} Deployment",
            f"**Provider:** {HOST_PROVIDER_NAME}\n**Virtualization:** KVM/QEMU/libvirt\n**Product:** {type_label}\n"
            f"**Network:** NAT or configured routed/bridge mode\n"
            f"**Default plan:** {self.ram} GB RAM • {self.cpu} CPU • {self.disk} GB disk\n"
            f"**Maximum plan:** {self.ram} GB RAM • {self.cpu} CPU • {self.disk} GB disk\n\n"
            f"{docker_note}\nSelect a node, then choose an operating system. Capacity is checked before provisioning.",
        )
        await interaction.response.edit_message(
            embed=embed,
            view=NodeSelectView(self.ram, self.cpu, self.disk,
                                self.user, self.ctx, self.expiry_days, product_type=product_type),
        )


class NodeSelectView(RGNODESView):
    PAGE_SIZE = 25

    def __init__(self, ram: int, cpu: int, disk: int, user: discord.Member, ctx,
                 expiry_days: int = None, page: int = 0, product_type: str = "KVM"):
        super().__init__(timeout=300)
        self.ram, self.cpu, self.disk = ram, cpu, disk
        self.user, self.ctx = user, ctx
        self.product_type = str(product_type or "KVM").strip().upper()
        if self.product_type not in {"KVM", "DOCKER"}:
            self.product_type = "KVM"
        self.expiry_days = expiry_days if expiry_days and expiry_days > 0 else DEFAULT_VPS_EXPIRATION_DAYS
        self.page = max(0, int(page))
        self.nodes = []
        self.total_pages = 1
        self._refresh_nodes()
        self._build()

    def _refresh_nodes(self):
        nodes = []
        raw_nodes = get_nodes()
        local_ready = _local_kvm_ready() if any(bool(n.get('is_local')) for n in raw_nodes) else False
        for n in raw_nodes:
            try:
                node_id = int(n["id"])
                capacity = max(0, int(n.get("total_vps") or 0))
            except (TypeError, ValueError, KeyError):
                continue
            if bool(n.get('is_local')) and not local_ready:
                continue
            available = max(0, capacity - get_current_vps_count(node_id))
            if available > 0:
                nodes.append((n, available))

        def node_score(item):
            n = item[0]
            node_id = int(n.get('id') or 0)
            name = str(n.get('name') or '').lower().replace('_', ' ').replace('-', ' ')
            location = str(n.get('location') or '').lower()
            preferred = DEFAULT_NODE_ID > 0 and node_id == DEFAULT_NODE_ID
            local_first = bool(n.get('is_local'))
            node1 = name.split() in (['node', '1'], ['node', '01'])
            singapore = 'singapore' in location or 'asia/singapore' in location
            return (0 if preferred else 1, 0 if local_first else 1, 0 if node1 else 1, 0 if singapore else 1, node_id)

        nodes.sort(key=node_score)
        self.nodes = nodes
        self.total_pages = max(1, (len(nodes) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        self.page = min(self.page, self.total_pages - 1)

    def _build(self):
        self.clear_items()
        items = self.nodes[self.page * self.PAGE_SIZE:(self.page + 1) * self.PAGE_SIZE]
        options = []
        for n, available in items:
            loc = str(n.get("location") or "Unknown")
            prefix = "📍" if n.get("is_local") else "🌐"
            options.append(discord.SelectOption(label=f"{str(n.get('name') or 'Node')[:70]} {prefix}",
                                                value=str(n["id"]),
                                                description=f"{loc[:50]} • {available} slots"[:100]))
        if not options:
            self.add_item(discord.ui.Select(
                placeholder="No ready nodes", disabled=True,
                options=[discord.SelectOption(label="No ready KVM node available", value="none",
                                              description="Check local KVM/libvirt or register a remote KVM node")]))
            return
        self.select = discord.ui.Select(placeholder=f"Select Node • {self.page + 1}/{self.total_pages}",
                                        min_values=1, max_values=1, options=options, row=0)
        self.select.callback = self.select_node
        self.add_item(self.select)
        if self.total_pages > 1:
            prev = discord.ui.Button(label="Previous", emoji="◀️", style=discord.ButtonStyle.secondary,
                                     disabled=self.page == 0, row=1)
            nxt = discord.ui.Button(label="Next", emoji="▶️", style=discord.ButtonStyle.secondary,
                                    disabled=self.page >= self.total_pages - 1, row=1)
            prev.callback = self.previous_page
            nxt.callback = self.next_page
            self.add_item(prev)
            self.add_item(nxt)

    async def _move_page(self, interaction: discord.Interaction, page: int):
        if str(interaction.user.id) != str(self.ctx.author.id):
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the command author can use this selector."), ephemeral=True)
            return
        self.page = page
        self._refresh_nodes()
        self._build()
        await interaction.response.edit_message(view=self)

    async def previous_page(self, interaction: discord.Interaction):
        await self._move_page(interaction, self.page - 1)

    async def next_page(self, interaction: discord.Interaction):
        await self._move_page(interaction, self.page + 1)

    async def select_node(self, interaction: discord.Interaction):
        if str(interaction.user.id) != str(self.ctx.author.id):
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the command author can select a node."), ephemeral=True)
            return
        try:
            node_id = int(self.select.values[0])
        except (TypeError, ValueError, IndexError):
            await interaction.response.send_message(embed=create_error_embed("Invalid Node", "Select a valid available KVM node."), ephemeral=True)
            return
        self.select.disabled = True
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            self.ram, self.cpu, self.disk, fit_reason = await auto_fit_vps_resources(node_id, self.ram, self.cpu, self.disk)
            if not self.ram or not self.cpu:
                raise RuntimeError(fit_reason or "No valid resource allocation is available on this node.")
            ok, reason = await check_node_capacity_for_vps(node_id, self.ram, self.cpu, self.disk)
            if not ok:
                raise RuntimeError(reason or "The selected node does not have sufficient free capacity.")
            node = get_node(node_id) or {}
            try:
                await interaction.message.edit(
                    embed=create_info_embed("Node Selected", f"Node **{node.get('name', node_id)}** passed capacity checks. Continue in your private OS selector."),
                    view=None, allowed_mentions=discord.AllowedMentions.none())
            except (discord.NotFound, discord.Forbidden, discord.HTTPException) as message_exc:
                logger.warning("Could not retire node selector for node %s: %s", node_id, type(message_exc).__name__)
            type_label = "Docker VPS" if self.product_type == "DOCKER" else "KVM VPS"
            selector_embed = create_info_embed(
                "💿 Select Operating System",
                f"**Product:** {type_label}\n**Node:** {node.get('name', node_id)}\n**Capacity check:** PASSED\n"
                f"{fit_reason}\n{reason}\n\nChoose a supported image, then press Deploy.",)
            view = OSSelectView(self.ram, self.cpu, self.disk, self.user, self.ctx, node_id,
                                self.expiry_days, product_type=self.product_type)
            await interaction.edit_original_response(embed=selector_embed, view=view)
        except Exception as exc:
            self.select.disabled = False
            logger.warning("Node preflight failed for %s: %s", node_id, exc, exc_info=True)
            try:
                await interaction.message.edit(view=self)
            except Exception:
                pass
            await interaction.edit_original_response(
                embed=create_error_embed("Node Preflight Failed", safe_error_summary("Node selection", exc)),
                view=None,
            )


class OSSelectView(RGNODESView):
    def __init__(self, ram: int, cpu: int, disk: int, user: discord.Member, ctx,
                 node_id: int, expiry_days: int = None, product_type: str = "KVM"):
        super().__init__(timeout=300)
        self.ram, self.cpu, self.disk = ram, cpu, disk
        self.user, self.ctx = user, ctx
        self.node_id = int(node_id)
        self.product_type = str(product_type or "KVM").strip().upper()
        if self.product_type not in {"KVM", "DOCKER"}:
            self.product_type = "KVM"
        self.expiry_days = expiry_days if expiry_days and expiry_days > 0 else DEFAULT_VPS_EXPIRATION_DAYS
        self.selected_os = None
        self.select = discord.ui.Select(
            placeholder="Select an OS for the VPS", min_values=1, max_values=1,
            options=[discord.SelectOption(label=o["label"], value=o["value"], emoji=os_option_emoji(o)) for o in OS_OPTIONS])
        self.select.callback = self.select_os
        self.add_item(self.select)
        self.deploy_button = discord.ui.Button(
            label="Deploy Docker VPS" if self.product_type == "DOCKER" else "Deploy KVM VPS",
            emoji="🐳" if self.product_type == "DOCKER" else "🚀",
            style=discord.ButtonStyle.success, disabled=True, row=1)
        self.deploy_button.callback = self.deploy_selected
        self.add_item(self.deploy_button)

    async def select_os(self, interaction: discord.Interaction):
        if str(interaction.user.id) != str(self.ctx.author.id):
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the command author can select an operating system."), ephemeral=True)
            return
        selected = str(self.select.values[0]).strip().lower()
        valid_os_values = {str(option["value"]).strip().lower() for option in OS_OPTIONS}
        if selected not in valid_os_values:
            await interaction.response.send_message(embed=create_error_embed("Unsupported OS", "That operating-system option is no longer supported. Reopen the menu and select a listed image."), ephemeral=True)
            return
        try:
            selected = await resolve_vps_image(selected, self.node_id)
        except Exception as exc:
            logger.warning("OS selector rejected %r for node %s: %s", selected, self.node_id, exc)
            await interaction.response.send_message(
                embed=create_error_embed("OS Image Unavailable", safe_error_summary("Operating-system selection", exc)),
                ephemeral=True,
            )
            return
        self.selected_os = selected
        self.select.disabled = True
        self.deploy_button.disabled = False
        node = get_node(self.node_id) or {}
        type_label = "Docker VPS" if self.product_type == "DOCKER" else "KVM VPS"
        os_label = friendly_os_label(selected)
        embed = create_info_embed(
            "🚀 Confirm VPS Deployment",
            f"**Product:** {type_label}\n**Node:** {node.get('name', self.node_id)}\n**OS:** {os_label}\n"
            f"**Plan:** {self.ram} GB RAM • {self.cpu} CPU core(s) • {self.disk} GB SSD\n"
            f"**Hostname:** `{VPS_HOSTNAME}`\n**Expiration:** {self.expiry_days} days\n\nPress Deploy to begin.")
        await interaction.response.edit_message(embed=embed, view=self)

    async def deploy_selected(self, interaction: discord.Interaction):
        if str(interaction.user.id) != str(self.ctx.author.id):
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the command author can deploy this VPS."), ephemeral=True)
            return
        if not self.selected_os:
            await interaction.response.send_message(embed=create_warning_embed("OS Required", "Select an operating system before deploying."), ephemeral=True)
            return
        user_id = str(self.user.id)
        if maintenance_enabled() and not is_admin_user(interaction.user):
            await interaction.response.send_message(embed=create_warning_embed("Under Maintenance", "VPS deployment is temporarily disabled."), ephemeral=True)
            return
        policy_error = public_vps_access_error(self.user, admin_override=is_admin_user(interaction.user))
        if policy_error:
            await interaction.response.send_message(embed=create_warning_embed("Public VPS Unavailable", policy_error), ephemeral=True)
            return
        if user_has_vps(user_id):
            await interaction.response.send_message(embed=create_error_embed("VPS Limit Reached", f"This account already owns {PUBLIC_VPS_MAX_PER_USER} VPS (public plan limit)."), ephemeral=True)
            return
        if user_id in ACTIVE_DEPLOYMENTS:
            await interaction.response.send_message(embed=create_warning_embed("Deployment Already Running", "A VPS deployment for this account is already in progress."), ephemeral=True)
            return

        # Acknowledge first; node serialization can wait longer than Discord's interaction deadline.
        await interaction.response.defer(ephemeral=True, thinking=True)
        self.select.disabled = True
        self.deploy_button.disabled = True
        try:
            await interaction.message.edit(view=self)
        except Exception:
            pass
        ACTIVE_DEPLOYMENTS.add(user_id)
        node_lock = _get_deploy_node_lock(self.node_id) if DEPLOY_NODE_SERIALIZE else None
        node_lock_acquired = False
        try:
            if node_lock is not None:
                await interaction.edit_original_response(
                    embed=create_info_embed("Deployment Queued", "Waiting for the selected node to finish its current deployment."),
                    view=None)
                # Bound queue time so the deferred Discord interaction remains valid
                # and users are not left waiting forever behind a stalled deployment.
                await asyncio.wait_for(node_lock.acquire(), timeout=540)
                node_lock_acquired = True
        except asyncio.CancelledError:
            ACTIVE_DEPLOYMENTS.discard(user_id)
            raise
        except Exception as lock_exc:
            ACTIVE_DEPLOYMENTS.discard(user_id)
            await interaction.edit_original_response(
                embed=create_error_embed("Deployment Queue Failed", safe_error_summary("Node deployment queue", lock_exc)),
                view=None)
            return

        os_version = self.selected_os
        type_label = "Docker VPS" if self.product_type == "DOCKER" else "KVM VPS"
        creating_embed = create_info_embed(
            f"Creating {type_label}",
            f"Deploying **{friendly_os_label(os_version)}** for {self.user.mention} on node {self.node_id}.\n"
            "Progress will be posted in this channel. Credentials will be sent privately.")
        progress_message = None
        try:
            await interaction.edit_original_response(
                embed=create_info_embed("Deployment Started", "Your deployment has started. Follow the progress message in this channel."),
                view=None)
            progress_message = await self.ctx.send(embed=creating_embed, allowed_mentions=discord.AllowedMentions.none())
        except Exception:
            ACTIVE_DEPLOYMENTS.discard(user_id)
            if node_lock_acquired and node_lock is not None and node_lock.locked():
                node_lock.release()
            raise

# Reserve a concurrency-safe persistent VPS ID inside the protected lifecycle so
        # even database/ID-reservation failures release the per-user and per-node locks.
        global_vps_id = None
        container_name = None
        ram_mb = self.ram * 1024
        container_created = False
        record_persisted = False
        try:
            global_vps_id = await run_deployment_stage(
                progress_message, 0, "Reserve a unique, persistent VPS ID before touching node resources.",
                lambda: asyncio.to_thread(reserve_vps_vmid), "rgnodes-vps-pending",
            )
            container_name = f"rgnodes-vps-{global_vps_id}"

            async def _deployment_preflight():
                health = await execute_vpsctl_compat("", "health", node_id=self.node_id, timeout=45)
                if not isinstance(health, dict) or str(health.get("status", "")).lower() != "ok":
                    raise RuntimeError("KVM/QEMU readiness check did not return a verified healthy status.")
                if not all(bool(health.get(key)) for key in ("kvm_device", "virsh_available", "qemu_img_available")):
                    raise RuntimeError("KVM node preflight failed: /dev/kvm, virsh, or qemu-img is unavailable.")
                if str(health.get('network_mode') or '').lower() == 'nat' and not bool(health.get('nat_port_forwarding_available')):
                    raise RuntimeError('KVM NAT mode is selected but iptables port forwarding is unavailable on the node.')
                capacity_ok, capacity_reason = await check_node_capacity_for_vps(self.node_id, self.ram, self.cpu, self.disk)
                if not capacity_ok:
                    raise RuntimeError(capacity_reason)
                resolved = await resolve_vps_image(os_version, self.node_id)
                return resolved, capacity_reason, health

            resolved_os, capacity_reason, kvm_health = await run_deployment_stage(
                progress_message, 1,
                f"Checking KVM/QEMU/libvirt, node reachability, resource reserves, and OS image readiness for `{container_name}`.",
                _deployment_preflight, container_name,
            )
            storage_pool = DEFAULT_STORAGE_POOL

            async def _create_container():
                return await execute_vpsctl_compat(
                    container_name,
                    f"init {shlex.quote(resolved_os)} {container_name} -s {shlex.quote(storage_pool)} --ram {self.ram} --cpu {self.cpu} --disk {self.disk}",
                    node_id=self.node_id, timeout=DEPLOY_EXECUTION_TIMEOUT,
                )

            await run_deployment_stage(
                progress_message, 2,
                f"Creating the KVM virtual machine from `{resolved_os}` with requested RAM/CPU/disk limits.",
                _create_container, container_name,
            )
            os_version = resolved_os
            container_created = True

            async def _apply_resources():
                await apply_vps_performance_profile(container_name, self.node_id, ram_mb, self.cpu)
                return await apply_vps_vm_config(container_name, self.node_id)

            await run_deployment_stage(
                progress_message, 3,
                f"Applying hard resource limits: {self.ram} GB RAM · {self.cpu} CPU · {self.disk} GB disk.",
                _apply_resources, container_name,
            )
            async def _boot_guest():
                await execute_vpsctl_compat(container_name, f"start {shlex.quote(container_name)}", node_id=self.node_id, timeout=180)
                await wait_for_guest_agent(container_name, self.node_id, GUEST_BOOTSTRAP_TIMEOUT)
                await apply_internal_permissions(container_name, self.node_id)
                return True

            await run_deployment_stage(
                progress_message, 4,
                "Booting the virtual machine, waiting for QEMU Guest Agent, and applying safe guest permissions.",
                _boot_guest, container_name,
            )

            await run_deployment_stage(
                progress_message, 5,
                "Applying the RGNODES hostname, guest MOTD, base protection, and OS baseline after the guest agent is ready.",
                lambda: safe_guest_install(container_name, self.node_id), container_name,
            )

            docker_required = self.product_type == "DOCKER" or DOCKER_INSTALL_ON_DEPLOY
            docker_strict = self.product_type == "DOCKER" or DOCKER_STRICT_DEPLOY

            async def _ensure_docker():
                if not docker_required:
                    return False
                return await ensure_docker_ready(container_name, self.node_id, strict=docker_strict)

            docker_ready = await run_deployment_stage(
                progress_message, 6,
                "Installing/verifying Docker inside the running guest. Strict mode controls whether an unavailable daemon blocks deployment.",
                _ensure_docker, container_name,
            )
            if docker_required and not docker_ready:
                logger.warning("Docker is not verified ready for %s; the guest repair loop will retry.", container_name)

            async def _repair_systemctl():
                probe = await _exec_guest_bash(
                    container_name, self.node_id,
                    "if [ -f /etc/alpine-release ] && command -v rc-service >/dev/null 2>&1; then rc-service sshd status >/dev/null 2>&1 || rc-service sshd start >/dev/null 2>&1 || true; printf 'OPENRC_OK\n'; elif command -v systemctl >/dev/null 2>&1; then systemctl daemon-reload >/dev/null 2>&1 || true; printf 'SYSTEMCTL_OK\n'; else printf 'SERVICE_MANAGER_MISSING\n'; fi",
                    timeout=25,
                )
                if "SERVICE_MANAGER_MISSING" in str(probe):
                    await bootstrap_vps_guest(container_name, self.node_id)
                    probe = await _exec_guest_bash(
                        container_name, self.node_id,
                        "if [ -f /etc/alpine-release ] && command -v rc-service >/dev/null 2>&1; then printf 'OPENRC_OK\n'; elif command -v systemctl >/dev/null 2>&1; then printf 'SYSTEMCTL_OK\n'; else printf 'SERVICE_MANAGER_MISSING\n'; fi",
                        timeout=25,
                    )
                if not any(marker in str(probe) for marker in ("SYSTEMCTL_OK", "OPENRC_OK")):
                    raise RuntimeError("Neither systemd nor OpenRC was available after the guest baseline repair attempt.")
                return str(probe).strip()[-120:]

            await run_deployment_stage(
                progress_message, 7,
                "Checking the guest service manager and refreshing systemd state; missing baseline packages trigger an OS-aware repair.",
                _repair_systemctl, container_name,
            )
            # SSH port allocation and the tunnel launch happen after the safe database record exists.
            # The database stage is intentionally early so restarts can recover a VM after a transient access failure.
            await send_progress(
                progress_message, DEPLOYMENT_STAGES[8], 8, len(DEPLOYMENT_STAGES),
                "Persisting the VPS owner, unique ID, OS, RAM/CPU/disk limits, expiry, and recovery metadata.",
                active_index=8, frame=0, vps_name=container_name,
            )
            # Generate strong password
            root_password = generate_strong_password()
            
            # Persist the VPS before optional/slow guest access setup. A transient SSH
            # package/mirror problem must never destroy an otherwise healthy container.
            type_label = "Docker VPS" if self.product_type == "DOCKER" else "KVM VPS"
            config_str = f"{type_label} / {self.ram}GB RAM / {self.cpu} CPU / {self.disk}GB Disk"
            vps_info = {
                "product_type": self.product_type,
                "container_name": container_name,
                "node_id": self.node_id,
                "ram": f"{self.ram}GB",
                "cpu": str(self.cpu),
                "storage": f"{self.disk}GB",
                "config": config_str,
                "os_version": os_version,
                "status": "running",
                "suspended": False,
                "whitelisted": False,
                "suspension_history": [],
                "created_at": datetime.now().isoformat(),
                "shared_with": [],
                "expiration_date": (datetime.now() + timedelta(days=self.expiry_days)).isoformat(),
                "root_password": root_password,
                "bandwidth_gb": VPS_BANDWIDTH_GB,
                "bandwidth_used_bytes": 0,
                "bandwidth_cycle_start": datetime.now().isoformat(),
                "id": None,
                "vmid": global_vps_id,
                "ssh_ready": False,
                "pinggy_host": None,
                "pinggy_port": None,
                "pinggy_url": None
            }
            logger.info(f"🆕 Creating VPS object: {vps_info['container_name']} for user {user_id}")
            if user_id not in vps_data:
                vps_data[user_id] = []
                logger.info(f"   Created new user entry in vps_data for {user_id}")
            vps_data[user_id].append(vps_info)
            logger.info(f"   ✅ VPS added to vps_data. Total VPS for user: {len(vps_data[user_id])}")
            logger.info(f"   Total users in vps_data: {len(vps_data)}")
            
            # Allocate 1 default port per user for SSH access
            try:
                with DB_LOCK:
                    conn = get_db()
                    # Check if user already has port allocation
                    existing = conn.execute(
                        "SELECT allocated_ports FROM port_allocations WHERE user_id = ?",
                        (str(user_id),)
                    ).fetchone()
                    
                    if not existing:
                        # Give each new user the configured forwarding quota.
                        conn.execute(
                            "INSERT INTO port_allocations (user_id, allocated_ports, last_modified) VALUES (?, ?, CURRENT_TIMESTAMP)",
                            (str(user_id), DEFAULT_PORT_QUOTA)
                        )
                        conn.commit()
                        logger.info(f"   ✅ Allocated {DEFAULT_PORT_QUOTA} default port slots for user {user_id}")
                    conn.close()
            except Exception as e:
                logger.warning(f"Could not allocate port for user {user_id}: {e}")
            
            try:
                save_vps_data_immediate()
            except Exception as persist_error:
                raise RuntimeError(
                    f"VPS was created, but its database record could not be persisted safely: {persist_error}"
                ) from persist_error
            record_persisted = True
            logger.info(f"   ✅ VPS database record persisted")
            await record_audit_event(
                "vps", "VPS Created",
                f"Created `{container_name}` • {os_version} • {self.ram}GB RAM • {self.cpu} CPU • {self.disk}GB disk • {VPS_BANDWIDTH_GB}GB bandwidth.",
                user_id=user_id, node_id=self.node_id, vps_container=container_name
            )
            await send_progress(
                progress_message, DEPLOYMENT_STAGES[8], 9, len(DEPLOYMENT_STAGES),
                "✅ VPS owner, identity, CPU/RAM/disk plan, and recovery metadata are persisted. Continuing with access setup.",
                active_index=9, frame=1, vps_name=container_name,
            )

            # Guest SSH setup is best-effort after persistence. access_repair_task will retry
            # only when ssh_ready is false, preventing a slow package mirror from causing
            # the earlier 120-second 'Creation Failed' behavior.
            async def _configure_ssh_best_effort():
                try:
                    return await configure_ssh(container_name, self.node_id, root_password)
                except Exception as ssh_setup_exc:
                    logger.warning("SSH setup deferred for %s: %s", container_name, type(ssh_setup_exc).__name__)
                    return False, type(ssh_setup_exc).__name__

            try:
                success, result = await run_deployment_stage(
                    progress_message, 9,
                    "Installing/verifying OpenSSH, setting the generated root password, and applying secure SSH configuration.",
                    _configure_ssh_best_effort, container_name,
                )
                vps_info["ssh_ready"] = bool(success)
                if success:
                    try:
                        await apply_guest_motd(container_name, self.node_id)
                    except Exception as motd_exc:
                        logger.debug("Post-SSH MOTD apply deferred for %s: %s", container_name, type(motd_exc).__name__)
                else:
                    logger.warning("SSH setup deferred for %s: %s", container_name, result)
                save_vps_data_immediate()
            except Exception as ssh_setup_exc:
                vps_info["ssh_ready"] = False
                logger.warning("SSH setup deferred for %s: %s", container_name, type(ssh_setup_exc).__name__)
                save_vps_data_immediate()

            async def _resolve_public_ip():
                try:
                    guest_ips = await asyncio.wait_for(get_container_addresses(container_name, self.node_id), timeout=20)
                except Exception:
                    guest_ips = {"ipv4": [], "ipv6": []}
                try:
                    node_mode=await get_node_network_mode(self.node_id)
                except Exception as mode_exc:
                    # The VM already exists and is persisted. A stale remote agent must
                    # leave access pending, not convert a successful VM build into failure.
                    logger.warning("Network mode for %s is not yet verifiable; access repair is pending: %s", container_name, type(mode_exc).__name__)
                    return guest_ips, {"ipv4":"", "ipv6":"", "network_mode":"unknown"}
                if node_mode in {"direct", "bridge"} and (guest_ips.get("ipv4") or guest_ips.get("ipv6")):
                    resolved_endpoints = {
                        "ipv4": (guest_ips.get("ipv4") or [""])[0],
                        "ipv6": (guest_ips.get("ipv6") or [""])[0],
                    }
                else:
                    resolved_endpoints = await detect_public_endpoints(self.node_id, container_name)
                resolved_endpoints['network_mode'] = node_mode
                return guest_ips, resolved_endpoints

            guest_ips_for_ssh, endpoints = await run_deployment_stage(
                progress_message, 10,
                "Reading the real guest IPv4/IPv6 addresses and node public-endpoint configuration; no fake IP is generated.",
                _resolve_public_ip, container_name,
            )

            async def _create_ssh_endpoint():
                node_mode = str(endpoints.get('network_mode') or await get_node_network_mode(self.node_id))
                if node_mode in {"direct", "bridge"}:
                    port = 22
                elif node_mode == "nat":
                    try:
                        port = await create_port_forward(str(user_id), container_name, 22, self.node_id)
                    except Exception as access_exc:
                        # The VM and its DB record are already durable. A temporary QGA/DHCP,
                        # quota or provider-firewall issue must not turn a running VPS into
                        # a false deployment failure; access_repair_task and !ssh retry later.
                        port = None
                        vps_info['ssh_access_error_type'] = type(access_exc).__name__
                        logger.warning("SSH endpoint for %s is pending; VPS remains running: %s", container_name, type(access_exc).__name__)
                else:
                    port = None
                    vps_info['ssh_access_error_type'] = 'network_mode_unverified'
                    logger.warning("SSH endpoint for %s is pending until its remote node reports a verified network mode.", container_name)
                vps_info['ssh_access_pending'] = not bool(port)
                if vps_info['ssh_access_pending']:
                    save_vps_data_immediate()
                return port, format_public_ssh_access(endpoints, port)

            ssh_port, ssh_access = await run_deployment_stage(
                progress_message, 11,
                "Preparing the SSH endpoint from verified network data; SSH credentials are only sent privately by DM.",
                _create_ssh_endpoint, container_name,
            )
            ssh_command = ssh_access.get("ssh_ipv4") or ssh_access.get("ssh_ipv6") or "Public SSH endpoint unavailable"

            # Tunnels are started in the background so a slow provider cannot cause a deployment timeout.
            # The checklist says 'queued' and does not claim an endpoint is active before the repair worker verifies it.
            pinggy_info = None
            async def _queue_pinggy():
                if PINGGY_ENABLED and PINGGY_AUTO_START:
                    asyncio.create_task(_background_start_pinggy(container_name, self.node_id), name=f"rgnodes_pinggy_bootstrap_{container_name}")
                    return "Pinggy bootstrap queued; live tunnel readiness is checked by the repair worker."
                return "Pinggy auto-start is disabled in configuration."

            await run_deployment_stage(
                progress_message, 12,
                "Starting the Pinggy SSH tunnel bootstrap without blocking VM deployment on the external tunnel provider.",
                _queue_pinggy, container_name,
            )

            async def _final_runtime_check():
                stats = await get_container_stats(container_name, self.node_id)
                docker_status = await get_container_docker_status(container_name, self.node_id) if docker_required else "Disabled by configuration"
                runtime_state = str(stats.get("status", "unknown")).lower()
                mode_label = str(endpoints.get('network_mode') or 'unknown').upper()
                ip_label = 'shared node public IPv4' if mode_label == 'NAT' else ('guest public IPv4' if mode_label in {'DIRECT','BRIDGE'} else 'public IPv4')
                access_state = 'SSH endpoint pending; retry with !ssh' if vps_info.get('ssh_access_pending') else ('SSH endpoint configured' if ssh_access.get('ssh_ipv4') or ssh_access.get('ssh_ipv6') else 'SSH endpoint not verified')
                result = f"Runtime: {runtime_state}; SSH: {'ready' if vps_info.get('ssh_ready') else 'repair queued'}; Access: {access_state}; Docker: {docker_status}; {ip_label}: {ssh_access.get('ipv4') or 'not verified yet'}."
                if runtime_state != "running":
                    logger.warning("Final deploy health check for %s reports runtime state %s.", container_name, runtime_state)
                return result

            final_runtime_summary = await run_deployment_stage(
                progress_message, 13,
                "Verifying live VPS runtime status and actual Docker state, and reconciling SSH/IP readiness flags.",
                _final_runtime_check, container_name,
            )
            await send_progress(
                progress_message, "Finished", 15, len(DEPLOYMENT_STAGES),
                f"✅ Deployment workflow finished. {final_runtime_summary}\nPinggy starts asynchronously; readiness is reported only after its health check succeeds.",
                active_index=14, frame=9, vps_name=container_name,
            )
            
            if self.ctx.guild:
                vps_role = await get_or_create_vps_role(self.ctx.guild)
                if vps_role:
                    try:
                        await self.user.add_roles(vps_role, reason=f"{BOT_NAME} VPS ownership granted")
                    except discord.Forbidden:
                        logger.warning(f"Failed to assign VPS role to {self.user.name}")
            success_embed = create_success_embed(f"RGNODES™ {type_label} Deployment Finished", f"✅ All deployment stages have finished.\n{create_progress_bar(100)}\n\n{final_runtime_summary}")
            add_field(success_embed, "Owner", self.user.mention, True)
            add_field(success_embed, "VPS ID", f"#{global_vps_id}", True)
            add_field(success_embed, "VPS Name", f"`{container_name}`", True)
            add_field(success_embed, "Product", type_label, True)
            add_field(success_embed, "Node", get_node(self.node_id)['name'], True)
            add_field(success_embed, "Resources", f"**RAM:** {self.ram} GB\n**CPU:** {self.cpu} cores\n**Disk:** {self.disk} GB", False)
            add_field(success_embed, "OS", friendly_os_label(os_version), True)
            add_field(success_embed, "SSH Configuration", "✅ Configured (PasswordAuth enabled)" if vps_info.get("ssh_ready") else "🟡 Setup queued; automatic access repair is running", True)
            access_note = ("✅ SSH endpoint configured; verify reachability from your network." if not vps_info.get('ssh_access_pending') else "🟡 VPS is running, but public SSH mapping is pending. Run `!ssh <vps-id>` after node/network repair.")
            add_field(success_embed, "SSH & Password", ("✅ SSH configured for password authentication" if vps_info.get("ssh_ready") else "🟡 SSH service is being finalized automatically") + f"\n{access_note}\n🔐 Root password generated and sent privately via DM\n📧 Check your DMs for SSH credentials!", False)
            add_field(success_embed, "Virtualization & Protection", "✅ KVM/QEMU host-passthrough\n✅ Virtio disk + network\n✅ Guest hardening + Fail2ban + sysctl protection\n✅ Automatic anti-mining guard\n✅ Resource autoscaling inside the hard ceilings", False)
            add_field(success_embed, "Disk Policy", "Starts on the small initial disk allocation and automatically grows in controlled steps up to the VPS plan limit when physical usage reaches the configured threshold.", False)
            try:
                await progress_message.edit(embed=success_embed, view=None, allowed_mentions=discord.AllowedMentions.none())
            except Exception as status_exc:
                logger.warning("VPS created but public completion message could not be updated: %s", status_exc)
                await interaction.followup.send(embed=success_embed, ephemeral=False)
            dm_embed = create_success_embed('🎉 VPS Deployed!', 'Your free VPS is ready!')
            expires_at = datetime.fromisoformat(vps_info['expiration_date'])
            add_field(dm_embed, '📊 Details', f'**VPS:** `#{global_vps_id}`  **VPS Name:** `{container_name}`\n**OS:** `{friendly_os_label(os_version)}`  **Config:** `{config_str}`\n**Bandwidth:** `{VPS_BANDWIDTH_GB} GB`\n**Expires:** `{expires_at.strftime("%Y-%m-%d %H:%M:%S")}`', False)
            try:
                guest_ips = await asyncio.wait_for(get_container_addresses(container_name, self.node_id), timeout=10)
            except Exception:
                guest_ips = {"ipv4": [], "ipv6": []}
            if endpoints.get('network_mode') == 'nat':
                public_ip_label = 'Shared node public IPv4 (NAT)'
                guest_ipv4_label = 'Private guest IPv4'
            else:
                public_ip_label = 'Guest public IPv4'
                guest_ipv4_label = 'Guest IPv4'
            add_field(dm_embed, '🌐 VPS IPs', f'**{guest_ipv4_label}:** `{", ".join(guest_ips.get("ipv4") or []) or "Not assigned"}`\n**Guest IPv6:** `{", ".join(guest_ips.get("ipv6") or []) or "Not assigned"}`\n**{public_ip_label}:** `{ssh_access.get("ipv4") or "Unavailable"}`\n**Public IPv6:** `{ssh_access.get("ipv6") or "Unavailable"}`', False)
            if pinggy_info:
                add_field(dm_embed, '🌐 Pinggy SSH Tunnel', f"**SSH Command:** `ssh root@{pinggy_info['host']} -p {pinggy_info['port']}`\n**Host:** `{pinggy_info['host']}`\n**Port:** `{pinggy_info['port']}`\n**Status:** 🟢 Tunnel Active\nPinggy is started automatically at deployment; use `-manage` → 🔄 **Reconnect Pinggy** for a fresh tunnel.", False)
            else:
                add_field(dm_embed, '🌐 Pinggy SSH Tunnel', '⚪ Pinggy was not connected at deployment time. Use `-manage` → 🔄 **Reconnect Pinggy** to create a fresh tunnel.', False)
            ssh_lines = []
            if ssh_access.get("ssh_ipv4"):
                ssh_lines.append(f"IPv4: `{ssh_access['ssh_ipv4']}`")
            if ssh_access.get("ssh_ipv6"):
                ssh_lines.append(f"IPv6: `{ssh_access['ssh_ipv6']}`")
            if not ssh_lines:
                ssh_lines.append("⚠️ No verified public SSH endpoint is available yet.")
            access_note = ('\n🟡 SSH port mapping is pending. The VPS is running; use `!ssh ' + container_name + '` later to retry, or wait for automatic access repair.' if not ssh_port else '')
            add_field(dm_embed, '💻 SSH Access', '\n'.join(ssh_lines) + access_note + f'\n**Username:** `root`\n**Password:** `{root_password}`\n🔒 Save this password securely.', False)
            docker_feature = "✅ Docker Engine installed and verified" if docker_required else "⚪ Docker installation disabled by configuration"
            add_field(dm_embed, '⚙️ Features', f'✅ SSH/SFTP  {docker_feature}  ✅ Port Forwarding  ✅ KVM/QEMU\n✅ Anti-mining guest hardening  ✅ Renewal support  ✅ Hostname: `rgnodes-vps`', False)
            add_field(dm_embed, '📞 Support', f'Use `-manage` for controls. Renewal becomes available in the final **{RENEWAL_WINDOW_DAYS} days** before expiry with `-renew`.', False)
            try:
                await self.user.send(embed=dm_embed)
            except discord.Forbidden:
                await self.ctx.send(embed=create_warning_embed(
                    'DM Not Delivered',
                    f"Couldn't DM {self.user.mention}. Enable DMs from this server and use `{PREFIX}vps-password {container_name}` (admin-only) or ask an admin to resend access privately. Credentials were not posted publicly."
                ))
        except Exception as e:
            ACTIVE_DEPLOYMENTS.discard(user_id)
            if record_persisted:
                logger.error(f"VPS {container_name} was provisioned but a post-create notification/action failed: {e}", exc_info=True)
                try:
                    warning_embed = create_warning_embed("VPS Created", f"VPS `{container_name}` was created successfully, but a final notification step failed. Check `{PREFIX}manage` for the VPS.")
                    await progress_message.edit(embed=warning_embed, view=None, allowed_mentions=discord.AllowedMentions.none())
                except Exception:
                    try:
                        await interaction.followup.send(embed=warning_embed, ephemeral=False)
                    except Exception:
                        pass
                return
            if container_created:
                try:
                    await execute_vpsctl_compat(container_name, f"delete {container_name} --force", timeout=300, node_id=self.node_id)
                except Exception as cleanup_error:
                    logger.critical(f"Deployment rollback failed for {container_name}: {cleanup_error}", exc_info=True)
            if user_id in vps_data:
                vps_data[user_id] = [v for v in vps_data[user_id] if v.get("container_name") != container_name]
                if not vps_data[user_id]:
                    vps_data.pop(user_id, None)
            save_vps_data_immediate()
            trace_id = secrets.token_hex(4).upper()
            diagnostic = _safe_diagnostic_text(e)
            logger.error("VPS_CREATE_FAILURE trace_id=%s node_id=%s vps=%s exception_type=%s message=%s",
                         trace_id, self.node_id, container_name, type(e).__name__, diagnostic)
            error_embed = create_error_embed("Creation Failed", safe_error_summary("VPS creation", e, trace_id=trace_id))
            try:
                await progress_message.edit(embed=error_embed, view=None, allowed_mentions=discord.AllowedMentions.none())
            except Exception:
                await interaction.followup.send(embed=error_embed, ephemeral=False)
        finally:
            if node_lock_acquired and node_lock is not None and node_lock.locked():
                node_lock.release()
                node_lock_acquired = False
            # Always release the per-user deployment lock, including successful deployments.
            ACTIVE_DEPLOYMENTS.discard(user_id)

@bot.command(name='deploy')
async def deploy_command(ctx, user: discord.Member = None):
    """Self-service public KVM/Docker VPS deployment; administrators retain the admin flow."""
    target = user or ctx.author
    caller_is_admin = is_admin_user(ctx.author)
    if user is not None and not caller_is_admin:
        await ctx.send(embed=create_error_embed('Access Denied', 'Only admins can deploy a VPS for another Discord account.'))
        return
    if maintenance_enabled() and not caller_is_admin:
        await ctx.send(embed=create_warning_embed('Under Maintenance', 'VPS deployment is temporarily disabled while maintenance mode is enabled.'))
        return
    policy_error = public_vps_access_error(target, admin_override=caller_is_admin)
    if policy_error:
        await ctx.send(embed=create_warning_embed('Public VPS Unavailable', policy_error))
        return
    if user_has_vps(target.id):
        await ctx.send(embed=create_error_embed('VPS Limit Reached', f'{target.mention} already has a VPS.'))
        return
    if caller_is_admin:
        plan_ram, plan_cpu, plan_disk = INITIAL_VPS_RAM_GB, INITIAL_VPS_CPU, INITIAL_VPS_DISK_GB
        expiry = DEFAULT_VPS_EXPIRATION_DAYS
        plan_text = 'Administrator deployment defaults'
    else:
        plan_ram, plan_cpu, plan_disk = PUBLIC_VPS_MAX_RAM, PUBLIC_VPS_MAX_CPU, PUBLIC_VPS_MAX_DISK
        expiry = PUBLIC_VPS_EXPIRY_DAYS
        plan_text = 'Free public VPS plan'
    network_state = 'NAT/shared node IPv4 with mapped ports' if KVM_NETWORK_MODE == 'nat' else 'routed/bridge (provider-routed IPv4 required)'
    description = (
        f'**Products:** KVM VPS or Docker VPS\n'
        f'**Virtualization:** KVM/QEMU/libvirt\n'
        f'**Network:** {network_state}\n'
        f'**Plan:** {plan_ram} GB RAM • {plan_cpu} CPU • {plan_disk} GB disk\n'
        f'**Expiry:** {expiry} days\n'
        f'**Availability:** {plan_text}\n\n'
        'Choose KVM VPS or Docker VPS to continue.'
    )
    await ctx.send(embed=create_info_embed('RGNODES™ Deployment Center', description),
                   view=DeployTypeView(target, ctx, expiry, plan_ram, plan_cpu, plan_disk))

@bot.command(name='create')
@is_admin()
async def create_machine(ctx, ram: int, cpu: int, disk: int, user: discord.Member, product: str = 'KVM', expiry_days: int = None):
    """Admin deployment: <ram> <cpu> <disk> @user [KVM|DOCKER] [expiry-days]."""
    product_arg = str(product or 'KVM').strip().upper().replace('_', '-').replace(' ', '-')
    if product_arg in {'VPS', 'KVM', 'KVM-VPS'}:
        product_type = 'KVM'
    elif product_arg in {'DOCKER', 'DOCKER-VPS'} and DOCKER_VPS_ENABLED:
        product_type = 'DOCKER'
    else:
        await ctx.send(embed=create_error_embed(
            'Invalid Product',
            f'Choose `KVM` or `DOCKER`. Usage: `{PREFIX}create <RAM> <CPU> <DISK> @user [KVM|DOCKER] [expiry-days]`.'
        ))
        return
    try:
        ram, cpu, disk = int(ram), int(cpu), int(disk)
    except (TypeError, ValueError):
        await ctx.send(embed=create_error_embed('Invalid Resources', 'RAM, CPU and Disk must be whole numbers.'))
        return
    if not (1 <= ram <= MAX_VPS_RAM_GB and 1 <= cpu <= MAX_VPS_CPU and VPS_MIN_DISK_GB <= disk <= VPS_MAX_DISK_GB):
        await ctx.send(embed=create_error_embed('Invalid Resources', f'Allowed limits: **RAM 1–{MAX_VPS_RAM_GB} GB** • **CPU 1–{MAX_VPS_CPU}** • **Disk {VPS_MIN_DISK_GB}–{VPS_MAX_DISK_GB} GB**.'))
        return
    if user_has_vps(user.id):
        await ctx.send(embed=create_error_embed('VPS Limit Reached', f'{user.mention} already owns a VPS.'))
        return
    expiry = int(expiry_days) if expiry_days and int(expiry_days) > 0 else DEFAULT_VPS_EXPIRATION_DAYS
    type_label = 'Docker VPS' if product_type == 'DOCKER' else 'KVM VPS'
    description = (
        f'**Owner:** {user.mention}\n**Product:** {type_label}\n**Backend:** KVM/QEMU/libvirt\n'
        f'**Maximum:** {ram} GB RAM • {cpu} CPU • {disk} GB disk\n'
        f'**Starting allocation:** {min(INITIAL_VPS_RAM_GB, ram)} GB RAM • {min(INITIAL_VPS_CPU, cpu)} CPU • {min(INITIAL_VPS_DISK_GB, disk)} GB disk\n'
        f'**Expiry:** {expiry} days\n\nSelect a node and OS to continue.'
    )
    await ctx.send(embed=create_info_embed('VPS Creation', description))
    await ctx.channel.send(
        embed=create_info_embed('Choose Node', f'Select a KVM/QEMU node for this **{type_label}**.'),
        view=NodeSelectView(ram, cpu, disk, user, ctx, expiry, product_type=product_type),
    )


class ReinstallOSSelectView(RGNODESView):
    def __init__(self, parent_view, container_name, owner_id, actual_idx, ram_gb, cpu, storage_gb, node_id):
        super().__init__(timeout=300)
        self.parent_view = parent_view
        self.container_name = container_name
        self.owner_id = owner_id
        self.actual_idx = actual_idx
        self.ram_gb = ram_gb
        self.cpu = cpu
        self.storage_gb = storage_gb
        self.node_id = node_id
        self.select = discord.ui.Select(
            placeholder="Select an OS for the reinstall",
            options=[discord.SelectOption(label=o["label"], value=o["value"], emoji=os_option_emoji(o)) for o in OS_OPTIONS]
        )
        self.select.callback = self.select_os
        self.add_item(self.select)

    async def select_os(self, interaction: discord.Interaction):
        os_version = self.select.values[0]
        self.select.disabled = True
        await interaction.response.edit_message(
            embed=create_info_embed(
                f"{resolve_custom_emoji('uninstall', '🔄')} {resolve_custom_emoji('install', '📦')} Reinstalling VPS",
                f"Preparing a safe OS replacement for `{self.container_name}`...\n\n"
                f"New OS: **{friendly_os_label(os_version)}**\n"
                f"Resources: **{self.ram_gb} GB RAM • {self.cpu} Core(s) • {self.storage_gb} GB SSD**"
            ),
            view=self,
        )
        ram_mb = self.ram_gb * 1024
        new_password = generate_strong_password()
        original_name = str(self.container_name)
        suffix = datetime.now().strftime('%Y%m%d%H%M%S')
        target_vps = None
        previous_status = 'stopped'
        previous_suspended = False
        previous_expiration = None
        rollback_name = sanitize_username_for_container(f"{original_name}-rgnodes-backup-{suffix}")[:55]
        staging_name = sanitize_username_for_container(f"rgnodes-reinstall-{suffix}")[:55]
        old_exists = False
        old_was_running = False
        old_renamed = False
        staging_created = False
        swapped = False

        node_lock = _get_deploy_node_lock(self.node_id) if DEPLOY_NODE_SERIALIZE else None
        if node_lock is not None:
            await node_lock.acquire()
        try:
            target_vps = vps_data.get(str(self.owner_id), [])[self.actual_idx]
            if str(target_vps.get('container_name')) != original_name:
                raise RuntimeError('VPS record changed while reinstall was being prepared. Please reopen the dashboard and try again.')
            previous_status = str(target_vps.get('status', 'stopped')).lower()
            previous_suspended = bool(target_vps.get('suspended', False))
            previous_product = str(target_vps.get('product_type') or ('DOCKER' if str(target_vps.get('config') or '').lower().startswith('docker vps') else 'KVM')).upper()
            if previous_product not in {'KVM', 'DOCKER'}:
                previous_product = 'KVM'
            reinstall_docker_required = previous_product == 'DOCKER' or DOCKER_INSTALL_ON_DEPLOY
            previous_expiration = target_vps.get('expiration_date')

            with DB_LOCK:
                conn = get_db()
                try:
                    forward_rows = conn.execute(
                        'SELECT id, host_port, vps_port FROM port_forwards WHERE vps_container = ? ORDER BY id',
                        (original_name,),
                    ).fetchall()
                finally:
                    conn.close()
            expected_forwards = len(forward_rows)

            await interaction.edit_original_response(
                embed=create_info_embed(
                    "🔄 Reinstall • Safety Check",
                    f"Checking the current VPS `{original_name}` and preparing a rollback point..."
                ),
                view=self,
            )

            try:
                info = await execute_vpsctl_compat('', f"info {shlex.quote(original_name)}", node_id=self.node_id, timeout=60)
                old_exists = bool(info is not None)
            except Exception:
                old_exists = False

            if old_exists:
                try:
                    current_stats = await get_container_stats(original_name, self.node_id)
                    old_was_running = str(current_stats.get('status', '')).lower() == 'running'
                except Exception:
                    old_was_running = previous_status == 'running'

            # Clear interrupted temporary names from older failed attempts.
            for stale in (rollback_name, staging_name):
                try:
                    await execute_vpsctl_compat(stale, f'delete {shlex.quote(stale)} --force', node_id=self.node_id, timeout=180)
                except Exception:
                    pass

            # Reinstall builds a second temporary VPS while the old one still exists.
            # Run a conservative admission check so the host never has to absorb two
            # full plans beyond its protected RAM/CPU/disk budget.
            reinstall_ok, reinstall_reason = await check_node_capacity_for_vps(self.node_id, self.ram_gb, self.cpu, self.storage_gb)
            if not reinstall_ok:
                raise RuntimeError(f"Reinstall blocked by host safety guard: {reinstall_reason}")
            storage_pool = DEFAULT_STORAGE_POOL
            resolved_os = await resolve_vps_image(os_version, self.node_id)
            os_version = resolved_os

            # Build and fully validate the replacement under a temporary name first.
            await execute_vpsctl_compat(
                staging_name,
                f'init {shlex.quote(resolved_os)} {shlex.quote(staging_name)} -s {shlex.quote(storage_pool)}',
                node_id=self.node_id,
                timeout=300,
            )
            staging_created = True
            await apply_vps_performance_profile(staging_name, self.node_id, ram_mb, self.cpu)
            await execute_vpsctl_compat(staging_name, f'config device set {staging_name} root size={self.storage_gb}GB', node_id=self.node_id)
            await apply_vps_vm_config(staging_name, self.node_id)
            await execute_vpsctl_compat(staging_name, f'start {staging_name}', node_id=self.node_id, timeout=180)
            await apply_internal_permissions(staging_name, self.node_id)
            await safe_guest_install(staging_name, self.node_id)
            await set_guest_hostname(staging_name, self.node_id, VPS_HOSTNAME)
            if reinstall_docker_required:
                await ensure_docker_ready(staging_name, self.node_id, strict=(previous_product == 'DOCKER' or DOCKER_STRICT_DEPLOY))

            ok, ssh_result = await configure_ssh(staging_name, self.node_id, new_password)
            if not ok:
                logger.warning('Replacement VPS %s SSH setup deferred: %s', staging_name, ssh_result)
            try:
                await apply_guest_motd(staging_name, self.node_id)
            except Exception as motd_exc:
                logger.debug('Replacement MOTD deferred for %s: %s', staging_name, motd_exc)
            if ok:
                await _exec_guest_bash(staging_name, self.node_id, "sshd -t", timeout=30)
            else:
                logger.warning("Skipping SSH daemon validation for %s because access repair is pending.", staging_name)
            await _exec_guest_bash(staging_name, self.node_id, "test -x /usr/local/sbin/rgnodes-mining-guard && systemctl is-enabled rgnodes-mining-guard.timer >/dev/null 2>&1 || true", timeout=30)

            # Verify the instance can execute commands before any destructive swap.
            await _exec_guest_bash(staging_name, self.node_id, 'true', timeout=30)
            await execute_vpsctl_compat(staging_name, f'stop {staging_name} --force', node_id=self.node_id, timeout=120)

            # Stop the old instance before renaming so its host-bound proxy devices are inactive.
            if old_exists:
                try:
                    await execute_vpsctl_compat(original_name, f'stop {original_name} --force', node_id=self.node_id, timeout=120)
                except Exception as e:
                    msg = str(e).lower()
                    if not any(x in msg for x in ('not running', 'already stopped', 'is stopped')):
                        raise
                await execute_vpsctl_compat(original_name, f'rename {original_name} {rollback_name}', node_id=self.node_id, timeout=180)
                old_renamed = True

            try:
                await execute_vpsctl_compat(staging_name, f'rename {staging_name} {original_name}', node_id=self.node_id, timeout=180)
                staging_created = False
                swapped = True
            except Exception:
                if old_renamed:
                    try:
                        await execute_vpsctl_compat(rollback_name, f'rename {rollback_name} {original_name}', node_id=self.node_id, timeout=180)
                        old_renamed = False
                    except Exception as rollback_error:
                        logger.critical(f'Reinstall rename rollback failed for {original_name}: {rollback_error}', exc_info=True)
                raise

            # Restore desired lifecycle state and persistent ports only after the replacement owns the original name.
            if old_was_running or previous_status == 'running':
                await execute_vpsctl_compat(original_name, f'start {original_name}', node_id=self.node_id, timeout=180)
                await apply_internal_permissions(original_name, self.node_id)
            else:
                # Intentionally stopped VPS stays stopped after reinstall.
                pass

            readded = await recreate_port_forwards(original_name) if (old_was_running or previous_status == 'running') else 0
            if expected_forwards and (old_was_running or previous_status == 'running') and readded != expected_forwards:
                raise RuntimeError(f'Only {readded}/{expected_forwards} persistent port forwards were restored.')

            # Commit DB only after the replacement has passed validation and runtime checks.
            target_vps['os_version'] = os_version
            target_vps['product_type'] = previous_product
            target_vps['status'] = 'running' if (old_was_running or previous_status == 'running') else 'stopped'
            target_vps['suspended'] = previous_suspended
            target_vps['root_password'] = new_password
            target_vps['ssh_ready'] = bool(ok)
            target_vps['config'] = f'{"Docker VPS" if previous_product == "DOCKER" else "KVM VPS"} / {self.ram_gb}GB RAM / {self.cpu} CPU / {self.storage_gb}GB Disk'
            target_vps['expiration_date'] = previous_expiration or (datetime.now() + timedelta(days=DEFAULT_VPS_EXPIRATION_DAYS)).isoformat()
            save_vps_data_immediate()

            if old_renamed:
                try:
                    await execute_vpsctl_compat(rollback_name, f'delete {rollback_name} --force', node_id=self.node_id, timeout=300)
                    old_renamed = False
                except Exception as cleanup_error:
                    logger.warning(f'Reinstall completed but rollback cleanup failed for {rollback_name}: {cleanup_error}')

            result = create_success_embed(
                '🎉 VPS Reinstalled',
                f'`{original_name}` ({"Docker VPS" if previous_product == "DOCKER" else "KVM VPS"}) was safely reinstalled with **{friendly_os_label(os_version)}**.'
            )
            add_field(result, '📊 Resources', f'RAM: **{self.ram_gb} GB**\nCPU: **{self.cpu} Core(s)**\nSSD: **{self.storage_gb} GB**\nBandwidth: **{int(target_vps.get("bandwidth_gb") or VPS_BANDWIDTH_GB)} GB**', False)
            add_field(result, '🔐 SSH', 'Username: `root`\nNew password generated', False)
            add_field(result, '🛡️ Protection', 'Anti-Mining Guard: **Enabled**\nKVM guest hardening: **Applied**', False)
            add_field(result, '🌐 Ports', f'Restored: **{readded}/{expected_forwards}**', False)
            await interaction.followup.send(embed=result, ephemeral=True)

            try:
                owner = await bot.fetch_user(int(self.owner_id))
                dm = create_success_embed('?? VPS Reinstalled!', f'Your VPS `{original_name}` has been reinstalled and is ready.')
                add_field(dm, '📊 Details', f'**OS:** `{os_version}`\n**Config:** `{self.ram_gb}GB RAM / {self.cpu} CPU / {self.storage_gb}GB Disk`\n**Hostname:** `{VPS_HOSTNAME}`\n**Expires:** `{_safe_fromiso(target_vps["expiration_date"]).strftime("%Y-%m-%d") if target_vps.get("expiration_date") else "N/A"}`', False)
                add_field(dm, '🔐 SSH Access', f'**Username:** `root`\n**Password:** `{new_password}`\n🔒 Save this password securely.', False)
                await owner.send(embed=dm)
            except Exception as dm_error:
                logger.info(f'Could not DM reinstall credentials for {self.owner_id}: {dm_error}')

        except Exception as e:
            logger.error(f'Safe reinstall failed for {original_name}: {e}', exc_info=True)
            # Roll back the destructive rename whenever possible.
            try:
                if swapped:
                    try:
                        await execute_vpsctl_compat(original_name, f'stop {original_name} --force', node_id=self.node_id, timeout=120)
                    except Exception:
                        pass
                    try:
                        await execute_vpsctl_compat(original_name, f'delete {original_name} --force', node_id=self.node_id, timeout=180)
                    except Exception:
                        pass
                    swapped = False
                if old_renamed:
                    await execute_vpsctl_compat(rollback_name, f'rename {rollback_name} {original_name}', node_id=self.node_id, timeout=180)
                    old_renamed = False
                    if old_was_running:
                        await execute_vpsctl_compat(original_name, f'start {original_name}', node_id=self.node_id, timeout=180)
                        await recreate_port_forwards(original_name)
                if staging_created:
                    try:
                        await execute_vpsctl_compat(staging_name, f'delete {staging_name} --force', node_id=self.node_id, timeout=180)
                    except Exception:
                        pass
            except Exception as rollback_error:
                logger.critical(f'REINSTALL ROLLBACK FAILED for {original_name}: {rollback_error}', exc_info=True)
            try:
                await interaction.followup.send(
                    embed=create_error_embed(
                        '❌ Reinstall Failed',
                        'The original VPS was kept/restored where possible. ' + safe_error_summary('VPS reinstall', e)
                    ),
                    ephemeral=True,
                )
            except Exception:
                pass
        finally:
            if node_lock is not None and node_lock.locked():
                node_lock.release()


class PortAddModal(discord.ui.Modal, title="🌐 Add Port Forward"):
    vps_port = discord.ui.TextInput(
        label="VPS Port",
        placeholder="25565",
        min_length=1,
        max_length=5,
        required=True,
    )

    def __init__(self, owner_id: str, container_name: str, node_id: int):
        super().__init__(timeout=120)
        self.owner_id = str(owner_id)
        self.container_name = str(container_name)
        self.node_id = int(node_id)

    async def on_submit(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.owner_id and not is_admin_user(interaction.user):
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "You do not own this VPS."), ephemeral=True)
            return
        try:
            port = int(str(self.vps_port.value).strip())
            if not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            await interaction.response.send_message(embed=create_error_embed("Invalid Port", "VPS port must be between 1 and 65535."), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        try:
            host_port = await create_port_forward(self.owner_id, self.container_name, port, self.node_id)
            if not host_port:
                await interaction.followup.send(
                    embed=create_error_embed(
                        "Port Creation Failed",
                        "No free port/quota is available, or the public-IP port configuration could not be created."
                    ),
                    ephemeral=True,
                )
                return
            await interaction.followup.send(
                embed=create_success_embed(
                    "🌐 Port Forward Created",
                    f"**VPS:** `{self.container_name}`\n**Guest/Public Port:** `{port}`\n**Protocol:** `TCP + UDP`\n\nThe VPS uses its own public IPv4; no host-NAT port is fabricated. Reachability also requires a listening service and provider routing/firewall to allow this port. Managed UFW rules are reconciled when UFW is active."
                ),
                ephemeral=True,
            )
        except Exception as e:
            logger.error(f"Port modal failed for {self.container_name}: {e}", exc_info=True)
            await interaction.followup.send(embed=create_error_embed("Port Error", safe_error_summary("Port update", e)), ephemeral=True)


class PortsView(RGNODESView):
    """Persistent port-forward control panel for one VPS."""
    def __init__(self, owner_id: str, container_name: str, node_id: int):
        super().__init__(timeout=300)
        self.owner_id = str(owner_id)
        self.container_name = str(container_name)
        self.node_id = int(node_id)
        self._rebuild_items()

    def _rebuild_items(self):
        self.clear_items()
        add_btn = discord.ui.Button(label="Add Port", emoji="➕", style=discord.ButtonStyle.secondary, row=0)
        add_btn.callback = self.add_port
        refresh_btn = discord.ui.Button(label="Refresh", emoji="🔄", style=discord.ButtonStyle.secondary, row=0)
        refresh_btn.callback = self.refresh
        close_btn = discord.ui.Button(label="Close", emoji="❌", style=discord.ButtonStyle.secondary, row=0)
        close_btn.callback = self.close
        self.add_item(add_btn)
        self.add_item(refresh_btn)
        self.add_item(close_btn)

        forwards = [f for f in get_user_forwards(self.owner_id) if str(f.get("vps_container")) == self.container_name]
        if forwards:
            options = [
                discord.SelectOption(
                    label=f"Remove ID {f['id']}",
                    description=f"Host {f['host_port']} → VPS {f['vps_port']} TCP/UDP",
                    value=str(f["id"]),
                ) for f in forwards[:25]
            ]
            select = discord.ui.Select(placeholder="🗑️ Select a forward to remove", options=options, row=1)
            select.callback = self.remove
            self.add_item(select)

    def _embed(self):
        forwards = [f for f in get_user_forwards(self.owner_id) if str(f.get("vps_container")) == self.container_name]
        quota = get_user_allocation(self.owner_id)
        lines = [f"• `{f['id']}` → host `{f['host_port']}` ⇢ VPS `{f['vps_port']}` • TCP/UDP" for f in forwards]
        body = (
            f"**VPS:** `{self.container_name}`\n"
            f"**Usage:** `{len(forwards)}/{quota}`\n\n"
            + ("\n".join(lines) if lines else "None configured")
            + "\n\nPublic port reservations are allocated automatically and persisted in the bot database."
        )
        return create_info_embed("🌐 Port Forwarding", body)

    async def add_port(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.owner_id and not is_admin_user(interaction.user):
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "You do not own this VPS."), ephemeral=True)
            return
        await interaction.response.send_modal(PortAddModal(self.owner_id, self.container_name, self.node_id))

    async def remove(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.owner_id and not is_admin_user(interaction.user):
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "You do not own this VPS."), ephemeral=True)
            return
        select = interaction.data.get("values", []) if isinstance(interaction.data, dict) else []
        if not select:
            await interaction.response.send_message(embed=create_error_embed("No Port Selected", "Select a forwarding rule first."), ephemeral=True)
            return
        try:
            fid = int(select[0])
        except ValueError:
            await interaction.response.send_message(embed=create_error_embed("Invalid Forward", "The selected forwarding rule is invalid."), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True)
        ok, owner = await remove_port_forward(fid, requester_id=str(interaction.user.id), is_admin=is_admin_user(interaction.user))
        await interaction.followup.send(
            embed=create_success_embed("🗑️ Port Removed", f"Forward ID `{fid}` was removed.") if ok else create_error_embed("Remove Failed", "That forward does not exist, is not yours, or could not be fully removed."),
            ephemeral=True,
        )
        await self.refresh(interaction, from_followup=True)

    async def refresh(self, interaction: discord.Interaction, from_followup: bool = False):
        self._rebuild_items()
        try:
            if not from_followup and not interaction.response.is_done():
                await interaction.response.edit_message(embed=self._embed(), view=self)
            elif interaction.message:
                await interaction.message.edit(embed=self._embed(), view=self)
        except Exception as e:
            logger.debug(f"Port view refresh failed: {e}")

    async def close(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.owner_id and not is_admin_user(interaction.user):
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "You do not own this VPS."), ephemeral=True)
            return
        await interaction.response.edit_message(view=None)
        self.stop()

class ManageView(RGNODESView):
    """Primary owner/admin VPS dashboard with live state, access, ports and lifecycle controls."""
    def __init__(self, user_id, vps_list, is_shared=False, owner_id=None, is_admin=False, actual_index: Optional[int] = None):
        super().__init__(timeout=1800)
        self.user_id = str(user_id)
        self.vps_list = list(vps_list)
        self.selected_index = 0 if len(self.vps_list) == 1 else None
        self.is_shared = bool(is_shared)
        self.owner_id = str(owner_id or user_id)
        self.is_admin = bool(is_admin)
        self.actual_index = actual_index
        self.indices = list(range(len(self.vps_list)))
        if self.is_shared and self.actual_index is None:
            raise ValueError("actual_index required for shared views")

        if len(self.vps_list) > 1:
            options = []
            for i, vps in enumerate(self.vps_list):
                vmid = vps.get("vmid") or vps.get("id") or (i + 1)
                options.append(discord.SelectOption(
                    label=f"VPS #{vmid}",
                    description=f"{str(vps.get('os_version', 'Unknown'))[:70]} • {vps.get('ram', '?')} RAM",
                    value=str(i),
                ))
            self.select = discord.ui.Select(placeholder="🖥️ Select a VPS", options=options, row=0)
            self.select.callback = self.select_vps
            self.add_item(self.select)
            self.initial_embed = create_info_embed(
                "🖥️ RGNODES™ VPS Management",
                "Select a VPS from the menu below to open its live control panel.",
            )
        else:
            self.initial_embed = None
            self.add_action_buttons()

    async def get_initial_embed(self):
        if self.initial_embed is not None:
            return self.initial_embed
        return await self.create_vps_embed(self.selected_index)

    async def _pinggy_block(self, container_name: str, node_id: int) -> str:
        try:
            host, port, active = await asyncio.wait_for(
                get_pinggy_session_info(container_name, node_id), timeout=10
            )
        except Exception:
            host, port, active = None, None, False
        if host and port and active:
            return (
                f"Status: {resolve_custom_emoji('pinggy', '🟢')} Tunnel Active\n"
                "Connection details are private and are not shown in this channel. "
                f"Use {resolve_custom_emoji('refresh', '🔄')} **Reconnect Pinggy** to receive connection details privately."
            )
        return (
            f"Status: {resolve_custom_emoji('pinggy_offline', '🟡')} Not Connected\n"
            "Pinggy starts automatically after deployment. Use the private reconnect flow to create a fresh session."
        )

    async def create_vps_embed(self, index):
        if index is None or index < 0 or index >= len(self.vps_list):
            raise IndexError("Invalid VPS selection")
        vps = self.vps_list[index]
        node_id = int(vps.get("node_id", 1))
        node = get_node(node_id) or {}
        container_name = str(vps.get("container_name", "unknown"))
        product_type = str(vps.get("product_type") or ("DOCKER" if str(vps.get("config") or "").lower().startswith("docker vps") else "KVM")).upper()
        product_label = "🐳 Docker VPS" if product_type == "DOCKER" else "🖥️ KVM VPS"

        try:
            stats = await asyncio.wait_for(get_container_stats(container_name, node_id), timeout=15)
        except Exception as e:
            logger.debug(f"Manage stats failed for {container_name}: {e}")
            stats = {"status": "unknown", "cpu": 0.0, "ram": {"used": 0, "total": 0, "pct": 0.0}, "disk": "N/A", "uptime": "N/A"}

        observed = str(stats.get("status") or "unknown").lower()
        if observed in {"running", "stopped", "frozen"}:
            vps["status"] = "running" if observed == "running" else "stopped"
        status = str(vps.get("status", observed)).lower()
        suspended = bool(vps.get("suspended", False))
        status_label = "SUSPENDED" if suspended else status.upper()
        viewer_under_maintenance = maintenance_applies_to_user(self.owner_id) and not self.is_admin
        status_emoji = resolve_custom_emoji("status", "🟢") if status == "running" and not suspended else (resolve_custom_emoji("warning", "🟡") if suspended else resolve_custom_emoji("error", "🔴"))
        if viewer_under_maintenance:
            status_label = "🔶 Under Maintenance\n🛠️ Service maintenance in progress"
            status_emoji = "🔴"
        vmid = int(vps.get("vmid") or vps.get("id") or (index + 1))

        forwards = [f for f in get_user_forwards(self.owner_id) if str(f.get("vps_container")) == container_name]
        port_used = len(forwards)
        port_quota = max(0, get_user_allocation(self.owner_id))
        slot_used = len(vps_data.get(self.owner_id, []))

        networks = {}
        addresses = {"ipv4": [], "ipv6": []}
        rx_text, tx_text = "N/A", "N/A"
        docker_text = "⚪ Offline"
        if status == "running":
            try:
                addresses = await asyncio.wait_for(get_container_addresses(container_name, node_id), timeout=10)
                networks = {f"iface{i}": ip for i, ip in enumerate(addresses.get("ipv4", []), 1)}
            except Exception:
                addresses = {"ipv4": [], "ipv6": []}
            try:
                rx_text, tx_text = await asyncio.wait_for(get_container_network_usage(container_name, node_id), timeout=10)
            except Exception:
                pass
            try:
                docker_text = await asyncio.wait_for(get_container_docker_status(container_name, node_id), timeout=8)
            except Exception:
                docker_text = "⚪ Unknown"

        ram = stats.get("ram") if isinstance(stats.get("ram"), dict) else {}
        plan_mb = _parse_gb(vps.get('ram', f'{DEFAULT_VPS_RAM_GB}GB'), DEFAULT_VPS_RAM_GB) * 1024
        memory_text = f"{ram.get('used', 0)} MB / {plan_mb} MB hard limit ({plan_mb/1024:.0f} GB plan)"
        cpu_value = stats.get("cpu")
        try:
            cpu_text = f"{float(cpu_value):.1f}%" if cpu_value is not None else "N/A"
        except Exception:
            cpu_text = "N/A"

        expiration_raw = vps.get("expiration_date")
        if expiration_raw:
            try:
                expiration_dt = datetime.fromisoformat(str(expiration_raw))
                seconds_left = (expiration_dt - datetime.now()).total_seconds()
                days_left = int(seconds_left // 86400)
                if seconds_left <= 0:
                    expiration_block = f"Status: 🔴 EXPIRED\nExpires: `{expiration_dt.strftime('%Y-%m-%d %H:%M:%S')}`\nDays Left: **0 days**"
                elif seconds_left <= RENEWAL_WINDOW_DAYS * 86400:
                    expiration_block = f"Status: 🟡 EXPIRING SOON\nExpires: `{expiration_dt.strftime('%Y-%m-%d %H:%M:%S')}`\nDays Left: **{max(0, days_left)} days**\n🔄 Renew opens now: `{PREFIX}renew {vmid}` (+{VPS_RENEWAL_DAYS} days)"
                else:
                    expiration_block = f"Status: 🟢 ACTIVE\nExpires: `{expiration_dt.strftime('%Y-%m-%d %H:%M:%S')}`\nDays Left: **{max(0, days_left)} days**"
            except Exception:
                expiration_block = "Status: ⚠️ INVALID DATE\nRenewal requires admin support."
        else:
            expiration_block = "Status: 🔵 NO EXPIRATION\nExpires: `Never`"

        pinggy_block = await self._pinggy_block(container_name, node_id) if PINGGY_ENABLED else "Status: ⚪ Disabled in configuration"

        node_text = f"{node.get('name', HOST_PROVIDER_NAME)} {location_flag(node.get('location', 'Unknown'))}"
        processor_text = HOST_PROCESSOR_NAME
        try:
            if node.get('is_local'):
                cpu_model = subprocess.check_output(['bash','-lc',"awk -F: '/^model name/{print $2; exit}' /proc/cpuinfo"], text=True, timeout=2).strip()
                if cpu_model:
                    processor_text = cpu_model
        except Exception:
            pass
        try:
            public_endpoints = await asyncio.wait_for(detect_public_endpoints(node_id, container_name), timeout=6)
        except Exception:
            public_endpoints = {"ipv4": "", "ipv6": ""}
        public_v4 = public_endpoints.get("ipv4") or "Unavailable"
        public_v6 = public_endpoints.get("ipv6") or "Unavailable"
        maintenance_banner = ""
        if viewer_under_maintenance:
            maintenance_banner = "🔶 **Under Maintenance**\n🛠️ **Service maintenance in progress**\n\n"
        description = (
            maintenance_banner +
            f"{status_emoji} **{status_label}** • **VPS ID: {vmid}**\n\n"
            f"📦 **Resources**\n"
            f"╭ **RAM:** {vps.get('ram', f'{DEFAULT_VPS_RAM_GB} GB')}\n"
            f"├ **CPU:** {vps.get('cpu', DEFAULT_VPS_CPU)} Core(s)\n"
            f"├ **SSD:** {vps.get('storage', f'{DEFAULT_VPS_STORAGE_GB} GB')}\n"
            f"├ **Bandwidth:** {int(vps.get('bandwidth_gb') or VPS_BANDWIDTH_GB)} GB\n"
            f"├ **Product:** {product_label}\n"
            f"├ **OS:** {friendly_os_label(vps.get('os_version', 'Unknown'))}\n"
            f"╰ **Node:** {node_text}\n"
            f"🧠 **Processor:** {processor_text}\n\n"
            f"⚙️ **Configuration**\n"
            f"╭ **Slots:** {slot_used}/1 used\n"
            f"├ **Uptime:** {stats.get('uptime', 'N/A') or 'N/A'}\n"
            f"├ **Hostname:** `{VPS_HOSTNAME}`\n"
            f"├ **Guest IPv4:** {', '.join(addresses.get('ipv4') or []) or 'Not assigned'}\n"
            f"├ **Guest IPv6:** {', '.join(addresses.get('ipv6') or []) or 'Not assigned'}\n"
            f"├ **{'Shared node IPv4 (NAT)' if (await get_node_network_mode(node_id))=='nat' else 'Guest public IPv4'}:** `{public_v4}`\n"
            f"├ **Public IPv6:** `{public_v6}`\n"
            f"╰ **Docker:** {docker_text}\n\n"
            f"📈 **Live Stats**\n"
            f"💻 **CPU:** {cpu_text} used / {vps.get('cpu', DEFAULT_VPS_CPU)} limit\n"
            f"🧠 **Memory:** {memory_text}\n"
            f"💾 **Disk:** {stats.get('disk', 'N/A')} • Current {stats.get('disk_current_gb', 'N/A')} GB • Plan {vps.get('storage', f'{DEFAULT_VPS_STORAGE_GB} GB')}\n"
            f"🌐 **Network:** RX {rx_text} • TX {tx_text}\n\n"
            f"⏰ **Expiration**\n{expiration_block}\n\n"
            f"🌐 **Pinggy SSH Tunnel**\n{pinggy_block}\n\n"
            f"🌐 **Public Access**\n├ {'Shared node IPv4 (NAT)' if (await get_node_network_mode(node_id))=='nat' else 'Guest IPv4'}: `{public_v4}`\n╰ IPv6: `{public_v6}`\n\n"
            f"🌐 **Port Forwarding • {port_used}/{port_quota}**\n{self._port_summary(forwards)}\n\n"
            f"🎮 **Action**\nUse the buttons below to control your VPS."
        )
        return create_embed(f"{resolve_custom_emoji('vps', '🖥️')} VPS #{vmid}", description)

    @staticmethod
    def _ssh_host_port(container_name, forwards):
        for fwd in forwards:
            try:
                if int(fwd.get("vps_port")) == 22:
                    return int(fwd.get("host_port"))
            except Exception:
                continue
        return None

    @staticmethod
    def _port_summary(forwards):
        if not forwards:
            return "None configured"
        lines = [f"• ID `{f['id']}` → `{f['host_port']}` ⇢ VPS `{f['vps_port']}` TCP/UDP" for f in forwards[:8]]
        if len(forwards) > 8:
            lines.append(f"• +{len(forwards) - 8} more")
        return "\n".join(lines)

    async def _refresh_dashboard(self, interaction: discord.Interaction):
        try:
            if interaction.message:
                await interaction.message.edit(embed=await self.create_vps_embed(self.selected_index), view=self)
        except Exception as e:
            logger.debug(f"Dashboard refresh failed: {e}")

    def add_action_buttons(self):
        user_maintenance = maintenance_applies_to_user(self.owner_id) and not self.is_admin

        def add(label, key, fallback, style, action, row, maintenance_allowed=False):
            btn = discord.ui.Button(
                label=label,
                emoji=resolve_custom_emoji(key, fallback),
                style=style,
                row=row,
                disabled=(user_maintenance and not maintenance_allowed),
            )
            async def _callback(inter: discord.Interaction, a=action):
                await self.action_callback(inter, a)
            btn.callback = _callback
            self.add_item(btn)

        add("Start", "start", "▶️", discord.ButtonStyle.secondary, "start", 0)
        add("Stop", "stop", "⏸️", discord.ButtonStyle.secondary, "stop", 0)
        add("Stats", "stats", "📊", discord.ButtonStyle.secondary, "stats", 0, True)
        add("Reset Password", "password", resolve_custom_emoji("password", "🔐"), discord.ButtonStyle.secondary, "regen_password", 1)
        add("SSH", "ssh", resolve_custom_emoji("ssh", "💻"), discord.ButtonStyle.secondary, "ssh", 2)
        add("Web SSH", "terminal", "🌐", discord.ButtonStyle.secondary, "webssh", 2)
        add("SFTP Files", "disk", "📁", discord.ButtonStyle.secondary, "sftp", 3)
        add("Reconnect Pinggy", "refresh", resolve_custom_emoji("refresh", "🔄"), discord.ButtonStyle.secondary, "reconnect_pinggy", 3)
        add("Ports", "ports", resolve_custom_emoji("ports", "🔌"), discord.ButtonStyle.secondary, "ports", 4)
        add("Renew", "renew", resolve_custom_emoji("renew", "⏰"), discord.ButtonStyle.secondary, "renew", 4, True)
        if not self.is_shared:
            add("Reinstall", "reinstall", "♻️", discord.ButtonStyle.secondary, "reinstall", 5)
        if not self.is_shared:
            add("Delete", "delete", "🗑️", discord.ButtonStyle.secondary, "delete", 5)

    async def select_vps(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id and not self.is_admin:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "This VPS selector belongs to another user."), ephemeral=True)
            return
        try:
            self.selected_index = int(self.select.values[0])
            self.clear_items()
            self.add_action_buttons()
            await interaction.response.defer()
            embed = await self.create_vps_embed(self.selected_index)
            await interaction.edit_original_response(embed=embed, view=self)
        except Exception as e:
            logger.error(f"VPS selector failed: {e}", exc_info=True)
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(embed=create_error_embed("⚠️ Selection Failed", "The live VPS panel could not be loaded. Please try again."), ephemeral=True)
                else:
                    await interaction.followup.send(embed=create_error_embed("⚠️ Selection Failed", "The live VPS panel could not be loaded. Please try again."), ephemeral=True)
            except Exception:
                pass

    async def action_callback(self, interaction: discord.Interaction, action: str):
        try:
            if str(interaction.user.id) != self.user_id and not self.is_admin:
                await interaction.response.send_message(embed=create_error_embed("Access Denied", "This is not your VPS."), ephemeral=True)
                return
            if self.selected_index is None:
                await interaction.response.send_message(embed=create_error_embed("No VPS Selected", "Please select a VPS first."), ephemeral=True)
                return
            actual_idx = self.actual_index if self.is_shared else self.indices[self.selected_index]
            owner_items = vps_data.get(str(self.owner_id), [])
            if actual_idx is None or actual_idx >= len(owner_items):
                await interaction.response.send_message(embed=create_error_embed("VPS Not Found", "This VPS record is no longer available. Reopen the dashboard."), ephemeral=True)
                return
            target_vps = owner_items[actual_idx]
            container_name = str(target_vps["container_name"])
            node_id = int(target_vps.get("node_id", 1))
            suspended = bool(target_vps.get("suspended", False))

            if maintenance_applies_to_user(self.owner_id) and not self.is_admin and action not in {"stats", "renew"}:
                await interaction.response.send_message(embed=create_warning_embed("🔧 🔶 Under Maintenance", "VPS control actions are temporarily disabled."), ephemeral=True)
                return
            if suspended and not self.is_admin and action not in {"stats", "renew"}:
                await interaction.response.send_message(embed=create_error_embed("⛔ VPS Suspended", "This VPS is suspended. Use Renew if it expired, or contact support."), ephemeral=True)
                return

            await interaction.response.defer()
            # Record dashboard actions with their real VPS/node context so the configured log channel
            # shows user-facing VPS operations as well as command completions.
            await record_audit_event(
                "vps",
                f"VPS Action • {str(action).replace('_', ' ').title()} Started",
                f"Dashboard action requested by <@{interaction.user.id}>.",
                user_id=interaction.user.id,
                node_id=node_id,
                vps_container=container_name,
            )

            if action == "stats":
                stats = await get_container_stats(container_name, node_id)
                rx, tx = await get_container_network_usage(container_name, node_id) if str(stats.get("status")) == "running" else ("N/A", "N/A")
                ram = stats.get("ram", {}) if isinstance(stats.get("ram"), dict) else {}
                e = create_info_embed("📈 Live VPS Statistics", f"`{container_name}` • VPS ID `{target_vps.get('vmid') or target_vps.get('id')}`")
                add_field(e, "🟢 Status", str(stats.get("status", "unknown")).upper(), True)
                add_field(e, "💻 CPU", f"{float(stats.get('cpu', 0)):.1f}% / {target_vps.get('cpu', DEFAULT_VPS_CPU)} cores", True)
                plan_mb = _parse_gb(target_vps.get("ram", "0GB"), DEFAULT_VPS_RAM_GB) * 1024
                add_field(e, "🧠 Memory", f"{ram.get('used', 0)} MB used / {plan_mb} MB limit", True)
                add_field(e, "💾 Disk", str(stats.get("disk", "N/A")), True)
                add_field(e, "🌐 Network", f"RX {rx} • TX {tx}", True)
                add_field(e, "⏱️ Uptime", str(stats.get("uptime", "N/A")), False)
                await interaction.followup.send(embed=e, ephemeral=True)
                await self._refresh_dashboard(interaction)
                return

            if action == "renew":
                ok, message = await process_vps_renewal(target_vps, VPS_RENEWAL_DAYS, user_initiated=not self.is_admin)
                await interaction.followup.send(embed=create_success_embed("⏰ VPS Renewed", message) if ok else create_warning_embed("⏰ Renewal Unavailable", message), ephemeral=True)
                if ok:
                    try:
                        owner = await bot.fetch_user(int(self.owner_id))
                        await owner.send(embed=create_success_embed("⏰ VPS Renewed!", f"Your VPS `{container_name}` has been extended by **{VPS_RENEWAL_DAYS} days**.\n\n{message}"))
                    except Exception:
                        pass
                await self._refresh_dashboard(interaction)
                return

            if action == "reconnect_pinggy":
                if suspended:
                    await interaction.followup.send(embed=create_error_embed("⛔ Access Denied", "Cannot access a suspended VPS."), ephemeral=True)
                    return
                try:
                    current = await get_container_stats(container_name, node_id)
                    runtime_status = str(current.get("status") or "unknown").lower()
                    recorded_status = str(target_vps.get("status") or "unknown").lower()
                    if runtime_status not in {"running", "unknown"} and recorded_status != "running":
                        await interaction.followup.send(embed=create_warning_embed("VPS Not Running", "Start the VPS before opening Pinggy."), ephemeral=True)
                        return
                    info = await asyncio.wait_for(start_pinggy_session(container_name, node_id), timeout=100)
                    if not info:
                        raise RuntimeError("Pinggy did not return a public tunnel endpoint. Try Reconnect Pinggy again.")
                    access = create_info_embed("🌐 RGNODES™ Pinggy SSH Tunnel", f"`{container_name}` • `{VPS_HOSTNAME}`")
                    add_field(access, "🌐 Pinggy SSH Tunnel", f"**SSH Command:** `ssh root@{info['host']} -p {info['port']}`\n**Host:** `{info['host']}`\n**Port:** `{info['port']}`\n**Status:** 🟢 Tunnel Active", False)
                    add_field(access, "🔗 Separation", "Pinggy is independent from normal SSH access. This action creates Pinggy only.", False)
                    add_field(access, "⚠️ Free Tunnel", "Pinggy free tunnels are temporary and reconnecting can create a new public endpoint.", False)
                    try:
                        owner = await bot.fetch_user(int(self.owner_id))
                        await owner.send(embed=access)
                        await interaction.followup.send(embed=create_success_embed("📨 Pinggy Sent", "Pinggy-only access details were sent to your DM."), ephemeral=True)
                    except discord.Forbidden:
                        await interaction.followup.send(embed=access, ephemeral=True)
                except Exception as e:
                    await interaction.followup.send(embed=create_error_embed("🌐 Pinggy Failed", safe_error_summary("Pinggy reconnect", e)), ephemeral=True)
                await self._refresh_dashboard(interaction)
                return

            if action == "ssh":
                if suspended:
                    await interaction.followup.send(embed=create_error_embed("⛔ Access Denied", "Cannot access a suspended VPS."), ephemeral=True)
                    return
                try:
                    # Use the same repair path as !ssh. This verifies guest sshd and
                    # reapplies a persisted NAT mapping before any endpoint is shown.
                    access_result = await ensure_vps_ssh_access(str(self.owner_id), target_vps, repair=True)
                    ssh_host = access_result['host']
                    ssh_port = access_result['port']
                    node_mode = access_result['mode']
                    endpoints = access_result['endpoints']
                    ssh_v4 = endpoints.get('ipv4') or ''
                    ssh_v6 = endpoints.get('ipv6') or ''
                    access = create_info_embed("💻 RGNODES™ SSH", f"`{container_name}` • `{VPS_HOSTNAME}`")
                    endpoint_label = 'Shared node IPv4 (NAT)' if node_mode=='nat' else 'Guest public IPv4'
                    if ssh_host and ssh_v4:
                        add_field(access, endpoint_label, f"```bash\nssh root@{ssh_v4} -p {ssh_port}\n```", False)
                    elif ssh_host and ssh_v6:
                        add_field(access, 'Guest public IPv6', f"```bash\nssh -6 root@[{ssh_v6}] -p {ssh_port}\n```", False)
                    if ssh_v6:
                        add_field(access, "🌐 SSH IPv6", f"```bash\nssh -6 root@[{ssh_v6}] -p {ssh_port}\n```", False)
                    else:
                        add_field(access, "🌐 SSH IPv6", "⚪ Public IPv6 unavailable on this node.", False)
                    add_field(access, "🔐 Credentials", f"Username: `root`\nPassword: `{access_result['password']}`", False)
                    try:
                        # Send access to the person who clicked Manage (including an
                        # authorized shared user), not automatically to the VPS owner.
                        await interaction.user.send(embed=access)
                        await interaction.followup.send(embed=create_success_embed("✅ SSH Sent", "SSH access details were sent to your DM."), ephemeral=True)
                    except discord.Forbidden:
                        await interaction.followup.send(embed=access, ephemeral=True)
                except Exception as e:
                    await interaction.followup.send(embed=create_error_embed("SSH Error", safe_error_summary("SSH access", e)), ephemeral=True)
                await self._refresh_dashboard(interaction)
                return

            if action in {"webssh", "sftp"}:
                if suspended:
                    await interaction.followup.send(embed=create_error_embed("⛔ VPS Suspended", "Access is disabled for a suspended VPS."), ephemeral=True)
                    return
                try:
                    # Repair SSH and reconcile the real endpoint before issuing either access method.
                    access_result = await ensure_vps_ssh_access(str(self.owner_id), target_vps, repair=True)
                    ssh_host, ssh_port, node_mode = access_result['host'], access_result['port'], access_result['mode']
                    access_password = access_result['password']
                except Exception as endpoint_exc:
                    await interaction.followup.send(embed=create_error_embed("VPS Access Not Ready", safe_error_summary('VPS access',endpoint_exc)), ephemeral=True)
                    return
                if action == "webssh":
                    if not WEB_TERMINAL_ENABLED or _WEB_TERMINAL_RUNNER is None:
                        await interaction.followup.send(embed=create_error_embed("Web SSH Unavailable", "The browser terminal service is not running. Enable WEB_TERMINAL_ENABLED, install requirements and restart the bot; then configure the HTTPS reverse proxy."), ephemeral=True)
                        return
                    ticket = issue_web_ssh_ticket(str(self.owner_id), container_name, ssh_host, int(ssh_port), "root")
                    access = create_success_embed("🌐 VPS Web SSH", f"A one-time Web SSH access token was created for `{container_name}`. It expires in {WEBSSH_TICKET_TTL // 60} minutes and is restricted to this VPS endpoint.")
                    add_field(access, "Terminal", WEB_TERMINAL_PUBLIC_URL, False)
                    add_field(access, "One-time access token", f"```text\n{ticket}\n```", False)
                    add_field(access, "SSH target", f"`root@{ssh_host}:{ssh_port}`", False)
                    add_field(access, "Network", "Shared node public IPv4 + unique forwarded port (NAT)." if node_mode=='nat' else "Guest-owned public IP (direct/bridge).", False)
                    add_field(access, "Root password", f"```text\n{access_password}\n```", False)
                    add_field(access, "Security", "The one-time token is restricted to this VPS endpoint.", False)
                else:
                    access = create_success_embed("📁 VPS File Access (SFTP)", f"Use an SFTP client to manage files on `{container_name}`. These are real SSH/SFTP details, not a simulated browser file manager.")
                    add_field(access, "Connection", f"Host: `{ssh_host}`\nPort: `{ssh_port}`\nProtocol: `SFTP`\nUsername: `root`\nPassword: `{access_password}`", False)
                    add_field(access, "Network", "Shared node IPv4 + unique host port (NAT)." if node_mode=='nat' else "Guest public IP (direct/bridge).", False)
                    add_field(access, "Example", f"```bash\nsftp -P {ssh_port} root@{ssh_host}\n```", False)
                    add_field(access, "Common SFTP commands", "`ls` · `cd /path` · `get file` · `put file` · `mkdir folder` · `rename old new` · `rm file`", False)
                try:
                    await interaction.user.send(embed=access)
                    await interaction.followup.send(embed=create_success_embed("📨 Private Access Sent", "Access details were sent to your DM. Keep the token/password private."), ephemeral=True)
                except discord.Forbidden:
                    await interaction.followup.send(embed=create_warning_embed("DM Not Delivered", "Enable DMs from this server and retry. Access credentials were not posted publicly."), ephemeral=True)
                await self._refresh_dashboard(interaction)
                return

            if action == "ports":
                forwards = get_user_forwards(self.owner_id)
                e = create_info_embed("🌐 Port Forwarding", f"**VPS:** `{container_name}`\n**Usage:** {len([f for f in forwards if str(f.get('vps_container')) == container_name])}/{get_user_allocation(self.owner_id)}")
                add_field(e, "Current Forwards", self._port_summary([f for f in forwards if str(f.get('vps_container')) == container_name]), False)
                await interaction.followup.send(embed=e, view=PortsView(self.owner_id, container_name, node_id), ephemeral=True)
                return

            if action == "regen_password":
                if suspended and not self.is_admin:
                    await interaction.followup.send(embed=create_error_embed("⛔ Access Denied", "Cannot reset a suspended VPS password."), ephemeral=True)
                    return
                new_password = generate_strong_password()
                success, result = await configure_ssh(container_name, node_id, new_password)
                if not success:
                    await interaction.followup.send(embed=create_error_embed("🔐 Password Reset Failed", str(result)[:900]), ephemeral=True)
                    return
                target_vps["root_password"] = new_password
                save_vps_data_immediate()
                e = create_success_embed("🔐 Password Reset", f"A new root password was generated for `{container_name}`.")
                add_field(e, "New Password", f"`{new_password}`\n🔒 Save this password securely.", False)
                await interaction.followup.send(embed=e, ephemeral=True)
                try:
                    owner = await bot.fetch_user(int(self.owner_id))
                    dm = create_success_embed("🔐 VPS Password Reset", f"Your VPS `{container_name}` has a new root password.")
                    add_field(dm, "Password", f"`{new_password}`\n🔒 Save this password securely.", False)
                    await owner.send(embed=dm)
                except Exception:
                    pass
                await self._refresh_dashboard(interaction)
                return

            if action == "reinstall":
                if self.is_shared:
                    await interaction.followup.send(embed=create_error_embed("Access Denied", "Reinstall is unavailable from a shared VPS view. Use the owner/admin management view."), ephemeral=True)
                    return
                if suspended:
                    await interaction.followup.send(embed=create_error_embed("⛔ Cannot Reinstall", "Unsuspend the VPS first."), ephemeral=True)
                    return
                try:
                    ram_gb = int(str(target_vps.get("ram", DEFAULT_VPS_RAM_GB)).lower().replace("gb", "").strip())
                    cpu = int(target_vps.get("cpu", DEFAULT_VPS_CPU))
                    storage_gb = int(str(target_vps.get("storage", DEFAULT_VPS_STORAGE_GB)).lower().replace("gb", "").strip())
                except Exception:
                    await interaction.followup.send(embed=create_error_embed("Invalid VPS Configuration", "The saved resource values are invalid. Contact support."), ephemeral=True)
                    return
                confirm_embed = create_warning_embed(
                    "⚠️ Reinstall VPS",
                    f"This will replace the OS on `{container_name}`. User data on the current OS will be erased.\n\n"
                    "The replacement is built and validated before the old container is removed, and persistent port rules are retained."
                )
                class ConfirmView(discord.ui.View):
                    def __init__(self, parent):
                        super().__init__(timeout=60)
                        self.parent = parent
                        self.owner_id = str(parent.owner_id)
                    @discord.ui.button(label="✅ Continue", style=discord.ButtonStyle.secondary)
                    async def confirm(self, inter: discord.Interaction, button: discord.ui.Button):
                        if str(inter.user.id) != self.parent.user_id:
                            await inter.response.send_message(embed=create_error_embed("Access Denied", "Only the VPS owner can confirm."), ephemeral=True)
                            return
                        await inter.response.send_message(embed=create_info_embed("💿 Select OS", "Choose the new operating system. The old VPS is not deleted until the OS is selected."), view=ReinstallOSSelectView(self.parent, container_name, self.owner_id, actual_idx, ram_gb, cpu, storage_gb, node_id), ephemeral=True)
                        self.stop()
                    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.secondary)
                    async def cancel(self, inter: discord.Interaction, button: discord.ui.Button):
                        if str(inter.user.id) != self.parent.user_id:
                            await inter.response.send_message(embed=create_error_embed("Access Denied", "Only the VPS owner can cancel."), ephemeral=True)
                            return
                        await inter.response.edit_message(content=None, embed=await self.parent.create_vps_embed(self.parent.selected_index), view=self.parent)
                        self.stop()
                await interaction.followup.send(embed=confirm_embed, view=ConfirmView(self), ephemeral=True)
                return

            if action == "start":
                if suspended:
                    await interaction.followup.send(embed=create_error_embed("⛔ VPS Suspended", "Use Renew for expiration suspension or ask an admin to unsuspend it."), ephemeral=True)
                    return
                try:
                    start_ram=_parse_gb(target_vps.get('ram', f'{DEFAULT_VPS_RAM_GB}GB'), DEFAULT_VPS_RAM_GB)
                    start_cpu=_parse_cpu(target_vps.get('cpu', DEFAULT_VPS_CPU), DEFAULT_VPS_CPU)
                    safe_start, start_reason = await check_node_capacity_for_start(node_id, container_name, start_ram, start_cpu)
                    if not safe_start:
                        await interaction.followup.send(embed=create_error_embed("🛡️ Start Blocked", start_reason), ephemeral=True)
                        return
                    await execute_vpsctl_compat(container_name, f"start {container_name}", timeout=180, node_id=node_id)
                except Exception as e:
                    msg = str(e).lower()
                    if "already running" not in msg and "is running" not in msg:
                        raise
                target_vps["status"] = "running"
                save_vps_data_immediate()
                try:
                    ram_mb_now = int(str(target_vps.get("ram", DEFAULT_VPS_RAM_GB)).lower().replace("gb", "").strip()) * 1024
                    await apply_vps_performance_profile(container_name, node_id, ram_mb_now, int(target_vps.get("cpu", DEFAULT_VPS_CPU)))
                except Exception as perf_error:
                    logger.debug(f"Performance profile refresh skipped for {container_name}: {perf_error}")
                await apply_internal_permissions(container_name, node_id)
                await install_anti_mining_guard(container_name, node_id)
                await apply_guest_motd(container_name, node_id)
                if DOCKER_INSTALL_ON_DEPLOY:
                    await ensure_docker_ready(container_name, node_id, strict=False)
                readded = await recreate_port_forwards(container_name)
                if not any(int(f.get("vps_port", 0)) == 22 for f in get_user_forwards(self.owner_id) if str(f.get("vps_container")) == container_name):
                    await create_port_forward(self.owner_id, container_name, 22, node_id)
                await interaction.followup.send(embed=create_success_embed("▶️ VPS Started", f"`{container_name}` is running.\n🔌 Restored **{readded}** port forwards."), ephemeral=True)
                await record_audit_event("vps", "VPS Started", f"Restored `{readded}` port forwards.", user_id=interaction.user.id, node_id=node_id, vps_container=container_name)
                await self._refresh_dashboard(interaction)
                return

            if action == "stop":
                try:
                    await execute_vpsctl_compat(container_name, f"stop {container_name} --force", timeout=180, node_id=node_id)
                except Exception as e:
                    msg = str(e).lower()
                    if not any(x in msg for x in ("not running", "already stopped", "is stopped")):
                        raise
                target_vps["status"] = "stopped"
                save_vps_data_immediate()
                await interaction.followup.send(embed=create_success_embed("⏸️ VPS Stopped", f"`{container_name}` is stopped."), ephemeral=True)
                await record_audit_event("vps", "VPS Stopped", "Dashboard stop completed.", user_id=interaction.user.id, node_id=node_id, vps_container=container_name)
                await self._refresh_dashboard(interaction)
                return

            if action == "delete":
                if self.is_shared and not self.is_admin:
                    await interaction.followup.send(embed=create_error_embed("Access Denied", "Delete from a shared dashboard is owner/admin restricted."), ephemeral=True)
                    return
                class DeleteConfirm(discord.ui.View):
                    def __init__(self, parent):
                        super().__init__(timeout=45)
                        self.parent = parent
                        self.confirmed = False
                    @discord.ui.button(label="🗑️ Delete VPS", style=discord.ButtonStyle.secondary)
                    async def confirm(self, inter: discord.Interaction, button: discord.ui.Button):
                        if str(inter.user.id) != self.parent.user_id and not self.parent.is_admin:
                            await inter.response.send_message(embed=create_error_embed("Access Denied", "Only the VPS owner or an admin can delete this VPS."), ephemeral=True)
                            return
                        self.confirmed = True
                        await inter.response.defer()
                        self.stop()
                    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.secondary)
                    async def cancel(self, inter: discord.Interaction, button: discord.ui.Button):
                        if str(inter.user.id) != self.parent.user_id and not self.parent.is_admin:
                            await inter.response.send_message(embed=create_error_embed("Access Denied", "Only the VPS owner or an admin can cancel."), ephemeral=True)
                            return
                        await inter.response.edit_message(embed=await self.parent.create_vps_embed(self.parent.selected_index), view=self.parent)
                        self.stop()
                confirm = DeleteConfirm(self)
                await interaction.followup.send(embed=create_warning_embed("⚠️ Delete VPS", f"Permanently delete `{container_name}` and its forwarding rules? **This cannot be undone.**"), view=confirm, ephemeral=True)
                await confirm.wait()
                if not confirm.confirmed:
                    return
                try:
                    backup_database()
                    await execute_vpsctl_compat(container_name, f"delete {container_name} --force", timeout=300, node_id=node_id)
                    with DB_LOCK:
                        conn = get_db()
                        try:
                            conn.execute("DELETE FROM port_forwards WHERE vps_container = ?", (container_name,))
                            conn.execute("DELETE FROM vps WHERE container_name = ?", (container_name,))
                            conn.commit()
                        finally:
                            conn.close()
                    owner_list = [v for v in vps_data.get(self.owner_id, []) if str(v.get("container_name")) != container_name]
                    if owner_list:
                        vps_data[self.owner_id] = owner_list
                    else:
                        vps_data.pop(self.owner_id, None)
                    save_vps_data_immediate()
                    await interaction.followup.send(embed=create_success_embed("🗑️ VPS Deleted", f"`{container_name}` has been deleted."), ephemeral=True)
                    await record_audit_event("vps", "VPS Deleted", "Dashboard deletion completed.", user_id=interaction.user.id, node_id=node_id, vps_container=container_name)
                    try:
                        await interaction.message.edit(embed=create_info_embed("🗑️ VPS Deleted", "This VPS no longer exists."), view=None)
                    except Exception:
                        pass
                except Exception as e:
                    await interaction.followup.send(embed=create_error_embed("❌ Delete Failed", safe_error_summary("VPS deletion", e)), ephemeral=True)
                return

            await interaction.followup.send(embed=create_error_embed("Unknown Action", f"Unsupported dashboard action: `{action}`"), ephemeral=True)
        except Exception as e:
            error_id = secrets.token_hex(4).upper()
            logger.error(f"Manage action {action} failed for VPS: {container_name if 'container_name' in locals() else 'unknown'} [{error_id}]: {e}", exc_info=True)
            safe_message = "The requested action could not be completed. The operation was stopped safely and logged."
            safe_message += f"\n\n{safe_error_summary('VPS management action', e)}\n**Error ID:** `{error_id}`"
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(embed=create_error_embed("⚠️ Action Failed", safe_message), ephemeral=True)
                else:
                    await interaction.followup.send(embed=create_error_embed("⚠️ Action Failed", safe_message), ephemeral=True)
            except Exception:
                try:
                    await interaction.followup.send(embed=create_error_embed("⚠️ Action Failed", safe_message), ephemeral=True)
                except Exception:
                    pass

@bot.command(name='manage')
async def manage_vps(ctx, user: discord.Member = None):
    if user:
        if not is_admin_user(ctx.author):
            await ctx.send(embed=create_error_embed("Access Denied", "Only admins can manage other users' VPS."))
            return
        user_id = str(user.id)
        vps_list = vps_data.get(user_id, [])
        if not vps_list:
            await ctx.send(embed=create_error_embed("No VPS Found", f"{user.mention} doesn't have any {BOT_NAME} VPS."))
            return
        view = ManageView(str(ctx.author.id), vps_list, is_admin=True, owner_id=user_id)
        await ctx.send(embed=create_info_embed(f"Managing {user.name}'s VPS", f"Managing VPS for {user.mention}"), view=view)
    else:
        user_id = str(ctx.author.id)
        vps_list = vps_data.get(user_id, [])
        if not vps_list:
            embed = create_error_embed("No VPS Found", f"You don't have any {BOT_NAME} VPS. Contact an admin to create one.")
            add_field(embed, "Quick Actions", f"• `{PREFIX}manage` - Manage VPS\n• Contact admin for VPS creation", False)
            await ctx.send(embed=embed)
            return
        view = ManageView(user_id, vps_list, is_admin=is_admin_user(ctx.author))
        embed = await view.get_initial_embed()
        await ctx.send(embed=embed, view=view)

async def get_node_status(node_id: int) -> str:
    node = get_node(node_id)
    if not node:
        return "❓ Unknown"
    if node['is_local']:
        return "🟢 Online (Local)"
    # Remote nodes - check connectivity but don't spam errors
    try:
        response = await asyncio.to_thread(requests.get, str(node['url']).rstrip('/') + '/api/ping', headers={'X-API-Key': str(node['api_key'])}, timeout=5)
        if response.status_code == 200:
            return "🟢 Online"
        else:
            return "🔴 Offline (Network unreachable)"
    except requests.exceptions.ConnectionError:
        return "🔴 Unreachable (Network issue)"
    except requests.exceptions.Timeout:
        return "🔴 No response"
    except Exception:
        return "🔴 Offline"


def get_host_disk_usage():
    """Get host disk usage - cross-platform compatible"""
    try:
        import platform
        system = platform.system()
        
        if system == "Windows":
            # Windows: Use wmic or psutil
            try:
                import psutil
                disk = psutil.disk_usage('/')
                return f"{disk.used // (1024**3)} GB / {disk.total // (1024**3)} GB ({disk.percent}%)"
            except ImportError:
                # Fallback for Windows without psutil
                try:
                    result = subprocess.run(['wmic', 'LogicalDisk', 'get', 'Size,FreeSpace'], 
                                          capture_output=True, text=True, timeout=5)
                    lines = result.stdout.strip().split('\n')
                    if len(lines) > 1:
                        values = lines[1].split()
                        if len(values) >= 2:
                            size = int(values[0]) // (1024**3)
                            free = int(values[1]) // (1024**3)
                            used = size - free
                            percent = (used / size * 100) if size > 0 else 0
                            return f"{used} GB / {size} GB ({percent:.0f}%)"
                except:
                    pass
                return "Unknown"
        else:
            # Linux/Unix: Use df command
            result = subprocess.run(['df', '-h', '/'], capture_output=True, text=True, timeout=10)
            lines = result.stdout.splitlines()
            if len(lines) > 1:
                parts = lines[1].split()
                if len(parts) >= 5:
                    used = parts[2]
                    size = parts[1]
                    perc = parts[4]
                    return f"{used}/{size} ({perc})"
            return "Unknown"
    except Exception as e:
        logger.debug(f"Error getting disk usage: {e}")
        return "Unknown"




@bot.command(name='vps-list')
@is_admin()
async def vps_list(ctx, node_id: int = 1):
    node = get_node(node_id)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"Node ID {node_id} not found."))
        return

    # Get node status
    node_status = await get_node_status(node_id)
    is_online = node_status.startswith("🟢")

    # Get node resource stats (will use defaults if offline)
    stats = await get_host_stats(node_id)
    cpu_usage = stats.get('cpu', 0.0)
    ram_usage = stats.get('ram', 0.0)
    disk_usage = stats.get('disk', 'Unknown')

    # Resources field text (modern: compact inline stats with progress-like emojis)
    if is_online:
        resources_text = (
            f"**CPU** {cpu_usage:.0f}% {'█' * int(cpu_usage / 5) + '░' * (20 - int(cpu_usage / 5))} "
            f"\n**RAM** {ram_usage:.0f}% {'█' * int(ram_usage / 5) + '░' * (20 - int(ram_usage / 5))} "
            f"\n**Disk** {disk_usage}"
        )
    else:
        resources_text = "⚠️ Resources unavailable (Offline)"

    # Get VPS capacity
    current_vps = get_current_vps_count(node_id)
    total_capacity = node['total_vps']
    capacity_percent = (current_vps / total_capacity * 100) if total_capacity > 0 else 0
    capacity_text = f"{current_vps}/{total_capacity} ({capacity_percent:.0f}%)"

    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT * FROM vps WHERE node_id = ?', (node_id,))
    rows = cur.fetchall()
    conn.close()

    total_vps = len(rows)

    # Modern counters: use more intuitive emojis and clean layout
    running = 0
    stopped = 0
    suspended = 0
    other = 0
    vps_info = []
    for i, row in enumerate(rows, 1):
        vps = dict(row)
        user_id = vps['user_id']
        try:
            user = await bot.fetch_user(int(user_id))
            username = user.name
        except:
            username = f"Unknown ({user_id})"

        vps_state = vps.get('status', 'unknown')
        suspended_flag = vps.get('suspended', False)

        # Count logic: suspended first, then status if not suspended
        if suspended_flag:
            suspended += 1
        elif vps_state == 'running':
            running += 1
        elif vps_state == 'stopped':
            stopped += 1
        else:
            other += 1

        # Modern emoji: vibrant and status-specific
        status_emoji = "🟢" if vps_state == 'running' and not suspended_flag else "🟡" if suspended_flag else "🔴"
        vps_status = vps_state.upper()
        if suspended_flag:
            vps_status += " (SUSPENDED)"
        if vps.get('whitelisted', False):
            vps_status += " (WHITELISTED)"
        config = vps.get('config', 'Custom')
        
        # Add expiration info
        expiration_info = ""
        if vps.get('expiration_date'):
            expiration_dt = datetime.fromisoformat(vps['expiration_date'])
            days_remaining = (expiration_dt - datetime.now()).days
            if days_remaining < 0:
                expiration_info = " | 🔴 EXPIRED"
            elif days_remaining <= EXPIRATION_WARNING_DAYS:
                expiration_info = f" | 🟡 EXPIRES({days_remaining}d)"
            else:
                expiration_info = f" | 🟢 ({days_remaining}d)"
        else:
            expiration_info = " | ⏰ No exp"
        
        product_type = str(vps.get("product_type") or ("DOCKER" if str(config).lower().startswith("docker vps") else "KVM")).upper()
        product_label = "🐳 Docker VPS" if product_type == "DOCKER" else "🖥️ KVM VPS"
        vps_info.append(f"{status_emoji} **{i}.** {username} • `{vps['container_name']}`\n _{product_label} | {vps_status} | {config}{expiration_info}_")

    # Create main embed (modern: gradient-inspired colors, clean typography)
    embed = create_embed(
        title=f"🖥️ VPS Dashboard - {node['name']}",
        description=f"**ID:** `{node_id}` | **Region:** {node['location']}\n*Updated: <t:{int(datetime.now().timestamp())}:R>*"
    )
    embed.set_thumbnail(url=node.get('thumbnail_url', None))

    # Inline status and capacity for compact top row
    add_field(embed, "📡 **Status**", node_status, True)
    add_field(embed, "🗄️ **Capacity**", capacity_text, True)

    # Resources field with modern bar visualization
    add_field(embed, "📊 **Resources**", resources_text, False)

    # Summary field (modern: compact bullet-like with inline emojis)
    summary_text = (
        f"**Total:** {total_vps} 📊\n"
        f"**Running:** {running} 🟢\n"
        f"**Stopped:** {stopped} ⏸️\n"
        f"**Suspended:** {suspended} 🟡"
    )
    if other > 0:
        summary_text += f"\n**Other:** {other} ⚠️"
    add_field(embed, "📈 **Summary**", summary_text, True)

    # VPS List - chunked embeds with modern pagination
    if vps_info:
        chunk_size = 6  # Smaller chunks for cleaner mobile-friendly embeds
        chunks = [vps_info[i:i + chunk_size] for i in range(0, len(vps_info), chunk_size)]
        first_chunk_text = "\n".join(chunks[0])
        add_field(embed, f"📋 **Active VPS (1/{len(chunks)})**", f"```{first_chunk_text}```", False)

        # Paginated follow-ups with consistent styling
        for idx, chunk in enumerate(chunks[1:], 2):
            page_embed = create_embed(
                title=f"🖥️ VPS Dashboard - {node['name']} (Page {idx}/{len(chunks)})",
                description=f"**ID:** `{node_id}` | **Region:** {node['location']}\n*Updated: <t:{int(datetime.now().timestamp())}:R>*"
            )
            chunk_text = "\n".join(chunk)
            add_field(page_embed, "📋 **VPS List**", f"```{chunk_text}```", False)
            page_embed.set_footer(text=f"⚡ RGNODES™ • {len(vps_info)} VPS shown")
            await ctx.send(embed=page_embed)
    else:
        add_field(embed, "📋 **VPS List**", "No deployments yet. Launch one! 🚀", False)

    embed.set_footer(text=f"⚡ RGNODES™ • Total: {len(vps_info)} VPS")
    await ctx.send(embed=embed)

@bot.command(name='list-all')
@is_admin()
async def list_all_vps(ctx):
    total_vps = 0
    total_users = len(vps_data)
    running_vps = 0
    stopped_vps = 0
    suspended_vps = 0
    whitelisted_vps = 0
    vps_info = []
    user_summary = []
    for user_id, vps_list in vps_data.items():
        try:
            user = await bot.fetch_user(int(user_id))
            user_vps_count = len(vps_list)
            user_running = sum(1 for vps in vps_list if vps.get('status') == 'running' and not vps.get('suspended', False))
            user_stopped = sum(1 for vps in vps_list if vps.get('status') == 'stopped')
            user_suspended = sum(1 for vps in vps_list if vps.get('suspended', False))
            user_whitelisted = sum(1 for vps in vps_list if vps.get('whitelisted', False))
            total_vps += user_vps_count
            running_vps += user_running
            stopped_vps += user_stopped
            suspended_vps += user_suspended
            whitelisted_vps += user_whitelisted
            user_summary.append(f"**{user.name}** ({user.mention}) - {user_vps_count} VPS ({user_running} running, {user_suspended} suspended, {user_whitelisted} whitelisted)")
            for i, vps in enumerate(vps_list):
                node = get_node(vps['node_id'])
                node_name = node['name'] if node else "Unknown"
                status_emoji = "🟢" if vps.get('status') == 'running' and not vps.get('suspended', False) else "🟡" if vps.get('suspended', False) else "🔴"
                status_text = vps.get('status', 'unknown').upper()
                if vps.get('suspended', False):
                    status_text += " (SUSPENDED)"
                if vps.get('whitelisted', False):
                    status_text += " (WHITELISTED)"
                
                # Add expiration info
                expiration_text = ""
                if vps.get('expiration_date'):
                    expiration_dt = datetime.fromisoformat(vps['expiration_date'])
                    days_remaining = (expiration_dt - datetime.now()).days
                    if days_remaining < 0:
                        expiration_text = " • 🔴 EXPIRED"
                    elif days_remaining <= EXPIRATION_WARNING_DAYS:
                        expiration_text = f" • 🟡 EXPIRING({days_remaining}d)"
                    else:
                        expiration_text = f" • 🟢 ({days_remaining}d)"
                else:
                    expiration_text = " • ⏰ No exp"
                
                vps_info.append(f"{status_emoji} **{user.name}** - VPS {i+1}: `{vps['container_name']}` - {vps.get('config', 'Custom')} - {status_text} (Node: {node_name}){expiration_text}")
        except discord.NotFound:
            vps_info.append(f"❓ Unknown User ({user_id}) - {len(vps_list)} VPS")
    embed = create_embed("All VPS Information", "Complete overview of all VPS deployments and user statistics", 0x1a1a1a)
    add_field(embed, "System Overview", f"**Total Users:** {total_users}\n**Total VPS:** {total_vps}\n**Running:** {running_vps}\n**Stopped:** {stopped_vps}\n**Suspended:** {suspended_vps}\n**Whitelisted:** {whitelisted_vps}", False)
    await ctx.send(embed=embed)
    if user_summary:
        embed = create_embed("User Summary", f"Summary of all users and their VPS", 0x1a1a1a)
        summary_text = "\n".join(user_summary)
        chunks = [summary_text[i:i+1024] for i in range(0, len(summary_text), 1024)]
        for idx, chunk in enumerate(chunks, 1):
            add_field(embed, f"Users (Part {idx})", chunk, False)
        await ctx.send(embed=embed)
    if vps_info:
        vps_text = "\n".join(vps_info)
        chunks = [vps_text[i:i+1024] for i in range(0, len(vps_text), 1024)]
        for idx, chunk in enumerate(chunks, 1):
            embed = create_embed(f"VPS Details (Part {idx})", "List of all VPS deployments", 0x1a1a1a)
            add_field(embed, "VPS List", chunk, False)
            await ctx.send(embed=embed)

def _find_owned_vps_reference(owner_id: int | str, reference: str):
    """Resolve a stable VPS ID/container name, with old 1-based indexes kept for compatibility."""
    items = vps_data.get(str(owner_id), [])
    ref = str(reference).strip()
    for idx, item in enumerate(items):
        if ref == str(item.get("container_name")) or ref == str(item.get("vmid") or item.get("id")):
            return idx, item
    if ref.isdigit():
        legacy_index = int(ref) - 1
        if 0 <= legacy_index < len(items):
            return legacy_index, items[legacy_index]
    return None, None


@bot.command(name='manage-shared')
async def manage_shared_vps(ctx, owner: discord.Member, vps_ref: str):
    owner_id = str(owner.id)
    user_id = str(ctx.author.id)
    idx, vps = _find_owned_vps_reference(owner_id, vps_ref)
    if vps is None:
        await ctx.send(embed=create_error_embed("Invalid VPS", "No VPS ID/name/index matched for that owner."))
        return
    if user_id not in {str(x) for x in vps.get("shared_with", [])}:
        await ctx.send(embed=create_error_embed("Access Denied", "You do not have access to this VPS."))
        return
    view = ManageView(user_id, [vps], is_shared=True, owner_id=owner_id, is_admin=is_admin_user(ctx.author), actual_index=idx)
    embed = await view.get_initial_embed()
    await ctx.send(embed=embed, view=view)

@bot.command(name='share-user')
async def share_user(ctx, shared_user: discord.Member, vps_ref: str):
    user_id = str(ctx.author.id)
    shared_user_id = str(shared_user.id)
    idx, vps = _find_owned_vps_reference(user_id, vps_ref)
    if vps is None:
        await ctx.send(embed=create_error_embed("Invalid VPS", "No VPS ID/name/index matched your account."))
        return
    vmid = vps.get("vmid") or vps.get("id") or (idx + 1)
    if "shared_with" not in vps:
        vps["shared_with"] = []
    if shared_user_id in vps["shared_with"]:
        await ctx.send(embed=create_error_embed("Already Shared", f"{shared_user.mention} already has access to this VPS!"))
        return
    vps["shared_with"].append(shared_user_id)
    save_vps_data_immediate()
    await ctx.send(embed=create_success_embed("VPS Shared", f"VPS ID `{vmid}` shared with {shared_user.mention}!"))
    try:
        await shared_user.send(embed=create_info_embed("VPS Access Granted", f"You have access to VPS ID `{vmid}` from {ctx.author.mention}. Use `{PREFIX}manage-shared {ctx.author.mention} {vmid}`."))
    except discord.Forbidden:
        await ctx.send(embed=create_info_embed("Notification Failed", f"Could not DM {shared_user.mention}"))

@bot.command(name='share-ruser', aliases=['share-revoke', 'share-remove-user'])
async def revoke_share(ctx, shared_user: discord.Member, vps_ref: str):
    user_id = str(ctx.author.id)
    shared_user_id = str(shared_user.id)
    idx, vps = _find_owned_vps_reference(user_id, vps_ref)
    if vps is None:
        await ctx.send(embed=create_error_embed("Invalid VPS", "No VPS ID/name/index matched your account."))
        return
    vmid = vps.get("vmid") or vps.get("id") or (idx + 1)
    if "shared_with" not in vps:
        vps["shared_with"] = []
    if shared_user_id not in vps["shared_with"]:
        await ctx.send(embed=create_error_embed("Not Shared", f"{shared_user.mention} doesn't have access to this VPS!"))
        return
    vps["shared_with"].remove(shared_user_id)
    save_vps_data_immediate()
    await ctx.send(embed=create_success_embed("Access Revoked", f"Access to VPS ID `{vmid}` revoked from {shared_user.mention}!"))
    try:
        await shared_user.send(embed=create_warning_embed("VPS Access Revoked", f"Your access to VPS ID `{vmid}` by {ctx.author.mention} has been revoked."))
    except discord.Forbidden:
        await ctx.send(embed=create_info_embed("Notification Failed", f"Could not DM {shared_user.mention}"))

@bot.command(name='ports-add-user')
@is_admin()
async def ports_add_user(ctx, amount: int, user: discord.Member):
    if amount <= 0:
        await ctx.send(embed=create_error_embed("Invalid Amount", "Amount must be a positive integer."))
        return
    user_id = str(user.id)
    allocate_ports(user_id, amount)
    embed = create_success_embed("Ports Allocated", f"Allocated {amount} port slots to {user.mention}.")
    add_field(embed, "Quota", f"Total: {get_user_allocation(user_id)} slots", False)
    await ctx.send(embed=embed)
    try:
        dm_embed = create_info_embed("Port Slots Allocated", f"You have been granted {amount} additional port forwarding slots by an admin.\nUse `{PREFIX}ports list` to view your quota and active forwards.")
        await user.send(embed=dm_embed)
    except discord.Forbidden:
        await ctx.send(embed=create_info_embed("DM Failed", f"Could not notify {user.mention} via DM."))

@bot.command(name='ports-remove-user')
@is_admin()
async def ports_remove_user(ctx, amount: int, user: discord.Member):
    if amount <= 0:
        await ctx.send(embed=create_error_embed("Invalid Amount", "Amount must be a positive integer."))
        return
    user_id = str(user.id)
    current = get_user_allocation(user_id)
    if amount > current:
        amount = current
    deallocate_ports(user_id, amount)
    remaining = get_user_allocation(user_id)
    embed = create_success_embed("Ports Deallocated", f"Removed {amount} port slots from {user.mention}.")
    add_field(embed, "Remaining Quota", f"{remaining} slots", False)
    await ctx.send(embed=embed)
    try:
        dm_embed = create_warning_embed("Port Slots Reduced", f"Your port forwarding quota has been reduced by {amount} slots by an admin.\nRemaining: {remaining} slots.")
        await user.send(embed=dm_embed)
    except discord.Forbidden:
        await ctx.send(embed=create_info_embed("DM Failed", f"Could not notify {user.mention} via DM."))

@bot.command(name='ports-revoke')
@is_admin()
async def ports_revoke(ctx, forward_id: int):
    success, user_id = await remove_port_forward(forward_id, is_admin=True)
    if success and user_id:
        try:
            user = await bot.fetch_user(int(user_id))
            dm_embed = create_warning_embed("Port Forward Revoked", f"One of your port forwards (ID: {forward_id}) has been revoked by an admin.")
            await user.send(embed=dm_embed)
        except:
            pass
        await ctx.send(embed=create_success_embed("Revoked", f"Port forward ID {forward_id} revoked."))
    else:
        await ctx.send(embed=create_error_embed("Failed", "Port forward ID not found or removal failed."))

@bot.command(name='ports')
async def ports_command(ctx, subcmd: str = None, *args):
    user_id = str(ctx.author.id)
    allocated = ensure_user_port_allocation(user_id) if user_has_vps(user_id) else get_user_allocation(user_id)
    used = get_user_used_ports(user_id)
    available = allocated - used
    if subcmd is None:
        embed = create_info_embed("Port Forwarding Help", f"**Your Quota:** Allocated: {allocated}, Used: {used}, Available: {available}")
        add_field(embed, "Commands", f"{PREFIX}ports add <vps_num> <port>\n{PREFIX}ports list\n{PREFIX}ports remove <id>", False)
        await ctx.send(embed=embed)
        return
    if subcmd == 'add':
        if len(args) < 2:
            await ctx.send(embed=create_error_embed("Usage", f"Usage: {PREFIX}ports add <vps_number> <vps_port>"))
            return
        try:
            vps_num = int(args[0])
            vps_port = int(args[1])
            if vps_port < 1 or vps_port > 65535:
                raise ValueError
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid Input", "VPS number and port must be positive integers (port: 1-65535)."))
            return
        vps_list = vps_data.get(user_id, [])
        if vps_num < 1 or vps_num > len(vps_list):
            await ctx.send(embed=create_error_embed("Invalid VPS", f"Invalid VPS number (1-{len(vps_list)}). Use {PREFIX}myvps to list."))
            return
        vps = vps_list[vps_num - 1]
        container = vps['container_name']
        node_id = vps['node_id']
        if used >= allocated:
            await ctx.send(embed=create_error_embed("Quota Exceeded", f"No available slots. Allocated: {allocated}, Used: {used}. Contact admin for more."))
            return
        host_port = await create_port_forward(user_id, container, vps_port, node_id)
        if host_port:
            endpoints = await detect_public_endpoints(int(node_id), container)
            v4 = endpoints.get("ipv4") or "Unavailable"
            v6 = endpoints.get("ipv6") or "Unavailable"
            embed = create_success_embed("🌐 Public Port Reserved", f"VPS #{vps_num} port {vps_port} (TCP/UDP) reservation is saved for direct public-IP access. External reachability requires the guest service to listen, guest firewall rules to be applied, and provider routing/firewall to allow the port. No host-NAT mapping is fabricated.")
            add_field(embed, "🌐 Public Access", f"IPv4: `{v4}:{vps_port}`\nIPv6: `{v6}:{vps_port}`", False)
            add_field(embed, "🎯 Target", f"VPS `{container}` → port `{vps_port}` (TCP + UDP)\nExternal access requires the guest service to listen and the provider network to allow the port.", False)
            add_field(embed, "Quota Update", f"Used: {used + 1}/{allocated}", False)
            await ctx.send(embed=embed)
        else:
            await ctx.send(embed=create_error_embed("Failed", "Could not reserve the public port. Try again later."))
    elif subcmd == 'list':
        forwards = get_user_forwards(user_id)
        embed = create_info_embed("Your Port Forwards", f"**Quota:** Allocated: {allocated}, Used: {used}, Available: {available}")
        if not forwards:
            add_field(embed, "Forwards", "No active port forwards.", False)
        else:
            text = []
            for f in forwards:
                vps_num = next((i+1 for i, v in enumerate(vps_data.get(user_id, [])) if v['container_name'] == f['vps_container']), 'Unknown')
                created = datetime.fromisoformat(f['created_at']).strftime('%Y-%m-%d %H:%M')
                text.append(f"**ID {f['id']}** - VPS #{vps_num}: {f['vps_port']} (TCP/UDP) → {f['host_port']} (Created: {created})")
            add_field(embed, "Active Forwards", "\n".join(text[:10]), False)
            if len(forwards) > 10:
                add_field(embed, "Note", f"Showing 10 of {len(forwards)}. Remove unused with {PREFIX}ports remove <id>.")
        await ctx.send(embed=embed)
    elif subcmd == 'remove':
        if len(args) < 1:
            await ctx.send(embed=create_error_embed("Usage", f"Usage: {PREFIX}ports remove <forward_id>"))
            return
        try:
            fid = int(args[0])
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid ID", "Forward ID must be an integer."))
            return
        success, _ = await remove_port_forward(fid, requester_id=user_id, is_admin=is_admin_user(ctx.author))
        if success:
            embed = create_success_embed("Removed", f"Port forward {fid} removed (TCP & UDP).")
            add_field(embed, "Quota Update", f"Used: {max(0, used - 1)}/{allocated}", False)
            await ctx.send(embed=embed)
        else:
            await ctx.send(embed=create_error_embed("Not Found", "Forward ID not found. Use !ports list."))
    else:
        await ctx.send(embed=create_error_embed("Invalid Subcommand", f"Use: add <vps_num> <port>, list, remove <id>"))

class ConfirmDeleteView(RGNODESView):
    """Confirmation dialog for VPS deletion"""
    def __init__(self, admin_id: str, vps_id: int, container_name: str, vps_number: int):
        super().__init__(timeout=60)  # 60 seconds to confirm
        self.admin_id = admin_id  # Admin who initiated the delete command
        self.vps_id = vps_id
        self.container_name = container_name
        self.vps_number = vps_number
        self.confirmed = False
    
    @discord.ui.button(label="✅ Confirm Delete", style=discord.ButtonStyle.secondary)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Allow only the admin who initiated the delete command to confirm
        if str(interaction.user.id) != self.admin_id:
            await interaction.response.send_message(
                embed=create_error_embed("Access Denied", "Only the admin who initiated the deletion can confirm!"),
                ephemeral=True
            )
            return
        
        self.confirmed = True
        await interaction.response.defer()
        self.stop()
    
    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Allow only the admin who initiated the delete command to cancel
        if str(interaction.user.id) != self.admin_id:
            await interaction.response.send_message(
                embed=create_error_embed("Access Denied", "Only the admin who initiated the deletion can cancel!"),
                ephemeral=True
            )
            return
        
        await interaction.response.send_message(
            embed=create_info_embed("Deletion Cancelled", f"VPS deletion for {self.container_name} has been cancelled."),
            ephemeral=True
        )
        self.stop()

@bot.command(name='delete-vps')
@is_admin()
async def delete_vps(ctx, user: discord.Member, vps_number: int, *, reason: str = "No reason"):
    user_id = str(user.id)

    if user_id not in vps_data or vps_number < 1 or vps_number > len(vps_data[user_id]):
        await ctx.send(embed=create_error_embed(
            "Invalid VPS",
            "Invalid VPS number or user doesn't have that VPS."
        ))
        return

    vps = vps_data[user_id][vps_number - 1]
    container_name = vps["container_name"]
    vps_id = vps.get("id", vps_number)
    node_id = vps.get("node_id", 1)

    # Create confirmation embed with clearer info
    confirm_embed = create_embed("⚠️ Confirm VPS Deletion", f"Are you sure you want to delete this VPS?", 0xff3366)
    add_field(confirm_embed, "VPS Details", 
        f"**VPS ID:** #{vps_id}\n"
        f"**VPS Name:** `{container_name}`\n"
        f"**Owner:** {user.mention}\n"
        f"**Config:** {vps.get('config', 'Custom')}\n"
        f"**Status:** {vps.get('status', 'unknown').upper()}", 
        False)
    add_field(confirm_embed, "Action", "Click **✅ Confirm Delete** to permanently delete this VPS, or **❌ Cancel** to abort.", False)
    add_field(confirm_embed, "Reason", reason, False)
    
    confirmation_view = ConfirmDeleteView(str(ctx.author.id), vps_id, container_name, vps_number)
    confirmation_msg = await ctx.send(embed=confirm_embed, view=confirmation_view)
    
    # Wait for confirmation
    await confirmation_view.wait()
    
    if not confirmation_view.confirmed:
        return  # User cancelled or timeout
    
    # Proceed with deletion
    await ctx.send(embed=create_info_embed(
        "🗑️ Deleting VPS",
        f"Removing VPS #{vps_id} for {user.mention}..."
    ))

    node_result = "Not checked"

    # Re-resolve the record after confirmation because another admin action could
    # have changed the owner's VPS list while the confirmation dialog was open.
    current_user_id, current_index, current_vps = find_vps_record(container_name)
    if not current_vps or str(current_user_id) != user_id:
        await ctx.send(embed=create_error_embed("Deletion Aborted", "This VPS record changed or was removed while waiting for confirmation."))
        return
    vps = current_vps
    node_id = int(vps.get("node_id", node_id))

    # 1️⃣ Delete the real VPS first. A failed remote/local deletion must NOT
    # silently erase the DB record and leave an unmanaged running container.
    container_missing = False
    try:
        await execute_vpsctl_compat(container_name, f"delete {container_name} --force", timeout=300, node_id=node_id)
        node_result = "Container deleted successfully."
    except Exception as e:
        err = str(e).lower()
        if any(x in err for x in ["not found", "does not exist", "no such container"]):
            container_missing = True
            node_result = "Container was already absent; database cleanup continued."
        else:
            await ctx.send(embed=create_error_embed("Deletion Failed", "The KVM VPS could not be deleted, so its database record was kept. " + safe_error_summary("VPS deletion", e)))
            return

    # 2️⃣ Remove persistent database records only after the container operation
    # succeeded or the container was confirmed absent. Keep a recovery snapshot first.
    backup_database()
    try:
        with DB_LOCK:
            conn = get_db()
            try:
                cur = conn.cursor()
                cur.execute("DELETE FROM port_forwards WHERE vps_container = ?", (container_name,))
                cur.execute("DELETE FROM vps WHERE container_name = ?", (container_name,))
                if cur.rowcount != 1:
                    raise RuntimeError("VPS database record was not found at commit time.")
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()
    except Exception as db_error:
        # The KVM VPS is already gone here; keep a recovery-style message because the
        # instance can no longer be operated. The DB failure is logged loudly.
        logger.critical(f"Container {container_name} deleted but DB cleanup failed: {db_error}", exc_info=True)
        await ctx.send(embed=create_error_embed("Database Cleanup Failed", "The KVM VPS was deleted, but the database cleanup did not complete. Check the bot logs and database backup before retrying."))
        return

    # 3️⃣ Remove the exact record from memory.
    try:
        vps_data[user_id] = [v for v in vps_data.get(user_id, []) if v.get("container_name") != container_name]
        if not vps_data[user_id]:
            del vps_data[user_id]
            if ctx.guild:
                role = await get_or_create_vps_role(ctx.guild)
                if role and role in user.roles:
                    try:
                        await user.remove_roles(role, reason="No VPS ownership")
                    except discord.Forbidden:
                        logger.warning(f"Failed to remove VPS role from {user.name}")
    finally:
        save_vps_data_immediate()

    # 4️⃣ Success embed
    embed = create_success_embed("✅ VPS Deleted Successfully")
    add_field(embed, "VPS ID", f"#{vps_id}", True)
    add_field(embed, "Owner", user.mention, True)
    add_field(embed, "Container", container_name, False)
    add_field(embed, "Node Result", node_result, False)
    add_field(embed, "Reason", reason, False)

    await ctx.send(embed=embed)

@bot.command(name='add-resources')
@is_admin()
async def add_resources(ctx, vps_id: str, ram: int = None, cpu: int = None, disk: int = None):
    if ram is None and cpu is None and disk is None:
        await ctx.send(embed=create_error_embed("Missing Parameters", "Please specify at least one resource to add (ram, cpu, or disk)"))
        return
    user_id, vps_index, found_vps = find_vps_record(vps_id)
    if not found_vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS found with ID/name: `{vps_id}`"))
        return
    vps_id = found_vps['container_name']
    node_id = int(found_vps.get('node_id', 1))
    try:
        current_ram = _parse_gb(found_vps.get('ram', '1GB'), 1)
        current_cpu = _parse_cpu(found_vps.get('cpu', 1), 1)
        current_disk = _parse_gb(found_vps.get('storage', f'{DEFAULT_VPS_STORAGE_GB}GB'), DEFAULT_VPS_STORAGE_GB)
        new_ram = current_ram + int(ram or 0)
        new_cpu = current_cpu + int(cpu or 0)
        new_disk = current_disk + int(disk or 0)
    except (TypeError, ValueError):
        await ctx.send(embed=create_error_embed("Invalid Resources", "Resource increments must be whole numbers."))
        return
    if any(value is not None and int(value) <= 0 for value in (ram, cpu, disk)):
        await ctx.send(embed=create_error_embed("Invalid Resources", "Only positive resource increments are allowed."))
        return
    if not (1 <= new_ram <= MAX_VPS_RAM_GB and 1 <= new_cpu <= MAX_VPS_CPU and VPS_MIN_DISK_GB <= new_disk <= VPS_MAX_DISK_GB):
        await ctx.send(embed=create_error_embed("Resource Ceiling Reached", f"Admin limit: **{MAX_VPS_RAM_GB} GB RAM · {MAX_VPS_CPU} CPU · {VPS_MAX_DISK_GB} GB disk**. No changes were applied."))
        return
    was_running = found_vps.get('status') == 'running' and not found_vps.get('suspended', False)
    disk_changed = disk is not None
    if was_running:
        await ctx.send(embed=create_info_embed("Stopping VPS", f"Stopping VPS `{vps_id}` to apply resource changes..."))
        try:
            await execute_vpsctl_compat(vps_id, f"stop {vps_id}", node_id=node_id)
            found_vps['status'] = 'stopped'
            save_vps_data_immediate()
        except Exception as e:
            await ctx.send(embed=create_error_embed("Stop Failed", safe_error_summary("VPS stop", e)))
            return
    changes = []
    try:
        new_ram_gb = current_ram
        new_cpu_value = current_cpu
        new_disk_gb = current_disk
        if ram is not None and ram > 0:
            new_ram_gb = new_ram
            ram_mb = new_ram_gb * 1024
            await execute_vpsctl_compat(vps_id, f"config set {vps_id} limits.memory {ram_mb}MB", node_id=node_id)
            changes.append(f"RAM: +{ram}GB (New total: {new_ram_gb}GB)")
            found_vps['ram'] = f"{new_ram_gb}GB"
            found_vps['config'] = f"{new_ram_gb}GB RAM / {new_cpu_value} CPU / {new_disk_gb}GB Disk"
            save_vps_data_immediate()
        if cpu is not None and cpu > 0:
            new_cpu_value = new_cpu
            await execute_vpsctl_compat(vps_id, f"config set {vps_id} limits.cpu {new_cpu_value}", node_id=node_id)
            changes.append(f"CPU: +{cpu} cores (New total: {new_cpu_value} cores)")
            found_vps['cpu'] = str(new_cpu_value)
            found_vps['config'] = f"{new_ram_gb}GB RAM / {new_cpu_value} CPU / {new_disk_gb}GB Disk"
            save_vps_data_immediate()
        if disk is not None and disk > 0:
            new_disk_gb = new_disk
            await execute_vpsctl_compat(vps_id, f"config device set {vps_id} root size={new_disk_gb}GB", node_id=node_id)
            changes.append(f"Disk: +{disk}GB (New total: {new_disk_gb}GB)")
            found_vps['storage'] = f"{new_disk_gb}GB"
            found_vps['config'] = f"{new_ram_gb}GB RAM / {new_cpu_value} CPU / {new_disk_gb}GB Disk"
            save_vps_data_immediate()
        found_vps['ram'] = f"{new_ram_gb}GB"
        found_vps['cpu'] = str(new_cpu_value)
        found_vps['storage'] = f"{new_disk_gb}GB"
        found_vps['config'] = f"{new_ram_gb}GB RAM / {new_cpu_value} CPU / {new_disk_gb}GB Disk"
        vps_data[user_id][vps_index] = found_vps
        save_vps_data_immediate()
        if was_running:
            await execute_vpsctl_compat(vps_id, f"start {vps_id}", node_id=node_id)
            found_vps['status'] = 'running'
            save_vps_data_immediate()
            await apply_internal_permissions(vps_id, node_id)
            await recreate_port_forwards(vps_id)
        embed = create_success_embed("Resources Added", f"Successfully added resources to VPS `{vps_id}`")
        add_field(embed, "Changes Applied", "\n".join(changes), False)
        if disk is not None and disk > 0:
            add_field(embed, "Disk Note", "Run `sudo resize2fs /` inside the VPS to expand the filesystem if the guest filesystem does not auto-grow.", False)
        await ctx.send(embed=embed)
    except Exception as e:
        logger.warning("VPS resource addition failed for %s (%s).", vps_id, type(e).__name__)
        if was_running:
            if found_vps.get('status') != 'running':
                try:
                    await execute_vpsctl_compat(vps_id, f"start {vps_id}", node_id=node_id)
                    found_vps['status'] = 'running'
                    save_vps_data_immediate()
                except Exception as restart_exc:
                    found_vps['status'] = 'stopped'
                    save_vps_data_immediate()
                    logger.error("Failed to restore VPS %s after resource update error (%s).", vps_id, type(restart_exc).__name__)
            if found_vps.get('status') == 'running':
                try:
                    await apply_internal_permissions(vps_id, node_id)
                    await recreate_port_forwards(vps_id)
                except Exception as repair_exc:
                    logger.warning("Post-failure access repair skipped for %s (%s).", vps_id, type(repair_exc).__name__)
        await ctx.send(embed=create_error_embed("Resource Addition Failed", safe_error_summary("Resource addition", e)))


@bot.command(name='permissions')
@is_admin()
async def permissions_check_command(ctx, channel: discord.TextChannel = None):
    """Audit the bot's effective Discord permissions in a target channel."""
    if ctx.guild is None:
        await ctx.send(embed=create_error_embed("Invalid Context", "Use this command inside a Discord server."))
        return
    target = channel or ctx.channel
    me = ctx.guild.me
    if me is None:
        await ctx.send(embed=create_error_embed("Permission Audit Failed", "Discord has not provided the bot member object yet."))
        return
    perms = target.permissions_for(me)
    required = {
        "View Channel": perms.view_channel,
        "Send Messages": perms.send_messages,
        "Embed Links": perms.embed_links,
        "Attach Files": perms.attach_files,
        "Read Message History": perms.read_message_history,
        "Manage Messages": perms.manage_messages,
        "Manage Channels": perms.manage_channels,
        "Manage Roles": perms.manage_roles,
        "Manage Webhooks": perms.manage_webhooks,
    }
    lines = [f"{'✅' if ok else '❌'} **{name}**" for name, ok in required.items()]
    missing = [name for name, ok in required.items() if not ok]
    embed = create_info_embed("🛡️ RGNODES Permission Audit", f"Effective permissions for the bot in {target.mention}.")
    add_field(embed, "Core Logging", "\n".join(lines[:5]), False)
    add_field(embed, "Management", "\n".join(lines[5:]), False)
    add_field(embed, "Result", "✅ Core permissions are available." if not missing else f"⚠️ Missing: {', '.join(missing)}", False)
    await ctx.send(embed=embed)

@bot.group(name='update', invoke_without_command=True)
@commands.guild_only()
@is_admin()
async def update_group(ctx):
    await ctx.send(embed=create_info_embed("⚙️ Update Center", f"Use `{PREFIX}update logs #channel` to configure the VPS/node log channel."))

@update_group.command(name='logs')
@is_admin()
async def update_logs(ctx, channel: discord.TextChannel):
    if ctx.guild is None or ctx.guild.me is None:
        await ctx.send(embed=create_error_embed("Invalid Context", "Use this command inside a Discord server."))
        return
    perms=channel.permissions_for(ctx.guild.me)
    missing=[name for name,ok in (("View Channel",perms.view_channel),("Send Messages",perms.send_messages),("Embed Links",perms.embed_links),("Attach Files",perms.attach_files)) if not ok]
    if missing:
        await ctx.send(embed=create_error_embed("Permission Check Failed", f"I need: {', '.join(missing)} in {channel.mention}."))
        return
    set_audit_channel_id(channel.id)
    await record_audit_event("system", "Logs Channel Updated", f"VPS + node logs are now published to {channel.mention}.", user_id=ctx.author.id, announce=False)
    await ctx.send(embed=create_success_embed("✅ Logs Channel Updated", f"VPS + node logs will now be sent to {channel.mention}.\n\nRequired bot permissions were verified: **View Channel • Send Messages • Embed Links**."))
    try:
        await channel.send(
            embed=create_success_embed(
                "📝 RGNODES Logging Active",
                "VPS and node operational events will appear here.\n\n"
                "✅ VPS audit events\n"
                "✅ Node health snapshots\n"
                "✅ Detailed `log-vps` / `node-logs` snapshots\n"
                "✅ Secrets are redacted from command-audit text."
            ),
            allowed_mentions=discord.AllowedMentions.none(),
        )
    except Exception:
        pass

@bot.command(name='update-logs')
@commands.guild_only()
@is_admin()
async def update_logs_alias(ctx, channel: discord.TextChannel):
    """Convenience alias for `update logs #channel`."""
    await update_logs.callback(ctx, channel)

@bot.command(name='log-channel')
@commands.guild_only()
@is_admin()
async def log_channel_command(ctx, action: str = 'show'):
    """Show or test the configured operational log channel."""
    action = str(action or 'show').lower().strip()
    channel_id = _audit_channel_id()
    if action in {'show','status'}:
        if not channel_id:
            await ctx.send(embed=create_warning_embed("📝 Logs Channel", f"No log channel is configured. Use `{PREFIX}update logs #channel`."))
            return
        try:
            channel = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
            await ctx.send(embed=create_info_embed("📝 Logs Channel", f"Configured channel: {getattr(channel, 'mention', f'`{channel_id}`')}\n\nVPS + node event logging is active."))
        except Exception:
            await ctx.send(embed=create_warning_embed("📝 Logs Channel", f"Configured channel ID `{channel_id}` is not currently reachable. Use `{PREFIX}update logs #channel` to repair it."))
        return
    if action in {'test','check'}:
        await logs_test_command.callback(ctx)
        return
    await ctx.send(embed=create_error_embed("Invalid Action", f"Use `{PREFIX}log-channel show` or `{PREFIX}log-channel test`."))

@bot.group(name='add', invoke_without_command=True)
@commands.guild_only()
@is_admin()
async def add_group(ctx):
    await ctx.send(embed=create_info_embed("➕ Admin Add", f"Use `{PREFIX}add slots @user amount`."))

@add_group.command(name='slots')
@is_admin()
async def add_group_slots(ctx, user: discord.Member, amount: int):
    if amount <= 0 or amount > 1000:
        await ctx.send(embed=create_error_embed("Invalid Amount", "Slots must be between 1 and 1000."))
        return
    before=get_user_allocation(str(user.id))
    allocate_ports(str(user.id), amount)
    after=get_user_allocation(str(user.id))
    await record_audit_event("vps", "Port Slots Added", f"Allocated `{amount}` slots. Quota `{before}` → `{after}`.", user_id=ctx.author.id)
    await ctx.send(embed=create_success_embed("✅ Slots Added", f"Added **{amount}** port-forwarding slots to {user.mention}.\n**New quota:** `{after}`"))
    try:
        await user.send(embed=create_info_embed("🌐 Port Slots Updated", f"An administrator added **{amount}** port-forwarding slots to your account.\n**New quota:** `{after}`"))
    except discord.Forbidden:
        pass

@bot.command(name='add-slots')
@commands.guild_only()
@is_admin()
async def add_slots_alias(ctx, user: discord.Member, amount: int):
    """Convenience alias for `add slots @user amount`."""
    await add_group_slots.callback(ctx, user, amount)

@bot.command(name='slots')
async def slots_command(ctx, user: discord.Member = None):
    """Show a user's port-slot quota. Admins may inspect another user."""
    if user is not None and str(user.id) != str(ctx.author.id) and not is_admin_user(ctx.author):
        await ctx.send(embed=create_error_embed("Access Denied", "You can only inspect your own slot quota unless you are an administrator."))
        return
    target = user or ctx.author
    allocated = get_user_allocation(str(target.id))
    used = get_user_used_ports(str(target.id))
    available = max(0, allocated - used)
    embed = create_info_embed("🌐 Port Slot Quota", f"Slot allocation for {target.mention}.")
    add_field(embed, "Allocated", f"`{allocated}` slots", True)
    add_field(embed, "Used", f"`{used}` slots", True)
    add_field(embed, "Available", f"`{available}` slots", True)
    await ctx.send(embed=embed)

@bot.command(name='log-vps')
async def log_vps_command(ctx, container_name: str, lines: int = LOG_CHANNEL_SNAPSHOT_LINES):
    """Fetch VPS guest logs and mirror the result to the configured log channel."""
    await vps_logs.callback(ctx, container_name, lines)

@bot.command(name='log-node')
@is_admin()
async def log_node_command(ctx, node_id: int, limit: int = LOG_CHANNEL_SNAPSHOT_LINES):
    """Fetch node diagnostics and mirror the result to the configured log channel."""
    await node_logs_command.callback(ctx, node_id, limit)

@bot.command(name='logs-test')
@commands.guild_only()
@is_admin()
async def logs_test_command(ctx):
    """Verify the configured log channel and permissions without changing anything."""
    channel_id = _audit_channel_id()
    if not channel_id:
        await ctx.send(embed=create_warning_embed("📝 Logs Not Configured", f"Use `{PREFIX}update logs #channel` first."))
        return
    try:
        channel = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
        if ctx.guild and isinstance(channel, discord.TextChannel) and ctx.guild.me:
            perms = channel.permissions_for(ctx.guild.me)
            missing = [name for name, ok in (("View Channel", perms.view_channel),("Send Messages", perms.send_messages),("Embed Links", perms.embed_links)) if not ok]
            if missing:
                await ctx.send(embed=create_error_embed("Permission Check Failed", f"Missing in {channel.mention}: {', '.join(missing)}"))
                return
        probe = create_success_embed("🧪 RGNODES Logs Test", f"Log delivery is working for {getattr(channel, 'mention', channel_id)}.")
        await channel.send(embed=probe, allowed_mentions=discord.AllowedMentions.none())
        await ctx.send(embed=create_success_embed("✅ Logs Channel Healthy", f"A test event was delivered to {getattr(channel, 'mention', f'`{channel_id}`')}."))
    except Exception as exc:
        await ctx.send(embed=create_error_embed("❌ Logs Test Failed", safe_error_summary("Logs test", exc)))

@bot.command(name='bandwidth')
async def bandwidth_command(ctx, vps_ref: str = None):
    target=vps_ref
    if target:
        owner_id,_,vps=find_vps_record(target)
    else:
        owner_id=str(ctx.author.id)
        items=vps_data.get(owner_id,[])
        vps=items[0] if len(items)==1 else None
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"Use `{PREFIX}bandwidth <vps-id|container>` as an administrator, or own exactly one VPS.")); return
    if str(ctx.author.id)!=str(owner_id) and not is_admin_user(ctx.author):
        await ctx.send(embed=create_error_embed("Access Denied", "You can only view your own VPS bandwidth unless you are an administrator.")); return
    rx,tx=await get_container_network_usage(str(vps.get('container_name')),int(vps.get('node_id',1)))
    embed=create_info_embed("🌐 VPS Bandwidth",f"`{vps.get('container_name')}` • **RGNODES fixed 50GB/month plan**")
    quota_gb = VPS_BANDWIDTH_GB
    used_bytes = int(vps.get('bandwidth_used_bytes') or 0)
    used_gb = used_bytes / 1024**3
    remaining_gb = max(0.0, quota_gb - used_gb)
    add_field(embed,"Monthly Quota",f"**{quota_gb} GB**",True)
    add_field(embed,"Accounted Usage",f"**{used_gb:.2f} GB**",True)
    add_field(embed,"Remaining",f"**{remaining_gb:.2f} GB**",True)
    add_field(embed,"Live RX / TX",f"RX `{rx}` • TX `{tx}`",False)
    add_field(embed,"Cycle",f"`{str(vps.get('bandwidth_cycle_start') or 'current')[:19]}`",True)
    await ctx.send(embed=embed)

@bot.command(name='node-capacity')
@is_admin()
async def node_capacity_command(ctx, node_id: int = 1):
    """Low-overhead host capacity snapshot used before provisioning."""
    node = get_node(node_id)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"Node `{node_id}` was not found."))
        return
    try:
        stats = await asyncio.wait_for(get_host_stats(node_id), timeout=12)
        total_ram = int(stats.get('ram_bytes_total') or 0)
        available_ram = int(stats.get('ram_bytes_available') or 0)
        used_ram = max(0, total_ram - available_ram)
        disk = stats.get('disk') or {}
        cpu = float(stats.get('cpu') or 0.0)
        ram_pct = (used_ram / total_ram * 100.0) if total_ram else float(stats.get('ram') or 0.0)
        disk_pct = float(disk.get('percent', 0) or 0) if isinstance(disk, dict) else 0.0
        embed = create_info_embed("🧠 Node Capacity", f"**{node.get('name','Node')}** • `{node_id}`\nProvider: **{HOST_PROVIDER_NAME}** • CPU: **{HOST_PROCESSOR_NAME}**")
        add_field(embed, "CPU", f"`{cpu:.1f}%` used • deploy ceiling `{HOST_CPU_MAX_DEPLOY_PCT:.0f}%`", True)
        add_field(embed, "RAM", f"`{available_ram/(1024**3):.2f} GiB` free / `{total_ram/(1024**3):.2f} GiB` total • `{ram_pct:.1f}%` used", True)
        add_field(embed, "Disk", f"`{disk_pct:.1f}%` used • reserve `{HOST_DISK_RESERVE_GB:.1f} GiB`", True)
        add_field(embed, "Allocation Policy", f"RAM share ≤ `{MAX_DEPLOY_RAM_SHARE*100:.0f}%` • RAM reserve `{HOST_RAM_RESERVE_GB:.1f} GiB` • swap guests `{'ON' if VPS_SWAP_ENABLED else 'OFF'}`", False)
        await ctx.send(embed=embed)
    except Exception as exc:
        await ctx.send(embed=create_error_embed("Node Capacity Failed", safe_error_summary("Node capacity check", exc)))

@bot.command(name='node-logs')
@commands.guild_only()
@is_admin()
async def node_logs_command(ctx, node_id: int, limit: int = 25):
    """Admin node diagnostics, local libvirt/QEMU journal (when available), and audit snapshots."""
    limit = max(5, min(50, int(limit)))
    node = get_node(node_id)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"Node `{node_id}` was not found."))
        return
    await ctx.send(embed=create_info_embed("🧩 Gathering Node Logs", f"Checking `{node.get('name','Node')}`..."))
    try:
        stats = await asyncio.wait_for(get_host_stats(node_id), timeout=12)
        cpu = float(stats.get("cpu") or 0)
        ram = float(stats.get("ram") or 0)
        disk = stats.get("disk") or {}
        if isinstance(disk, dict):
            disk_text = f"{float(disk.get('percent',0) or 0):.1f}% used • {int(disk.get('free',0) or 0)/(1024**3):.1f} GiB free"
        else:
            disk_text = str(disk)
        health = f"CPU `{cpu:.1f}%` • RAM `{ram:.1f}%` • Disk `{disk_text}`"
    except Exception as exc:
        health = safe_error_summary("Node health check", exc)

    journal = "Remote node journal unavailable through the current node-agent contract."
    if node.get('is_local'):
        try:
            def _read_local_node_journal() -> str:
                proc = subprocess.run(
                    ['journalctl', '--no-pager', '-n', str(min(limit, 50)), '-u', 'libvirtd.service', '-u', 'virtqemud.service'],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=12, check=False,
                )
                return proc.stdout or "No local libvirt service journal entries."
            journal = await asyncio.to_thread(_read_local_node_journal)
        except Exception as exc:
            journal = safe_error_summary("Local node journal retrieval", exc)

    rows = get_recent_audit_logs(limit, node_id=node_id)
    lines_text = "\n".join(
        f"{r.get('created_at','')[:19]} | {r.get('kind','system')} | {r.get('action','Event')} | {r.get('detail','')}"
        for r in rows
    ) or "No node audit events recorded yet."
    embed=create_info_embed("🧩 Node Logs",f"**{node.get('name','Node')}** • Node `{node_id}`\n{health}")
    add_field(embed,"Node Service Logs",f"```text\n{journal[-2400:]}\n```",False)
    add_field(embed,"Recent RGNODES Events",f"```text\n{lines_text[-2600:]}\n```",False)
    await ctx.send(embed=embed)

    # Also publish the diagnostic to the configured log channel so the operator has
    # one central place for VPS/node operational history. Avoid duplicate posting.
    channel_id = _audit_channel_id()
    if channel_id and (not getattr(ctx.channel, 'id', None) or int(ctx.channel.id) != int(channel_id)):
        try:
            target = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
            raw_bundle = f"RGNODES NODE LOG SNAPSHOT\nNode: {node.get('name','Node')}\nNode ID: {node_id}\nGenerated: {datetime.now().isoformat()}\nHealth: {health}\n\n=== NODE SERVICE LOGS ===\n{journal}\n\n=== RGNODES AUDIT ===\n{lines_text}\n"
            if hasattr(target, 'send'):
                await _publish_log_bundle(target, embed, raw_bundle, f"node-{node_id}-logs.txt")
        except Exception as exc:
            logger.debug('Failed to publish node diagnostics to log channel: %s', exc)
    await record_audit_event("node", "Node Logs Viewed", f"Diagnostic snapshot requested ({limit} events).", user_id=ctx.author.id, node_id=node_id)

@bot.command(name='logs')
@commands.guild_only()
@is_admin()
async def logs_command(ctx, limit: int = 25):
    rows=get_recent_audit_logs(limit)
    lines="\n".join(f"`{str(r.get('created_at',''))[:19]}` • **{r.get('kind','system').upper()} / {r.get('action','Event')}** — {r.get('detail','')}" for r in rows[:25]) or "No audit events recorded yet."
    channel_id=_audit_channel_id()
    await ctx.send(embed=create_info_embed("📝 RGNODES Audit Logs",f"Configured channel: `{channel_id or 'Not configured'}`\n\n{lines[:3800]}"))

@bot.command(name='log-config')
@is_admin()
async def log_config_command(ctx):
    channel_id = _audit_channel_id()
    channel = bot.get_channel(channel_id) if channel_id else None
    label = channel.mention if channel else (f"`{channel_id}`" if channel_id else "Not configured")
    await ctx.send(embed=create_info_embed("📝 Log Channel", f"VPS + node operational logs are sent to: **{label}**\nUse `{PREFIX}update logs #channel` to change it.\n\nAutomatic: VPS actions + node health. Detailed: `{PREFIX}log-vps <vps>` / `{PREFIX}log-node <node>`."))

@bot.command(name='node-log')
@is_admin()
async def node_log_alias(ctx, node_id: int, limit: int = 25):
    await node_logs_command.callback(ctx, node_id, limit)

@bot.command(name='vps-log')
async def vps_log_alias(ctx, container_name: str, lines: int = 50):
    owner_id, _, vps = find_vps_record(container_name)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"`{container_name}` was not found.")); return
    if str(ctx.author.id) != str(owner_id) and not is_admin_user(ctx.author):
        await ctx.send(embed=create_error_embed("Access Denied", "You can only view logs for your own VPS.")); return
    await vps_logs.callback(ctx, container_name, lines)

@bot.command(name='motd')
@commands.guild_only()
@is_admin()
async def motd_command(ctx, action: str = 'show', *, text: str = ''):
    action=str(action or 'show').lower().strip()
    if action=='show':
        current = get_motd_text()
        status = "🟢 Enabled" if current else "⚪ Disabled"
        body = current or "MOTD is currently disabled."
        await ctx.send(embed=create_info_embed("📜 Current MOTD",f"**Status:** {status}\n\n```text\n{body[:1800]}\n```")); return
    if action in {'clear','off','disable'}:
        set_setting('motd_text','')
        ok,failed=await apply_motd_to_all_running_vps()
        await record_audit_event("system","MOTD Disabled",f"Cleared on `{ok}` running VPS; `{failed}` failed.",user_id=ctx.author.id)
        await ctx.send(embed=create_success_embed("✅ MOTD Disabled",f"Cleared on **{ok}** running VPS. Failed: **{failed}**.")); return
    if action in {'set','on','enable'}:
        text=text.strip()[:1200]
        if not text:
            await ctx.send(embed=create_error_embed("Missing MOTD",f"Usage: `{PREFIX}motd set Your message here`")); return
        set_setting('motd_text',text)
        await ctx.send(embed=create_info_embed("📜 Applying MOTD","Saving the new MOTD and applying it to running VPS..."))
        ok,failed=await apply_motd_to_all_running_vps()
        await record_audit_event("system","MOTD Updated",f"Applied to `{ok}` running VPS; `{failed}` failed.",user_id=ctx.author.id)
        await ctx.send(embed=create_success_embed("✅ MOTD Updated",f"Applied to **{ok}** running VPS. Failed: **{failed}**.")); return
    await ctx.send(embed=create_error_embed("Invalid MOTD Action",f"Use `{PREFIX}motd show`, `{PREFIX}motd set <text>`, or `{PREFIX}motd clear`."))

@bot.command(name='status')
@is_admin()
async def system_status(ctx):
    """
    Show complete system status including:
    - Bot uptime
    - Total nodes & their status
    - Running/stopped nodes count
    - Total RAM/CPU/DISK allocated vs free
    - Total VPS & users
    - Running/stopped/suspended VPS counts
    - Total admin users
    - Whitelisted VPS
    """
    
    # Start timing for response time
    start_time = time.time()  # Also used below to report how long metrics collection took.
    # Use the process monotonic clock, not gateway latency (which can be near zero).
    elapsed_seconds = max(0, int(time.monotonic() - BOT_PROCESS_STARTED_MONOTONIC))
    bot_uptime = str(timedelta(seconds=elapsed_seconds))
    
    # Get total nodes
    nodes = get_nodes()
    total_nodes = len(nodes)
    
    # Node status counters
    running_nodes = 0
    stopped_nodes = 0
    local_nodes = 0
    remote_nodes = 0
    
    # Node resource tracking
    total_node_cpu_allocated = 0
    total_node_ram_allocated = 0
    total_node_disk_allocated = 0
    total_node_cpu_free = 0
    total_node_ram_free = 0
    total_node_disk_free = 0
    
    # VPS counters
    total_vps = 0
    total_users = len(vps_data)
    running_vps = 0
    stopped_vps = 0
    suspended_vps = 0
    whitelisted_vps = 0
    
    # Admin counters
    total_admins = len(admin_data.get("admins", []))
    
    # Port statistics
    with DB_LOCK:
        conn = get_db()
        try:
            cur = conn.cursor()
            cur.execute("SELECT SUM(allocated_ports) FROM port_allocations")
            total_ports_allocated = cur.fetchone()[0] or 0
            cur.execute("SELECT COUNT(*) FROM port_forwards")
            total_ports_used = cur.fetchone()[0] or 0
        finally:
            conn.close()
    
    # Resource counters for all VPS
    total_ram_allocated = 0
    total_cpu_allocated = 0
    total_disk_allocated = 0
    
    # Process all VPS data
    for user_id, vps_list in vps_data.items():
        total_vps += len(vps_list)
        
        for vps in vps_list:
            # Count status
            if vps.get('suspended', False):
                suspended_vps += 1
            elif vps.get('status') == 'running':
                running_vps += 1
            else:
                stopped_vps += 1
            
            # Count whitelisted
            if vps.get('whitelisted', False):
                whitelisted_vps += 1
            
            # Calculate allocated resources
            try:
                ram_gb = int(vps['ram'].replace('GB', ''))
                total_ram_allocated += ram_gb
            except:
                pass
            
            try:
                cpu_cores = int(vps['cpu'])
                total_cpu_allocated += cpu_cores
            except:
                pass
            
            try:
                disk_gb = int(vps['storage'].replace('GB', ''))
                total_disk_allocated += disk_gb
            except:
                pass
    
    # Check node status and calculate free resources
    node_statuses = []
    
    for node in nodes:
        # Determine node type
        if node['is_local']:
            local_nodes += 1
            node_type = "🖥️ Local"
        else:
            remote_nodes += 1
            node_type = "🌐 Remote"
        
        # Check node status
        if node['is_local']:
            status = "🟢 Online"
            running_nodes += 1
            
            # Get local resources (approximate) - cross-platform
            try:
                import platform
                system = platform.system()
                
                if system == "Windows":
                    # Windows: Use psutil
                    try:
                        import psutil
                        mem = psutil.virtual_memory()
                        total_ram_gb = mem.total / (1024**3)
                        free_ram_gb = mem.available / (1024**3)
                        
                        cpu_count = psutil.cpu_count()
                        total_cpu = cpu_count if cpu_count else 0
                        
                        disk = psutil.disk_usage('C:\\' if 'C:\\' else '/')
                        total_disk = disk.total / (1024**3)
                    except ImportError:
                        # Fallback for Windows without psutil
                        try:
                            result = await asyncio.to_thread(subprocess.run, ['wmic', 'OS', 'get', 'TotalVisibleMemorySize,FreePhysicalMemory'], capture_output=True, text=True, timeout=5)
                            lines = result.stdout.strip().split('\n')
                            if len(lines) > 1:
                                values = lines[1].split()
                                total_ram_gb = int(values[0]) / (1024**2)
                                free_ram_gb = int(values[1]) / (1024**2)
                            else:
                                total_ram_gb = 0
                                free_ram_gb = 0
                            
                            result = await asyncio.to_thread(subprocess.run, ['wmic', 'os', 'get', 'numberofprocessors'], capture_output=True, text=True, timeout=5)
                            total_cpu = int(result.stdout.strip().split('\n')[-1]) if result.stdout else 0
                            
                            total_disk = 0  # Approximate
                        except:
                            total_ram_gb = 0
                            free_ram_gb = 0
                            total_cpu = 0
                            total_disk = 0
                else:
                    # Linux/Unix: Use traditional commands
                    # Get system memory
                    mem_result = await asyncio.to_thread(subprocess.run, ['free', '-m'], capture_output=True, text=True, timeout=10)
                    mem_lines = mem_result.stdout.splitlines()
                    if len(mem_lines) > 1:
                        mem = mem_lines[1].split()
                        total_ram_mb = int(mem[1])
                        used_ram_mb = int(mem[2])
                        free_ram_mb = total_ram_mb - used_ram_mb
                        total_ram_gb = total_ram_mb / 1024
                        free_ram_gb = free_ram_mb / 1024
                    else:
                        total_ram_gb = 0
                        free_ram_gb = 0
                    
                    # Get CPU cores
                    cpu_result = await asyncio.to_thread(subprocess.run, ['nproc'], capture_output=True, text=True, timeout=10)
                    total_cpu = int(cpu_result.stdout.strip()) if cpu_result.stdout.strip() else 0
                    
                    # Get disk space
                    disk_result = await asyncio.to_thread(subprocess.run, ['df', '-h', '/'], capture_output=True, text=True, timeout=10)
                    disk_lines = disk_result.stdout.splitlines()
                    if len(disk_lines) > 1:
                        disk_parts = disk_lines[1].split()
                        total_disk_str = disk_parts[1]
                        # Convert to GB
                        if 'T' in total_disk_str:
                            total_disk = float(total_disk_str.replace('T', '')) * 1024
                        elif 'G' in total_disk_str:
                            total_disk = float(total_disk_str.replace('G', ''))
                        elif 'M' in total_disk_str:
                            total_disk = float(total_disk_str.replace('M', '')) / 1024
                        else:
                            total_disk = 0
                    else:
                        total_disk = 0
                
                # Calculate free resources (simplified - actual would need more complex logic)
                free_cpu = max(0, total_cpu - (total_cpu_allocated // total_nodes)) if total_nodes > 0 else 0
                free_disk = max(0, total_disk - (total_disk_allocated // total_nodes)) if total_nodes > 0 else 0
                
                # Update totals
                if total_ram_gb > 0:
                    total_node_ram_allocated += total_ram_gb - free_ram_gb
                    total_node_ram_free += free_ram_gb
                if total_cpu > 0:
                    total_node_cpu_allocated += total_cpu - free_cpu
                    total_node_cpu_free += free_cpu
                if total_disk > 0:
                    total_node_disk_allocated += total_disk - free_disk
                    total_node_disk_free += free_disk
                
            except Exception as e:
                logger.debug(f"Error getting local node resources: {e}")
                status = "⚠️ Unknown"
                # Don't reset to 0, just skip this node's resources
        else:
            # Check remote node status
            try:
                response = await asyncio.to_thread(requests.get, str(node['url']).rstrip('/') + '/api/ping', headers={'X-API-Key': str(node['api_key'])}, timeout=5)
                if response.status_code == 200:
                    status = "🟢 Online"
                    running_nodes += 1
                else:
                    status = "🔴 Offline"
                    stopped_nodes += 1
            except:
                status = "🔴 Offline"
                stopped_nodes += 1
        
        # Get current VPS count on this node
        node_vps_count = get_current_vps_count(node['id'])
        capacity = node['total_vps']
        usage_percentage = (node_vps_count / capacity * 100) if capacity > 0 else 0
        
        node_statuses.append(
            f"**{node['name']}** ({node_type})\n"
            f"📍 {node['location']} • 📊 {node_vps_count}/{capacity} VPS ({usage_percentage:.0f}%)\n"
            f"Status: {status}"
        )
    
    # Calculate response time
    response_time = (time.time() - start_time) * 1000
    
    # Create main embed
    embed = create_embed(
        title="📊 System Status Dashboard",
        description=f"**{BOT_NAME}** - Complete System Overview\n*Generated in {response_time:.0f}ms*"
    )
    
    # Bot & Uptime Section
    add_field(embed, "🤖 Bot Status", 
        f"**Provider:** {HOST_PROVIDER_NAME}\n"
        f"**Uptime:** {bot_uptime}\n"
        f"**Latency:** {round(bot.latency * 1000)}ms\n"
        f"**Version:** {BOT_VERSION}\n"
        f"**Developer:** {BOT_DEVELOPER}", 
        True)
    
    # Nodes Section
    add_field(embed, "🌐 Nodes Overview",
        f"**Total Nodes:** {total_nodes}\n"
        f"**Running:** {running_nodes} 🟢\n"
        f"**Stopped:** {stopped_nodes} 🔴\n"
        f"**Local/Remote:** {local_nodes}/{remote_nodes}",
        True)
    
    # VPS & Users Section
    add_field(embed, "👥 Users & VPS",
        f"**Total Users:** {total_users}\n"
        f"**Total VPS:** {total_vps}\n"
        f"**Running:** {running_vps} 🟢\n"
        f"**Stopped:** {stopped_vps} 🔴\n"
        f"**Suspended:** {suspended_vps} 🟡\n"
        f"**Whitelisted:** {whitelisted_vps} ✅",
        True)
    
    # Resources Section - Allocated vs Free
    add_field(embed, "💾 Resource Allocation",
        f"**RAM Allocated:** {total_ram_allocated} GB\n"
        f"**RAM Free:** {total_node_ram_free:.1f} GB\n"
        f"**CPU Allocated:** {total_cpu_allocated} Cores\n"
        f"**CPU Free:** {total_node_cpu_free:.1f} Cores\n"
        f"**Disk Allocated:** {total_disk_allocated} GB\n"
        f"**Disk Free:** {total_node_disk_free:.1f} GB",
        True)
    
    # System & Admin Section
    add_field(embed, "⚙️ System Information",
        f"**Total Admins:** {total_admins}\n"
        f"**Main Admin:** <@{MAIN_ADMIN_ID}>\n"
        f"**Ports Allocated:** {total_ports_allocated}\n"
        f"**Ports In Use:** {total_ports_used}\n"
        f"**Ports Available:** {total_ports_allocated - total_ports_used}",
        True)
    
    # Node Details Section (if any nodes exist)
    if node_statuses:
        # Split node statuses into chunks if too long
        node_text = "\n\n".join(node_statuses)
        chunks = [node_text[i:i+1024] for i in range(0, len(node_text), 1024)]
        
        for idx, chunk in enumerate(chunks, 1):
            title = "📡 Node Details" if idx == 1 else f"📡 Node Details (Part {idx})"
            add_field(embed, title, chunk, False)
    
    # Expiration Status Section
    expiring_soon_count = 0
    expired_count = 0
    active_exp_count = 0
    no_exp_count = 0
    
    for user_id, vps_list in vps_data.items():
        for vps in vps_list:
            if vps.get('expiration_date'):
                expiration_dt = datetime.fromisoformat(vps['expiration_date'])
                days_remaining = (expiration_dt - datetime.now()).days
                if days_remaining < 0:
                    expired_count += 1
                elif days_remaining <= EXPIRATION_WARNING_DAYS:
                    expiring_soon_count += 1
                else:
                    active_exp_count += 1
            else:
                no_exp_count += 1
    
    add_field(embed, "⏰ VPS Expiration Status",
        f"**🟢 Active:** {active_exp_count} VPS\n"
        f"**🟡 Expiring Soon:** {expiring_soon_count} VPS\n"
        f"**🔴 Expired:** {expired_count} VPS\n"
        f"**🔵 No Expiration:** {no_exp_count} VPS",
        True)
    
    # System Health Indicator
    health_status = "✅ Excellent"
    health_color = 0x00ff88
    
    if running_nodes == 0:
        health_status = "🔴 Critical - No nodes running"
        health_color = 0xff3366
    elif stopped_nodes > 0:
        health_status = "🟡 Warning - Some nodes offline"
        health_color = 0xffaa00
    elif total_vps == 0:
        health_status = "ℹ️ No VPS deployed"
        health_color = 0x00ccff
    
    add_field(embed, "🏥 System Health", health_status, False)
    
    # Footer with current time
    embed.set_footer(text=f"⚡ RGNODES™ • System Status • Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    icon_url=BOT_ICON_URL)
    
    await ctx.send(embed=embed)


@bot.command(name='status-summary')
@is_admin()
async def status_summary(ctx):
    """
    Quick summary of system status
    """
    # Get quick stats
    nodes = get_nodes()
    total_nodes = len(nodes)
    running_nodes = 0
    
    for node in nodes:
        if node['is_local']:
            running_nodes += 1
        else:
            try:
                response = await asyncio.to_thread(requests.get, str(node['url']).rstrip('/') + '/api/ping', headers={'X-API-Key': str(node['api_key'])}, timeout=3)
                if response.status_code == 200:
                    running_nodes += 1
            except:
                pass
    
    total_vps = sum(len(vps_list) for vps_list in vps_data.values())
    total_users = len(vps_data)
    
    # Count VPS status
    running_vps = 0
    stopped_vps = 0
    suspended_vps = 0
    
    for vps_list in vps_data.values():
        for vps in vps_list:
            if vps.get('suspended', False):
                suspended_vps += 1
            elif vps.get('status') == 'running':
                running_vps += 1
            else:
                stopped_vps += 1
    
    embed = create_success_embed(
        "📈 Quick Status Summary",
        f"**Nodes:** {running_nodes}/{total_nodes} 🟢\n"
        f"**VPS:** {total_vps} total\n"
        f"• Running: {running_vps} 🟢\n"
        f"• Stopped: {stopped_vps} 🔴\n"
        f"• Suspended: {suspended_vps} 🟡\n"
        f"**Users:** {total_users} 👥\n"
        f"**Bot Latency:** {round(bot.latency * 1000)}ms"
    )
    
    embed.set_footer(text=f"Use '{PREFIX}status' for detailed information")
    await ctx.send(embed=embed)

@bot.command(name='admin-add')
@is_main_admin()
async def admin_add(ctx, user: discord.Member):
    user_id = str(user.id)
    if user_id == str(MAIN_ADMIN_ID):
        await ctx.send(embed=create_error_embed("Already Admin", "This user is already the main admin!"))
        return
    if user_id in admin_data.get("admins", []):
        await ctx.send(embed=create_error_embed("Already Admin", f"{user.mention} is already an admin!"))
        return
    admin_data["admins"].append(user_id)
    save_admin_data()
    await ctx.send(embed=create_success_embed("Admin Added", f"{user.mention} is now an admin!"))
    try:
        await user.send(embed=create_embed("🎉 Admin Role Granted", f"You are now an admin by {ctx.author.mention}", 0x00ff88))
    except discord.Forbidden:
        await ctx.send(embed=create_info_embed("Notification Failed", f"Could not DM {user.mention}"))

@bot.command(name='add-admin')
@is_main_admin()
async def add_admin_alias(ctx, user: discord.Member):
    """Stable alias requested by operators for adding an admin."""
    await admin_add.callback(ctx, user)


@bot.command(name='admin-remove')
@is_main_admin()
async def admin_remove(ctx, user: discord.Member):
    user_id = str(user.id)
    if user_id == str(MAIN_ADMIN_ID):
        await ctx.send(embed=create_error_embed("Cannot Remove", "You cannot remove the main admin!"))
        return
    if user_id not in admin_data.get("admins", []):
        await ctx.send(embed=create_error_embed("Not Admin", f"{user.mention} is not an admin!"))
        return
    admin_data["admins"].remove(user_id)
    save_admin_data()
    await ctx.send(embed=create_success_embed("Admin Removed", f"{user.mention} is no longer an admin!"))
    try:
        await user.send(embed=create_embed("⚠️ Admin Role Revoked", f"Your admin role was removed by {ctx.author.mention}", 0xff3366))
    except discord.Forbidden:
        await ctx.send(embed=create_info_embed("Notification Failed", f"Could not DM {user.mention}"))

@bot.command(name='admin-list')
@is_main_admin()
async def admin_list(ctx):
    admins = admin_data.get("admins", [])
    main_admin = await bot.fetch_user(MAIN_ADMIN_ID)
    embed = create_embed("👑 Admin Team", "Current administrators:", 0x1a1a1a)
    add_field(embed, "🔰 Main Admin", f"{main_admin.mention} (ID: {MAIN_ADMIN_ID})", False)
    if admins:
        admin_list = []
        for admin_id in admins:
            try:
                admin_user = await bot.fetch_user(int(admin_id))
                admin_list.append(f"• {admin_user.mention} (ID: {admin_id})")
            except:
                admin_list.append(f"• Unknown User (ID: {admin_id})")
        admin_text = "\n".join(admin_list)
        add_field(embed, "🛡️ Admins", admin_text, False)
    else:
        add_field(embed, "🛡️ Admins", "No additional admins", False)
    await ctx.send(embed=embed)

@bot.command(name="userinfo")
@is_admin()
async def user_info(ctx, user: discord.Member):
    user_id = str(user.id)
    vps_list = vps_data.get(user_id, [])

    # ─── Embed ─────────────────────────────────────────────────
    embed = create_embed(
        title="👤 User Dashboard",
        description=f"Statistics & resources for {user.mention}"
    )

    # ─── Row 1 : User Info ─────────────────────────────────────
    embed.add_field(
        name="👤 User",
        value=(
            f"**Name:** `{user.name}`\n"
            f"**ID:** `{user.id}`\n"
            f"**Joined:** `{user.joined_at.strftime('%Y-%m-%d') if user.joined_at else 'Unknown'}`"
        ),
        inline=True
    )

    target_is_admin = is_admin_user(user)
    embed.add_field(
        name="🛡️ Admin",
        value="✅ Yes" if target_is_admin else "❌ No",
        inline=True
    )

    embed.add_field(
        name="🖥️ VPS Count",
        value=f"`{len(vps_list)}` VPS",
        inline=True
    )

    # ─── If VPS Exists ─────────────────────────────────────────
    if vps_list:
        total_ram = total_cpu = total_storage = 0
        running = suspended = whitelisted = 0

        vps_lines = []

        for i, vps in enumerate(vps_list, start=1):
            node = get_node(vps.get("node_id"))
            node_name = node["name"] if node else "Unknown"

            ram = int(vps.get("ram", "0GB").replace("GB", ""))
            storage = int(vps.get("storage", "0GB").replace("GB", ""))
            cpu = int(vps.get("cpu", 0))

            total_ram += ram
            total_storage += storage
            total_cpu += cpu

            if vps.get("suspended"):
                status = "⛔ SUSPENDED"
                suspended += 1
            elif vps.get("status") == "running":
                status = "🟢 RUNNING"
                running += 1
            else:
                status = "🔴 STOPPED"

            if vps.get("whitelisted"):
                whitelisted += 1

            vps_lines.append(
                f"**{i}.** `{vps['container_name']}`\n"
                f"{status} | `{ram}GB` RAM • `{cpu}` CPU • `{storage}GB` Disk\n"
                f"📍 Node: `{node_name}`" + 
                (f"\n⏰ {('🔴 EXPIRED' if (datetime.fromisoformat(vps['expiration_date']) - datetime.now()).days < 0 else '🟡 EXPIRING' if (datetime.fromisoformat(vps['expiration_date']) - datetime.now()).days <= EXPIRATION_WARNING_DAYS else '🟢 ACTIVE')} • {(datetime.fromisoformat(vps['expiration_date']).strftime('%Y-%m-%d'))} ({max(0, (datetime.fromisoformat(vps['expiration_date']) - datetime.now()).days)}d)" if vps.get('expiration_date') else "\n⏰ No expiration set")
            )

        # ─── Row 2 : VPS Summary ────────────────────────────────
        embed.add_field(
            name="📊 VPS Summary",
            value=(
                f"🖥️ `{len(vps_list)}` Total\n"
                f"🟢 `{running}` Running\n"
                f"⛔ `{suspended}` Suspended\n"
                f"✅ `{whitelisted}` Whitelisted"
            ),
            inline=True
        )

        embed.add_field(
            name="📈 Resources",
            value=(
                f"**RAM:** `{total_ram} GB`\n"
                f"**CPU:** `{total_cpu} Cores`\n"
                f"**Disk:** `{total_storage} GB`"
            ),
            inline=True
        )

        port_quota = get_user_allocation(user_id)
        port_used = get_user_used_ports(user_id)

        embed.add_field(
            name="🌐 Ports",
            value=f"`{port_used}/{port_quota}` Used",
            inline=True
        )

        # ─── VPS List (Split if needed) ────────────────────────
        vps_text = "\n\n".join(vps_lines)
        for i in range(0, len(vps_text), 1024):
            embed.add_field(
                name="📋 VPS List",
                value=vps_text[i:i + 1024],
                inline=False
            )

    else:
        embed.add_field(
            name="🖥️ VPS",
            value="❌ No VPS assigned",
            inline=False
        )

    embed.set_footer(text="⚡ RGNODES™ • User Resource Dashboard")
    embed.timestamp = ctx.message.created_at

    await ctx.send(embed=embed)

@bot.command(name="serverstats")
@is_admin()
async def server_stats(ctx):
    # ─── Counts ────────────────────────────────────────────────
    total_users = len(vps_data)
    total_admins = len(admin_data.get("admins", [])) + 1
    total_vps = sum(len(vps_list) for vps_list in vps_data.values())

    total_ram = total_cpu = total_storage = 0
    running_vps = suspended_vps = stopped_vps = 0
    whitelisted_vps = 0

    # ─── VPS Data ──────────────────────────────────────────────
    for vps_list in vps_data.values():
        for vps in vps_list:
            total_ram += int(vps.get("ram", "0GB").replace("GB", ""))
            total_storage += int(vps.get("storage", "0GB").replace("GB", ""))
            total_cpu += int(vps.get("cpu", 0))

            if vps.get("status") == "running":
                if vps.get("suspended", False):
                    suspended_vps += 1
                else:
                    running_vps += 1
            else:
                stopped_vps += 1

            if vps.get("whitelisted", False):
                whitelisted_vps += 1

    # ─── Ports ─────────────────────────────────────────────────
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT SUM(allocated_ports) FROM port_allocations")
    total_ports_allocated = cur.fetchone()[0] or 0

    cur.execute("SELECT COUNT(*) FROM port_forwards")
    total_ports_used = cur.fetchone()[0] or 0
    conn.close()

    # ─── Embed ─────────────────────────────────────────────────
    embed = create_embed(
        title="📊 Server Statistics",
        description="**Live Infrastructure Dashboard**"
    )

    # ── Row 1 ──────────────────────────────────────────────────
    embed.add_field(
        name="👥 Users",
        value=f"`{total_users}` Users\n`{total_admins}` Admins",
        inline=True
    )

    embed.add_field(
        name="🖥️ VPS",
        value=(
            f"Total: `{total_vps}`\n"
            f"🟢 `{running_vps}` Running\n"
            f"⛔ `{suspended_vps}` Suspended"
        ),
        inline=True
    )

    embed.add_field(
        name="📌 Status",
        value=(
            f"🔴 `{stopped_vps}` Stopped\n"
            f"✅ `{whitelisted_vps}` Whitelisted"
        ),
        inline=True
    )

    # ── Row 2 ──────────────────────────────────────────────────
    embed.add_field(
        name="📈 RAM",
        value=f"`{total_ram} GB`",
        inline=True
    )

    embed.add_field(
        name="⚙️ CPU",
        value=f"`{total_cpu} Cores`",
        inline=True
    )

    embed.add_field(
        name="💾 Storage",
        value=f"`{total_storage} GB`",
        inline=True
    )

    # ─── Expiration Counts ─────────────────────────────────────
    expiring_soon_count = 0
    expired_count = 0
    active_exp_count = 0
    no_exp_count = 0
    
    for vps_list in vps_data.values():
        for vps in vps_list:
            if vps.get('expiration_date'):
                expiration_dt = datetime.fromisoformat(vps['expiration_date'])
                days_remaining = (expiration_dt - datetime.now()).days
                if days_remaining < 0:
                    expired_count += 1
                elif days_remaining <= EXPIRATION_WARNING_DAYS:
                    expiring_soon_count += 1
                else:
                    active_exp_count += 1
            else:
                no_exp_count += 1

    # ── Row 3 ──────────────────────────────────────────────────
    embed.add_field(
        name="⏰ Expiration",
        value=(
            f"🟢 `{active_exp_count}` Active\n"
            f"🟡 `{expiring_soon_count}` Expiring Soon\n"
            f"🔴 `{expired_count}` Expired\n"
            f"🔵 `{no_exp_count}` No Exp"
        ),
        inline=True
    )

    embed.add_field(
        name="🌐 Ports Allocated",
        value=f"`{total_ports_allocated}`",
        inline=True
    )

    embed.add_field(
        name="🔌 Ports In Use",
        value=f"`{total_ports_used}`",
        inline=True
    )

    # ── Row 4 ──────────────────────────────────────────────────

    # ── Row 4 ──────────────────────────────────────────────────
    embed.add_field(
        name="📊 Port Utilization",
        value=(
            f"`{total_ports_used}/{total_ports_allocated}`"
            if total_ports_allocated else "`N/A`"
        ),
        inline=True
    )

    embed.set_footer(text="⚡ RGNODES™ • Real-Time Monitoring")
    embed.timestamp = ctx.message.created_at

    await ctx.send(embed=embed)

# ---------------------- RGNODES Live Monitoring Dashboard ----------------------
# Dashboard status is cached briefly to avoid hammering the provider's external-IP service.
_DASHBOARD_PUBLIC_IP_CACHE = {"checked_at": 0.0, "value": "", "source": ""}
_DASHBOARD_PUBLIC_IP_LOCK = asyncio.Lock()
_DASHBOARD_FRAMES = ("◐", "◓", "◑", "◒")


def _dashboard_valid_global_ipv4(value: str) -> bool:
    try:
        import ipaddress
        ip = ipaddress.ip_address(str(value or '').strip())
        return bool(ip.version == 4 and ip.is_global and not ip.is_multicast and not ip.is_reserved
                    and not ip.is_unspecified and not ip.is_loopback and not ip.is_link_local)
    except Exception:
        return False


def _collect_dashboard_host_metrics() -> Dict[str, Any]:
    """Collect local host metrics in a worker thread; never block the Discord event loop."""
    result: Dict[str, Any] = {
        "cpu": None, "ram_pct": None, "ram_used_gb": None, "ram_total_gb": None,
        "disk_pct": None, "disk_used_gb": None, "disk_total_gb": None, "uptime_seconds": None,
        "load1": None, "cpu_count": os.cpu_count() or 0, "net_rx_mb": None, "net_tx_mb": None,
        "interfaces_up": [],
    }
    try:
        import psutil
        result["cpu"] = float(psutil.cpu_percent(interval=0.20))
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        result.update({
            "ram_pct": float(memory.percent), "ram_used_gb": memory.used / (1024 ** 3),
            "ram_total_gb": memory.total / (1024 ** 3), "disk_pct": float(disk.percent),
            "disk_used_gb": disk.used / (1024 ** 3), "disk_total_gb": disk.total / (1024 ** 3),
            "uptime_seconds": max(0.0, time.time() - float(psutil.boot_time())),
        })
        counters = psutil.net_io_counters()
        if counters:
            result["net_rx_mb"] = counters.bytes_recv / (1024 ** 2)
            result["net_tx_mb"] = counters.bytes_sent / (1024 ** 2)
        result["interfaces_up"] = sorted(name for name, stats in psutil.net_if_stats().items()
                                          if stats.isup and name != 'lo')
    except Exception as exc:
        logger.debug("Dashboard psutil metrics unavailable: %s", type(exc).__name__)
    try:
        loads = os.getloadavg()
        result["load1"] = float(loads[0])
    except (AttributeError, OSError):
        pass
    return result


def _dashboard_probe_command(argv: List[str], timeout: float = 2.5) -> tuple[bool, str]:
    """Run a fixed diagnostic argv (never user-supplied shell text)."""
    try:
        completed = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False)
        text = (completed.stdout or completed.stderr or '').strip()
        return completed.returncode == 0, text[:500]
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, type(exc).__name__


def _collect_dashboard_services() -> Dict[str, Any]:
    """Read-only KVM/Docker/firewall service probes; this function never changes host policy."""
    kvm_device = Path('/dev/kvm').exists()
    virsh = shutil.which('virsh')
    libvirt_ok = False
    libvirt_detail = 'virsh not installed' if not virsh else 'libvirt unavailable'
    if kvm_device and virsh:
        libvirt_ok, libvirt_detail = _dashboard_probe_command([virsh, '-c', 'qemu:///system', 'list', '--all'], 3.0)
        if libvirt_ok:
            libvirt_detail = 'qemu:///system responding'
        else:
            libvirt_detail = 'connection unavailable'
    docker = shutil.which('docker')
    docker_ok = False
    docker_detail = 'not installed' if not docker else 'daemon unavailable'
    if docker:
        docker_ok, docker_detail = _dashboard_probe_command([docker, 'info', '--format', '{{.ServerVersion}}'], 2.5)
        if docker_ok:
            docker_detail = 'daemon online · ' + (docker_detail or 'version unknown')
    ufw = shutil.which('ufw')
    ufw_state = 'not installed'
    if ufw:
        ok, text = _dashboard_probe_command([ufw, 'status'], 2.0)
        lowered = text.lower()
        if 'status: active' in lowered:
            ufw_state = 'active'
        elif 'status: inactive' in lowered:
            ufw_state = 'inactive'
        elif not ok:
            ufw_state = 'unknown'
    fail2ban_state = 'unknown'
    systemctl = shutil.which('systemctl')
    if systemctl:
        active, _ = _dashboard_probe_command([systemctl, 'is-active', 'fail2ban'], 2.0)
        if active:
            fail2ban_client = shutil.which('fail2ban-client')
            jail_ok, _ = _dashboard_probe_command([fail2ban_client, 'status', 'sshd'], 2.0) if fail2ban_client else (False, '')
            fail2ban_state = 'active · sshd jail active' if jail_ok else 'service active · sshd jail unverified'
        else:
            installed, _ = _dashboard_probe_command([systemctl, 'list-unit-files', 'fail2ban.service', '--no-legend'], 2.0)
            fail2ban_state = 'inactive/not installed' if installed else 'unknown'
    uplink = PUBLIC_PARENT_INTERFACE
    if not uplink:
        ip_cmd = shutil.which('ip')
        if ip_cmd:
            _, route = _dashboard_probe_command([ip_cmd, 'route', 'get', '1.1.1.1'], 1.5)
            match = re.search(r'\bdev\s+([A-Za-z0-9_.:@-]+)', route)
            if match:
                uplink = match.group(1)
    return {
        'kvm_device': kvm_device, 'libvirt_ok': libvirt_ok, 'libvirt_detail': libvirt_detail,
        'docker_ok': docker_ok, 'docker_detail': docker_detail, 'ufw_state': ufw_state,
        'fail2ban_state': fail2ban_state, 'uplink': uplink or 'not detected',
        'bridge': PUBLIC_BRIDGE_NAME or 'not configured', 'network_mode': KVM_NETWORK_MODE,
    }


async def _dashboard_public_ipv4() -> tuple[str, str]:
    """Return configured/detected host egress IPv4; explicitly not a guest-address guarantee."""
    configured = str(PUBLIC_IPV4 or '').strip()
    if _dashboard_valid_global_ipv4(configured):
        return configured, 'configured'
    if not AUTO_DETECT_PUBLIC_IP:
        return '', 'auto-detection disabled'
    now = time.monotonic()
    async with _DASHBOARD_PUBLIC_IP_LOCK:
        if now - float(_DASHBOARD_PUBLIC_IP_CACHE.get('checked_at', 0.0)) < 300:
            return str(_DASHBOARD_PUBLIC_IP_CACHE.get('value', '')), str(_DASHBOARD_PUBLIC_IP_CACHE.get('source', 'cached'))
        value, source = '', 'unavailable'
        try:
            response = await asyncio.wait_for(asyncio.to_thread(
                requests.get, 'https://api4.ipify.org',
                headers={'User-Agent': _make_discord_user_agent(BOT_NAME, BOT_VERSION)}, timeout=2.5
            ), timeout=3.0)
            candidate = response.text.strip() if response.status_code == 200 else ''
            if _dashboard_valid_global_ipv4(candidate):
                value, source = candidate, 'auto-detected host egress'
        except Exception as exc:
            logger.debug('Dashboard public IPv4 detection unavailable: %s', type(exc).__name__)
        _DASHBOARD_PUBLIC_IP_CACHE.update({'checked_at': time.monotonic(), 'value': value, 'source': source})
        return value, source


def _dashboard_progress(value: Optional[float]) -> str:
    if value is None:
        return '`unavailable`'
    try:
        numeric = max(0.0, min(100.0, float(value)))
    except (TypeError, ValueError):
        return '`unavailable`'
    return create_progress_bar(numeric)


def _dashboard_uptime(seconds: Optional[float]) -> str:
    if seconds is None:
        return 'unavailable'
    total = max(0, int(seconds))
    days, rem = divmod(total, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, _ = divmod(rem, 60)
    return f'{days}d {hours:02d}h {minutes:02d}m'


async def build_monitoring_dashboard_embed(frame: int = 0) -> discord.Embed:
    """Create a detailed, animated-by-refresh RGNODES host + virtualisation dashboard."""
    metrics, services = await asyncio.gather(
        asyncio.to_thread(_collect_dashboard_host_metrics),
        asyncio.to_thread(_collect_dashboard_services),
    )
    nodes = []
    try:
        nodes = list(get_nodes())
    except Exception as exc:
        logger.debug('Dashboard node inventory failed: %s', type(exc).__name__)
    vps_items = [v for owner_items in list(vps_data.values()) for v in list(owner_items)]
    total_vps = len(vps_items)
    running_vps = sum(1 for v in vps_items if str(v.get('status', '')).lower() == 'running' and not v.get('suspended', False))
    suspended_vps = sum(1 for v in vps_items if bool(v.get('suspended', False)))
    stopped_vps = max(0, total_vps - running_vps - suspended_vps)
    total_users = len(vps_data)

    async def check_node(node: Dict[str, Any]) -> bool:
        if node.get('is_local'):
            return bool(services['kvm_device'] and services['libvirt_ok'])
        url = str(node.get('url') or '').rstrip('/') + '/api/ping'
        key = str(node.get('api_key') or '')
        if not url.startswith(('https://', 'http://')) or not key:
            return False
        try:
            response = await asyncio.wait_for(asyncio.to_thread(
                requests.get, url, headers={'X-API-Key': key, 'User-Agent': _make_discord_user_agent(BOT_NAME, BOT_VERSION)}, timeout=2.5
            ), timeout=3.0)
            return response.status_code == 200
        except Exception:
            return False

    node_checks = await asyncio.gather(*(check_node(n) for n in nodes[:20]), return_exceptions=True) if nodes else []
    nodes_checked = len(node_checks)
    nodes_online = sum(1 for result in node_checks if result is True)
    total_vps_users = sum(1 for _owner, items in vps_data.items() if items)
    public_ip, public_ip_source = await _dashboard_public_ipv4()

    cpu = metrics.get('cpu')
    ram = metrics.get('ram_pct')
    disk = metrics.get('disk_pct')
    health_issues = []
    if not services['kvm_device']:
        health_issues.append('KVM device unavailable')
    if not services['libvirt_ok']:
        health_issues.append('libvirt unavailable')
    if cpu is not None and cpu >= 90:
        health_issues.append('CPU critical')
    if ram is not None and ram >= 90:
        health_issues.append('RAM critical')
    if disk is not None and disk >= 95:
        health_issues.append('disk nearly full')
    if services['fail2ban_state'] != 'active · sshd jail active':
        health_issues.append('fail2ban not confirmed active')
    if not health_issues:
        health = '● ALL CHECKED SYSTEMS HEALTHY'
    elif any(x in health_issues for x in ('KVM device unavailable', 'libvirt unavailable', 'CPU critical', 'RAM critical', 'disk nearly full')):
        health = '▲ ATTENTION REQUIRED · ' + ', '.join(health_issues[:3])
    else:
        health = '◆ PARTIAL HARDENING · ' + ', '.join(health_issues[:3])

    spinner = _DASHBOARD_FRAMES[frame % len(_DASHBOARD_FRAMES)]
    embed = create_embed(f'{spinner} RGNODES™ · LIVE HOST DASHBOARD',
                         'Animated monitoring panel · refreshes every 15 seconds while auto-refresh is enabled')
    embed.set_author(name='Power By RGNODES™', icon_url=BOT_ICON_URL or None)
    load_text = f'{metrics["load1"]:.2f}' if metrics.get('load1') is not None else 'unavailable'
    telemetry = (f'**CPU**  {_dashboard_progress(cpu)}\n'
                 f'**RAM**  {_dashboard_progress(ram)}\n'
                 f'**Disk** {_dashboard_progress(disk)}\n'
                 f'**Uptime:** `{_dashboard_uptime(metrics.get("uptime_seconds"))}`\n'
                 f'**Load 1m:** `{load_text}`')
    add_field(embed, '⚡ Host Resource Telemetry', telemetry, True)
    ram_text = (f'{metrics["ram_used_gb"]:.2f}/{metrics["ram_total_gb"]:.2f} GiB'
                if metrics.get('ram_used_gb') is not None and metrics.get('ram_total_gb') else 'unavailable')
    disk_text = (f'{metrics["disk_used_gb"]:.1f}/{metrics["disk_total_gb"]:.1f} GiB'
                 if metrics.get('disk_used_gb') is not None and metrics.get('disk_total_gb') else 'unavailable')
    network_text = (f'RX `{metrics["net_rx_mb"]:.1f} MiB` · TX `{metrics["net_tx_mb"]:.1f} MiB`'
                    if metrics.get('net_rx_mb') is not None and metrics.get('net_tx_mb') is not None else 'Counters unavailable')
    add_field(embed, '📦 Capacity', f'RAM `{ram_text}`\nDisk `{disk_text}`\nLogical CPUs `{metrics.get("cpu_count", 0)}`\n{network_text}', True)
    libvirt_status = 'ONLINE' if services['libvirt_ok'] else 'OFFLINE / UNAVAILABLE'
    kvm_status = 'PRESENT' if services['kvm_device'] else 'MISSING'
    docker_status = services['docker_detail'] if services['docker_ok'] else services['docker_detail']
    add_field(embed, '🧩 Virtualization & Docker',
              f'**KVM:** `{kvm_status}`\n**libvirt:** `{libvirt_status}`\n'
              f'**Docker:** `{truncate_text(docker_status, 110)}`\n**Backend:** `KVM/QEMU/libvirt`', True)
    add_field(embed, '🌐 Network & Addressing',
              f'**Host egress IPv4:** `{public_ip or "Unavailable"}`\n'
              f'**Source:** `{public_ip_source}`\n'
              f'**Mode:** `{services["network_mode"]}`\n'
              f'**Uplink:** `{services["uplink"]}`\n'
              f'**Bridge:** `{services["bridge"]}`\n'
              f'**Pool:** `{PUBLIC_IPV4_POOL_CIDR or "not configured"}`', True)
    # Explicitly prevent confusion between NAT egress and public IPs routed into guests.
    add_field(embed, '🛡️ Host Protection Signals',
              f'**Anti-mining policy:** `{ "ENABLED" if ANTI_MINING_ENABLED else "disabled" }`\n'
              f'**Host CPU deploy ceiling:** `{HOST_CPU_MAX_DEPLOY_PCT:.0f}%`\n'
              f'**RAM reserve:** `{HOST_RAM_RESERVE_GB:.1f} GiB`\n'
              f'**Disk reserve:** `{HOST_DISK_RESERVE_GB:.1f} GiB`\n'
              f'**Fail2ban:** `{services["fail2ban_state"]}`\n**UFW:** `{services["ufw_state"]}`', True)
    add_field(embed, '🖥️ VPS / Node Fleet',
              f'**VPS:** `{total_vps}` total · `{running_vps}` running · `{stopped_vps}` stopped · `{suspended_vps}` suspended\n'
              f'**Owners with VPS:** `{total_vps_users}`\n'
              f'**Nodes online:** `{nodes_online}/{nodes_checked}` checked'
              + (f' · `{max(0, len(nodes)-nodes_checked)}` beyond probe cap' if len(nodes) > nodes_checked else ''), True)
    latency = round(bot.latency * 1000) if bot.is_ready() and bot.latency is not None else None
    embed.add_field(name='➤ Bot / Health', value=(
        f'**Gateway:** `{"CONNECTED" if bot.is_ready() else "NOT READY"}`\n'
        f'**Latency:** `{latency} ms`' if latency is not None else
        f'**Gateway:** `{"CONNECTED" if bot.is_ready() else "NOT READY"}`\n**Latency:** `unavailable`'
    ) + f'\n**Health:** {health}', inline=False)
    embed.set_footer(text=f'Power By RGNODES™ · Live frame {frame % len(_DASHBOARD_FRAMES) + 1}/{len(_DASHBOARD_FRAMES)} · {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    return embed


class MonitoringDashboardView(RGNODESView):
    """Owner-controlled dashboard controls with bounded 5-minute auto-refresh."""
    def __init__(self, owner_id: int):
        super().__init__(timeout=300)
        self.owner_id = int(owner_id)
        self.message = None
        self.auto_refresh = True
        self.frame = 0
        self._refresh_task = None

    async def _authorized(self, interaction: discord.Interaction) -> bool:
        if int(getattr(interaction.user, 'id', 0)) == self.owner_id or is_admin_user(interaction.user):
            return True
        await interaction.response.send_message('Only the dashboard creator or an administrator can control this live panel.', ephemeral=True)
        return False

    async def _render_and_edit(self, interaction: Optional[discord.Interaction] = None):
        self.frame = (self.frame + 1) % len(_DASHBOARD_FRAMES)
        embed = await build_monitoring_dashboard_embed(self.frame)
        if interaction is not None and not interaction.response.is_done():
            await interaction.response.edit_message(embed=embed, view=self)
        elif self.message is not None:
            await self.message.edit(embed=embed, view=self)

    def start_auto_refresh(self):
        if self.auto_refresh and (self._refresh_task is None or self._refresh_task.done()):
            self._refresh_task = asyncio.create_task(self._auto_refresh_loop(), name=f'rgnodes_dashboard_{self.owner_id}')

    async def _auto_refresh_loop(self):
        try:
            while self.auto_refresh and not self.is_finished():
                await asyncio.sleep(15)
                if not self.auto_refresh or self.is_finished() or self.message is None:
                    break
                try:
                    await self._render_and_edit()
                except discord.NotFound:
                    break
                except discord.HTTPException as exc:
                    logger.debug('Dashboard auto-refresh HTTP error: %s', getattr(exc, 'status', 'unknown'))
                except Exception as exc:
                    logger.warning('Dashboard auto-refresh failed (%s).', type(exc).__name__)
        except asyncio.CancelledError:
            raise
        finally:
            self._refresh_task = None

    @discord.ui.button(label='Refresh now', emoji='🔄', style=discord.ButtonStyle.secondary)
    async def refresh_now(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._authorized(interaction):
            return
        await interaction.response.defer()
        try:
            await self._render_and_edit()
        except Exception as exc:
            logger.warning('Manual dashboard refresh failed (%s).', type(exc).__name__)
            await interaction.followup.send('Dashboard refresh failed temporarily. Check bot logs and try again.', ephemeral=True)

    @discord.ui.button(label='Auto-refresh: ON', emoji='⏱️', style=discord.ButtonStyle.secondary)
    async def toggle_auto_refresh(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._authorized(interaction):
            return
        self.auto_refresh = not self.auto_refresh
        button.label = f'Auto-refresh: {"ON" if self.auto_refresh else "OFF"}'
        button.style = discord.ButtonStyle.secondary if self.auto_refresh else discord.ButtonStyle.secondary
        if self.auto_refresh:
            self.start_auto_refresh()
        elif self._refresh_task and not self._refresh_task.done():
            self._refresh_task.cancel()
        await interaction.response.defer()
        await self._render_and_edit()

    @discord.ui.button(label='Close panel', emoji='✖️', style=discord.ButtonStyle.secondary)
    async def close_dashboard(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._authorized(interaction):
            return
        self.auto_refresh = False
        if self._refresh_task and not self._refresh_task.done():
            self._refresh_task.cancel()
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(content='RGNODES live dashboard session closed.', embed=None, view=self)
        self.stop()

    async def on_timeout(self):
        self.auto_refresh = False
        if self._refresh_task and not self._refresh_task.done():
            self._refresh_task.cancel()
        for child in self.children:
            child.disabled = True
        if self.message is not None:
            try:
                await self.message.edit(view=self)
            except (discord.NotFound, discord.HTTPException):
                pass


@bot.command(name='dashboard', aliases=['monitor', 'monitoring'])
@is_admin()
async def monitoring_dashboard(ctx):
    """Open a live host/KVM/IPv4/Docker/security monitor with animated refresh controls."""
    view = MonitoringDashboardView(ctx.author.id)
    try:
        embed = await build_monitoring_dashboard_embed(view.frame)
        message = await ctx.send(embed=embed, view=view, allowed_mentions=discord.AllowedMentions.none())
        view.message = message
        view.start_auto_refresh()
    except Exception as exc:
        logger.error('Unable to render monitoring dashboard (%s).', type(exc).__name__, exc_info=True)
        await ctx.send(embed=create_error_embed('Dashboard Unavailable', 'Live metrics could not be collected. Check `-check` output and bot logs; no host settings were changed.'))


@bot.command(name='vpsinfo')
@is_admin()
async def vps_info(ctx, container_name: str = None):
    if not container_name:
        all_vps = []
        for user_id, vps_list in vps_data.items():
            try:
                user = await bot.fetch_user(int(user_id))
                for i, vps in enumerate(vps_list):
                    node = get_node(vps['node_id'])
                    node_name = node['name'] if node else "Unknown"
                    status_text = vps.get('status', 'unknown').upper()
                    if vps.get('suspended', False):
                        status_text += " (SUSPENDED)"
                    if vps.get('whitelisted', False):
                        status_text += " (WHITELISTED)"
                    
                    # Add expiration info
                    expiration_text = ""
                    if vps.get('expiration_date'):
                        expiration_dt = datetime.fromisoformat(vps['expiration_date'])
                        days_remaining = (expiration_dt - datetime.now()).days
                        if days_remaining < 0:
                            expiration_text = " • 🔴 EXPIRED"
                        elif days_remaining <= EXPIRATION_WARNING_DAYS:
                            expiration_text = f" • 🟡 EXPIRING ({days_remaining}d)"
                        else:
                            expiration_text = f" • 🟢 ({days_remaining}d)"
                    
                    all_vps.append(f"**{user.name}** - VPS {i+1}: `{vps['container_name']}` - {status_text} (Node: {node_name}){expiration_text}")
            except:
                pass
        vps_text = "\n".join(all_vps)
        chunks = [vps_text[i:i+1024] for i in range(0, len(vps_text), 1024)]
        for idx, chunk in enumerate(chunks, 1):
            embed = create_embed(f"🖥️ All VPS (Part {idx}/{len(chunks)})", f"Complete list of all VPS deployments with expiration status", 0x2ecc71)
            add_field(embed, "VPS Inventory", chunk, False)
            embed.set_footer(text=f"⚡ RGNODES™ • VPS Information System")
            await ctx.send(embed=embed)
    else:
        found_vps = None
        found_user = None
        for user_id, vps_list in vps_data.items():
            for vps in vps_list:
                if vps['container_name'] == container_name:
                    found_vps = vps
                    found_user = await bot.fetch_user(int(user_id))
                    break
            if found_vps:
                break
        if not found_vps:
            await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS found with container name: `{container_name}`"))
            return
        node = get_node(found_vps['node_id'])
        node_name = node['name'] if node else "Unknown"
        
        # Determine status color based on expiration and suspension
        status_color = 0x1a1a1a
        if found_vps.get('suspended', False):
            status_color = 0xffaa00
        elif found_vps.get('expiration_date'):
            expiration_dt = _safe_fromiso(found_vps['expiration_date'])
            if expiration_dt == datetime.max:
                add_field(embed, 'Status', '⚠️ INVALID EXPIRATION DATA', True)
                await ctx.send(embed=embed)
                return
            days_remaining = (expiration_dt - datetime.now()).days
            if days_remaining < 0:
                status_color = 0xff3366
            elif days_remaining <= EXPIRATION_WARNING_DAYS:
                status_color = 0xffaa00
            else:
                status_color = 0x2ecc71
        
        suspended_text = " (SUSPENDED)" if found_vps.get('suspended', False) else ""
        whitelisted_text = " (WHITELISTED)" if found_vps.get('whitelisted', False) else ""
        embed = create_embed(f"🖥️ VPS Information - {container_name}", f"Detailed VPS profile owned by {found_user.mention}{suspended_text}{whitelisted_text}")
        
        add_field(embed, "👤 Owner", f"**Name:** {found_user.name}\n**ID:** `{found_user.id}`\n**Mention:** {found_user.mention}", False)
        
        add_field(embed, "🌐 Location & Node", f"**Node:** {node_name}\n**Node Type:** {'📍 Local' if node.get('is_local') else '🌐 Remote'}\n**Node ID:** `{found_vps.get('node_id', 1)}`", True)
        
        add_field(embed, "📊 Specifications", f"**RAM:** `{found_vps['ram']}`\n**CPU:** `{found_vps['cpu']}` Cores\n**Storage:** `{found_vps['storage']}`\n**Config:** {found_vps.get('config', 'Custom')}", True)
        
        # Status information
        status_info = f"**Current Status:** `{found_vps.get('status', 'unknown').upper()}`\n"
        status_info += f"**Suspended:** {'🟡 Yes' if found_vps.get('suspended', False) else '🟢 No'}\n"
        status_info += f"**Whitelisted:** {'✅ Yes' if found_vps.get('whitelisted', False) else '❌ No'}\n"
        status_info += f"**Created:** `{found_vps.get('created_at', 'Unknown')}`"
        add_field(embed, "📈 Status", status_info, False)
        
        # Expiration information
        if found_vps.get('expiration_date'):
            expiration_dt = datetime.fromisoformat(found_vps['expiration_date'])
            days_remaining = (expiration_dt - datetime.now()).days
            
            if days_remaining < 0:
                exp_status = "🔴 EXPIRED"
                exp_color = "FF3366"
            elif days_remaining <= EXPIRATION_WARNING_DAYS:
                exp_status = "🟡 EXPIRING SOON"
                exp_color = "FFAA00"
            else:
                exp_status = "🟢 ACTIVE"
                exp_color = "2ECC71"
            
            exp_info = f"**Status:** {exp_status}\n"
            exp_info += f"**Expires On:** `{expiration_dt.strftime('%Y-%m-%d %H:%M:%S')}`\n"
            exp_info += f"**Days Remaining:** `{max(0, days_remaining)}` days\n"
            exp_info += f"**Time Left:** `{max(0, days_remaining)} days` from today"
            add_field(embed, "⏰ Expiration", exp_info, False)
        else:
            add_field(embed, "⏰ Expiration", f"**Status:** 🔵 No expiration date set\n**Action:** Use `{PREFIX}set-expiration` to configure", False)
        
        if found_vps.get('shared_with'):
            shared_users = []
            for shared_id in found_vps['shared_with']:
                try:
                    shared_user = await bot.fetch_user(int(shared_id))
                    shared_users.append(f"• {shared_user.mention} (`{shared_id}`)")
                except:
                    shared_users.append(f"• Unknown User (`{shared_id}`)")
            shared_text = "\n".join(shared_users)
            add_field(embed, "🔗 Shared Access", shared_text, False)
        
        # Port forwarding info
        conn = get_db()
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM port_forwards WHERE vps_container = ?', (container_name,))
        port_count = cur.fetchone()[0]
        cur.execute('SELECT * FROM port_forwards WHERE vps_container = ? LIMIT 5', (container_name,))
        ports = cur.fetchall()
        conn.close()
        
        if port_count > 0:
            port_info = f"**Total:** `{port_count}` forwarded ports (TCP & UDP)\n"
            if ports:
                port_info += "**Active Forwards:**\n"
                for p in ports:
                    port_info += f"  • `{p['host_port']}` → VPS:`{p['vps_port']}`\n"
                if port_count > 5:
                    port_info += f"  • ... +{port_count - 5} more"
            add_field(embed, "🌐 Port Forwarding", port_info, False)
        else:
            add_field(embed, "🌐 Port Forwarding", "**Status:** No active port forwards", False)
        
        # OS information
        add_field(embed, "🐧 Operating System", f"`{found_vps.get('os_version', 'ubuntu:22.04')}`", True)
        
        embed.set_footer(text=f"⚡ RGNODES™ • VPS Information System • Container: {container_name}")
        await ctx.send(embed=embed)

@bot.command(name='restart-vps')
@is_admin()
async def restart_vps(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    _, _, target = find_vps_record(container_name)
    if not target:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"`{container_name}` was not found."))
        return
    if target.get('suspended', False):
        await ctx.send(embed=create_error_embed("VPS Suspended", "This VPS is suspended. Use the appropriate unsuspend/renew command first."))
        return
    await ctx.send(embed=create_info_embed("Restarting VPS", f"Restarting VPS `{container_name}`..."))
    try:
        await execute_vpsctl_compat(container_name, f"restart {container_name}", node_id=node_id)
        for user_id, vps_list in vps_data.items():
            for vps in vps_list:
                if vps['container_name'] == container_name:
                    vps['status'] = 'running'
                    save_vps_data_immediate()
                    break
        await apply_internal_permissions(container_name, node_id)
        await install_anti_mining_guard(container_name, node_id)
        await apply_guest_motd(container_name, node_id)
        await recreate_port_forwards(container_name)
        await ctx.send(embed=create_success_embed("VPS Restarted", f"VPS `{container_name}` has been restarted successfully!"))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Restart Failed", safe_error_summary("VPS restart", e)))

@bot.command(name='exec')
@is_admin()
async def execute_command(ctx, container_name: str, *, command: str):
    """Run a remote admin command but DM output to avoid leaking host/guest secrets."""
    node_id = find_node_id_for_container(container_name)
    await ctx.send(embed=create_info_embed("Executing Command", f"Running the requested command in VPS `{container_name}`. Results will be sent privately."))
    try:
        output = await _exec_guest_bash(container_name, node_id, command, timeout=300)
        embed = create_embed(f"Private Command Result - {container_name}", "The command completed. Command text is not echoed into Discord channels.")
        if output.strip():
            if len(output) > 900:
                output = output[:900] + "\n... (truncated; output exceeded the private report limit)"
            add_field(embed, "📤 Output", f"```text\n{output}\n```", False)
        else:
            add_field(embed, "📤 Output", "The command returned no output.", False)
        try:
            await ctx.author.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
        except (discord.Forbidden, discord.HTTPException):
            await ctx.send(embed=create_warning_embed(
                "Private Output Not Delivered",
                "The remote command completed, but Discord could not deliver its output to your DM. The output was not posted publicly. Enable DMs and rerun the command if a fresh result is needed."
            ))
            return
        await ctx.send(embed=create_success_embed("Command Completed", "The command result was delivered privately to your DMs; no output or command text was published in this channel."))
    except Exception as e:
        logger.error("Remote command execution failed for %s (%s)", container_name, type(e).__name__)
        await ctx.send(embed=create_error_embed("Execution Failed", safe_error_summary("Remote command execution", e)))

@bot.command(name='stop-vps-all')
@is_admin()
async def stop_all_vps(ctx):
    embed = create_warning_embed("Stopping All VPS", "⚠️ **WARNING:** This will stop all **bot-managed** running VPS across all configured nodes.\n\nUnmanaged KVM VPSs are not touched. Continue?")
    class ConfirmView(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=60)

        @discord.ui.button(label="Stop All VPS", style=discord.ButtonStyle.secondary)
        async def confirm(self, interaction: discord.Interaction, item: discord.ui.Button):
            if str(interaction.user.id) != str(ctx.author.id):
                await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the admin who started this operation can confirm it."), ephemeral=True)
                return
            await interaction.response.defer()
            try:
                stopped_count = 0
                failed = []
                for user_id, vps_list in list(vps_data.items()):
                    for vps in list(vps_list):
                        container = str(vps.get('container_name') or '')
                        if not container:
                            continue
                        node_id = int(vps.get('node_id', 1))
                        try:
                            await execute_vpsctl_compat(container, f"stop {container} --force", timeout=180, node_id=node_id)
                        except Exception as e:
                            msg = str(e).lower()
                            if not any(x in msg for x in ("not running", "already stopped", "is stopped")):
                                failed.append(f"{container}: {type(e).__name__}")
                                continue
                        if vps.get('status') != 'stopped':
                            stopped_count += 1
                        vps['status'] = 'stopped'
                save_vps_data_immediate()
                description = f"Ensured **{stopped_count}** managed VPS instances are stopped."
                if failed:
                    description += f"\n\n**Failures:** {len(failed)}\n" + "\n".join(f"• {x}" for x in failed[:8])
                embed = create_success_embed("All Managed VPS Stopped", description)
                await interaction.followup.send(embed=embed)
            except Exception as e:
                embed = create_error_embed("Error", safe_error_summary("Stop all VPS", e))
                await interaction.followup.send(embed=embed)

        @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
        async def cancel(self, interaction: discord.Interaction, item: discord.ui.Button):
            if str(interaction.user.id) != str(ctx.author.id):
                await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the admin who started this operation can cancel it."), ephemeral=True)
                return
            await interaction.response.edit_message(embed=create_info_embed("Operation Cancelled", "The stop all VPS operation has been cancelled."))

    await ctx.send(embed=embed, view=ConfirmView())

@bot.command(name='cpu-monitor')
@is_admin()
async def resource_monitor_control(ctx, action: str = "status"):
    global resource_monitor_active
    if action.lower() == "status":
        status = "Active" if resource_monitor_active else "Inactive"
        embed = create_embed("Resource Monitor Status", f"Resource monitoring is currently **{status}** (logs only; no auto-stop)", 0x00ccff if resource_monitor_active else 0xffaa00)
        add_field(embed, "Thresholds", f"{CPU_THRESHOLD}% CPU / {RAM_THRESHOLD}% RAM usage", True)
        add_field(embed, "Check Interval", f"60 seconds (all nodes)", True)
        await ctx.send(embed=embed)
    elif action.lower() == "enable":
        resource_monitor_active = True
        await ctx.send(embed=create_success_embed("Resource Monitor Enabled", "Resource monitoring has been enabled."))
    elif action.lower() == "disable":
        resource_monitor_active = False
        await ctx.send(embed=create_warning_embed("Resource Monitor Disabled", "Resource monitoring has been disabled."))
    else:
        await ctx.send(embed=create_error_embed("Invalid Action", f"Use: `{PREFIX}cpu-monitor <status|enable|disable>`"))

@bot.command(name='resize-vps')
@is_admin()
async def resize_vps(ctx, container_name: str, ram: int = None, cpu: int = None, disk: int = None):
    if ram is None and cpu is None and disk is None:
        await ctx.send(embed=create_error_embed("Missing Parameters", "Please specify at least one resource to resize (ram, cpu, or disk)"))
        return
    found_vps = None
    user_id = None
    vps_index = None
    for uid, vps_list in vps_data.items():
        for i, vps in enumerate(vps_list):
            if vps['container_name'] == container_name:
                found_vps = vps
                user_id = uid
                vps_index = i
                break
        if found_vps:
            break
    if not found_vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS found with container name: `{container_name}`"))
        return
    node_id = found_vps['node_id']
    if ram is not None and not (1 <= int(ram) <= MAX_VPS_RAM_GB):
        await ctx.send(embed=create_error_embed("Invalid RAM", f"RAM must be between 1 and {MAX_VPS_RAM_GB} GB. VPS was not stopped.")); return
    if cpu is not None and not (1 <= int(cpu) <= MAX_VPS_CPU):
        await ctx.send(embed=create_error_embed("Invalid CPU", f"CPU must be between 1 and {MAX_VPS_CPU} cores. VPS was not stopped.")); return
    if disk is not None and not (VPS_MIN_DISK_GB <= int(disk) <= VPS_MAX_DISK_GB):
        await ctx.send(embed=create_error_embed("Invalid Disk", f"Disk must be between {VPS_MIN_DISK_GB} and {VPS_MAX_DISK_GB} GB. VPS was not stopped.")); return
    was_running = found_vps.get('status') == 'running' and not found_vps.get('suspended', False)
    disk_changed = disk is not None
    if was_running:
        await ctx.send(embed=create_info_embed("Stopping VPS", f"Stopping VPS `{container_name}` to apply resource changes..."))
        try:
            await execute_vpsctl_compat(container_name, f"stop {container_name}", node_id=node_id)
            found_vps['status'] = 'stopped'
            save_vps_data_immediate()
        except Exception as e:
            await ctx.send(embed=create_error_embed("Stop Failed", safe_error_summary("VPS stop", e)))
            return
    changes = []
    try:
        new_ram = int(found_vps['ram'].replace('GB', ''))
        new_cpu = int(found_vps['cpu'])
        new_disk = int(found_vps['storage'].replace('GB', ''))
        if ram is not None and ram > 0:
            new_ram = ram
            ram_mb = ram * 1024
            await execute_vpsctl_compat(container_name, f"config set {container_name} limits.memory {ram_mb}MB", node_id=node_id)
            changes.append(f"RAM: {ram}GB")
            found_vps['ram'] = f"{new_ram}GB"
            found_vps['config'] = f"{new_ram}GB RAM / {new_cpu} CPU / {new_disk}GB Disk"
            save_vps_data_immediate()
        if cpu is not None and cpu > 0:
            new_cpu = cpu
            await execute_vpsctl_compat(container_name, f"config set {container_name} limits.cpu {cpu}", node_id=node_id)
            changes.append(f"CPU: {cpu} cores")
            found_vps['cpu'] = str(new_cpu)
            found_vps['config'] = f"{new_ram}GB RAM / {new_cpu} CPU / {new_disk}GB Disk"
            save_vps_data_immediate()
        if disk is not None and disk > 0:
            new_disk = disk
            await execute_vpsctl_compat(container_name, f"config device set {container_name} root size={disk}GB", node_id=node_id)
            changes.append(f"Disk: {disk}GB")
            found_vps['storage'] = f"{new_disk}GB"
            found_vps['config'] = f"{new_ram}GB RAM / {new_cpu} CPU / {new_disk}GB Disk"
            save_vps_data_immediate()
        found_vps['ram'] = f"{new_ram}GB"
        found_vps['cpu'] = str(new_cpu)
        found_vps['storage'] = f"{new_disk}GB"
        found_vps['config'] = f"{new_ram}GB RAM / {new_cpu} CPU / {new_disk}GB Disk"
        vps_data[user_id][vps_index] = found_vps
        save_vps_data_immediate()
        if was_running:
            await execute_vpsctl_compat(container_name, f"start {container_name}", node_id=node_id)
            found_vps['status'] = 'running'
            save_vps_data_immediate()
            await apply_internal_permissions(container_name, node_id)
            await recreate_port_forwards(container_name)
        embed = create_success_embed("VPS Resized", f"Successfully resized resources for VPS `{container_name}`")
        add_field(embed, "Changes Applied", "\n".join(changes), False)
        if disk_changed:
            add_field(embed, "Disk Note", "Run `sudo resize2fs /` inside the VPS to expand the filesystem.", False)
        await ctx.send(embed=embed)
    except Exception as e:
        logger.warning("VPS resize failed for %s (%s).", container_name, type(e).__name__)
        if was_running:
            if found_vps.get('status') != 'running':
                try:
                    await execute_vpsctl_compat(container_name, f"start {container_name}", node_id=node_id)
                    found_vps['status'] = 'running'
                    save_vps_data_immediate()
                except Exception as restart_exc:
                    found_vps['status'] = 'stopped'
                    save_vps_data_immediate()
                    logger.error("Failed to restore VPS %s after resize error (%s).", container_name, type(restart_exc).__name__)
            if found_vps.get('status') == 'running':
                try:
                    await apply_internal_permissions(container_name, node_id)
                    await recreate_port_forwards(container_name)
                except Exception as repair_exc:
                    logger.warning("Post-failure access repair skipped for %s (%s).", container_name, type(repair_exc).__name__)
        await ctx.send(embed=create_error_embed("Resize Failed", safe_error_summary("VPS resize", e)))

@bot.command(name='clone-vps')
@is_admin()
async def clone_vps(ctx, container_name: str, new_name: str = None):
    """Clone a managed VPS using the same canonical rgnodes-vps-{VPS ID} naming scheme."""
    source_node_id = find_node_id_for_container(container_name)
    found_vps = None
    user_id = None
    for uid, vps_list in vps_data.items():
        for vps in vps_list:
            if str(vps.get('container_name')) == container_name:
                found_vps, user_id = vps, str(uid)
                break
        if found_vps:
            break
    if not found_vps:
        await ctx.send(embed=create_error_embed('🖥️ VPS Not Found', f'No VPS found with container name: `{container_name}`'))
        return
    new_vmid = reserve_vps_vmid()
    new_name = f'{VPS_HOSTNAME}-{new_vmid}'
    await ctx.send(embed=create_info_embed('📋 VPS Clone', f'Preparing `{new_name}` from `{container_name}`.'))
    created = False
    try:
        await execute_vpsctl_compat(container_name, f'copy {container_name} {new_name}', node_id=source_node_id)
        created = True
        await apply_vps_vm_config(new_name, source_node_id)
        await execute_vpsctl_compat(new_name, f'start {new_name}', node_id=source_node_id)
        await apply_internal_permissions(new_name, source_node_id)
        await safe_guest_install(new_name, source_node_id)
        clone_product = str(found_vps.get('product_type') or ('DOCKER' if str(found_vps.get('config') or '').lower().startswith('docker vps') else 'KVM')).upper()
        if clone_product not in {'KVM', 'DOCKER'}:
            clone_product = 'KVM'
        clone_docker_required = clone_product == 'DOCKER' or DOCKER_INSTALL_ON_DEPLOY
        if clone_docker_required:
            await ensure_docker_ready(new_name, source_node_id, strict=(clone_product == 'DOCKER' or DOCKER_STRICT_DEPLOY))
        clone_password = generate_strong_password()
        clone_ssh_ok, clone_ssh_result = await configure_ssh(new_name, source_node_id, clone_password)
        if not clone_ssh_ok:
            logger.warning('Cloned VPS %s SSH setup deferred: %s', new_name, clone_ssh_result)
        new_vps = dict(found_vps)
        new_vps.update({
            'container_name': new_name, 'status': 'running', 'suspended': False, 'product_type': clone_product,
            'config': f'{"Docker VPS" if clone_product == "DOCKER" else "KVM VPS"} / {found_vps.get("ram", "?")} RAM / {found_vps.get("cpu", "?")} CPU / {found_vps.get("storage", "?")} Disk',
            'whitelisted': False, 'suspension_history': [], 'created_at': datetime.now().isoformat(),
            'shared_with': [], 'id': None, 'vmid': new_vmid, 'root_password': clone_password,
            'ssh_ready': bool(clone_ssh_ok),
            'pinggy_host': None, 'pinggy_port': None, 'pinggy_url': None, 'pinggy_pid': None,
            'bandwidth_gb': VPS_BANDWIDTH_GB, 'bandwidth_used_bytes': 0,
            'bandwidth_cycle_start': datetime.now().isoformat(), 'bandwidth_last_rx_bytes': 0,
            'bandwidth_last_tx_bytes': 0, 'bandwidth_last_sample_at': None,
        })
        vps_data.setdefault(user_id, []).append(new_vps)
        try:
            save_vps_data()
        except Exception as exc:
            vps_data[user_id].remove(new_vps)
            if created:
                try:
                    await execute_vpsctl_compat(new_name, f'delete {new_name} --force', timeout=180, node_id=source_node_id)
                except Exception:
                    logger.critical(f'Clone rollback failed for {new_name}', exc_info=True)
            raise RuntimeError(f'Clone was created but database persistence failed: {exc}') from exc
        await create_port_forward(user_id, new_name, 22, source_node_id)
        endpoints = await detect_public_endpoints(source_node_id, new_name)
        ssh_forward = next((int(f['host_port']) for f in get_user_forwards(user_id) if str(f.get('vps_container')) == new_name and int(f.get('vps_port',0)) == 22), None)
        access = format_public_ssh_access(endpoints, ssh_forward)
        embed = create_success_embed('✅ VPS Cloned', f'Created `{new_name}` from `{container_name}`.')
        add_field(embed, '🖥️ VPS', f'VPS ID: `{new_vmid}`\nHostname: `{VPS_HOSTNAME}`\nNode: `{(get_node(source_node_id) or {}).get("name", "Unknown")}`', False)
        add_field(embed, '📦 Resources', f'RAM: `{new_vps["ram"]}`\nCPU: `{new_vps["cpu"]}` Core(s)\nSSD: `{new_vps["storage"]}`\nBandwidth: `{int(new_vps.get("bandwidth_gb") or VPS_BANDWIDTH_GB)} GB`', False)
        add_field(embed, '💻 SSH IPv4', f'`{access["ssh_ipv4"]}`' if access['ssh_ipv4'] else 'Unavailable', False)
        add_field(embed, '🌐 SSH IPv6', f'`{access["ssh_ipv6"]}`' if access['ssh_ipv6'] else 'Unavailable', False)
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(embed=create_error_embed('❌ Clone Failed', safe_error_summary('VPS clone', e)))

@bot.command(name='migrate-vps')
@is_admin()
async def migrate_vps(ctx, container_name: str, target_node_id: int):
    """Safely refuse unsupported cross-node migration rather than risking source loss."""
    source_node_id = find_node_id_for_container(container_name)
    source_node = get_node(source_node_id)
    target_node = get_node(target_node_id)
    if not source_node or not target_node:
        await ctx.send(embed=create_error_embed("🌐 Invalid Node", "Source or target node does not exist."))
        return
    if int(source_node_id) == int(target_node_id):
        await ctx.send(embed=create_warning_embed("🌐 Same Node", "The VPS is already on the selected node."))
        return
    await ctx.send(embed=create_warning_embed(
        "🛡️ Migration Blocked Safely",
        "Cross-node migration is disabled with the current node-agent contract because the target cannot safely access the source container.\n\n"
        "The previous implementation could stop the source before the copy was actually possible. No VPS data was changed.",
    ))

@bot.command(name='vps-stats')
@is_admin()
async def vps_stats(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    await ctx.send(embed=create_info_embed("Gathering Statistics", f"Collecting statistics for VPS `{container_name}`..."))
    try:
        stats = await get_container_stats(container_name, node_id)
        embed = create_info_embed(f"📊 VPS Statistics - {container_name}", "Resource usage statistics")
        add_field(embed, "📈 Status", f"**{stats['status'].upper()}**", False)
        add_field(embed, "💻 CPU Usage", f"**{stats['cpu']:.1f}%**", True)
        add_field(embed, "🧠 Memory Usage", f"**{stats['ram']['used']}/{stats['ram']['total']} MB ({stats['ram']['pct']:.1f}%)**", True)
        add_field(embed, "💾 Disk Usage", f"**{stats['disk']}**", True)
        add_field(embed, "⏱️ Uptime", f"**{stats['uptime']}**", True)
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(embed=create_error_embed("Statistics Failed", safe_error_summary("VPS statistics", e)))


@bot.command(name='kvm-status', aliases=['kvmstatus', 'kvm-health'])
@is_admin()
async def kvm_status(ctx, node_id: int = None):
    """Show real KVM/QEMU/libvirt host health without disclosing node secrets."""
    try:
        selected_node = int(node_id) if node_id is not None else _preferred_deployment_node_id()
        node = get_node(selected_node)
        if not node:
            await ctx.send(embed=create_error_embed("KVM Status", f"Node `{selected_node}` is not configured."))
            return
        health = await asyncio.wait_for(
            execute_vpsctl_compat("", "health", node_id=selected_node, timeout=30),
            timeout=32,
        )
        if not isinstance(health, dict):
            try:
                health = json.loads(str(health or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                health = {"status": "unknown", "detail": truncate_text(str(health or "No health payload"), 800)}
        status = str(health.get("status", "unknown")).strip().lower()
        def state_line(key, fallback="unknown"):
            value = health.get(key, fallback)
            if isinstance(value, bool):
                return "Available" if value else "Missing"
            return truncate_text(str(value or fallback), 120)
        embed = create_info_embed("RGNODES™ KVM / QEMU Status", f"Node: **{truncate_text(str(node.get('name') or selected_node), 100)}**\nOverall: **{status.upper()}**")
        add_field(embed, "KVM Device", state_line("kvm_device"), True)
        add_field(embed, "virsh / libvirt", state_line("virsh_available"), True)
        add_field(embed, "qemu-img", state_line("qemu_img_available"), True)
        add_field(embed, "Network Mode", state_line("network_mode", KVM_NETWORK_MODE), True)
        add_field(embed, "Health Detail", truncate_text(str(health.get("detail") or health.get("message") or "Host health payload received."), 900), False)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
    except Exception as exc:
        await ctx.send(embed=create_error_embed("KVM Status Failed", safe_error_summary("KVM health check", exc)))


async def _get_owned_vps_for_status(ctx, reference: str):
    owner_id, _index, vps = find_vps_record(reference)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", "Use the VPS ID or exact container name shown by your VPS list."))
        return None
    if str(ctx.author.id) != str(owner_id) and not is_admin_user(ctx.author):
        await ctx.send(embed=create_error_embed("Permission Denied", "Only the VPS owner or an RGNODES administrator can view this status."))
        return None
    return owner_id, vps


@bot.command(name='ssh-status', aliases=['sshstatus', 'openssh-status'])
async def ssh_status(ctx, reference: str):
    """Check persisted SSH readiness and probe the guest's SSH service without showing credentials."""
    resolved = await _get_owned_vps_for_status(ctx, reference)
    if not resolved:
        return
    _owner_id, vps = resolved
    container_name = str(vps.get("container_name") or "")
    node_id = int(vps.get("node_id") or find_node_id_for_container(container_name))
    unit_probe = "SSH_SERVICE_UNKNOWN"
    port_probe = "SSH_PORT_UNKNOWN"
    try:
        output = await asyncio.wait_for(_exec_guest_bash(
            container_name, node_id,
            "set +e\nif systemctl is-active --quiet ssh 2>/dev/null || systemctl is-active --quiet sshd 2>/dev/null; then echo SSH_SERVICE_ACTIVE; else echo SSH_SERVICE_INACTIVE; fi\nif (ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null) | grep -E '(^|[[:space:]])(0\\.0\\.0\\.0|\\[::\\]|\\*):22([[:space:]]|$)' >/dev/null; then echo SSH_PORT_LISTENING; else echo SSH_PORT_NOT_LISTENING; fi",
            timeout=20,
        ), timeout=23)
        output = str(output or "")
        unit_probe = "Active" if "SSH_SERVICE_ACTIVE" in output else "Inactive" if "SSH_SERVICE_INACTIVE" in output else "Unknown"
        port_probe = "Listening" if "SSH_PORT_LISTENING" in output else "Not listening" if "SSH_PORT_NOT_LISTENING" in output else "Unknown"
    except Exception as exc:
        logger.debug("SSH status probe deferred for %s (%s)", container_name, type(exc).__name__)
    try:
        addresses = await asyncio.wait_for(get_container_addresses(container_name, node_id), timeout=30)
    except Exception:
        addresses = {"ipv4": [], "ipv6": []}
    embed = create_info_embed("RGNODES™ OpenSSH Status", f"VPS: `{truncate_text(container_name, 100)}`")
    add_field(embed, "VPS Runtime", str((await get_container_stats(container_name, node_id)).get("status", "unknown")).upper(), True)
    add_field(embed, "SSH Setup Record", "Ready" if bool(vps.get("ssh_ready")) else "Repair queued / not verified", True)
    add_field(embed, "SSH Service", unit_probe, True)
    add_field(embed, "Port 22", port_probe, True)
    add_field(embed, "IPv4", ", ".join(addresses.get("ipv4") or []) or "Not detected", False)
    add_field(embed, "IPv6", ", ".join(addresses.get("ipv6") or []) or "Not detected", False)
    add_field(embed, "Security", "Credentials are never shown by this status command. The host key is checked by SSH clients.", False)
    await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())


@bot.command(name='docker-status', aliases=['dockerstatus'])
async def docker_status(ctx, reference: str):
    """Report actual Docker installation and daemon status for an owned VPS."""
    resolved = await _get_owned_vps_for_status(ctx, reference)
    if not resolved:
        return
    _owner_id, vps = resolved
    container_name = str(vps.get("container_name") or "")
    node_id = int(vps.get("node_id") or find_node_id_for_container(container_name))
    try:
        docker_state = await asyncio.wait_for(get_container_docker_status(container_name, node_id), timeout=30)
        runtime_state = (await get_container_stats(container_name, node_id)).get("status", "unknown")
        embed = create_info_embed("RGNODES™ Docker Status", f"VPS: `{truncate_text(container_name, 100)}`")
        add_field(embed, "VPS Runtime", str(runtime_state).upper(), True)
        add_field(embed, "Docker", str(docker_state), True)
        add_field(embed, "Automatic Repair", "Enabled; background guest repair rechecks installed packages and service health.", False)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
    except Exception as exc:
        await ctx.send(embed=create_error_embed("Docker Status Failed", safe_error_summary("Docker status", exc)))


@bot.command(name='node-check')
@is_admin()
async def node_check(ctx, node_id: int):
    """Check node status and available storage pools"""
    node = get_node(node_id)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"Node ID {node_id} not found."))
        return
    
    embed = create_info_embed(f"Node Check - {node['name']}", 
                             f"Checking status and configuration of node {node['name']}...")
    
    # Check if node is reachable
    status = await get_node_status(node_id)
    add_field(embed, "📡 Connection Status", status, False)
    
    if status.startswith("🟢"):
        # Try to get storage pools
        try:
            pools_output = await execute_vpsctl_compat("", "storage list", node_id=node_id, timeout=30)
            add_field(embed, "💾 Available Storage Pools", f"```{pools_output}```", False)
            
            # Try to get default profile
            try:
                profile_output = await execute_vpsctl_compat("", "profile list", node_id=node_id, timeout=30)
                add_field(embed, "📋 Available Profiles", f"```{profile_output[:500]}...```", False)
            except Exception as e:
                add_field(embed, "📋 Profiles", safe_error_summary("Profile list", e), False)
                
        except Exception as e:
            add_field(embed, "💾 Storage Pools", safe_error_summary("Storage pool list", e), False)
        
        # Check remote API endpoint
        try:
            test_response = await asyncio.to_thread(requests.get, str(node['url']).rstrip('/') + '/api/ping', headers={'X-API-Key': str(node['api_key'])}, timeout=5)
            add_field(embed, "🔌 API Endpoint", f"✅ Reachable\nURL: {node['url']}", False)
        except Exception as e:
            add_field(embed, "🔌 API Endpoint", "❌ Unreachable\n" + safe_error_summary("Node API check", e), False)
    else:
        add_field(embed, "⚠️ Status", "Node is offline or unreachable", False)
    
    await ctx.send(embed=embed)

@bot.command(name='vps-network')
@is_admin()
async def vps_network(ctx, container_name: str, action: str, value: str = None):
    node_id = find_node_id_for_container(container_name)
    if action.lower() not in ["list", "add", "remove", "limit"]:
        await ctx.send(embed=create_error_embed("Invalid Action", f"Use: `{PREFIX}vps-network <container> <list|add|remove|limit> [value]`"))
        return
    try:
        if action.lower() == "list":
            output = await execute_vpsctl_compat(container_name, f"exec {container_name} -- ip addr", node_id=node_id)
            if len(output) > 1000:
                output = output[:1000] + "\n... (truncated)"
            embed = create_embed(f"🌐 Network Interfaces - {container_name}", "Network configuration", 0x1a1a1a)
            add_field(embed, "Interfaces", f"```\n{output}\n```", False)
            await ctx.send(embed=embed)
        elif action.lower() == "limit" and value:
            if not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?(?:kbit|mbit|gbit|kbps|mbps|gbps)", value.strip().lower()):
                await ctx.send(embed=create_error_embed("Invalid Rate", "Use a Linux tc rate such as `10mbit`, `100mbit`, or `1gbit`."))
                return
            rate=value.strip().lower()
            script = f"""set -e
command -v tc >/dev/null 2>&1 || {{ echo 'tc is not installed'; exit 1; }}
IF=eth0
# Egress shaping. Ingress is policed to the same ceiling so a single VPS cannot
# saturate the public uplink and starve other VPSs.
tc qdisc replace dev $IF root tbf rate {rate} burst 64k latency 400ms
tc qdisc replace dev $IF handle ffff: ingress
tc filter del dev $IF parent ffff: 2>/dev/null || true
tc filter add dev $IF parent ffff: protocol all prio 1 u32 match u32 0 0 police rate {rate} burst 64k conform-exceed drop
printf 'RATE_APPLIED %s\n' {shlex.quote(rate)}
"""
            await _exec_guest_bash(container_name, node_id, script, timeout=45)
            await ctx.send(embed=create_success_embed("Network Limited", f"Applied guest-level ingress/egress rate limit **{rate}** to `{container_name}`."))
        elif action.lower() == "add" and value:
            await execute_vpsctl_compat(container_name, f"config device add {container_name} eth1 nic nictype=bridged parent={value}", node_id=node_id)
            await ctx.send(embed=create_success_embed("Network Added", f"Added network interface to VPS `{container_name}` with bridge `{value}`"))
        elif action.lower() == "remove" and value:
            await execute_vpsctl_compat(container_name, f"config device remove {container_name} {value}", node_id=node_id)
            await ctx.send(embed=create_success_embed("Network Removed", f"Removed network interface `{value}` from VPS `{container_name}`"))
        else:
            await ctx.send(embed=create_error_embed("Invalid Parameters", "Please provide valid parameters for the action"))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Network Management Failed", safe_error_summary("Network management", e)))

@bot.command(name='vps-processes')
@is_admin()
async def vps_processes(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    await ctx.send(embed=create_info_embed("Gathering Processes", f"Listing processes in VPS `{container_name}`..."))
    try:
        output = await execute_vpsctl_compat(container_name, f"exec {container_name} -- ps aux", node_id=node_id)
        if len(output) > 1000:
            output = output[:1000] + "\n... (truncated)"
        embed = create_embed(f"⚙️ Processes - {container_name}", "Running processes", 0x1a1a1a)
        add_field(embed, "Process List", f"```\n{output}\n```", False)
        await ctx.send(embed=embed)
    except Exception as e:
        await ctx.send(embed=create_error_embed("Process Listing Failed", safe_error_summary("Process listing", e)))

@bot.command(name='vps-logs')
async def vps_logs(ctx, container_name: str, lines: int = 50):
    """Show real guest logs plus RGNODES audit events for an owned/admin VPS."""
    lines = max(5, min(100, int(lines)))
    owner_id, _, vps = find_vps_record(container_name)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"`{container_name}` was not found."))
        return
    if str(ctx.author.id) != str(owner_id) and not is_admin_user(ctx.author):
        await ctx.send(embed=create_error_embed("Access Denied", "You can only view logs for your own VPS unless you are an administrator."))
        return
    container = str(vps.get("container_name"))
    node_id = int(vps.get("node_id", 1))
    await ctx.send(embed=create_info_embed("📋 Gathering VPS Logs", f"Fetching `{lines}` lines from `{container}`..."))
    guest = ""
    try:
        guest = str(await execute_vpsctl_compat(container, f"exec {shlex.quote(container)} -- bash -lc 'if command -v journalctl >/dev/null 2>&1; then journalctl -n {lines} --no-pager -o short-iso; elif [ -f /var/log/syslog ]; then tail -n {lines} /var/log/syslog; else dmesg | tail -n {lines}; fi'", node_id=node_id, timeout=40) or "")
    except Exception as exc:
        guest = safe_error_summary("Guest log retrieval", exc)
    rows = get_recent_audit_logs(min(20, lines), vps_container=container)
    audit = "\n".join(f"{r.get('created_at','')[:19]} | {r.get('action','Event')} | {r.get('detail','')}" for r in rows) or "No RGNODES audit events yet."
    guest = guest[-2200:] if guest else "No guest log output."
    audit = audit[-1600:]
    embed = create_info_embed("📋 VPS Logs", f"`{container}` • Owner `{owner_id}` • Node `{node_id}`")
    add_field(embed, "Guest System Logs", f"```text\n{guest}\n```", False)
    add_field(embed, "RGNODES Audit", f"```text\n{audit}\n```", False)
    await ctx.send(embed=embed)
    channel_id = _audit_channel_id()
    if channel_id and (not getattr(ctx.channel, 'id', None) or int(ctx.channel.id) != int(channel_id)):
        try:
            target = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
            raw_bundle = f"RGNODES VPS LOG SNAPSHOT\nVPS: {container}\nOwner: {owner_id}\nNode: {node_id}\nGenerated: {datetime.now().isoformat()}\n\n=== GUEST SYSTEM LOGS ===\n{guest}\n\n=== RGNODES AUDIT ===\n{audit}\n"
            if hasattr(target, 'send'):
                await _publish_log_bundle(target, embed, raw_bundle, f"vps-{container}-logs.txt")
        except Exception as exc:
            logger.debug('Failed to publish VPS logs to log channel: %s', exc)
    await record_audit_event("vps", "VPS Logs Viewed", f"Fetched guest + audit logs ({lines} lines).", user_id=ctx.author.id, node_id=node_id, vps_container=container)

@bot.command(name='vps-uptime')
@is_admin()
async def vps_uptime(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    uptime = await get_container_uptime(container_name, node_id)
    embed = create_info_embed("VPS Uptime", f"Uptime for `{container_name}`: {uptime}")
    await ctx.send(embed=embed)

@bot.command(name='vps-password')
@is_admin()
async def vps_password(ctx, container_name: str = None):
    """DM VPS root passwords to the invoking administrator; never reveal them in channels."""
    records = []
    if container_name:
        found = None
        for owner_id, vps_list in vps_data.items():
            for vps in vps_list:
                if str(vps.get('container_name', '')).casefold() == str(container_name).casefold():
                    found = (str(owner_id), vps)
                    break
            if found:
                break
        if not found:
            await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS found with container name: `{truncate_text(container_name, 80)}`"))
            return
        owner_id, vps = found
        password = str(vps.get('root_password') or '').strip()
        if not password:
            await ctx.send(embed=create_info_embed("Password Not Set", f"VPS `{truncate_text(container_name, 80)}` has no stored root password."))
            return
        records.append(f"Owner ID: {owner_id} | VPS: {vps.get('container_name', container_name)} | Root password: {password}")
    else:
        for owner_id, vps_list in vps_data.items():
            for vps in vps_list:
                password = str(vps.get('root_password') or '').strip() or 'NOT SET'
                records.append(f"Owner ID: {owner_id} | VPS: {vps.get('container_name', 'unknown')} | Root password: {password}")
        if not records:
            await ctx.send(embed=create_info_embed("No Passwords", "No VPS records were found."))
            return

    # Plain-text chunks stay under Discord's per-message limit and avoid embed field limits.
    chunks = []
    current = ""
    for line in records:
        if len(line) > 1800:
            line = line[:1800]
        candidate = f"{current}\n{line}" if current else line
        if len(candidate) > 1800 and current:
            chunks.append(current)
            current = line
        else:
            current = candidate
    if current:
        chunks.append(current)

    try:
        recipient = await bot.fetch_user(int(ctx.author.id))
        for index, chunk in enumerate(chunks, 1):
            await recipient.send(
                content=f"🔐 RGNODES™ private VPS password report ({index}/{len(chunks)}). Keep this message confidential.\n```text\n{chunk}\n```",
                allowed_mentions=discord.AllowedMentions.none(),
            )
    except discord.Forbidden:
        logger.info("VPS password report DM was blocked for admin ID %s; no password report was posted publicly.", ctx.author.id)
        await ctx.send(embed=create_warning_embed(
            "🔒 Private Password Report Not Delivered",
            "Discord blocked my DM to you. Enable DMs from this server and rerun the command. For safety, VPS root passwords are never posted in a public channel."
        ))
        return
    except discord.HTTPException as exc:
        logger.warning("VPS password report DM failed for admin ID %s (HTTP %s).", ctx.author.id, getattr(exc, 'status', 'unknown'))
        await ctx.send(embed=create_warning_embed(
            "🔒 Password Report Delivery Failed",
            "Discord could not deliver the private report. Check your DMs and retry; credentials were not posted in this channel."
        ))
        return

    await ctx.send(embed=create_success_embed(
        "🔐 Private Password Report Sent",
        "The requested VPS root password report was sent to your DM. No credentials were included in this channel message."
    ))

@bot.command(name='suspend-vps')
@is_admin()
async def suspend_vps(ctx, container_name: str, *, reason: str = "Admin action"):
    node_id = find_node_id_for_container(container_name)
    found = False
    for uid, lst in vps_data.items():
        for vps in lst:
            if vps['container_name'] == container_name:
                if vps.get('status') != 'running':
                    await ctx.send(embed=create_error_embed("Cannot Suspend", "VPS must be running to suspend."))
                    return
                try:
                    await execute_vpsctl_compat(container_name, f"stop {container_name}", node_id=node_id)
                    vps['status'] = 'stopped'
                    vps['suspended'] = True
                    if 'suspension_history' not in vps:
                        vps['suspension_history'] = []
                    vps['suspension_history'].append({
                        'time': datetime.now().isoformat(),
                        'reason': reason,
                        'by': f"{ctx.author.name} ({ctx.author.id})"
                    })
                    save_vps_data_immediate()
                except Exception as e:
                    await ctx.send(embed=create_error_embed("Suspend Failed", safe_error_summary("VPS suspension", e)))
                    return
                try:
                    owner = await bot.fetch_user(int(uid))
                    embed = create_warning_embed("🚨 VPS Suspended", f"Your VPS `{container_name}` has been suspended by an admin.\n\n**Reason:** {reason}\n\nContact an admin to unsuspend.")
                    await owner.send(embed=embed)
                except Exception as dm_e:
                    logger.error(f"Failed to DM owner {uid}: {dm_e}")
                await ctx.send(embed=create_success_embed("VPS Suspended", f"VPS `{container_name}` suspended. Reason: {reason}"))
                found = True
                break
        if found:
            break
    if not found:
        await ctx.send(embed=create_error_embed("Not Found", f"VPS `{container_name}` not found."))

@bot.command(name='unsuspend-vps')
@is_admin()
async def unsuspend_vps(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    found = False
    for uid, lst in vps_data.items():
        for vps in lst:
            if vps['container_name'] == container_name:
                if not vps.get('suspended', False):
                    await ctx.send(embed=create_error_embed("Not Suspended", "VPS is not suspended."))
                    return
                try:
                    try:
                        await execute_vpsctl_compat(container_name, f"start {container_name}", node_id=node_id)
                    except Exception as start_error:
                        msg = str(start_error).lower()
                        if "already running" not in msg and "is running" not in msg:
                            raise
                    await apply_internal_permissions(container_name, node_id)
                    await install_anti_mining_guard(container_name, node_id)
                    await recreate_port_forwards(container_name)
                    vps['suspended'] = False
                    vps['status'] = 'running'
                    save_vps_data_immediate()
                    await ctx.send(embed=create_success_embed("VPS Unsuspended", f"VPS `{container_name}` unsuspended and started."))
                    found = True
                except Exception as e:
                    await ctx.send(embed=create_error_embed("Start Failed", safe_error_summary("VPS unsuspension", e)))
                try:
                    owner = await bot.fetch_user(int(uid))
                    embed = create_success_embed("🟢 VPS Unsuspended", f"Your VPS `{container_name}` has been unsuspended by an admin.\nYou can now manage it again.")
                    await owner.send(embed=embed)
                except Exception as dm_e:
                    logger.error(f"Failed to DM owner {uid} about unsuspension: {dm_e}")
                break
        if found:
            break
    if not found:
        await ctx.send(embed=create_error_embed("Not Found", f"VPS `{container_name}` not found."))

@bot.command(name='suspension-logs')
@is_admin()
async def suspension_logs(ctx, container_name: str = None):
    if container_name:
        found = None
        for lst in vps_data.values():
            for vps in lst:
                if vps['container_name'] == container_name:
                    found = vps
                    break
            if found:
                break
        if not found:
            await ctx.send(embed=create_error_embed("Not Found", f"VPS `{container_name}` not found."))
            return
        history = found.get('suspension_history', [])
        if not history:
            await ctx.send(embed=create_info_embed("No Suspensions", f"No suspension history for `{container_name}`."))
            return
        embed = create_embed("Suspension History", f"For `{container_name}`")
        text = []
        for h in sorted(history, key=lambda x: x['time'], reverse=True)[:10]:
            t = datetime.fromisoformat(h['time']).strftime('%Y-%m-%d %H:%M:%S')
            text.append(f"**{t}** - {h['reason']} (by {h['by']})")
        add_field(embed, "History", "\n".join(text), False)
        if len(history) > 10:
            add_field(embed, "Note", "Showing last 10 entries.")
        await ctx.send(embed=embed)
    else:
        all_logs = []
        for uid, lst in vps_data.items():
            for vps in lst:
                h = vps.get('suspension_history', [])
                for event in sorted(h, key=lambda x: x['time'], reverse=True):
                    t = datetime.fromisoformat(event['time']).strftime('%Y-%m-%d %H:%M')
                    all_logs.append(f"**{t}** - VPS `{vps['container_name']}` (Owner: <@{uid}>) - {event['reason']} (by {event['by']})")
        if not all_logs:
            await ctx.send(embed=create_info_embed("No Suspensions", "No suspension events recorded."))
            return
        logs_text = "\n".join(all_logs)
        chunks = [logs_text[i:i+1024] for i in range(0, len(logs_text), 1024)]
        for idx, chunk in enumerate(chunks, 1):
            embed = create_embed(f"Suspension Logs (Part {idx})", f"Global suspension events (newest first)")
            add_field(embed, "Events", chunk, False)
            await ctx.send(embed=embed)

@bot.command(name='docker-repair')
async def docker_repair_cmd(ctx):
    target=next(iter(vps_data.get(str(ctx.author.id), [])), None)
    if not target:
        await ctx.send(embed=create_error_embed('🐳 No VPS', 'This account does not have a managed VPS.'))
        return
    if maintenance_enabled() and not is_admin_user(ctx.author):
        await ctx.send(embed=create_warning_embed('🟠 Under maintenance', 'User VPS actions are temporarily disabled.'))
        return
    container=str(target.get('container_name') or '')
    node_id=int(target.get('node_id',1))
    try:
        repaired=await ensure_docker_ready(container,node_id,strict=False)
        status=await get_container_docker_status(container,node_id)
        add=create_info_embed('🐳 Docker Repair', f'`{container}`')
        add_field(add,'Status',status,False)
        add_field(add,'Repair', '✅ Verified and ready.' if repaired else '⚠️ Docker could not be verified on this nested guest.', False)
        await ctx.send(embed=add)
    except Exception as e:
        await ctx.send(embed=create_error_embed('🐳 Docker Repair Failed', safe_error_summary('Docker repair', e)))

@bot.command(name='apply-permissions')
@is_admin()
async def apply_permissions(ctx, container_name: str):
    node_id = find_node_id_for_container(container_name)
    await ctx.send(embed=create_info_embed("Applying Permissions", f"Applying advanced permissions to `{container_name}`..."))
    try:
        status = await get_container_status(container_name, node_id)
        was_running = status == 'running'
        if was_running:
            await execute_vpsctl_compat(container_name, f"stop {container_name}", node_id=node_id)
        await apply_vps_vm_config(container_name, node_id)
        await execute_vpsctl_compat(container_name, f"start {container_name}", node_id=node_id)
        await apply_internal_permissions(container_name, node_id)
        await recreate_port_forwards(container_name)
        for user_id, vps_list in vps_data.items():
            for vps in vps_list:
                if vps['container_name'] == container_name:
                    vps['status'] = 'running'
                    vps['suspended'] = False
                    save_vps_data_immediate()
                    break
        await ctx.send(embed=create_success_embed("Permissions Applied", f"Advanced permissions applied to VPS `{container_name}`. Docker-ready with unprivileged ports!"))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Apply Failed", safe_error_summary("Permission apply", e)))

@bot.command(name='resource-check')
@is_admin()
async def resource_check(ctx):
    suspended_count = 0
    embed = create_info_embed("Resource Check", "Checking all running VPS for high resource usage...")
    msg = await ctx.send(embed=embed)
    for user_id, vps_list in vps_data.items():
        for vps in vps_list:
            if vps.get('status') == 'running' and not vps.get('suspended', False) and not vps.get('whitelisted', False):
                container = vps['container_name']
                node_id = vps['node_id']
                stats = await get_container_stats(container, node_id)
                cpu = stats['cpu']
                ram = stats['ram']['pct']
                if cpu > CPU_THRESHOLD or ram > RAM_THRESHOLD:
                    reason = f"High resource usage: CPU {cpu:.1f}%, RAM {ram:.1f}% (threshold: {CPU_THRESHOLD}% CPU / {RAM_THRESHOLD}% RAM)"
                    logger.warning(f"Suspending {container}: {reason}")
                    try:
                        await execute_vpsctl_compat(container, f"stop {container}", node_id=node_id)
                        vps['status'] = 'stopped'
                        vps['suspended'] = True
                        if 'suspension_history' not in vps:
                            vps['suspension_history'] = []
                        vps['suspension_history'].append({
                            'time': datetime.now().isoformat(),
                            'reason': reason,
                            'by': 'Manual Resource Check'
                        })
                        save_vps_data_immediate()
                        try:
                            owner = await bot.fetch_user(int(user_id))
                            warn_embed = create_warning_embed("🚨 VPS Auto-Suspended", f"Your VPS `{container}` has been suspended due to high resource usage.\n\n**Reason:** {reason}\n\nContact admin to unsuspend and address the issue.")
                            await owner.send(embed=warn_embed)
                        except Exception as dm_e:
                            logger.error(f"Failed to DM owner {user_id}: {dm_e}")
                        suspended_count += 1
                    except Exception as e:
                        logger.error(f"Failed to suspend {container}: {e}")
    final_embed = create_info_embed("Resource Check Complete", f"Checked all VPS. Suspended {suspended_count} high-usage VPS.")
    await msg.edit(embed=final_embed)

@bot.command(name='whitelist-vps')
@is_admin()
async def whitelist_vps(ctx, container_name: str, action: str):
    if action.lower() not in ['add', 'remove']:
        await ctx.send(embed=create_error_embed("Invalid Action", f"Use: `{PREFIX}whitelist-vps <container> <add|remove>`"))
        return
    found = False
    for user_id, vps_list in vps_data.items():
        for vps in vps_list:
            if vps['container_name'] == container_name:
                if action.lower() == 'add':
                    vps['whitelisted'] = True
                    msg = "added to whitelist (exempt from auto-suspension)"
                else:
                    vps['whitelisted'] = False
                    msg = "removed from whitelist"
                save_vps_data_immediate()
                await ctx.send(embed=create_success_embed("Whitelist Updated", f"VPS `{container_name}` {msg}."))
                found = True
                break
        if found:
            break
    if not found:
        await ctx.send(embed=create_error_embed("Not Found", f"VPS `{container_name}` not found."))

@bot.command(name='maintenance')
@is_admin()
async def maintenance_command(ctx, action: str = "status"):
    action = action.lower().strip()
    if action == "status":
        if maintenance_enabled():
            await ctx.send(embed=create_error_embed("🔶 Under Maintenance", "🔶 **Under Maintenance**\n🛠️ **Service maintenance in progress**\n\nThis maintenance state applies to users only. Administrators remain fully operational."))
        else:
            await ctx.send(embed=create_success_embed("🟢 Service Operational", "Maintenance mode is **OFF**. User dashboards have returned to the VPS's live runtime status."))
        return
    if action not in {"on", "off"}:
        await ctx.send(embed=create_error_embed("Usage", f"Use `{PREFIX}maintenance on`, `{PREFIX}maintenance off`, or `{PREFIX}maintenance status`"))
        return
    set_setting("maintenance", action)
    if action == "on":
        await record_audit_event("system", "Maintenance ON", "Maintenance enabled for normal users; administrators remain operational.", user_id=ctx.author.id)
        await ctx.send(embed=create_error_embed("🔶 Under Maintenance", "Maintenance mode is now **ON** for users.\n\n🔶 **Under Maintenance**\n🛠️ **Service maintenance in progress**\n\nAdministrators remain fully operational."))
        return

    await record_audit_event("system", "Maintenance OFF", "Maintenance disabled; normal user VPS access restored.", user_id=ctx.author.id)
    await ctx.send(embed=create_success_embed("🟢 Service Operational", "Maintenance mode is now **OFF**. User dashboards have returned to the VPS live runtime status."))


@bot.command(name='setexpire')
@is_admin()
async def setexpire(ctx, container_name: str, days: int):
    if days <= 0:
        await ctx.send(embed=create_error_embed("Invalid Days", "Days must be greater than 0."))
        return
    uid, idx, vps = find_vps_record(container_name)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"`{container_name}` was not found."))
        return
    actual_container = str(vps['container_name'])
    old_key = (actual_container, str(vps.get('expiration_date'))) if vps.get('expiration_date') else None
    vps['expiration_date'] = (datetime.now() + timedelta(days=days)).isoformat()
    if old_key:
        EXPIRATION_WARNING_SENT.discard(old_key)
        EXPIRATION_EXPIRED_NOTICE_SENT.discard(old_key)
    save_vps_data_immediate()
    await ctx.send(embed=create_success_embed("Expiration Set", f"`{actual_container}` now expires in **{days} days**."))


@bot.command(name='extendexpire')
@is_admin()
async def extendexpire(ctx, container_name: str, days: int):
    if days <= 0:
        await ctx.send(embed=create_error_embed("Invalid Days", "Days must be greater than 0."))
        return
    uid, idx, vps = find_vps_record(container_name)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"`{container_name}` was not found."))
        return
    actual_container = str(vps['container_name'])
    current = _safe_fromiso(vps.get('expiration_date')) if vps.get('expiration_date') else datetime.now()
    if current == datetime.max:
        current = datetime.now()
    old_key = (actual_container, str(vps.get('expiration_date'))) if vps.get('expiration_date') else None
    vps['expiration_date'] = (max(current, datetime.now()) + timedelta(days=days)).isoformat()
    auto_unsuspended = False
    if suspended_due_to_expiration(vps):
        try:
            node_id = int(vps.get('node_id', 1))
            try:
                await execute_vpsctl_compat(actual_container, f"start {actual_container}", node_id=node_id)
            except Exception as start_error:
                msg = str(start_error).lower()
                if 'already running' not in msg and 'is running' not in msg:
                    raise
            vps['status'] = 'running'
            vps['suspended'] = False
            await apply_internal_permissions(actual_container, node_id)
            await recreate_port_forwards(actual_container)
            auto_unsuspended = True
        except Exception as e:
            logger.warning(f"Could not auto-unsuspend {actual_container}: {e}")
    if old_key:
        EXPIRATION_WARNING_SENT.discard(old_key)
        EXPIRATION_EXPIRED_NOTICE_SENT.discard(old_key)
    save_vps_data_immediate()
    suspension_state = "Auto-unsuspended" if auto_unsuspended else "Preserved"
    await ctx.send(embed=create_success_embed("Expiration Extended", f"`{actual_container}` was extended by **{days} days**.\n\nSuspension: **{suspension_state}**"))


@bot.command(name='removeexpire')
@is_admin()
async def removeexpire(ctx, container_name: str):
    uid, idx, vps = find_vps_record(container_name)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"`{container_name}` was not found."))
        return
    actual_container = str(vps['container_name'])
    old_key = (actual_container, str(vps.get('expiration_date'))) if vps.get('expiration_date') else None
    vps['expiration_date'] = None
    if old_key:
        EXPIRATION_WARNING_SENT.discard(old_key)
        EXPIRATION_EXPIRED_NOTICE_SENT.discard(old_key)
    save_vps_data_immediate()
    await ctx.send(embed=create_success_embed("Expiration Removed", f"`{actual_container}` now has no expiration date."))


async def _resolve_backup_path(container_name: str, requested: Optional[str] = None) -> Optional[Path]:
    safe_prefix = sanitize_username_for_container(container_name)
    if requested:
        p = (VPS_BACKUP_DIR / Path(requested).name).resolve()
        try:
            p.relative_to(VPS_BACKUP_DIR.resolve())
        except ValueError:
            return None
        return p if p.is_file() else None
    candidates = sorted(VPS_BACKUP_DIR.glob(f"{safe_prefix}_*.tar.gz"))
    return candidates[-1] if candidates else None


@bot.command(name='backup-vps')
@is_admin()
async def backup_vps(ctx, container_name: str):
    uid, idx, vps = find_vps_record(container_name)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"`{container_name}` was not found."))
        return
    container_name = str(vps['container_name'])
    node = get_node(vps.get('node_id', 1))
    if not node or not node.get('is_local'):
        await ctx.send(embed=create_error_embed("Unsupported Node", "VPS backups currently require a local KVM node."))
        return
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    backup_file = VPS_BACKUP_DIR / f"{sanitize_username_for_container(container_name)}_{stamp}.tar.gz"
    await ctx.send(embed=create_info_embed("📦 VPS Backup", f"Exporting `{container_name}` to `{backup_file.name}`..."))
    try:
        await execute_vpsctl_compat(container_name, f"export {container_name} {shlex.quote(str(backup_file))} --instance-only", timeout=1800, node_id=vps.get('node_id', 1))
        if not backup_file.exists() or backup_file.stat().st_size < 1024:
            raise RuntimeError("KVM VPS export returned without a usable backup file.")
        await ctx.send(embed=create_success_embed("Backup Complete", f"Created `{backup_file.name}` ({backup_file.stat().st_size / 1024 / 1024:.1f} MiB)."))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Backup Failed", safe_error_summary("VPS backup", e)))


@bot.command(name='restore-vps')
@is_admin()
async def restore_vps(ctx, container_name: str, backup_file: str = None):
    """Safely restore a local KVM VPS using a validated temporary instance and rollback rename."""
    uid, idx, vps = find_vps_record(container_name)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"`{container_name}` was not found."))
        return
    container_name = str(vps['container_name'])
    node_id = int(vps.get('node_id', 1))
    node = get_node(node_id)
    if not node or not node.get('is_local'):
        await ctx.send(embed=create_error_embed("Unsupported Node", "VPS restore currently requires a local KVM node."))
        return

    path = await _resolve_backup_path(container_name, backup_file)
    if not path:
        await ctx.send(embed=create_error_embed("Backup Not Found", "No valid backup file was found in the VPS backup directory."))
        return

    class RestoreView(discord.ui.View):
        def __init__(self, admin_id):
            super().__init__(timeout=60)
            self.admin_id = str(admin_id)
            self.confirmed = False
        @discord.ui.button(label="✅ Confirm Restore", style=discord.ButtonStyle.secondary)
        async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
            if str(interaction.user.id) != self.admin_id:
                await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the admin who started the restore can confirm."), ephemeral=True)
                return
            self.confirmed = True
            await interaction.response.defer()
            self.stop()
        @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.secondary)
        async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
            if str(interaction.user.id) != self.admin_id:
                await interaction.response.send_message(embed=create_error_embed("Access Denied", "Only the admin who started the restore can cancel."), ephemeral=True)
                return
            await interaction.response.edit_message(embed=create_info_embed("Restore Cancelled", "No changes were made."), view=None)
            self.stop()

    previous_status = str(vps.get('status', 'stopped')).lower()
    previous_suspended = bool(vps.get('suspended', False))
    should_run_after_restore = previous_status == 'running' and not previous_suspended
    temp_name = sanitize_username_for_container(f"rgnodes-restore-{int(vps.get('vmid', vps.get('id', 0)) or 0)}-{datetime.now().strftime('%H%M%S')}")[:55]
    rollback_name = sanitize_username_for_container(f"{container_name}-rollback-{datetime.now().strftime('%H%M%S')}")[:55]
    if temp_name == container_name:
        temp_name = sanitize_username_for_container(f"rgnodes-restore-{datetime.now().strftime('%Y%m%d%H%M%S')}")[:55]

    confirm_embed = create_warning_embed(
        "⚠️ Restore VPS",
        f"A validated temporary KVM VPS will be imported first. The existing `{container_name}` stays untouched until validation succeeds.\n\nBackup: `{path.name}`\nPrevious state: **{('SUSPENDED' if previous_suspended else previous_status.upper())}**"
    )
    view = RestoreView(ctx.author.id)
    await ctx.send(embed=confirm_embed, view=view)
    await view.wait()
    if not view.confirmed:
        return

    await ctx.send(embed=create_info_embed("Restoring VPS", f"Validating `{path.name}` in temporary instance `{temp_name}`..."))
    original_exists = False
    rollback_created = False
    new_instance_ready = False
    password = vps.get('root_password') or generate_strong_password()

    try:
        try:
            await execute_vpsctl_compat('', f"info {container_name}", node_id=node_id)
            original_exists = True
        except Exception:
            original_exists = False

        # Remove stale temporary/rollback names if an earlier interrupted restore left them behind.
        for stale in (temp_name, rollback_name):
            try:
                await execute_vpsctl_compat(stale, f"delete {stale} --force", node_id=node_id)
            except Exception:
                pass

        # Import while the real VPS is still intact.
        storage_pool = await resolve_storage_pool(node_id)
        await execute_vpsctl_compat(
            temp_name,
            f"import {shlex.quote(str(path))} {temp_name} --storage {shlex.quote(storage_pool)}",
            timeout=1800,
            node_id=node_id,
        )

        # Imported snapshots/config may contain old RGNODES proxy devices. Remove the known
        # persistent forwarding devices before validation so the temporary instance cannot
        # collide with the current host ports.
        with DB_LOCK:
            conn = get_db()
            try:
                forward_rows = conn.execute(
                    "SELECT host_port FROM port_forwards WHERE vps_container = ? ORDER BY host_port",
                    (container_name,),
                ).fetchall()
            finally:
                conn.close()
        for row in forward_rows:
            hp = int(row[0])
            for proto in ("tcp", "udp"):
                try:
                    await execute_vpsctl_compat(temp_name, f"config device remove {temp_name} rgnodes-pf-{proto}-{hp}", node_id=node_id)
                except Exception:
                    pass

        await apply_vps_vm_config(temp_name, node_id)
        await execute_vpsctl_compat(temp_name, f"start {temp_name}", timeout=180, node_id=node_id)
        await safe_guest_install(temp_name, node_id)
        ok, result = await configure_ssh(temp_name, node_id, password)
        if not ok:
            raise RuntimeError(f"SSH validation failed: {result}")
        await set_guest_hostname(temp_name, node_id, VPS_HOSTNAME)
        await execute_vpsctl_compat(temp_name, f"exec {temp_name} -- bash -lc 'true'", timeout=60, node_id=node_id)
        await execute_vpsctl_compat(temp_name, f"stop {temp_name} --force", timeout=120, node_id=node_id)
        new_instance_ready = True

        # Atomic-ish same-host swap with rollback: rename old -> rollback, temp -> original.
        if original_exists:
            try:
                await execute_vpsctl_compat(container_name, f"stop {container_name} --force", timeout=120, node_id=node_id)
            except Exception:
                pass
            await execute_vpsctl_compat(container_name, f"rename {container_name} {rollback_name}", timeout=180, node_id=node_id)
            rollback_created = True

        try:
            await execute_vpsctl_compat(temp_name, f"rename {temp_name} {container_name}", timeout=180, node_id=node_id)
        except Exception:
            if rollback_created:
                try:
                    await execute_vpsctl_compat(rollback_name, f"rename {rollback_name} {container_name}", timeout=180, node_id=node_id)
                except Exception:
                    pass
            raise

        # Restore original lifecycle state instead of forcing every restore to RUNNING.
        if should_run_after_restore:
            await execute_vpsctl_compat(container_name, f"start {container_name}", timeout=180, node_id=node_id)
            await apply_internal_permissions(container_name, node_id)
            readded = await recreate_port_forwards(container_name)
        else:
            readded = 0
            if not previous_suspended:
                # The VPS was intentionally stopped, so keep it stopped; no active proxy devices.
                readded = 0

        await set_guest_hostname(container_name, node_id, VPS_HOSTNAME)
        vps['status'] = 'running' if should_run_after_restore else 'stopped'
        vps['suspended'] = previous_suspended
        vps['root_password'] = password
        save_vps_data_immediate()

        if rollback_created:
            try:
                await execute_vpsctl_compat(rollback_name, f"delete {rollback_name} --force", timeout=300, node_id=node_id)
            except Exception as cleanup_error:
                logger.warning(f"Restored VPS but could not delete rollback instance {rollback_name}: {cleanup_error}")

        if previous_suspended:
            await ctx.send(embed=create_success_embed("Restore Complete", f"`{container_name}` restored successfully and remains **SUSPENDED** to preserve its previous state."))
        else:
            await ctx.send(embed=create_success_embed("Restore Complete", f"`{container_name}` restored successfully from `{path.name}`. State preserved: **{'RUNNING' if should_run_after_restore else 'STOPPED'}**. Port forwards restored: **{readded}**."))

    except Exception as e:
        logger.error(f"Restore failed for {container_name}: {e}", exc_info=True)

        # If the new instance was swapped in but failed during finalization, restore rollback.
        try:
            if rollback_created:
                try:
                    await execute_vpsctl_compat(container_name, f"stop {container_name} --force", timeout=120, node_id=node_id)
                except Exception:
                    pass
                try:
                    await execute_vpsctl_compat(container_name, f"delete {container_name} --force", timeout=180, node_id=node_id)
                except Exception:
                    pass
                await execute_vpsctl_compat(rollback_name, f"rename {rollback_name} {container_name}", timeout=180, node_id=node_id)
                if should_run_after_restore:
                    await execute_vpsctl_compat(container_name, f"start {container_name}", timeout=180, node_id=node_id)
                    await recreate_port_forwards(container_name)
        except Exception as rollback_error:
            logger.critical(f"ROLLBACK FAILED for {container_name}: {rollback_error}", exc_info=True)

        try:
            await execute_vpsctl_compat(temp_name, f"delete {temp_name} --force", timeout=180, node_id=node_id)
        except Exception:
            pass
        vps['status'] = previous_status if previous_status in {'running', 'stopped'} else 'stopped'
        vps['suspended'] = previous_suspended
        save_vps_data_immediate()
        await ctx.send(embed=create_error_embed("Restore Failed", "The restore was not committed safely. Original VPS state was preserved where possible. " + safe_error_summary("VPS restore", e)))


@bot.command(name='backup-db')
@is_admin()
async def backup_db(ctx):
    try:
        backup_database()
        backup_files = sorted(DB_BACKUP_DIR.glob("vps_backup_*.db"))
        latest = backup_files[-1].name if backup_files else "backup"
        await ctx.send(
            embed=create_success_embed(
                "DB Backup Created",
                f"Consistent SQLite backup created: `{latest}`"
            )
        )
    except Exception as e:
        await ctx.send(embed=create_error_embed("Backup Failed", safe_error_summary("Database backup", e)))

@bot.command(name='repair-ports')
@is_admin()
async def repair_ports(ctx, container_name: str):
    await ctx.send(embed=create_info_embed("Repairing Ports", f"Re-adding port forward devices for `{container_name}`..."))
    try:
        readded = await recreate_port_forwards(container_name)
        await ctx.send(embed=create_success_embed("Ports Repaired", f"Re-added {readded} port forwards for `{container_name}`."))
    except Exception as e:
        await ctx.send(embed=create_error_embed("Repair Failed", safe_error_summary("Port repair", e)))

@bot.command(name='set-expiration')
@is_admin()
async def set_expiration(ctx, container_name: str, days: int):
    """Set VPS expiration date (admin only)"""
    if days <= 0:
        await ctx.send(embed=create_error_embed("Invalid Days", "Days must be a positive number."))
        return
    
    found_vps = None
    user_id = None
    vps_index = None
    
    for uid, vps_list in vps_data.items():
        for i, vps in enumerate(vps_list):
            if vps['container_name'] == container_name:
                found_vps = vps
                user_id = uid
                vps_index = i
                break
        if found_vps:
            break
    
    if not found_vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS found with container name: `{container_name}`"))
        return
    
    # Calculate expiration date
    expiration_date = (datetime.now() + timedelta(days=days)).isoformat()
    found_vps['expiration_date'] = expiration_date
    vps_data[user_id][vps_index] = found_vps
    save_vps_data_immediate()
    
    # Get owner info
    try:
        owner = await bot.fetch_user(int(user_id))
        owner_mention = owner.mention
    except:
        owner_mention = f"User {user_id}"
    
    embed = create_success_embed("Expiration Date Set", 
        f"VPS `{container_name}` expiration date set for {days} days from now")
    add_field(embed, "Owner", owner_mention, True)
    add_field(embed, "Expires On", datetime.fromisoformat(expiration_date).strftime('%Y-%m-%d %H:%M:%S'), True)
    add_field(embed, "Days Remaining", str(days), True)
    
    await ctx.send(embed=embed)
    
    # Notify owner
    try:
        owner = await bot.fetch_user(int(user_id))
        dm_embed = create_info_embed("⏰ VPS Expiration Date Set",
            f"Your VPS `{container_name}` will expire in {days} days.\n\n"
            f"**Expires:** {datetime.fromisoformat(expiration_date).strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"Contact admin to renew your VPS before it expires.")
        await owner.send(embed=dm_embed)
    except:
        pass

async def process_vps_renewal(vps: Dict[str, Any], requested_days: int = None, user_initiated: bool = False) -> tuple[bool, str]:
    '''Central renewal logic: owner can renew in the last two days or after expiry; admins can renew anytime.'''
    if user_initiated and not PUBLIC_VPS_RENEWAL_ENABLED:
        return False, 'Public VPS renewal is currently disabled.'
    days = int(requested_days or (PUBLIC_VPS_RENEWAL_DAYS if user_initiated else VPS_RENEWAL_DAYS))
    if days <= 0:
        return False, 'Renewal duration must be greater than zero.'
    now = datetime.now()
    if user_initiated and PUBLIC_VPS_COOLDOWN_HOURS > 0:
        previous = vps.get('last_public_renewal_at')
        if previous:
            try:
                previous_dt = datetime.fromisoformat(str(previous))
                elapsed = (now - previous_dt).total_seconds()
                remaining = PUBLIC_VPS_COOLDOWN_HOURS * 3600 - elapsed
                if remaining > 0:
                    return False, f'Please wait **{max(1, int(remaining // 3600) + 1)} hour(s)** before another public renewal.'
            except (TypeError, ValueError):
                pass
    raw = vps.get('expiration_date')
    try:
        current = datetime.fromisoformat(str(raw)) if raw else now
    except (TypeError, ValueError):
        current = now
    seconds_left = (current - now).total_seconds()
    window_days = PUBLIC_VPS_RENEWAL_WINDOW_DAYS if user_initiated else RENEWAL_WINDOW_DAYS
    window = max(0, window_days) * 86400
    if user_initiated and seconds_left > window:
        left = max(1, int(seconds_left // 86400))
        return False, f'Renewal opens during the final **{window_days} days** before expiry. Your VPS still has about **{left} days** remaining.'

    container = str(vps['container_name'])
    old_key = (container, str(raw)) if raw else None
    was_expiry_suspended = suspended_due_to_expiration(vps)
    new_expiration = max(current, now) + timedelta(days=days)
    if was_expiry_suspended:
        node_id = int(vps.get('node_id', 1))
        try:
            try:
                await execute_vpsctl_compat(container, f'start {container}', timeout=180, node_id=node_id)
            except Exception as e:
                msg = str(e).lower()
                if 'already running' not in msg and 'is running' not in msg:
                    raise
            vps['status'] = 'running'
            vps['suspended'] = False
            await apply_internal_permissions(container, node_id)
            await install_anti_mining_guard(container, node_id)
            await recreate_port_forwards(container)
        except Exception as e:
            return False, 'The VPS could not be safely restarted, so renewal was not committed. ' + safe_error_summary('VPS restart during renewal', e)
    vps['expiration_date'] = new_expiration.isoformat()
    if user_initiated:
        vps['last_public_renewal_at'] = now.isoformat()
    if old_key:
        EXPIRATION_WARNING_SENT.discard(old_key)
        EXPIRATION_EXPIRED_NOTICE_SENT.discard(old_key)
    save_vps_data_immediate()
    state = '✅ Auto-unsuspended' if was_expiry_suspended and not vps.get('suspended') else '✅ State preserved'
    return True, f'`{container}` renewed for **{days} days**.\n**New expiry:** `{new_expiration.strftime("%Y-%m-%d %H:%M:%S")}`\n**Suspension:** {state}'


@bot.command(name='renew')
async def renew_user(ctx, container_name: str = None):
    '''User renewal command. Adds 60 days during the final two-day window.'''
    owner_id = str(ctx.author.id)
    owned = list(vps_data.get(owner_id, []))
    if not owned:
        await ctx.send(embed=create_error_embed('No VPS Found', 'You do not currently own a VPS.'))
        return
    if container_name:
        wanted = str(container_name).strip()
        target = next((v for v in owned if str(v.get('container_name')) == wanted or str(v.get('id')) == wanted or str(v.get('vmid')) == wanted), None)
    elif len(owned) == 1:
        target = owned[0]
    else:
        await ctx.send(embed=create_warning_embed('Select a VPS', f'Usage: `{PREFIX}renew <vps-id-or-name>`'))
        return
    if not target:
        await ctx.send(embed=create_error_embed('VPS Not Found', 'That VPS does not belong to your account.'))
        return
    ok, message = await process_vps_renewal(target, VPS_RENEWAL_DAYS, user_initiated=True)
    if not ok:
        await ctx.send(embed=create_warning_embed('Renewal Unavailable', message))
        return
    await ctx.send(embed=create_success_embed('⏰ VPS Renewed', message))
    try:
        await ctx.author.send(embed=create_success_embed('⏰ VPS Renewed', message))
    except Exception:
        pass


@bot.command(name='renew-vps')
@is_admin()
async def renew_vps(ctx, container_name: str, additional_days: int = None):
    try:
        days = int(additional_days if additional_days is not None else VPS_RENEWAL_DAYS)
    except (TypeError, ValueError):
        await ctx.send(embed=create_error_embed('Invalid Days', 'Renewal days must be a positive integer.'))
        return
    if days <= 0:
        await ctx.send(embed=create_error_embed('Invalid Days', 'Renewal days must be greater than 0.'))
        return
    uid, idx, vps = find_vps_record(container_name)
    if not vps:
        await ctx.send(embed=create_error_embed('VPS Not Found', f'No VPS found with ID/name: `{container_name}`'))
        return
    ok, message = await process_vps_renewal(vps, days, user_initiated=False)
    if not ok:
        await ctx.send(embed=create_error_embed('Renewal Failed', message))
        return
    await ctx.send(embed=create_success_embed('⏰ VPS Renewed', message))
    try:
        owner = await bot.fetch_user(int(uid))
        await owner.send(embed=create_success_embed('⏰ VPS Renewed', message))
    except Exception:
        pass


@bot.command(name='dm-mass')
@is_admin()
async def dm_mass(ctx, *, message: str = None):
    """Send an admin announcement only to users who currently own managed VPS records."""
    message = (message or '').strip()
    if not message:
        await ctx.send(embed=create_error_embed('📢 Message Required', f'Usage: `{PREFIX}dm-mass <message>`'))
        return
    if len(message) > 1800:
        await ctx.send(embed=create_error_embed('📏 Message Too Long', 'Keep the announcement below 1800 characters.'))
        return

    recipients = []
    seen = set()
    for owner_id, items in vps_data.items():
        if not items:
            continue
        try:
            uid = int(owner_id)
        except (TypeError, ValueError):
            continue
        if uid not in seen:
            seen.add(uid)
            recipients.append(uid)

    if not recipients:
        await ctx.send(embed=create_warning_embed('📢 No VPS Users', 'No users currently own a managed VPS.'))
        return

    confirm = create_warning_embed(
        '📢 VPS User Announcement',
        f'This will DM **{len(recipients)}** current VPS owner(s).\n\n**Message:**\n{message}\n\nContinue?',
    )

    class DMConfirmView(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=60)
            self.confirmed = False

        @discord.ui.button(label='✅ Send', style=discord.ButtonStyle.secondary)
        async def send_now(self, interaction: discord.Interaction, button: discord.ui.Button):
            if str(interaction.user.id) != str(ctx.author.id):
                await interaction.response.send_message(embed=create_error_embed('⛔ Access Denied', 'Only the admin who started this announcement can confirm it.'), ephemeral=True)
                return
            self.confirmed = True
            await interaction.response.defer()
            self.stop()
            sent = failed = 0
            announcement = create_info_embed('📢 RGNODES™ Announcement', message)
            add_field(announcement, 'ℹ️ Scope', 'Sent only to users with a managed VPS record.', False)
            for uid in recipients:
                try:
                    user = await bot.fetch_user(uid)
                    await user.send(embed=announcement)
                    sent += 1
                except (discord.Forbidden, discord.NotFound, discord.HTTPException) as e:
                    failed += 1
                    logger.warning(f'DM mass delivery failed for {uid}: {e}')
                await asyncio.sleep(1.0)
            await interaction.followup.send(embed=create_success_embed(
                '📨 Announcement Complete',
                f'✅ Sent: **{sent}**\n⚠️ Failed/blocked: **{failed}**\n👥 Eligible: **{len(recipients)}**',
            ))

        @discord.ui.button(label='❌ Cancel', style=discord.ButtonStyle.secondary)
        async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
            if str(interaction.user.id) != str(ctx.author.id):
                await interaction.response.send_message(embed=create_error_embed('⛔ Access Denied', 'Only the admin who started this announcement can cancel it.'), ephemeral=True)
                return
            await interaction.response.edit_message(embed=create_info_embed('📢 Announcement Cancelled', 'No DMs were sent.'), view=None)
            self.stop()

    await ctx.send(embed=confirm, view=DMConfirmView())


@bot.command(name="access-check", aliases=["repair-access"])
async def access_check_command(ctx, container_name: str = None):
    """Verify and repair the guest SSH daemon and selected node's public mapping."""
    caller_id = str(ctx.author.id)
    admin = is_admin_user(ctx.author)
    if container_name:
        target_owner, _, target = find_vps_record(container_name)
        if not target:
            await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS matches `{container_name}`."))
            return
        if not admin and str(target_owner) != caller_id:
            await ctx.send(embed=create_error_embed("Access Denied", "You can only repair access to your own VPS."))
            return
    else:
        owned = list(vps_data.get(caller_id, []))
        if len(owned) != 1:
            await ctx.send(embed=create_warning_embed("Select a VPS", f"Usage: `{current_command_prefix()}access-check <vps-id>`"))
            return
        target_owner, target = caller_id, owned[0]

    status_message = await ctx.send(embed=create_info_embed(
        "SSH Access Check", "Checking VPS runtime, guest SSH daemon, node public IPv4 and NAT forwarding..."
    ))
    try:
        result = await ensure_vps_ssh_access(str(target_owner), target, repair=True)
        command = f"ssh root@{result['host']} -p {result['port']}"
        network_note = (
            "Shared node public IPv4 + per-VPS forwarded port (NAT). Your provider firewall/security group must allow the configured host-port range."
            if result['mode'] == 'nat' else "Guest-routed public IP (direct/bridge)."
        )
        embed = create_success_embed(
            "SSH Access Ready",
            f"The guest SSH daemon is verified and the selected node's managed mapping has been applied for `{target.get('container_name')}`."
        )
        add_field(embed, "Connection", f"```bash\n{command}\n```", False)
        add_field(embed, "Network", network_note, False)
        add_field(embed, "Credentials", "Use `!ssh` to receive the root password privately by DM.", False)
        await status_message.edit(embed=embed)
    except Exception as exc:
        logger.warning("Access check failed for %s: %s", target.get('container_name'), type(exc).__name__, exc_info=True)
        await status_message.edit(embed=create_error_embed(
            "SSH Access Check Failed",
            safe_error_summary("SSH access repair", exc) +
            "\n\nCheck the selected node agent, QEMU Guest Agent, real public IPv4, inbound provider firewall and VPS status."
        ))


@bot.command(name="webssh", aliases=["web-ssh", "terminal"])
async def webssh_command(ctx, container_name: str = None):
    """Create a short-lived browser SSH token restricted to one owned VPS."""
    owner_id = str(ctx.author.id)
    admin = is_admin_user(ctx.author)
    target = None
    target_owner = owner_id
    if container_name:
        target_owner, _, target = find_vps_record(container_name)
        if not target:
            await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS matches `{container_name}`."))
            return
        if not admin and str(target_owner) != owner_id:
            await ctx.send(embed=create_error_embed("Access Denied", "Web SSH is available only for your own VPS."))
            return
    else:
        owned = list(vps_data.get(owner_id, []))
        if len(owned) != 1:
            await ctx.send(embed=create_warning_embed("Select a VPS", f"Usage: `{current_command_prefix()}webssh <vps-id>`"))
            return
        target = owned[0]
    container = str(target.get("container_name") or "")
    node_id = int(target.get("node_id", 1))
    if target.get("suspended"):
        await ctx.send(embed=create_error_embed("VPS Suspended", "Web SSH is disabled for suspended VPS."))
        return
    try:
        if not WEB_TERMINAL_ENABLED or _WEB_TERMINAL_RUNNER is None:
            raise RuntimeError("The browser terminal service is not running. Enable WEB_TERMINAL_ENABLED, install requirements, restart the bot, and configure the HTTPS Nginx reverse proxy.")
        access_result = await ensure_vps_ssh_access(str(target_owner), target, repair=True)
        host, port, node_mode, endpoints = access_result['host'], access_result['port'], access_result['mode'], access_result['endpoints']
        token = issue_web_ssh_ticket(str(target_owner), container, host, int(port), "root")
        dm = create_success_embed("🌐 VPS Web SSH", f"A one-time token was created for `{container}`. It expires in {WEBSSH_TICKET_TTL // 60} minutes and is bound to this VPS endpoint.")
        add_field(dm, "Open terminal", WEB_TERMINAL_PUBLIC_URL, False)
        add_field(dm, "Access token", f"```text\n{token}\n```", False)
        add_field(dm, "Target", f"`root@{host}:{port}`", False)
        add_field(dm, "Network", "Shared node IPv4 + forwarded port (NAT)." if node_mode=='nat' else "Guest-owned public IP (direct/bridge).", False)
        add_field(dm, "Root password", f"```text\n{access_result['password']}\n```", False)
        add_field(dm, "Login", "Paste the one-time token, then authenticate with the root password above.", False)
        await ctx.author.send(embed=dm)
        await ctx.send(embed=create_success_embed("Web SSH Sent", "A VPS-restricted one-time token was sent to your DM."))
    except discord.Forbidden:
        await ctx.send(embed=create_warning_embed("DM Not Delivered", "Enable DMs from this server and retry. No credentials were posted in this channel."))
    except Exception as exc:
        await ctx.send(embed=create_error_embed("Web SSH Unavailable", safe_error_summary("Web SSH", exc)))


@bot.command(name="file-manager", aliases=["filemanager", "sftp"])
async def file_manager_command(ctx, container_name: str = None):
    """Send genuine SFTP connection details for the caller's VPS."""
    owner_id = str(ctx.author.id)
    admin = is_admin_user(ctx.author)
    target = None
    target_owner = owner_id
    if container_name:
        target_owner, _, target = find_vps_record(container_name)
        if not target:
            await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS matches `{container_name}`."))
            return
        if not admin and str(target_owner) != owner_id:
            await ctx.send(embed=create_error_embed("Access Denied", "SFTP is available only for your own VPS."))
            return
    else:
        owned = list(vps_data.get(owner_id, []))
        if len(owned) != 1:
            await ctx.send(embed=create_warning_embed("Select a VPS", f"Usage: `{current_command_prefix()}file-manager <vps-id>`"))
            return
        target = owned[0]
    container = str(target.get("container_name") or "")
    node_id = int(target.get("node_id", 1))
    if target.get("suspended"):
        await ctx.send(embed=create_error_embed("VPS Suspended", "SFTP access is disabled for suspended VPS."))
        return
    try:
        access_result = await ensure_vps_ssh_access(str(target_owner), target, repair=True)
        host, port, node_mode, endpoints = access_result['host'], access_result['port'], access_result['mode'], access_result['endpoints']
        dm = create_success_embed("📁 VPS File Manager · SFTP", f"Connect an SFTP client to `{container}`. This is the standard SSH File Transfer Protocol.")
        add_field(dm, "Connection", f"Host: `{host}`\nPort: `{port}`\nUsername: `root`\nPassword: `{access_result['password']}`", False)
        add_field(dm, "Network", "Shared node IPv4 + forwarded port (NAT)." if node_mode=='nat' else "Guest public IP (direct/bridge).", False)
        add_field(dm, "Command", f"```bash\nsftp -P {port} root@{host}\n```", False)
        add_field(dm, "Actions", "`ls` list · `cd` change folder · `get` download · `put` upload · `mkdir` create folder · `rename` rename · `rm` delete", False)
        await ctx.author.send(embed=dm)
        await ctx.send(embed=create_success_embed("SFTP Details Sent", "Connection details were sent to your DM."))
    except discord.Forbidden:
        await ctx.send(embed=create_warning_embed("DM Not Delivered", "Enable DMs from this server and retry. Credentials were not exposed in the channel."))
    except Exception as exc:
        await ctx.send(embed=create_error_embed("File Access Unavailable", safe_error_summary("SFTP access", exc)))


@bot.command(name="ssh")
async def ssh_command(ctx, container_name: str = None):
    """Send normal OpenSSH access details privately."""
    caller_id = str(ctx.author.id)
    if maintenance_enabled() and not is_admin_user(ctx.author):
        await ctx.send(embed=create_warning_embed('🟠 Under maintenance', 'User VPS actions are temporarily disabled.'))
        return
    admin = is_admin_user(ctx.author)
    owned = list(vps_data.get(caller_id, []))
    target_user_id = caller_id
    target = None
    if container_name:
        target_user_id, _, target = find_vps_record(container_name)
        if not target:
            await ctx.send(embed=create_error_embed("🖥️ VPS Not Found", f"No VPS was found for `{container_name}`."))
            return
        if not admin and str(target_user_id) != caller_id:
            await ctx.send(embed=create_error_embed("⛔ Access Denied", "You can only open SSH for your own VPS."))
            return
    elif len(owned) == 1:
        target = owned[0]
    else:
        await ctx.send(embed=create_warning_embed("🖥️ Select a VPS", f"Usage: `{PREFIX}ssh <vmid|vps-name>`"))
        return
    container = str(target.get("container_name") or "")
    node_id = int(target.get("node_id", 1))
    if target.get("suspended"):
        await ctx.send(embed=create_error_embed("⛔ VPS Suspended", "Renew or ask support to unsuspend this VPS."))
        return
    try:
        access_result = await ensure_vps_ssh_access(str(target_user_id), target, repair=True)
        ssh_host, ssh_port, node_mode, endpoints = access_result['host'], access_result['port'], access_result['mode'], access_result['endpoints']
        access_info = format_public_ssh_access(endpoints, ssh_port)
        access = create_success_embed("💻 RGNODES™ SSH", f"`{container}` • `{VPS_HOSTNAME}`")
        if access_info.get("ssh_ipv4"):
            endpoint_label='💻 Shared node IPv4 (NAT)' if node_mode=='nat' else '💻 Guest public IPv4'
            add_field(access, endpoint_label, f"```bash\n{access_info['ssh_ipv4']}\n```", False)
        elif access_info.get("ssh_ipv6"):
            add_field(access, "🌐 Guest public IPv6", f"```bash\n{access_info['ssh_ipv6']}\n```", False)
        else:
            add_field(access, "💻 SSH endpoint", "⚠️ No verified public endpoint is available.", False)
        add_field(access, "🔐 Credentials", f"Username: `root`\nPassword: `{access_result['password']}`", False)
        add_field(access, "🔗 Separation", "This sends normal OpenSSH access details only.", False)
        add_field(access, "Network", "Node public IPv4 + forwarded host port (NAT)." if node_mode=='nat' else "Guest-owned public IP (direct/bridge).", False)
        try:
            await ctx.author.send(embed=access)
            await ctx.send(embed=create_success_embed("📨 SSH Sent", "SSH-only access details were sent to your DM."))
        except discord.Forbidden:
            logger.info("SSH credentials DM was blocked for owner ID %s; no credentials were posted publicly.", target_user_id)
            await ctx.send(embed=create_warning_embed(
                "🔒 Private SSH Details Not Delivered",
                "Discord blocked the VPS owner's DM. Enable DMs from this server and retry. For safety, the root password and SSH details were **not** posted in this channel."
            ))
    except Exception as e:
        logger.error("SSH command failed for %s (%s)", container, type(e).__name__)
        await ctx.send(embed=create_error_embed(
            "💻 SSH Failed",
            "SSH details could not be generated or delivered. Check that the VPS is running and has a reachable public endpoint; private credentials were not posted here."
        ))


@bot.command(name="pinggy")
async def pinggy_command(ctx, container_name: str = None):
    """Open Pinggy SSH tunnel only."""
    caller_id = str(ctx.author.id)
    if maintenance_enabled() and not is_admin_user(ctx.author):
        await ctx.send(embed=create_warning_embed('🟠 Under maintenance', 'User VPS actions are temporarily disabled.'))
        return
    admin = is_admin_user(ctx.author)
    target_user_id = caller_id
    target = None
    if container_name:
        target_user_id, _, target = find_vps_record(container_name)
        if not target:
            await ctx.send(embed=create_error_embed("🖥️ VPS Not Found", f"No VPS was found for `{container_name}`."))
            return
        if not admin and str(target_user_id) != caller_id:
            await ctx.send(embed=create_error_embed("⛔ Access Denied", "You can only open Pinggy for your own VPS."))
            return
    else:
        owned = list(vps_data.get(caller_id, []))
        if len(owned) != 1:
            await ctx.send(embed=create_warning_embed("🖥️ Select a VPS", f"Usage: `{PREFIX}pinggy <vmid|container-name>`"))
            return
        target = owned[0]
    container = str(target.get("container_name") or "")
    node_id = int(target.get("node_id", 1))
    if target.get("suspended"):
        await ctx.send(embed=create_error_embed("⛔ VPS Suspended", "Renew or ask support to unsuspend this VPS."))
        return
    try:
        stats = await asyncio.wait_for(get_container_stats(container, node_id), timeout=20)
        if str(stats.get("status", "")).lower() != "running":
            await ctx.send(embed=create_warning_embed("⏸️ VPS Not Running", f"`{container}` is stopped. Start it first."))
            return
        info = await asyncio.wait_for(start_pinggy_session(container, node_id), timeout=100)
        if not info:
            raise RuntimeError("Pinggy returned no public endpoint. Try again or use Reconnect Pinggy.")
        e = create_success_embed("🌐 RGNODES™ Pinggy Connected", f"`{container}` • `{VPS_HOSTNAME}`")
        add_field(e, "🌐 Pinggy SSH Tunnel", f"**SSH Command:** `ssh root@{info['host']} -p {info['port']}`\n**Host:** `{info['host']}`\n**Port:** `{info['port']}`\n**Status:** 🟢 Tunnel Active", False)
        add_field(e, "🔗 Separation", "Pinggy only. Normal SSH access is managed separately.", False)
        try:
            recipient = await bot.fetch_user(int(target_user_id))
            await recipient.send(embed=e)
            await ctx.send(embed=create_success_embed("📨 Pinggy Sent", "Pinggy-only access details were sent to your DM."))
        except discord.Forbidden:
            logger.info("Pinggy endpoint DM was blocked for owner ID %s; endpoint was not posted publicly.", target_user_id)
            await ctx.send(embed=create_warning_embed(
                "🔒 Private Pinggy Details Not Delivered",
                "Discord blocked the VPS owner's DM. Enable DMs from this server and retry. For safety, the private tunnel endpoint was **not** posted in this channel."
            ))
    except Exception as e:
        logger.error("Pinggy command failed for %s (%s)", container, type(e).__name__)
        await ctx.send(embed=create_error_embed(
            "🌐 Pinggy Failed",
            "Pinggy could not create or deliver a tunnel. Check VPS status and try reconnecting. Private tunnel endpoints and diagnostic payloads are hidden."
        ))

@bot.command(name="reconnect-pinggy")
async def reconnect_pinggy_command(ctx, container_name: str = None):
    """Reconnect Pinggy only; normal SSH access is managed separately."""
    await pinggy_command.callback(ctx, container_name)

@bot.command(name='vps-expiration')
@is_admin()
async def check_expiration(ctx, container_name: str = None):
    """Check VPS expiration status (admin only)"""
    if container_name:
        # Check specific VPS
        found_vps = None
        user_id = None
        
        for uid, vps_list in vps_data.items():
            for vps in vps_list:
                if vps['container_name'] == container_name:
                    found_vps = vps
                    user_id = uid
                    break
            if found_vps:
                break
        
        if not found_vps:
            await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS found with container name: `{container_name}`"))
            return
        
        # Get owner info
        try:
            owner = await bot.fetch_user(int(user_id))
            owner_mention = owner.mention
        except:
            owner_mention = f"User {user_id}"
        
        embed = create_info_embed("VPS Expiration Status", f"Details for `{container_name}`")
        add_field(embed, "Owner", owner_mention, True)
        add_field(embed, "Container", f"`{container_name}`", True)
        
        if found_vps.get('expiration_date'):
            expiration_dt = datetime.fromisoformat(found_vps['expiration_date'])
            days_remaining = (expiration_dt - datetime.now()).days
            
            if days_remaining < 0:
                status = "🔴 EXPIRED"
            elif days_remaining <= EXPIRATION_WARNING_DAYS:
                status = "🟡 EXPIRING SOON"
            else:
                status = "🟢 ACTIVE"

            add_field(embed, "Status", status, True)
            add_field(embed, "Expiration Date", expiration_dt.strftime('%Y-%m-%d %H:%M:%S'), True)
            add_field(embed, "Days Remaining", str(max(0, days_remaining)), True)
        else:
            add_field(embed, "Status", "🔵 NO EXPIRATION SET", False)
        
        await ctx.send(embed=embed)
    else:
        # List all VPS with expiration status
        embed = create_info_embed("📋 All VPS Expiration Status", "Global expiration overview")
        
        expiring_soon = []
        expired = []
        active = []
        no_expiration = []
        
        for user_id, vps_list in vps_data.items():
            try:
                owner = await bot.fetch_user(int(user_id))
                owner_name = owner.name
            except:
                owner_name = f"Unknown ({user_id})"
            
            for vps in vps_list:
                if vps.get('expiration_date'):
                    expiration_dt = datetime.fromisoformat(vps['expiration_date'])
                    days_remaining = (expiration_dt - datetime.now()).days
                    
                    status_line = f"**{owner_name}** - `{vps['container_name']}`\n" \
                                 f"Expires: {expiration_dt.strftime('%Y-%m-%d')} ({days_remaining} days)"
                    
                    if days_remaining < 0:
                        expired.append(status_line)
                    elif days_remaining <= EXPIRATION_WARNING_DAYS:
                        expiring_soon.append(status_line)
                    else:
                        active.append(status_line)
                else:
                    no_expiration.append(f"**{owner_name}** - `{vps['container_name']}`")
        
        if expiring_soon:
            add_field(embed, "🟡 Expiring Soon", "\n\n".join(expiring_soon), False)
        if expired:
            add_field(embed, "🔴 Expired", "\n\n".join(expired), False)
        if active:
            add_field(embed, "🟢 Active", "\n\n".join(active[:10]), False)
            if len(active) > 10:
                add_field(embed, "Note", f"Showing 10 of {len(active)} active VPS", False)
        if no_expiration:
            add_field(embed, "🔵 No Expiration Set", "\n".join(no_expiration[:5]), False)
            if len(no_expiration) > 5:
                add_field(embed, "Note", f"Total {len(no_expiration)} VPS without expiration date", False)
        
        await ctx.send(embed=embed)

@bot.command(name='about')
async def about(ctx):
    total_users = len(vps_data)
    total_vps = sum(len(vps_list) for vps_list in vps_data.values())
    latency = round(bot.latency * 1000)
    main_admin = await bot.fetch_user(MAIN_ADMIN_ID)
    embed = create_info_embed(f"About {BOT_NAME}", f"Bot information and statistics")
    add_field(embed, "Bot Name", BOT_NAME, True)
    add_field(embed, "Main Owner", main_admin.mention, True)
    add_field(embed, "Developer", BOT_DEVELOPER, True)
    add_field(embed, "Host Provider", HOST_PROVIDER_NAME, True)
    add_field(embed, "Ping", f"{latency}ms", True)
    add_field(embed, "Version", BOT_VERSION, True)
    add_field(embed, "Total VPS", str(total_vps), True)
    add_field(embed, "Total Users", str(total_users), True)
    await ctx.send(embed=embed)


@bot.command(name='quickhelp')
async def quick_help(ctx):
    """Show quick reference for common tasks"""
    user_id = str(ctx.author.id)
    is_admin_access = is_admin_user(ctx.author)
    
    embed = create_info_embed("🚀 Quick Help Reference", 
        f"Quick reference for common tasks. Use `{PREFIX}help` for complete command list.")
    
    # Common user tasks
    add_field(embed, "👤 For Users", 
        f"• `{PREFIX}myvps` - List your VPS\n"
        f"• `{PREFIX}manage` - Start/stop/manage VPS\n"
        f"• `{PREFIX}ports` - Manage port forwarding\n"
        f"• `{PREFIX}share-user @user 1` - Share VPS #1\n"
        f"• `{PREFIX}about` - Bot information", False)
    
    # VPS management
    add_field(embed, "🖥️ VPS Control", 
        f"• In `{PREFIX}manage`: Click ▶ to start VPS\n"
        f"• In `{PREFIX}manage`: Click ⏸ to stop VPS\n"
        f"• In `{PREFIX}manage`: Click 🔑 for SSH access\n"
        f"• In `{PREFIX}manage`: Click 📊 for live stats\n"
        f"• In `{PREFIX}manage`: Click 🔄 to reinstall OS", False)
    
    # Troubleshooting
    add_field(embed, "🔧 Common Issues", 
        f"• Ports not working? Use `{PREFIX}repair-ports <container>` (admin)\n"
        "• VPS suspended? Contact admin to unsuspend\n"
        "• Need more resources? Contact admin for upgrade\n"
        "• SSH not working? Try reinstall with different OS", False)
    
    if is_admin_access:
        add_field(embed, "🛡️ Admin Quick Actions", 
            f"• `{PREFIX}create 2 2 20 @user` - Create 2GB/2CPU/20GB VPS\n"
            f"• `{PREFIX}userinfo @user` - Check user details\n"
            f"• `{PREFIX}node list` - List all nodes\n"
            f"• `{PREFIX}serverstats` - System overview\n"
            f"• `{PREFIX}dashboard` - Live animated host monitor\n"
            f"• `{PREFIX}suspend-vps <container> <reason>` - Suspend VPS", False)
    
    embed.set_footer(text=f"⚡ RGNODES™ • Use {PREFIX}help for complete command list")
    await ctx.send(embed=embed)

@bot.command(name='help-search')
async def help_search(ctx, *, search_term: str = None):
    """Search for commands"""
    if not search_term:
        await show_help.callback(ctx)
        return
    
    search_term = search_term.lower()
    user_id = str(ctx.author.id)
    is_admin_access = is_admin_user(ctx.author)
    is_main_admin_user = user_id == str(MAIN_ADMIN_ID)
    
    # Build complete command list based on permissions
    all_commands = []
    
    # User commands (always available)
    user_categories = ["user", "vps", "ports", "system", "bot"]
    for cat in user_categories:
        all_commands.extend(HelpView(ctx).command_categories[cat]["commands"])
    
    # Admin commands
    if is_admin_access:
        all_commands.extend(HelpView(ctx).command_categories["admin"]["commands"])
        all_commands.extend(HelpView(ctx).command_categories["nodes"]["commands"])
    
    # Main admin commands
    if is_main_admin_user:
        all_commands.extend(HelpView(ctx).command_categories["main_admin"]["commands"])
    
    # Search through commands
    matches = []
    for cmd, desc in all_commands:
        if (search_term in cmd.lower() or search_term in desc.lower()):
            matches.append((cmd, desc))
    
    if not matches:
        embed = create_info_embed("🔍 No Results Found",
            f"No commands found matching '{search_term}'. Try a different search term.")
        await ctx.send(embed=embed)
        return
    
    # Show results
    embed = create_info_embed(f"🔍 Search Results for '{search_term}'",
        f"Found {len(matches)} command(s) matching your search.")
    
    # Group matches by category
    results_text = "\n".join([f"**{cmd}** - {desc}" for cmd, desc in matches[:15]])
    add_field(embed, "Matching Commands", results_text, False)
    
    if len(matches) > 15:
        add_field(embed, "Note", f"Showing 15 of {len(matches)} matches. Try a more specific search.", False)
    
    embed.set_footer(text=f"⚡ RGNODES™ • Use {PREFIX}help for complete list")
    await ctx.send(embed=embed)    

async def send_private_node_setup(recipient, node_id, node_name, node_url, api_key, rotate=False):
    """Deliver remote-node credentials over DM only; never put API secrets in a channel embed."""
    embed = create_info_embed("Private Remote Node Key Rotation" if rotate else "Private Remote Node Setup", f"Node **{node_name}** (ID: {node_id})\nKeep this message private. Anyone with the API key may control this node through the bot.")
    add_field(embed, "Node URL", str(node_url), False)
    add_field(embed, "API Key", f"`{api_key}`", False)
    command = "sudo bash node.sh --prompt-api-key --port=18443"
    add_field(embed, "Install / Update", f"Upload `node.sh` from the seven-file release to the Linux node, then run:\n```bash\n{command}\n```\nThe command deliberately forces a hidden key prompt, even if an older key already exists in the node config. Paste the API key from this DM; input is not echoed. Do not put the key directly in a shell command or share this DM.", False)
    add_field(embed, "Network Setup", "The agent binds to `127.0.0.1` by default and does not open firewall ports. For remote access, either use a private VPN and bind with `--host=NODE_VPN_IP` (then use that private URL in the bot), or put the loopback listener behind a TLS reverse proxy and register its HTTPS URL. Do not expose plain HTTP to the public Internet.", False)
    try:
        await recipient.send(embed=embed)
        return True
    except Exception as exc:
        logger.warning("Could not send private node setup details to Discord user ID %s (%s). No API key was posted publicly.", getattr(recipient, "id", "unknown"), type(exc).__name__)
        return False


@bot.command(name='node')
@is_admin()
async def node_cmd(ctx, sub: str, *args):
    if sub == 'create':
        await ctx.send(embed=create_info_embed("Node Setup", "Enter node name:"))
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        name = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        await ctx.send(embed=create_info_embed("Node Setup", "Enter location:"))
        location = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        await ctx.send(embed=create_info_embed("Node Setup", "Enter total VPS capacity:"))
        total_vps_str = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        try:
            total_vps = int(total_vps_str)
            if total_vps < 1:
                raise ValueError
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid Input", "Total VPS must be a positive integer."))
            return
        if not name or not location:
            await ctx.send(embed=create_error_embed("Invalid Input", "Node name and location cannot be empty."))
            return
        await ctx.send(embed=create_info_embed("Node Setup", "Enter tags (comma separated):"))
        tags_str = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        tags = [t.strip() for t in tags_str.split(',') if t.strip()]
        tags_json = json.dumps(tags)
        await ctx.send(embed=create_info_embed("Node Setup", "Enter node URL (HTTPS or a trusted private VPN URL; leave blank only to register a local node):"))
        url_str = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        
        # Normalize the remote URL if provided; the Local Node itself is registered automatically on startup.
        if url_str:
            if not url_str.startswith('http://') and not url_str.startswith('https://'):
                url_str = f'http://{url_str}'
            url = url_str
        else:
            url = None
        is_local = 1 if not url else 0
        if is_local:
            existing_local = next((item for item in get_nodes() if bool(item.get('is_local'))), None)
            if existing_local:
                await ctx.send(embed=create_info_embed(
                    'Local Node Already Registered',
                    f"The local node is created automatically and already exists as **{existing_local.get('name', 'Local Node')}** (ID `{existing_local.get('id')}`).\n\nUse `{PREFIX}node list` to inspect it, or provide a node URL to register a remote node.\n\nThe local node is only deploy-ready when `/dev/kvm` and libvirt are available.",
                ))
                return
        api_key = None if is_local else secrets.token_hex(32)
        conn = get_db()
        cur = conn.cursor()
        try:
            cur.execute('INSERT INTO nodes (name, location, total_vps, tags, api_key, url, is_local) VALUES (?, ?, ?, ?, ?, ?, ?)',
                        (name, location, total_vps, tags_json, api_key, url, is_local))
            conn.commit()
            node_id = cur.lastrowid
            embed = create_success_embed("Node Created", f"ID: {node_id}\nName: {name}\nLocation: {location}\nCapacity: {total_vps}\nTags: {', '.join(tags)}")
            if not is_local:
                add_field(embed, "Remote Setup", "The node URL and API credentials are sent privately by DM. They are intentionally not displayed in this channel.", False)
            await ctx.send(embed=embed)
            if not is_local:
                delivered = await send_private_node_setup(ctx.author, node_id, name, url, api_key, rotate=False)
                if not delivered:
                    await ctx.send(embed=create_warning_embed("Private Setup DM Not Delivered", "No API key was shared in this channel. Enable server-member DMs, then use `node regen-key <id>` to generate and privately deliver a fresh key."))
        except sqlite3.IntegrityError:
            await ctx.send(embed=create_error_embed("Error", "Node name already exists."))
        conn.close()
    elif sub == 'list':
        nodes = get_nodes()
        embed = create_info_embed("Nodes List", "")
        for n in nodes:
            status = ("Local · Up" if _local_kvm_ready() else "Local · KVM unavailable") if n['is_local'] else "Down"
            if not n['is_local']:
                try:
                    response = await asyncio.to_thread(requests.get, str(n['url']).rstrip('/') + '/api/ping', headers={'X-API-Key': str(n['api_key'])}, timeout=5)
                    status = "Up" if response.status_code == 200 else "Down"
                except:
                    pass
            field = f"ID: {n['id']}\nName: {n['name']}\nLocation: {n['location']}\nCapacity: {n['total_vps']}\nTags: {', '.join(n['tags'])}\nStatus: {status}"
            if not n['is_local']:
                field += f"\nURL: {n['url']}"
            add_field(embed, f"Node {n['id']}", field, False)
        await ctx.send(embed=embed)
    elif sub == 'capacity':
        if not args:
            await ctx.send(embed=create_error_embed("Usage", f"{PREFIX}node capacity <id> [new_capacity]"))
            return
        try:
            node_id = int(args[0])
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid ID", "Node ID must be an integer."))
            return
        node = get_node(node_id)
        if not node:
            await ctx.send(embed=create_error_embed("Not Found", "Node not found."))
            return
        if len(args) == 1:
            current = max(0, int(node.get('total_vps') or 0))
            used = get_current_vps_count(node_id)
            await ctx.send(embed=create_info_embed("🌐 Node Capacity", f"Node **{node['name']}**: **{used}/{current}** VPS slots used."))
            return
        try:
            new_capacity = int(args[1])
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid Capacity", "Capacity must be a non-negative integer."))
            return
        if new_capacity < 0:
            await ctx.send(embed=create_error_embed("Invalid Capacity", "Capacity cannot be negative."))
            return
        used = get_current_vps_count(node_id)
        if new_capacity < used:
            await ctx.send(embed=create_error_embed("Capacity Too Low", f"This node already has **{used}** VPS. Capacity cannot be reduced below the current usage."))
            return
        with DB_LOCK:
            conn = get_db()
            try:
                conn.execute("UPDATE nodes SET total_vps=?, last_updated=CURRENT_TIMESTAMP WHERE id=?", (new_capacity, node_id))
                conn.commit()
            finally:
                conn.close()
        await record_audit_event("node", "Node Capacity Updated", f"Capacity changed from {node.get('total_vps')} to {new_capacity}.", user_id=ctx.author.id, node_id=node_id)
        await ctx.send(embed=create_success_embed("🌐 Node Capacity Updated", f"**{node['name']}** capacity is now **{new_capacity}** VPS. Current usage: **{used}**."))

    elif sub == 'edit':
        if not args:
            await ctx.send(embed=create_error_embed("Usage", f"{PREFIX}node edit <id>"))
            return
        try:
            node_id = int(args[0])
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid ID", "Node ID must be an integer."))
            return
        node = get_node(node_id)
        if not node:
            await ctx.send(embed=create_error_embed("Not Found", "Node not found."))
            return
        private_setup_rotate = False
        await ctx.send(embed=create_info_embed("Edit Node", f"Editing node {node['name']}. Enter a new name, or `.` to skip:"))
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel
        new_name = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        if new_name != '.':
            node['name'] = new_name
        await ctx.send(embed=create_info_embed("Edit Node", "New location, or `.` to skip:"))
        new_loc = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        if new_loc != '.':
            node['location'] = new_loc
        await ctx.send(embed=create_info_embed("Edit Node", "New total VPS capacity, or `.` to skip:"))
        new_total = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        if new_total != '.':
            try:
                parsed_total = int(new_total)
                if parsed_total < 1:
                    raise ValueError
            except ValueError:
                await ctx.send(embed=create_error_embed("Invalid Input", "Total VPS capacity must be a positive integer; no changes were saved."))
                return
            node['total_vps'] = parsed_total
        await ctx.send(embed=create_info_embed("Edit Node", "New tags (comma separated), or `.` to skip:"))
        new_tags = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
        if new_tags != '.':
            node['tags'] = [t.strip() for t in new_tags.split(',') if t.strip()]
        
        # NEW: Add conversion option between Local and Dynamic
        if node['is_local']:
            await ctx.send(embed=create_info_embed("Edit Node", "Convert this local node to a dynamic URL-based node? Reply `y` or `n`."))
            convert = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip().lower()
            if convert == 'y':
                await ctx.send(embed=create_info_embed("Edit Node", "Enter node URL (HTTPS recommended; use HTTP only over a trusted private VPN):"))
                url_str = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
                if not url_str:
                    await ctx.send(embed=create_error_embed("Error", "URL cannot be empty for dynamic node."))
                    return
                
                # Normalize URL - add http:// if not present
                if not url_str.startswith('http://') and not url_str.startswith('https://'):
                    url_str = f'http://{url_str}'
                
                node['url'] = url_str
                node['is_local'] = 0
                node['api_key'] = secrets.token_hex(32)
        else:
            await ctx.send(embed=create_info_embed("Edit Node", "Convert this dynamic node to a local node? Reply `y` or `n`."))
            convert = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip().lower()
            if convert == 'y':
                node['url'] = None
                node['api_key'] = None
                node['is_local'] = 1
                await ctx.send(embed=create_success_embed("Node Converted", "The node is now local."))
            else:
                await ctx.send(embed=create_info_embed("Edit Node", "New URL (HTTPS recommended; use HTTP only over a trusted private VPN), or `.` to skip:"))
                new_url = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip()
                if new_url != '.':
                    # Normalize URL - add http:// if not present
                    if not new_url.startswith('http://') and not new_url.startswith('https://'):
                        new_url = f'http://{new_url}'
                    node['url'] = new_url
                await ctx.send(embed=create_info_embed("Edit Node", "Regenerate the API key? Reply `y` or `n`."))
                regen = (await asyncio.wait_for(bot.wait_for('message', check=check), timeout=180)).content.strip().lower()
                if regen == 'y':
                    node['api_key'] = secrets.token_hex(32)
                    private_setup_rotate = True
        
        conn = get_db()
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET name=?, location=?, total_vps=?, tags=?, api_key=?, url=?, is_local=? WHERE id=?',
                    (node['name'], node['location'], node['total_vps'], json.dumps(node['tags']), node.get('api_key'), node.get('url'), node['is_local'], node_id))
        conn.commit()
        conn.close()
        embed = create_success_embed("Node Updated", f"ID: {node_id}\nName: {node['name']}\nLocation: {node['location']}\nCapacity: {node['total_vps']}\nTags: {', '.join(node['tags'])}\nType: {'Local' if node['is_local'] else 'Dynamic'}")
        if not node['is_local']:
            add_field(embed, "Remote Setup", "Current connection details and API key are sent by private DM; no secret is displayed here.", False)
        await ctx.send(embed=embed)
        if not node['is_local']:
            delivered = await send_private_node_setup(ctx.author, node_id, node['name'], node['url'], node['api_key'], rotate=private_setup_rotate)
            if not delivered:
                await ctx.send(embed=create_warning_embed("Private Setup DM Not Delivered", f"No API key was shared in this channel. Enable DMs and run `node regen-key {node_id}` to privately deliver a fresh key."))
    
    # NEW: Add delete subcommand
    elif sub == 'delete':
        if not args:
            await ctx.send(embed=create_error_embed("Usage", f"{PREFIX}node delete <id> [force]"))
            return
        
        try:
            node_id = int(args[0])
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid ID", "Node ID must be an integer."))
            return
        
        force = False
        if len(args) > 1 and args[1].lower() == 'force':
            force = True
        elif len(args) > 1:
            await ctx.send(embed=create_error_embed("Invalid Argument", "Optional argument must be 'force'."))
            return
        
        node = get_node(node_id)
        if not node:
            await ctx.send(embed=create_error_embed("Not Found", "Node not found."))
            return
        
        # Check if this is the local node
        if node['is_local']:
            await ctx.send(embed=create_error_embed("Cannot Delete", "Cannot delete the local node."))
            return
        
        # Check if node has any VPS assigned
        vps_count = get_current_vps_count(node_id)
        if not force and vps_count > 0:
            await ctx.send(embed=create_error_embed("Cannot Delete", 
                f"Node has {vps_count} VPS assigned. Migrate or delete them first, or use 'force' to delete all VPS and the node."))
            return
        
        # Prepare warning message
        warning_msg = f"Are you sure you want to delete node **{node['name']}** (ID: {node_id})?\n\n"
        warning_msg += f"**Location:** {node['location']}\n"
        warning_msg += f"**Tags:** {', '.join(node['tags'])}\n\n"
        if force and vps_count > 0:
            warning_msg += f"**WARNING: Force mode will delete all {vps_count} VPS on this node first!**\n\n"
        warning_msg += "This action cannot be undone!"
        
        embed = create_warning_embed("⚠️ Delete Node", warning_msg)
        
        class ConfirmDelete(discord.ui.View):
            def __init__(self, node_id, node_name, force, vps_count):
                super().__init__(timeout=60)
                self.node_id = node_id
                self.node_name = node_name
                self.force = force
                self.vps_count = vps_count
            
            @discord.ui.button(label="Delete Node", style=discord.ButtonStyle.secondary)
            async def confirm(self, inter: discord.Interaction, item: discord.ui.Button):
                if str(inter.user.id) != str(ctx.author.id):
                    await inter.response.send_message(
                        embed=create_error_embed("Access Denied", "Only the command author can confirm."),
                        ephemeral=True
                    )
                    return
                
                await inter.response.defer()
                
                # Force-deleting a node must delete the real KVM VPSs first.
                # Never remove DB records for containers that could not be deleted,
                # otherwise they become unmanaged/orphaned VPS instances.
                if self.force and self.vps_count > 0:
                    with DB_LOCK:
                        conn = get_db()
                        try:
                            rows = conn.execute(
                                "SELECT container_name FROM vps WHERE node_id = ? ORDER BY id",
                                (self.node_id,),
                            ).fetchall()
                        finally:
                            conn.close()

                    failed = []
                    for row in rows:
                        container = str(row["container_name"])
                        try:
                            await execute_vpsctl_compat(
                                container,
                                f"delete {container} --force",
                                timeout=300,
                                node_id=self.node_id,
                            )
                        except Exception as delete_error:
                            failed.append(f"{container}: {delete_error}")

                    if failed:
                        detail = "\n".join(f"• {x}" for x in failed[:8])
                        await inter.followup.send(
                            embed=create_error_embed(
                                "Node Deletion Aborted",
                                "One or more KVM VPSs could not be deleted, so the database records were kept intact.\n\n" + detail,
                            )
                        )
                        return

                # Keep a recoverable DB snapshot before a destructive node purge.
                backup_database()
                with DB_LOCK:
                    conn = get_db()
                    try:
                        if self.force and self.vps_count > 0:
                            cur = conn.cursor()
                            cur.execute(
                                "DELETE FROM port_forwards WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id = ?)",
                                (self.node_id,),
                            )
                            cur.execute("DELETE FROM vps WHERE node_id = ?", (self.node_id,))
                        cur = conn.cursor()
                        cur.execute("DELETE FROM nodes WHERE id = ?", (self.node_id,))
                        if cur.rowcount != 1:
                            raise RuntimeError("Node disappeared before deletion was committed.")
                        conn.commit()
                    except Exception:
                        conn.rollback()
                        raise
                    finally:
                        conn.close()

                if self.force and self.vps_count > 0:
                    deleted_containers = {str(row["container_name"]) for row in rows}
                    for owner_id in list(vps_data):
                        vps_data[owner_id] = [
                            v for v in vps_data[owner_id]
                            if str(v.get("container_name")) not in deleted_containers
                        ]
                        if not vps_data[owner_id]:
                            del vps_data[owner_id]
                msg = f"Node **{self.node_name}** (ID: {self.node_id}) has been deleted."
                if self.force and self.vps_count > 0:
                    msg += f" All {self.vps_count} VPS and their KVM VPSs were deleted."

                success_embed = create_success_embed("Node Deleted", msg)
                await inter.followup.send(embed=success_embed)
                self.stop()
            
            @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
            async def cancel(self, inter: discord.Interaction, item: discord.ui.Button):
                if str(inter.user.id) != str(ctx.author.id):
                    await inter.response.send_message(
                        embed=create_error_embed("Access Denied", "Only the command author can cancel."),
                        ephemeral=True
                    )
                    return
                
                await inter.response.edit_message(
                    embed=create_info_embed("Deletion Cancelled", "Node deletion was cancelled."),
                    view=None
                )
                self.stop()
        
        await ctx.send(embed=embed, view=ConfirmDelete(node_id, node['name'], force, vps_count))
    
    elif sub == 'status':
        # New: Check node status
        if not args:
            await ctx.send(embed=create_error_embed("Usage", f"{PREFIX}node status <id>"))
            return
        
        try:
            node_id = int(args[0])
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid ID", "Node ID must be an integer."))
            return
        
        node = get_node(node_id)
        if not node:
            await ctx.send(embed=create_error_embed("Not Found", "Node not found."))
            return
        
        embed = create_info_embed(f"Node Status - {node['name']}")
        
        if node['is_local']:
            status = "🟢 Local Node"
            cpu_usage = get_host_cpu_usage()
            ram_usage = get_host_ram_usage()
            add_field(embed, "Status", status, True)
            add_field(embed, "CPU Usage", f"{cpu_usage:.1f}%", True)
            add_field(embed, "RAM Usage", f"{ram_usage:.1f}%", True)
        else:
            try:
                response = await asyncio.to_thread(requests.get, str(node['url']).rstrip('/') + '/api/ping', headers={'X-API-Key': str(node['api_key'])}, timeout=5)
                if response.status_code == 200:
                    status = "🟢 Online"
                    try:
                        stats_response = await asyncio.to_thread(requests.get, str(node['url']).rstrip('/') + '/api/get_host_stats', 
                                                    headers={'X-API-Key': str(node['api_key'])}, 
                                                    timeout=5)
                        if stats_response.status_code == 200:
                            stats = stats_response.json()
                            cpu_usage = stats.get('cpu', 0.0)
                            ram_usage = stats.get('ram', 0.0)
                            add_field(embed, "CPU Usage", f"{cpu_usage:.1f}%", True)
                            add_field(embed, "RAM Usage", f"{ram_usage:.1f}%", True)
                    except:
                        cpu_usage = "Unknown"
                        ram_usage = "Unknown"
                else:
                    status = "🔴 Offline"
            except:
                status = "🔴 Offline"
            
            add_field(embed, "Status", status, True)
        
        vps_count = get_current_vps_count(node_id)
        capacity = node['total_vps']
        usage_percentage = (vps_count / capacity * 100) if capacity > 0 else 0
        
        add_field(embed, "VPS Capacity", f"{vps_count}/{capacity} ({usage_percentage:.1f}%)", True)
        add_field(embed, "Location", node['location'], True)
        add_field(embed, "Tags", ", ".join(node['tags']), True)
        
        if not node['is_local']:
            add_field(embed, "URL", node['url'], False)
        
        await ctx.send(embed=embed)
    
    elif sub == 'regen-key':
        # NEW: Regenerate API key for dynamic node
        if not args:
            await ctx.send(embed=create_error_embed("Usage", f"{PREFIX}node regen-key <id>"))
            return
        
        try:
            node_id = int(args[0])
        except ValueError:
            await ctx.send(embed=create_error_embed("Invalid ID", "Node ID must be an integer."))
            return
        
        node = get_node(node_id)
        if not node:
            await ctx.send(embed=create_error_embed("Not Found", "Node not found."))
            return
        
        # Check if node is local
        if node['is_local']:
            await ctx.send(embed=create_error_embed("Error", "Cannot regenerate API key for Local nodes. Only Dynamic nodes have API keys."))
            return
        
        # Confirm regeneration
        warning_embed = create_warning_embed("⚠️ Regenerate API Key", 
            f"You are about to regenerate the API key for node **{node['name']}**.\n\n"
            f"The current key is hidden. The new 64-character key will be sent by private DM only.\n\n"
            f"**This action will:**\n"
            f"• Generate a new 64-character API key\n"
            f"• Invalidate the old API key\n"
            f"• Require updating the remote node agent\n\n"
            f"Are you sure you want to continue?")
        
        class ConfirmRegenKey(discord.ui.View):
            def __init__(self, node_id, node):
                super().__init__(timeout=60)
                self.node_id = node_id
                self.node = node
            
            @discord.ui.button(label="Regenerate Key", style=discord.ButtonStyle.secondary)
            async def confirm(self, inter: discord.Interaction, item: discord.ui.Button):
                if str(inter.user.id) != str(ctx.author.id):
                    await inter.response.send_message(
                        embed=create_error_embed("Access Denied", "Only the command author can confirm."),
                        ephemeral=True
                    )
                    return
                
                await inter.response.defer()
                
                # Generate new API key
                new_api_key = secrets.token_hex(32)
                
                # Update database
                conn = get_db()
                cur = conn.cursor()
                cur.execute('UPDATE nodes SET api_key=? WHERE id=?', (new_api_key, self.node_id))
                conn.commit()
                conn.close()
                
                # Keep credentials out of the public follow-up; only send the replacement via DM.
                private_delivery = await send_private_node_setup(
                    ctx.author, self.node_id, self.node['name'], self.node['url'], new_api_key, rotate=True
                )
                success_embed = create_success_embed("API Key Regenerated", f"Node **{self.node['name']}** (ID: {self.node_id})")
                add_field(success_embed, "Status", "The old API key is now invalid. The remote node must be updated with the new key before it can authenticate.", False)
                if private_delivery:
                    add_field(success_embed, "Private Delivery", "The new key and secure update instructions were sent by DM.", False)
                else:
                    add_field(success_embed, "Private Delivery", f"DM failed; no key was posted publicly. Enable DMs and run `node regen-key {self.node_id}` again to issue a key privately.", False)
                await inter.followup.send(embed=success_embed)
                self.stop()
            
            @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
            async def cancel(self, inter: discord.Interaction, item: discord.ui.Button):
                if str(inter.user.id) != str(ctx.author.id):
                    await inter.response.send_message(
                        embed=create_error_embed("Access Denied", "Only the command author can cancel."),
                        ephemeral=True
                    )
                    return
                
                await inter.response.edit_message(
                    embed=create_info_embed("Cancelled", "API key regeneration was cancelled."),
                    view=None
                )
                self.stop()
        
        await ctx.send(embed=warning_embed, view=ConfirmRegenKey(node_id, node))
    
    else:
        # Show help for node command
        embed = create_info_embed("Node Management", 
            f"Manage multi-node infrastructure for {BOT_NAME}")

class HelpView(RGNODESView):
    def __init__(self, ctx):
        super().__init__(timeout=300)
        self.ctx = ctx
        self.current_category = "user"
        # Command categories
        self.command_categories = {
            "user": {
                "name": "👤 User Commands",
                "commands": [
                    (f"{PREFIX}ping [node-name]", "Check bot or node API latency"),
                    (f"{PREFIX}uptime [node-name]", "Show host or local-node uptime; remote uptime availability is reported honestly"),
                    (f"{PREFIX}deploy", "Deploy an auto-fitted RGNODES™ VPS (up to 8GB RAM)"),
                    (f"{PREFIX}myvps", "List your VPS"),
                    (f"{PREFIX}list", "List VPS with live CPU/RAM/Disk usage"),
                    (f"{PREFIX}info <vps-id>", "View VPS details"),
                    (f"{PREFIX}stats [vps-id]", "View invite/boost totals or VPS live usage"),
                    (f"{PREFIX}plans", "View the free VPS plan"),
                    (f"{PREFIX}claimfree inv <1-6>", "Verify tracked invite tier and open deployment"),
                    (f"{PREFIX}claimfree boost <1-5>", "Verify tracked boost tier and open deployment"),
                    (f"{PREFIX}start <vps-id>", "Start an owned/shared VPS"),
                    (f"{PREFIX}stop <vps-id>", "Stop an owned/shared VPS"),
                    (f"{PREFIX}restart <vps-id>", "Restart an owned/shared VPS"),
                    (f"{PREFIX}manage [@user]", "Manage your VPS or another user's VPS (Admin only)"),
                    (f"{PREFIX}share-user @user <vps-id>", "Share VPS access"),
                    (f"{PREFIX}share-ruser @user <vps-id>", "Revoke VPS access"),
                    (f"{PREFIX}manage-shared @owner <vps-id>", "Manage shared VPS"),
                    (f"{PREFIX}renew [vps-id]", "Renew your VPS in the final 2 days or after expiration; adds 60 days"),
                    (f"{PREFIX}ssh [vps-id]", "Receive normal OpenSSH access details privately"),
                    (f"{PREFIX}pinggy [vps-id]", "Open Pinggy SSH tunnel only"),
                    (f"{PREFIX}reconnect-pinggy [vps-id]", "Reconnect Pinggy tunnel only"),
                    (f"{PREFIX}bandwidth [vps-id]", "View the fixed 50GB monthly bandwidth plan and usage"),
                    (f"{PREFIX}vps-log <vps-id> [lines]", "View your VPS system/audit logs")
                ]
            },
            "vps": {
                "name": "🖥️ VPS Management",
                "commands": [
                    (f"{PREFIX}myvps", "List your VPS"),
                    (f"{PREFIX}vpsinfo [vps-id]", "Get VPS information by ID"),
                    (f"{PREFIX}vps-stats <vps-id>", "Get VPS resource stats"),
                    (f"{PREFIX}vps-uptime <vps-id>", "Get VPS uptime"),
                    (f"{PREFIX}vps-processes <vps-id>", "List running processes in VPS"),
                    (f"{PREFIX}vps-logs <vps-id> [lines]", "Admin: view guest system + RGNODES audit logs"),
                    (f"{PREFIX}vps-log <vps-id> [lines]", "View your VPS logs"),
                    (f"{PREFIX}restart-vps <vps-id>", "Restart VPS"),
                    (f"{PREFIX}clone-vps <vps-id> [new_name]", "Clone VPS by ID"),
                    (f"{PREFIX}vps-password <vps-id>", "Get/reset VPS root password"),
                    (f"{PREFIX}vps-network <vps-id>", "Show VPS network configuration"),
                    (f"{PREFIX}status <vps-id>", "Get VPS status (running/stopped)")
                ]
            },
            "ports": {
                "name": "🔌 Port Forwarding",
                "commands": [
                    (f"{PREFIX}ports [add <vps_num> <port> | list | remove <id>]", "Manage port forwards (TCP/UDP)"),
                    (f"{PREFIX}ports-add-user <amount> @user", "Allocate port slots to user (Admin only)"),
                    (f"{PREFIX}ports-remove-user <amount> @user", "Deallocate port slots from user (Admin only)"),
                    (f"{PREFIX}ports-revoke <id>", "Revoke specific port forward (Admin only)")
                ]
            },
            "system": {
                "name": "⚙️ System Commands",
                "commands": [
                    (f"{PREFIX}serverstats", "Server statistics (Admin only)"),
                    (f"{PREFIX}check-resources <node>", "Check host CPU/RAM/Disk resources"),
                    (f"{PREFIX}start-all <node>", "Start eligible VPS sequentially with capacity checks"),
                    (f"{PREFIX}purge-prot <vps-id>", "Enable purge protection"),
                    (f"{PREFIX}purge-remove-prot <vps-id>", "Disable purge protection"),
                    (f"{PREFIX}purge-status <vps-id>", "Check purge protection"),
                    (f"{PREFIX}purge-list-prot <node>", "List protected VPS"),
                    (f"{PREFIX}purge-list-unprot <node>", "List unprotected VPS"),
                    (f"{PREFIX}purge-vm-all <node>", "Main-admin-only purge preview (no bulk deletion)"),
                    (f"{PREFIX}machine-status <node> [seconds]", "Get a bounded node status snapshot"),
                    (f"{PREFIX}resource-check", "Check and suspend high-usage VPS (Admin only)"),
                    (f"{PREFIX}cpu-monitor <status|enable|disable>", "Resource monitor control (logging only)"),
                    (f"{PREFIX}dashboard", "Live animated host/KVM/IPv4/Docker/security dashboard"),
                    (f"{PREFIX}thresholds", "View resource thresholds"),
                    (f"{PREFIX}set-threshold <cpu> <ram>", "Set resource thresholds (Admin only)"),
                    (f"{PREFIX}set-status <type> <name>", "Set bot activity (Admin only)"),
                    (f"{PREFIX}change-prefix <prefix>", "Change the bot prefix immediately"),
                    (f"{PREFIX}change-mode <online|idle|dnd|invis>", "Change bot presence mode"),
                    (f"{PREFIX}log-config", "Show the configured VPS/node logging channel (Admin only)"),
                    (f"{PREFIX}log-channel <show|test>", "Show or test the configured logging channel (Admin only)"),
                    (f"{PREFIX}permissions [#channel]", "Audit the bot's Discord permissions (Admin only)"),
                    (f"{PREFIX}node-capacity [node_id]", "Low-overhead node capacity snapshot (Admin only)"),
                    (f"{PREFIX}update logs #channel", "Publish VPS/node logs to a channel (Admin only)"),
                    (f"{PREFIX}motd <show|set|clear>", "Manage the SSH MOTD on running VPS (Admin only)")
                ]
            },
            "nodes": {
                "name": "🌐 Node Management",
                "commands": [
                    (f"{PREFIX}node create", "Create a new node (Admin only)"),
                    (f"{PREFIX}node list", "List all nodes (Admin only)"),
                    (f"{PREFIX}node status <id>", "Check node status (Admin only)"),
                    (f"{PREFIX}node edit <id>", "Edit node details or convert Local↔Dynamic (Admin only)"),
                    (f"{PREFIX}node regen-key <id>", "Regenerate API key for Dynamic node (Admin only)"),
                    (f"{PREFIX}node delete <id>", "Delete a node (Admin only)"),
                    (f"{PREFIX}node migrate <from> <to>", "Migrate VPS between nodes (Admin only)"),
                    (f"{PREFIX}vps-list [node_id]", "List KVM VPSs on node (Admin only)")
                ],
                "admin_only": True
            },
            "bot": {
                "name": "🤖 Bot Control",
                "commands": [
                    (f"{PREFIX}ping", "Check bot latency"),
                    (f"{PREFIX}uptime", "Show host uptime"),
                    (f"{PREFIX}help", "Show this help menu"),
                    (f"{PREFIX}set-status <type> <name>", "Set bot status (Admin only)")
                ]
            },
            "admin": {
                "name": "🛡️ Admin Commands",
                "commands": [
                    (f"{PREFIX}vps-list", "List all KVM VPSs"),
                    (f"{PREFIX}deploy [@user]", "Open OS + node selection and deploy an auto-fitted VPS (up to 8GB RAM)"),
                    (f"{PREFIX}create <ram_gb> <cpu_cores> <disk_gb> @user [expiry_days]", "Admin VPS creation with OS selection (optional expiry)"),
                    (f"{PREFIX}delete-vps @user <vps-id> [reason]", "Delete user's VPS by ID"),
                    (f"{PREFIX}add-resources <vps-id> [ram] [cpu] [disk]", "Add resources to VPS"),
                    (f"{PREFIX}resize-vps <vps-id> [ram] [cpu] [disk]", "Resize VPS resources"),
                    (f"{PREFIX}suspend-vps <vps-id> [reason]", "Suspend VPS by ID"),
                    (f"{PREFIX}unsuspend-vps <vps-id>", "Unsuspend VPS by ID"),
                    (f"{PREFIX}suspension-logs [vps-id]", "View suspension logs"),
                    (f"{PREFIX}whitelist-vps <vps-id> <add|remove>", "Whitelist VPS from auto-suspend"),
                    (f"{PREFIX}userinfo @user", "User information"),
                    (f"{PREFIX}list-all", "List all VPS"),
                    (f"{PREFIX}exec <vps-id> <command>", "Execute command in VPS"),
                    (f"{PREFIX}stop-vps-all", "Stop all VPS on system"),
                    (f"{PREFIX}backup-vps <vps>", "Export a VPS backup (Admin only)"),
                    (f"{PREFIX}restore-vps <vps> [backup]", "Restore a VPS backup (Admin only)"),
                    (f"{PREFIX}maintenance <on|off|status>", "Toggle VPS maintenance mode (Admin only)"),
                    (f"{PREFIX}migrate-vps <vps-id> <pool>", "Migrate VPS to different storage pool"),
                    (f"{PREFIX}vps-network <vps-id> <action> [value]", "Network management and configuration"),
                    (f"{PREFIX}apply-permissions <vps-id>", "Apply Docker-ready permissions to VPS"),
                    (f"{PREFIX}vps-password <vps-id>", "Get/reset VPS password by ID"),
                    (f"{PREFIX}node-check <node_id>", "Check node health and status"),
                    (f"{PREFIX}status <vps-id>", "Get VPS status"),
                    (f"{PREFIX}status-summary", "Get summary of all VPS status"),
                    (f"{PREFIX}repair-ports", "Repair port forwarding configuration"),
                    (f"{PREFIX}resource-check", "Check and suspend high-usage VPS"),
                    (f"{PREFIX}node-logs <node_id> [limit]", "View node health/audit history"),
                    (f"{PREFIX}logs [limit]", "View recent VPS/node audit logs"),
                    (f"{PREFIX}log-config", "Show configured log channel"),
                    (f"{PREFIX}update logs #channel", "Set the VPS/node log channel"),
                    (f"{PREFIX}update-logs #channel", "Alias for update logs #channel"),
                    (f"{PREFIX}add slots @user amount", "Add port slots to a user"),
                    (f"{PREFIX}bandwidth <vps-id>", "View 50GB monthly bandwidth usage"),
                    (f"{PREFIX}motd <show|set|clear>", "Manage VPS SSH MOTD"),
                ],
                "admin_only": True
            },
            "expiration": {
                "name": "⏰ VPS Expiration",
                "commands": [
                    (f"{PREFIX}renew [vps-id]", "Owner renewal in the final 2 days; adds 60 days"),
                    (f"{PREFIX}setexpire <vps-id> <days>", "Set VPS expiration date (Admin only)"),
                    (f"{PREFIX}extendexpire <vps-id> <days>", "Extend VPS expiration (Admin only)"),
                    (f"{PREFIX}removeexpire <vps-id>", "Remove VPS expiration (Admin only)"),
                    (f"{PREFIX}set-expiration <vps-id> <days>", "Legacy alias for setexpire"),
                    (f"{PREFIX}renew <vps-id>", "Owner renewal in final 2-day window (adds 60 days)"),
                    (f"{PREFIX}renew-vps <vps-id> [days]", "Renew VPS expiration (Admin only)"),
                    (f"{PREFIX}vps-expiration [vps-id]", "Check VPS expiration status (Admin only)")
                ],
                "admin_only": True
            },
            "maintenance": {
                "name": "🔧 Maintenance & Monitoring",
                "commands": [
                    (f"{PREFIX}cpu-monitor <status|enable|disable>", "Resource monitor control (logging only)"),
                    (f"{PREFIX}backup-db", "Backup VPS database (Admin only)"),
                    (f"{PREFIX}backup-vps <vps>", "Backup a VPS (Admin only)"),
                    (f"{PREFIX}restore-vps <vps> [backup]", "Restore a VPS KVM VPS (Admin only)"),
                    (f"{PREFIX}maintenance <on|off|status>", "Maintenance control (Admin only)"),
                    (f"{PREFIX}repair-ports", "Repair port forwarding configuration (Admin only)"),
                    (f"{PREFIX}node-check <node_id>", "Check node health and status (Admin only)"),
                    (f"{PREFIX}resource-check", "Check and suspend high-usage VPS (Admin only)"),
                    (f"{PREFIX}node-logs <node_id> [limit]", "View node health/audit history"),
                    (f"{PREFIX}node-log <node_id> [limit]", "Alias for node-logs"),
                    (f"{PREFIX}logs [limit]", "View recent audit log history"),
                    (f"{PREFIX}log-config", "Show configured logs channel"),
                    (f"{PREFIX}update logs #channel", "Set the VPS/node log channel"),
                    (f"{PREFIX}add slots @user amount", "Add port-forwarding slots to a user"),
                    (f"{PREFIX}bandwidth <vps-id>", "View 50GB monthly bandwidth accounting"),
                    (f"{PREFIX}motd <show|set|clear>", "Manage guest SSH MOTD")
                ],
                "admin_only": True
            },
            "main_admin": {
                "name": "👑 Main Admin Commands",
                "commands": [
                    (f"{PREFIX}add-admin @user", "Add admin (main admin only)"),
                    (f"{PREFIX}admin-add @user", "Legacy admin-add alias"),
                    (f"{PREFIX}admin-remove @user", "Remove admin"),
                    (f"{PREFIX}admin-list", "List admins")
                ],
                "admin_only": True,
                "main_admin_only": True
            }
        }
        self.update_select()
        self.update_embed()
        self.add_item(self.select)

    def update_select(self):
        """Update the category selection dropdown based on user permissions"""
        self.select = discord.ui.Select(placeholder="Select Category", options=[])
        user_id = str(self.ctx.author.id)
        admin_access = is_admin_user(self.ctx.author)
        is_main_admin_user = user_id == str(MAIN_ADMIN_ID)
       
        # Add all categories that user has access to
        options = []
        # Always show basic categories
        basic_categories = ["user", "vps", "ports", "system", "bot"]
        for category in basic_categories:
            options.append(discord.SelectOption(
                label=self.command_categories[category]["name"],
                value=category,
                emoji=self.get_category_emoji(category)
            ))
       
        # Add nodes category if admin
        if admin_access:
            options.append(discord.SelectOption(
                label=self.command_categories["nodes"]["name"],
                value="nodes",
                emoji=self.get_category_emoji("nodes")
            ))
       
        # Add admin categories if user has permissions
        if admin_access:
            options.append(discord.SelectOption(
                label=self.command_categories["admin"]["name"],
                value="admin",
                emoji=self.get_category_emoji("admin")
            ))
            options.append(discord.SelectOption(
                label=self.command_categories["expiration"]["name"],
                value="expiration",
                emoji=self.get_category_emoji("expiration")
            ))
            options.append(discord.SelectOption(
                label=self.command_categories["maintenance"]["name"],
                value="maintenance",
                emoji=self.get_category_emoji("maintenance")
            ))
       
        if is_main_admin_user:
            options.append(discord.SelectOption(
                label=self.command_categories["main_admin"]["name"],
                value="main_admin",
                emoji=self.get_category_emoji("main_admin")
            ))
       
        self.select.options = options
        self.select.callback = self.select_callback
   
    async def select_callback(self, interaction: discord.Interaction):
        """Handle category selection"""
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(embed=create_error_embed("Access Denied", "This menu is not assigned to your account."), ephemeral=True)
            return
        
        self.current_category = interaction.data['values'][0]
        self.update_embed()
        await interaction.response.edit_message(embed=self.embed, view=self)

    def get_category_emoji(self, category):
        """Get emoji for each category"""
        emojis = {
            "user": "👤",
            "vps": "🖥️",
            "ports": "🔌",
            "system": "⚙️",
            "bot": "🤖",
            "nodes": "🌐",
            "admin": "🛡️",
            "expiration": "⏰",
            "maintenance": "🔧",
            "main_admin": "👑"
        }
        return emojis.get(category, "📁")
   
    def update_embed(self):
        """Update the embed based on current category and user permissions"""
        category_data = self.command_categories[self.current_category]
        # Create embed with category-specific styling
        colors = {
            "user": 0x3498db, # Blue
            "vps": 0x2ecc71, # Green
            "ports": 0xe74c3c, # Red
            "system": 0xf39c12, # Orange
            "bot": 0x9b59b6, # Purple
            "nodes": 0x1abc9c, # Teal
            "admin": 0xe67e22, # Carrot
            "expiration": 0xff6b6b, # Coral red for expiration
            "maintenance": 0x34495e, # Dark gray for maintenance
            "main_admin": 0xf1c40f # Yellow
        }
        color = colors.get(self.current_category, 0x1a1a1a)
       
        title = f"📚 {BOT_NAME} Command Help - {category_data['name']}"
        description = f"**{category_data['name']}**\nUse the dropdown below to switch categories."
       
        # Add helpful tips based on category
        tips = {
            "user": f"Tip: Use `{PREFIX}myvps` to see all your VPS and `{PREFIX}manage` to control them.",
            "vps": f"Tip: Use `{PREFIX}manage` to control your VPS from Discord.",
            "ports": "Tip: Port forwards work for both TCP and UDP protocols.",
            "system": "Tip: Set thresholds to monitor resource usage across nodes.",
            "nodes": f"Tip: Use `{PREFIX}node list` to see all available nodes and their status.",
            "admin": f"Tip: Always check `{PREFIX}userinfo @user` before modifying VPS.",
            "expiration": "Tip: VPS are automatically suspended when they expire. Renew them to unsuspend.",
            "maintenance": f"Tip: Use `{PREFIX}backup-db` regularly to backup your VPS database.",
            "main_admin": "Tip: Be careful when adding/removing admin privileges."
        }
       
        if self.current_category in tips:
            description += f"\n\n💡 {tips[self.current_category]}"
       
        self.embed = create_embed(title, description, color)
       
        # Add commands to embed
        commands_text = "\n".join([f"**{cmd}** - {desc}" for cmd, desc in category_data["commands"]])
        add_field(self.embed, "Commands", commands_text, False)
       
        # Add appropriate footer based on category
        footers = {
            "user": f"{BOT_NAME} VPS Manager • User Commands • Need help? Contact admin",
            "vps": f"{BOT_NAME} VPS Manager • VPS Management • Cloning",
            "ports": f"{BOT_NAME} VPS Manager • Port Forwarding • TCP/UDP Support",
            "system": f"{BOT_NAME} VPS Manager • System Monitoring • Resource Management",
            "nodes": f"{BOT_NAME} VPS Manager • Multi-Node Management • Distributed Infrastructure",
            "bot": f"{BOT_NAME} VPS Manager • Bot Control • Status Management",
            "admin": f"{BOT_NAME} VPS Manager • Admin Panel • Restricted Access",
            "expiration": f"{BOT_NAME} VPS Manager • VPS Expiration • Auto-Suspension",
            "maintenance": f"{BOT_NAME} VPS Manager • System Maintenance • Database Backup & Repair",
            "main_admin": f"{BOT_NAME} VPS Manager • Main Admin • Full System Control"
        }
       
        self.embed.set_footer(text=footers.get(self.current_category, f"{BOT_NAME} VPS Manager"))


@bot.command(name='help')
async def show_help(ctx):
    """Display the interactive help menu"""
    view = HelpView(ctx)
    await ctx.send(embed=view.embed, view=view)


# Additional command names requested for the public VPS manager.
def _vps_access_allowed(ctx, owner_id: str, vps: Dict[str, Any]) -> bool:
    actor_id = str(ctx.author.id)
    return is_admin_user(ctx.author) or actor_id == str(owner_id) or actor_id in {str(x) for x in (vps.get("shared_with") or [])}


def _resource_pct(value: Any) -> str:
    try:
        return f"{max(0.0, min(100.0, float(value))):.1f}%"
    except (TypeError, ValueError):
        return "N/A"


@bot.command(name="list", aliases=["vps"])
async def list_vps_command(ctx):
    """Detailed VPS list: users see their own; admins see all owners and live usage."""
    if is_admin_user(ctx.author):
        records = [(owner_id, item) for owner_id, items in vps_data.items() for item in items]
        title = "🗂️ All VPS Inventory"
    else:
        records = [(str(ctx.author.id), item) for item in vps_data.get(str(ctx.author.id), [])]
        title = "🖥️ Your VPS Inventory"
    if not records:
        await ctx.send(embed=create_info_embed(title, "No VPS records found."))
        return

    semaphore = asyncio.Semaphore(4)
    async def fetch_one(owner_id, item):
        async with semaphore:
            name = str(item.get("container_name") or "unknown")
            node_id = int(item.get("node_id") or 1)
            try:
                stats = await asyncio.wait_for(get_container_stats(name, node_id), timeout=15)
            except Exception:
                stats = {"status": "unknown", "cpu": None, "ram": {}, "disk": "Unknown"}
            ram = stats.get("ram") if isinstance(stats.get("ram"), dict) else {}
            status = str(stats.get("status") or item.get("status") or "unknown").lower()
            known = status not in {"unknown", "error", "unavailable", ""}
            disk = stats.get("disk", "Unknown")
            if isinstance(disk, dict):
                disk_pct = _resource_pct(disk.get("percent"))
                disk_text = f"{disk_pct} used"
            else:
                match = re.search(r"\((\d+(?:\.\d+)?)%\)", str(disk))
                disk_pct = f"{float(match.group(1)):.1f}%" if match else "N/A"
                disk_text = str(disk)[:70]
            owner = f"<@{owner_id}>"
            vmid = item.get("vmid") or item.get("id") or "?"
            state = "🟢 RUNNING" if status == "running" else "🔴 STOPPED" if status == "stopped" else "🟡 UNKNOWN"
            if item.get("suspended"):
                state = "⛔ SUSPENDED"
            product_type = str(item.get("product_type") or ("DOCKER" if str(item.get("config") or "").lower().startswith("docker vps") else "KVM")).upper()
            product_label = "🐳 Docker VPS" if product_type == "DOCKER" else "🖥️ KVM VPS"
            node = get_node(node_id)
            expiry = format_expiration(item)
            cpu_text = _resource_pct(stats.get("cpu")) if known else "N/A"
            ram_text = _resource_pct(ram.get("pct")) if known else "N/A"
            disk_display = disk_pct if known else "N/A"
            return (
                f"{state} • Owner: {owner} • VPS ID `{vmid}`\n"
                f"Container: `{name}` • {product_label} • Node: `{node.get('name') if node else 'Unknown'}`\n"
                f"CPU `{cpu_text}` | RAM `{ram_text}` | Disk `{disk_display}`\n"
                f"Plan: `{item.get('ram')} RAM / {item.get('cpu')} CPU / {item.get('storage')} Disk`\n"
                f"⏰ `{expiry}`"
            )

    details = await asyncio.gather(*(fetch_one(owner_id, item) for owner_id, item in records))
    # Stay within Discord embed limits and readable on a phone.
    for page_start in range(0, len(details), 5):
        page = details[page_start:page_start + 5]
        page_number = page_start // 5 + 1
        embed = create_info_embed(f"{title} • {page_number}/{(len(details)+4)//5}", "\n\n".join(page))
        embed.set_footer(text=f"{BOT_NAME} • {len(records)} VPS • Live metrics; unavailable values shown as N/A")
        await ctx.send(embed=embed)


@bot.command(name="info")
async def info_alias(ctx, vps_id: str):
    owner_id, _idx, vps = find_vps_record(vps_id)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS matches `{vps_id}`."))
        return
    if not _vps_access_allowed(ctx, owner_id, vps):
        await ctx.send(embed=create_error_embed("Access Denied", "Only the VPS owner, an authorized shared user, or an administrator can view this VPS."))
        return
    stats = await get_container_stats(str(vps.get("container_name")), int(vps.get("node_id") or 1))
    ram = stats.get("ram") if isinstance(stats.get("ram"), dict) else {}
    node = get_node(int(vps.get("node_id") or 1))
    description = (
        f"**Owner:** <@{owner_id}>\n**VPS ID:** `{vps.get('vmid') or vps.get('id')}`\n"
        f"**Container:** `{vps.get('container_name')}`\n**Node:** `{node.get('name') if node else 'Unknown'}`\n"
        f"**Status:** `{str(stats.get('status') or vps.get('status') or 'unknown').upper()}`\n"
        f"**Resources:** {vps.get('ram')} RAM • {vps.get('cpu')} CPU • {vps.get('storage')} Disk\n"
        f"**Live usage:** CPU `{_resource_pct(stats.get('cpu'))}` • RAM `{_resource_pct(ram.get('pct'))}`\n"
        f"**Disk:** `{stats.get('disk', 'Unknown')}`\n**OS:** `{vps.get('os_version', 'Unknown')}`\n"
        f"**Expires:** `{format_expiration(vps)}`"
    )
    await ctx.send(embed=create_info_embed("🔎 VPS Information", description))


@bot.command(name="stats")
async def stats_alias(ctx, vps_id: str = None):
    if vps_id:
        owner_id, _idx, vps = find_vps_record(vps_id)
        if not vps:
            await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS matches `{vps_id}`."))
            return
        if not _vps_access_allowed(ctx, owner_id, vps):
            await ctx.send(embed=create_error_embed("Access Denied", "You do not have permission to inspect this VPS."))
            return
        stats = await get_container_stats(str(vps.get("container_name")), int(vps.get("node_id") or 1))
        ram = stats.get("ram") if isinstance(stats.get("ram"), dict) else {}
        metrics_known = str(stats.get("status") or "unknown").lower() not in {"unknown", "error", "unavailable", ""}
        node = get_node(int(vps.get("node_id") or 1))
        disk = stats.get("disk", "Unknown") if metrics_known else "N/A (controller did not return metrics)"
        embed = create_info_embed(
            "📊 VPS Live Usage",
            f"**Owner:** <@{owner_id}> • **Node:** `{node.get('name') if node else 'Unknown'}`\n"
            f"**CPU:** `{_resource_pct(stats.get('cpu')) if metrics_known else 'N/A'}`\n**RAM:** `{ram.get('used', 'N/A')}/{ram.get('total', 'N/A')} MB ({_resource_pct(ram.get('pct')) if metrics_known else 'N/A'})`\n"
            f"**Disk:** `{disk}`\n**Status:** `{str(stats.get('status') or 'unknown').upper()}`\n**Uptime:** `{stats.get('uptime', 'Unknown')}`"
        )
        await ctx.send(embed=embed)
        return
    if ctx.guild is None:
        await ctx.send(embed=create_error_embed("Server Only", "Invite/boost stats are tracked per Discord server."))
        return
    counts = get_reward_stats(ctx.guild.id, ctx.author.id)
    await ctx.send(embed=create_info_embed(
        "📈 Your Invite & Boost Stats",
        f"**Member invites attributed:** `{counts['invites']}`\n**Active server boosts:** `{counts['boosts']}`\n\n"
        "Invite attribution requires the bot's **Manage Server** permission and is only counted when one invite-use change can be identified unambiguously."
    ))


@bot.command(name="plans", aliases=["freeplans"])
async def plans_command(ctx):
    await ctx.send(embed=create_info_embed(
        "🧾 Free VPS Plan",
        f"**Provider:** {HOST_PROVIDER_NAME}\n**Virtualization:** KVM/QEMU\n"
        f"**Default allocation:** {DEFAULT_VPS_RAM_GB} GB RAM • {DEFAULT_VPS_CPU} vCPU • {DEFAULT_VPS_STORAGE_GB} GB disk\n"
        f"**Maximum allocation (admin-controlled):** {MAX_VPS_RAM_GB} GB RAM • {MAX_VPS_CPU} vCPU • {VPS_MAX_DISK_GB} GB disk\n"
        f"**Default expiry:** {DEFAULT_VPS_EXPIRATION_DAYS} days\n**Docker in guest:** {'Enabled' if DOCKER_INSTALL_ON_DEPLOY else 'Disabled'}\n\n"
        f"Use `{PREFIX}deploy` to open the verified node and OS selector. Availability depends on live node capacity and public network readiness."
    ))


@bot.group(name="claimfree", invoke_without_command=True)
async def claimfree_group(ctx):
    await ctx.send(embed=create_info_embed("🎁 Free VPS Claim", f"Use `{PREFIX}claimfree inv <1-6>` or `{PREFIX}claimfree boost <1-5>`. The number is the minimum tracked invite/boost credits required. One VPS per user still applies."))


@claimfree_group.command(name="inv")
async def claimfree_invite(ctx, tier: int):
    if ctx.guild is None or tier < 1 or tier > 6:
        await ctx.send(embed=create_error_embed("Invalid Tier", "Choose an invite tier from 1 to 6 in a server.")); return
    current = get_reward_stats(ctx.guild.id, ctx.author.id)["invites"]
    if current < tier:
        await ctx.send(embed=create_warning_embed("Invite Requirement Not Met", f"Tier `{tier}` requires `{tier}` tracked invites. Your current count is `{current}`.")); return
    if user_has_vps(ctx.author.id):
        await ctx.send(embed=create_error_embed("VPS Limit Reached", "This account already owns a VPS. The current deployment policy is one VPS per account.")); return
    await ctx.send(embed=create_success_embed("🎁 Invite Tier Verified", f"{ctx.author.mention} meets the `{tier}`-invite requirement. Continue with the standard KVM VPS node/OS selector."), view=DeployTypeView(ctx.author, ctx))


@claimfree_group.command(name="boost")
async def claimfree_boost(ctx, tier: int):
    if ctx.guild is None or tier < 1 or tier > 5:
        await ctx.send(embed=create_error_embed("Invalid Tier", "Choose a boost tier from 1 to 5 in a server.")); return
    current = get_reward_stats(ctx.guild.id, ctx.author.id)["boosts"]
    if current < tier:
        await ctx.send(embed=create_warning_embed("Boost Requirement Not Met", f"Tier `{tier}` requires `{tier}` tracked boost credits. Your current count is `{current}`. Active booster events are tracked automatically; additional boost credits can be reconciled by an administrator.")); return
    if user_has_vps(ctx.author.id):
        await ctx.send(embed=create_error_embed("VPS Limit Reached", "This account already owns a VPS. The current deployment policy is one VPS per account.")); return
    await ctx.send(embed=create_success_embed("🎁 Boost Tier Verified", f"{ctx.author.mention} meets the `{tier}`-boost requirement. Continue with the standard KVM VPS node/OS selector."), view=DeployTypeView(ctx.author, ctx))


@bot.command(name="about-bot", aliases=["aboutbot"])
async def about_bot_command(ctx):
    await about.callback(ctx)


async def _run_lifecycle_action(ctx, vps_id: str, action: str):
    owner_id, _idx, vps = find_vps_record(vps_id)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS matches `{vps_id}`."))
        return
    if not _vps_access_allowed(ctx, owner_id, vps):
        await ctx.send(embed=create_error_embed("Access Denied", "Only the owner, an authorized shared user, or an administrator can control this VPS."))
        return
    if vps.get("suspended") and not is_admin_user(ctx.author):
        await ctx.send(embed=create_error_embed("VPS Suspended", "This VPS is suspended. Contact an administrator before starting or restarting it."))
        return
    node_id = int(vps.get("node_id") or 1)
    container = str(vps.get("container_name") or "")
    if action in {"start", "restart"}:
        allowed, reason = await check_node_capacity_for_start(
            node_id, container,
            _parse_gb(vps.get("ram", f"{DEFAULT_VPS_RAM_GB}GB"), DEFAULT_VPS_RAM_GB),
            _parse_cpu(vps.get("cpu", DEFAULT_VPS_CPU), DEFAULT_VPS_CPU),
        )
        if not allowed:
            await ctx.send(embed=create_warning_embed("🛡️ Start Blocked by Host Protection", reason))
            return
    progress = await ctx.send(embed=create_info_embed(f"{ '▶️' if action == 'start' else '⏹️' if action == 'stop' else '🔄' } {action.title()}ing VPS", f"Checking `{container}` on node `{node_id}`…"))
    try:
        result = await execute_vpsctl_compat(container, f"{action} {shlex.quote(container)}", timeout=180, node_id=node_id)
        latest = await get_container_stats(container, node_id)
        vps["status"] = str(latest.get("status") or ("stopped" if action == "stop" else "running")).lower()
        save_vps_data()
        await record_audit_event("vps", f"VPS {action.title()}", f"VPS {container} • requested by {ctx.author.id}", user_id=ctx.author.id, node_id=node_id, vps_container=container)
        await progress.edit(embed=create_success_embed(f"✅ VPS {action.title()} Requested", f"**VPS:** `{container}`\n**Status:** `{vps['status'].upper()}`\n**Node:** `{node_id}`\n\n{str(result or 'Controller accepted the operation.')[:700]}"))
    except Exception as exc:
        logger.warning("VPS lifecycle operation %s failed for %s: %s", action, container, type(exc).__name__)
        await progress.edit(embed=create_error_embed("VPS Operation Failed", f"Could not {action} `{container}`. The failure was logged; check node/controller health."))


@bot.command(name="start")
async def start_vps_command(ctx, vps_id: str):
    await _run_lifecycle_action(ctx, vps_id, "start")


@bot.command(name="stop")
async def stop_vps_command(ctx, vps_id: str):
    await _run_lifecycle_action(ctx, vps_id, "stop")


@bot.command(name="restart")
async def restart_vps_command(ctx, vps_id: str):
    await _run_lifecycle_action(ctx, vps_id, "restart")


@bot.command(name="change-prefix")
@is_admin()
async def change_prefix_command(ctx, new_prefix: str):
    global PREFIX
    new_prefix = str(new_prefix).strip()
    if not new_prefix or len(new_prefix) > 5 or any(ch.isspace() for ch in new_prefix):
        await ctx.send(embed=create_error_embed("Invalid Prefix", "Use 1–5 non-space characters, for example `!` or `.`."))
        return
    PREFIX = new_prefix
    set_setting("command_prefix", new_prefix)
    await ctx.send(embed=create_success_embed("Prefix Updated", f"New command prefix: `{new_prefix}` (active immediately and saved across restarts)."))


@bot.command(name="change-mode")
@is_admin()
async def change_mode_command(ctx, mode: str):
    modes = {"online": discord.Status.online, "idle": discord.Status.idle,
             "dnd": discord.Status.dnd, "invis": discord.Status.invisible,
             "invisible": discord.Status.invisible}
    key = str(mode).lower().strip()
    if key not in modes:
        await ctx.send(embed=create_error_embed("Invalid Mode", "Choose: `online`, `idle`, `dnd`, or `invis`."))
        return
    await bot.change_presence(status=modes[key])
    await ctx.send(embed=create_success_embed("Bot Presence Updated", f"Presence set to `{key}`."))


@bot.command(name="check-resources")
@is_admin()
async def check_resources_command(ctx, node_ref: str):
    node = next((n for n in get_nodes() if str(n.get("id")) == node_ref or str(n.get("name", "")).lower() == node_ref.lower()), None)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"No node matches `{node_ref}`."))
        return
    node_id = int(node["id"])
    node_status = await get_node_status(node_id)
    host = await get_host_stats(node_id)
    disk = host.get("disk", "Unknown")
    if isinstance(disk, dict):
        disk = f"{disk.get('used', 0)/(1024**3):.1f}/{disk.get('total', 0)/(1024**3):.1f} GiB ({_resource_pct(disk.get('percent'))})"
    await ctx.send(embed=create_info_embed(
        f"📊 Node Resources • {node['name']}",
        f"**Status:** {node_status}\n**CPU:** `{_resource_pct(host.get('cpu'))}`\n**RAM:** `{_resource_pct(host.get('ram'))}`\n**Disk:** `{disk}`\n**VPS Slots:** `{get_current_vps_count(node_id)}/{node.get('total_vps', 0)}`"
    ))


@bot.command(name="machine-status")
@is_admin()
async def machine_status_command(ctx, node_ref: str, seconds: int = 0):
    # One fresh snapshot keeps this command bounded and avoids a noisy infinite stream.
    seconds = max(0, min(60, int(seconds)))
    if seconds:
        await asyncio.sleep(seconds)
    await check_resources_command.callback(ctx, node_ref)



@bot.command(name="addinv")
@is_admin()
async def add_invites_command(ctx, member: discord.Member, amount: int):
    if ctx.guild is None or amount < 1 or amount > 100000:
        await ctx.send(embed=create_error_embed("Invalid Amount", "Use this command in a server with an amount from 1 to 100000.")); return
    counts = change_reward_count(ctx.guild.id, member.id, "invites", amount, "Admin adjustment", ctx.author.id)
    await ctx.send(embed=create_success_embed("Invite Credits Updated", f"{member.mention} now has **{counts['invites']}** tracked invites."))


@bot.command(name="removeinv")
@is_admin()
async def remove_invites_command(ctx, member: discord.Member, amount: int):
    if ctx.guild is None or amount < 1 or amount > 100000:
        await ctx.send(embed=create_error_embed("Invalid Amount", "Use this command in a server with an amount from 1 to 100000.")); return
    counts = change_reward_count(ctx.guild.id, member.id, "invites", -amount, "Admin adjustment", ctx.author.id)
    await ctx.send(embed=create_success_embed("Invite Credits Updated", f"{member.mention} now has **{counts['invites']}** tracked invites."))


@bot.command(name="addboost")
@is_admin()
async def add_boosts_command(ctx, member: discord.Member, amount: int):
    if ctx.guild is None or amount < 1 or amount > 100000:
        await ctx.send(embed=create_error_embed("Invalid Amount", "Use this command in a server with an amount from 1 to 100000.")); return
    counts = change_reward_count(ctx.guild.id, member.id, "boosts", amount, "Admin adjustment", ctx.author.id)
    await ctx.send(embed=create_success_embed("Boost Credits Updated", f"{member.mention} now has **{counts['boosts']}** tracked boosts."))


@bot.command(name="removeboost")
@is_admin()
async def remove_boosts_command(ctx, member: discord.Member, amount: int):
    if ctx.guild is None or amount < 1 or amount > 100000:
        await ctx.send(embed=create_error_embed("Invalid Amount", "Use this command in a server with an amount from 1 to 100000.")); return
    counts = change_reward_count(ctx.guild.id, member.id, "boosts", -amount, "Admin adjustment", ctx.author.id)
    await ctx.send(embed=create_success_embed("Boost Credits Updated", f"{member.mention} now has **{counts['boosts']}** tracked boosts."))


@bot.command(name="user-stats")
@is_admin()
async def user_reward_stats_command(ctx, member: discord.Member):
    counts = get_reward_stats(ctx.guild.id if ctx.guild else 0, member.id)
    await ctx.send(embed=create_info_embed("👤 User Invite & Boost Stats", f"**User:** {member.mention}\n**Invites:** `{counts['invites']}`\n**Boosts:** `{counts['boosts']}`"))


async def _send_reward_logs(ctx, kind: str, member: discord.Member = None):
    if ctx.guild is None:
        return await ctx.send(embed=create_error_embed("Server Only", "Reward logs are per Discord server."))
    query = "SELECT user_id, delta, detail, actor_id, created_at FROM reward_events WHERE guild_id = ? AND event_type = ?"
    params = [str(ctx.guild.id), kind]
    if member:
        query += " AND user_id = ?"; params.append(str(member.id))
    query += " ORDER BY id DESC LIMIT 10"
    with DB_LOCK:
        conn = get_db()
        try: rows = conn.execute(query, tuple(params)).fetchall()
        finally: conn.close()
    if not rows:
        return await ctx.send(embed=create_info_embed(f"{kind.title()} Logs", "No entries recorded yet."))
    lines = [f"<@{r['user_id']}> • `{int(r['delta']):+d}` • {str(r['detail'] or 'No detail')[:80]} • <t:{int(datetime.fromisoformat(r['created_at']).timestamp())}:R>" for r in rows]
    await ctx.send(embed=create_info_embed(f"{kind.title()} Logs • Latest 10", "\n".join(lines)))


@bot.command(name="invite-logs")
@is_admin()
async def invite_logs_command(ctx, member: discord.Member = None):
    await _send_reward_logs(ctx, "invites", member)


@bot.command(name="boost-logs")
@is_admin()
async def boost_logs_command(ctx, member: discord.Member = None):
    await _send_reward_logs(ctx, "boosts", member)


@bot.command(name="start-all")
@is_admin()
async def start_all_command(ctx, node_ref: str):
    node = next((n for n in get_nodes() if str(n.get("id")) == node_ref or str(n.get("name", "")).lower() == node_ref.lower()), None)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"No node matches `{node_ref}`.")); return
    node_id = int(node["id"])
    targets = [(owner_id, v) for owner_id, items in vps_data.items() for v in items
               if int(v.get("node_id") or 1) == node_id and str(v.get("status", "")).lower() != "running" and not v.get("suspended")]
    if not targets:
        await ctx.send(embed=create_info_embed("Start All", "No stopped, non-suspended VPS were found on this node.")); return
    msg = await ctx.send(embed=create_info_embed("▶️ Starting VPS • Resource Guard Enabled", f"Queued `{len(targets)}` VPS on **{node['name']}**. Starting sequentially; the operation stops when host capacity checks fail."))
    started, skipped = [], []
    for owner_id, vps in targets:
        container = str(vps.get("container_name") or "")
        allowed, reason = await check_node_capacity_for_start(node_id, container,
            _parse_gb(vps.get("ram", f"{DEFAULT_VPS_RAM_GB}GB"), DEFAULT_VPS_RAM_GB),
            _parse_cpu(vps.get("cpu", DEFAULT_VPS_CPU), DEFAULT_VPS_CPU))
        if not allowed:
            skipped.append(f"`{container}` — {reason}")
            break
        try:
            await execute_vpsctl_compat(container, f"start {shlex.quote(container)}", timeout=180, node_id=node_id)
            vps["status"] = "running"
            started.append(container)
            save_vps_data()
        except Exception as exc:
            skipped.append(f"`{container}` — controller error ({type(exc).__name__})")
    await msg.edit(embed=create_info_embed("▶️ Start All • Completed", f"**Started:** `{len(started)}`\n**Skipped/blocked:** `{len(skipped)}`\n" + ("\n".join(skipped[:4]) if skipped else "All eligible VPS accepted by the controller.")))


@bot.command(name="purge-prot")
@is_admin()
async def purge_protect_command(ctx, vps_id: str):
    await _set_purge_protection(ctx, vps_id, True)


@bot.command(name="purge-remove-prot")
@is_admin()
async def purge_unprotect_command(ctx, vps_id: str):
    await _set_purge_protection(ctx, vps_id, False)


async def _set_purge_protection(ctx, vps_id: str, enabled: bool):
    owner_id, _idx, vps = find_vps_record(vps_id)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS matches `{vps_id}`.")); return
    vps["whitelisted"] = bool(enabled)
    save_vps_data_immediate()
    await record_audit_event("vps", "Purge Protection Updated", f"{vps.get('container_name')} protection={'enabled' if enabled else 'disabled'}", user_id=ctx.author.id, node_id=int(vps.get('node_id') or 1), vps_container=str(vps.get('container_name')))
    await ctx.send(embed=create_success_embed("🛡️ Purge Protection Updated", f"VPS `{vps.get('container_name')}` protection is now **{'ENABLED' if enabled else 'DISABLED'}**."))


@bot.command(name="purge-status")
@is_admin()
async def purge_status_command(ctx, vps_id: str):
    _owner, _idx, vps = find_vps_record(vps_id)
    if not vps:
        await ctx.send(embed=create_error_embed("VPS Not Found", f"No VPS matches `{vps_id}`.")); return
    await ctx.send(embed=create_info_embed("🛡️ Purge Protection", f"`{vps.get('container_name')}` • **{'Protected' if vps.get('whitelisted') else 'Unprotected'}**"))


async def _purge_list(ctx, node_ref: str, protected: bool):
    node = next((n for n in get_nodes() if str(n.get("id")) == node_ref or str(n.get("name", "")).lower() == node_ref.lower()), None)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"No node matches `{node_ref}`.")); return
    matches = [(owner, v) for owner, items in vps_data.items() for v in items
               if int(v.get("node_id") or 1) == int(node["id"]) and bool(v.get("whitelisted")) == protected]
    label = "Protected" if protected else "Unprotected"
    lines = [f"<@{owner}> • `{v.get('vmid') or v.get('id')}` • `{v.get('container_name')}`" for owner, v in matches[:25]]
    await ctx.send(embed=create_info_embed(f"🛡️ {label} VPS • {node['name']}", "\n".join(lines) if lines else "No matching VPS."))


@bot.command(name="purge-list-prot")
@is_admin()
async def purge_list_protected_command(ctx, node_ref: str):
    await _purge_list(ctx, node_ref, True)


@bot.command(name="purge-list-unprot")
@is_admin()
async def purge_list_unprotected_command(ctx, node_ref: str):
    await _purge_list(ctx, node_ref, False)


@bot.command(name="purge-vm-all")
@is_main_admin()
async def purge_vm_all_preview(ctx, node_ref: str):
    node = next((n for n in get_nodes() if str(n.get("id")) == node_ref or str(n.get("name", "")).lower() == node_ref.lower()), None)
    if not node:
        await ctx.send(embed=create_error_embed("Node Not Found", f"No node matches `{node_ref}`.")); return
    candidates = [(owner, v) for owner, items in vps_data.items() for v in items
                  if int(v.get("node_id") or 1) == int(node["id"]) and not v.get("whitelisted")]
    await ctx.send(embed=create_warning_embed(
        "⚠️ Purge Preview Only",
        f"Found `{len(candidates)}` unprotected VPS on **{node['name']}**. This command is preview-only in this release; it will not bulk-delete customer data. Use `{PREFIX}delete-vps <vps-id>` individually after verifying ownership and backups."
    ))


# Command aliases for typos and convenience
@bot.command(name='mangage')
async def manage_typo(ctx):
    await ctx.send(embed=create_info_embed("Command Correction", f"Did you mean `{PREFIX}manage`? Use the correct command."))


@bot.command(name='commands')
async def commands_alias(ctx):
    """Alias for help command"""
    await show_help.callback(ctx)



def _make_discord_user_agent(bot_name: str, bot_version: str) -> str:
    """Build a strictly ASCII HTTP User-Agent; brand names may include Unicode ™."""
    safe_name = re.sub(r'[^A-Za-z0-9._-]', '', str(bot_name).encode('ascii', 'ignore').decode('ascii'))
    safe_version = re.sub(r'[^A-Za-z0-9._-]', '', str(bot_version).encode('ascii', 'ignore').decode('ascii'))
    safe_name = safe_name or 'RGNODESBot'
    safe_version = safe_version or '1.0'
    # RFC-compatible ASCII avoids urllib3/http.client latin-1 header encoding failures.
    return f'{safe_name}/{safe_version} (Discord bot)'


def discord_token_preflight(token: str) -> bool:
    """Validate the configured bot token with Discord REST without logging the secret."""
    try:
        response=requests.get(
            'https://discord.com/api/v10/users/@me',
            headers={'Authorization': f'Bot {token}', 'User-Agent': _make_discord_user_agent(BOT_NAME, BOT_VERSION)},
            timeout=8,
        )
        if response.status_code == 200:
            logger.info('✅ Discord token preflight passed.')
            return True
        if response.status_code == 401:
            logger.error('❌ Discord rejected the configured token (HTTP 401). Reset/copy the Bot Token from Developer Portal → Bot.')
            return False
        if response.status_code == 429:
            logger.warning('⚠️ Discord token preflight was rate-limited; gateway login will be attempted normally.')
            return True
        logger.warning('⚠️ Discord token preflight returned HTTP %s; gateway login will be attempted normally.', response.status_code)
        return True
    except (requests.RequestException, UnicodeError, ValueError) as exc:
        logger.warning('⚠️ Discord token preflight could not complete safely (%s); gateway login will be attempted normally.', type(exc).__name__)
        return True
    except Exception as exc:
        # A REST preflight is only a diagnostic; it must never crash bot startup.
        logger.warning('⚠️ Discord token preflight encountered an unexpected %s; gateway login will be attempted normally.', type(exc).__name__)
        return True


def run_self_check() -> int:
    """Non-destructive health diagnostics for the fixed Local + Remote deployment mode."""
    problems = []
    logger.info('🧪 RGNODES™ VPS-only deep self-check')
    logger.info('Role: combined local + remote KVM deployment • Provider: %s • Processor: %s', HOST_PROVIDER_NAME, HOST_PROCESSOR_NAME)

    local_problem_prefixes = (
        'KVM controller is missing', '/dev/kvm is unavailable', 'virsh is missing',
        'qemu-img is missing', 'sshpass is missing', 'KVM_NETWORK_MODE must be',
        'PUBLIC_PARENT_INTERFACE is not configured', 'PUBLIC_BRIDGE_NAME is not configured',
        'no real public IPv4 network source is configured',
    )

    controller = _find_kvm_vpsctl()
    if controller:
        logger.info('✅ Hash-verified KVM VPS controller: %s', controller)
    else:
        problems.append('KVM controller is missing or failed integrity verification')
        logger.warning('⚠️ Trusted embedded KVM controller could not be installed/found; run setup.sh as root and verify /usr/local/sbin is writable.')

    if Path('/dev/kvm').exists():
        logger.info('✅ /dev/kvm is available.')
    else:
        problems.append('/dev/kvm is unavailable')
        logger.warning('⚠️ /dev/kvm is unavailable. Local KVM cannot deploy guest VMs on this host; a healthy remote node may still be used.')

    for binary in ('virsh', 'qemu-img', 'sshpass'):
        if shutil.which(binary):
            logger.info('✅ %s available at %s', binary, shutil.which(binary))
        else:
            problems.append(f'{binary} is missing')
            logger.warning('⚠️ %s is missing; local KVM deployments require it.', binary)

    if KVM_NETWORK_MODE not in {'direct', 'bridge', 'nat'}:
        problems.append('KVM_NETWORK_MODE must be direct, bridge, or nat')
        logger.error('❌ Invalid KVM_NETWORK_MODE=%s', KVM_NETWORK_MODE)
    elif KVM_NETWORK_MODE == 'nat' and not shutil.which('iptables'):
        problems.append('iptables is missing for KVM NAT port forwarding')
        logger.error('❌ iptables is missing; run setup.sh to install it for NAT mode')
    elif KVM_NETWORK_MODE == 'direct' and not PUBLIC_PARENT_INTERFACE:
        problems.append('PUBLIC_PARENT_INTERFACE is not configured')
        logger.warning('⚠️ PUBLIC_PARENT_INTERFACE is empty; node.sh should auto-detect the uplink.')
    elif KVM_NETWORK_MODE == 'bridge' and not PUBLIC_BRIDGE_NAME:
        problems.append('PUBLIC_BRIDGE_NAME is not configured')
        logger.warning('⚠️ PUBLIC_BRIDGE_NAME is empty for bridge mode.')
    if REAL_PUBLIC_IPV4_REQUIRED and KVM_NETWORK_MODE != 'nat' and not (PUBLIC_PARENT_INTERFACE or PUBLIC_BRIDGE_NAME or PUBLIC_IPV4_POOL_CIDR):
        problems.append('no real public IPv4 network source is configured')
        logger.warning('⚠️ No real public IPv4 network source is configured.')

    # Remote health checks are explicit diagnostics only, never a high-frequency background loop.
    remote_healthy_nodes = []
    for candidate in get_nodes():
        if bool(candidate.get('is_local')):
            continue
        node_url = str(candidate.get('url') or '').rstrip('/')
        api_key = str(candidate.get('api_key') or '')
        if not node_url or not api_key:
            continue
        headers = {'X-API-Key': api_key, 'User-Agent': _make_discord_user_agent(BOT_NAME, BOT_VERSION)}
        try:
            ping = requests.get(f'{node_url}/api/ping', headers=headers, timeout=5)
            ping_data = ping.json() if ping.status_code == 200 else {}
            if not isinstance(ping_data, dict) or ping_data.get('status') != 'ok':
                continue
            controller_path = str(candidate.get('vpsctl_path') or '/usr/local/sbin/vpsctl')
            health_response = requests.post(
                f'{node_url}/api/execute',
                json={'command': f'{shlex.quote(controller_path)} compat health'},
                headers=headers, timeout=12,
            )
            if health_response.status_code != 200:
                continue
            health_payload = health_response.json()
            if not isinstance(health_payload, dict) or int(health_payload.get('returncode', 1) or 0) != 0:
                continue
            health = json.loads(str(health_payload.get('stdout') or '{}'))
            if isinstance(health, dict) and health.get('status') == 'ok' and health.get('backend') == 'KVM/QEMU/libvirt':
                remote_healthy_nodes.append(str(candidate.get('name') or candidate.get('id') or 'remote node'))
        except Exception as exc:
            logger.debug('Combined-mode remote self-check skipped node ID %s (%s).', candidate.get('id'), type(exc).__name__)

    if remote_healthy_nodes:
        local_failures = [problem for problem in problems if problem.startswith(local_problem_prefixes)]
        if local_failures:
            problems = [problem for problem in problems if not problem.startswith(local_problem_prefixes)]
            logger.warning(
                '⚠️ Local KVM is not ready, but remote node(s) passed authenticated KVM health: %s. Local-only issues are non-blocking for remote deployments.',
                ', '.join(remote_healthy_nodes),
            )
        else:
            logger.info('✅ Remote node(s) passed authenticated KVM health: %s.', ', '.join(remote_healthy_nodes))

    if not remote_healthy_nodes and not _local_kvm_ready():
        logger.error('❌ No ready KVM execution target detected: host KVM is unavailable and no authenticated remote node passed its health check.')

    if DISCORD_TOKEN:
        fingerprint = hashlib.sha256(DISCORD_TOKEN.encode()).hexdigest()[:12]
        logger.info('✅ Discord token is configured (length=%d, sha256[:12]=%s).', len(DISCORD_TOKEN), fingerprint)
    else:
        problems.append('DISCORD_TOKEN is empty')
        logger.error('❌ DISCORD_TOKEN is empty.')

    logger.info('Resource policy: initial=%s GiB RAM/%s CPU/%s GiB disk • max=%s GiB RAM/%s CPU/%s GiB disk • autoscale=%s • disk-scale=%s%%/%sGiB', INITIAL_VPS_RAM_GB, INITIAL_VPS_CPU, INITIAL_VPS_DISK_GB, VPS_MAX_RAM_GB, VPS_MAX_CPU, VPS_MAX_DISK_GB, RESOURCE_AUTOSCALE_ENABLED, RESOURCE_SCALE_UP_DISK_THRESHOLD, RESOURCE_SCALE_UP_DISK_STEP_GB)
    logger.info('Protection: anti-mining=%s • guest hardening=cloud-init+fail2ban+sysctl • embeds=colorless', ANTI_MINING_ENABLED)
    if problems:
        logger.error('❌ Self-check found %d issue(s): %s', len(problems), '; '.join(problems))
        return 2
    logger.info('✅ Self-check passed for the configured Local + Remote deployment setup.')
    return 0

# Run the bot
if __name__ == "__main__":
    if "--self-check" in sys.argv:
        raise SystemExit(run_self_check())
    if DISCORD_TOKEN_CONFIG_ERROR:
        logger.error("❌ Discord token configuration error: %s", DISCORD_TOKEN_CONFIG_ERROR)
        logger.error("Please fix DISCORD_TOKEN in %s", ENV_FILE)
        raise SystemExit(1)
    if not DISCORD_TOKEN:
        logger.error("❌ No valid Discord token found in %s", ENV_FILE)
        logger.error("Paste the raw Bot Token from Discord Developer Portal → Bot.")
        raise SystemExit(1)
    logger.info("🔐 Discord token loaded from %s (secret content hidden)", ENV_FILE)
    if not discord_token_preflight(DISCORD_TOKEN):
        raise SystemExit(1)
    restart_delay = max(3, env_int("BOT_RESTART_DELAY", "8"))
    auto_restart = str(os.getenv("BOT_AUTO_RESTART", "false")).strip().lower() in {"1", "true", "yes", "on"}
    while True:
        try:
            bot.run(DISCORD_TOKEN)
            break
        except discord.errors.LoginFailure:
            logger.error("❌ Discord rejected the bot token. Reset/copy the Bot Token in Developer Portal → Bot and update %s.", ENV_FILE)
            break
        except KeyboardInterrupt:
            raise
        except Exception as e:
            logger.critical("🔥 Fatal bot process error: %s", e, exc_info=True)
            if not auto_restart:
                raise
            logger.warning("♻️ Auto-restarting RGNODES™ bot process in %ss.", restart_delay)
            time.sleep(restart_delay)

