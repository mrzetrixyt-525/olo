RGNODES™ VPS Deploying Bot V9 Manager Pro
========================================
Release: 9.4.2 — SSH/SFTP/Terminal Access Recovery & Black Embed Accent

RELEASE 9.4.2 ACCESS RECOVERY
-----------------------------
- All user VPS access entry points (`!ssh`, `!webssh`, `!file-manager`/`!sftp`, `!access-check`, and Manage-panel buttons) use the same guest readiness and node NAT mapping reconciliation helper.
- NAT SSH mappings are re-applied on access requests even when a SQLite row already exists. Guest port 22 is reserved for management and does not consume optional application-port quota.
- The selected remote node agent is the primary source for its public IPv4/network mode; controller and configured-IP fallbacks are used only when appropriate.
- A remote node can never silently fall back to the Discord bot host IPv4. If the selected remote node endpoint cannot be verified, access stops with a node-specific diagnostic rather than returning an incorrect SSH command.
- Guest SSH checks include sshd syntax, effective root/password authentication, the effective SFTP subsystem, and the listening port.
- Access details and current root credentials are sent to the requesting authorized Discord user by DM. Browser SSH requires the configured HTTPS terminal service; SFTP access is connection details for a real SFTP client, not a browser file-manager GUI.
- `EMBED_COLOR=none` is retained for compatibility; the bot does not pass a custom colour to Discord embeds.

Previous access repairs: Release 9.4.1 — SSH Access & Dark Embed Repair

RELEASE 9.4.1 ACCESS REPAIRS (HISTORICAL)
-----------------------------------------
- The Manage panel SSH, Web SSH and SFTP buttons now use the same guest-SSH verification and NAT mapping repair routine as the prefix commands.
- SSH port 22 is a reserved management mapping and does not consume optional application-port quota. Existing NAT port rows are actively replayed through the node controller so tagged DNAT/FORWARD rules can be restored after a node reboot or firewall reload.
- The periodic access-repair worker replays the SSH mapping for each running, non-suspended VPS on its bounded schedule; it does not rely on the presence of a SQLite row as proof that the host firewall rule still exists.
- SSH, Web SSH and SFTP access messages now include the current verified root password and are delivered to the user who requested the access (including an authorized Manage-panel user), not automatically to a different VPS owner.
- `!access-check <vps-id>` / `!repair-access <vps-id>` verify guest SSH readiness and request the selected node to reapply the mapping. This confirms the guest and managed node-side state; it cannot test a provider's external cloud firewall/security group.
- Discord embeds are created without a custom accent colour. Discord clients control the card background.
- SSH repair now also verifies the effective SFTP subsystem (`Subsystem sftp internal-sftp`) before advertising SFTP access.
- The access report explains NAT host IPv4/forwarded port requirements. The VPS host/provider must permit inbound TCP in `PORT_HOST_MIN..PORT_HOST_MAX` and route that traffic to the selected node.

Previous platform repairs: Release 9.4.0 — OS Selector Repair & KVM/Docker VPS Deployment

RELEASE 9.4.0 REPAIRS
- The deployment UI now uses a clear product → node → operating-system → confirmation sequence. The node selector is retired after successful preflight; the OS selector is returned in one acknowledged private interaction, and deployment is acknowledged before the per-node queue wait. Queue waiting is capped at nine minutes with a clear timeout error.
- All six advertised Ubuntu/Debian OS choices are resolved through the production OS resolver and matched to the embedded KVM controller image catalogue before deployment. Unsupported selections are rejected.
- VPS product type (KVM or Docker) is stored in SQLite and retained through upgrades, clone, reinstall and status display. Docker VPS requires Docker Engine installation and a successful daemon check inside its isolated KVM guest before success is reported.
- Node Protection and LXC/LXD VPS creation are removed. Normal Node Management, capacity checks, KVM health validation, Docker support, per-VPS purge protection and guest-level security remain.
- Docker VPS in this release means a KVM/QEMU virtual machine with Docker Engine inside the guest. The original archive did not contain a separate host-level Docker-container VPS backend; this release does not claim to provide one.


PACKAGE AND SECRETS
-------------------
The archive contains the bot, interactive installer, `.env` template, regression checker, remote node installer, one-command display-name editor, terminal proxy, checksums, and this guide. The Discord bot token is blank and must be added before startup. The supplied `.env` retains the configured Main Admin ID and Admin IDs from your original package; review these IDs before first launch. Never upload your configured `.env`, bot token, node API keys or `web_terminal.token` to a public channel.

INSTALL
-------
1. Extract the ZIP on a supported Debian/Ubuntu Linux control host. Local + Remote node routing is always enabled. Installing KVM/QEMU/libvirt on the control host is optional; when local KVM is unavailable, configured remote nodes remain eligible. If `unzip` is missing, install it first with `sudo apt-get update && sudo apt-get install -y unzip`.
2. Keep `.env` private: `chmod 600 .env`. On first install, `setup.sh` opens an interactive wizard and asks for the Discord token (hidden), main/additional admin IDs, default RAM/CPU/disk, command prefix, Pinggy, IPv4 detection, and optional host tools.
3. Install/repair the host and bot using: `sudo bash setup.sh`. Do not pass `--check` for installation: check mode is read-only and exits after tests.
4. Read-only bundle validation: `sudo bash setup.sh --check`
5. Static validation: `bash check.sh --static`; host readiness report: `sudo bash check.sh --host`
6. To show the setup questions again on an existing install: `sudo env RGNODES_SETUP_WIZARD=1 bash setup.sh`. To explicitly approve a host-wide full upgrade, run `sudo env RGNODES_FULL_UPGRADE=1 bash setup.sh` only when you accept the reboot/service-restart risk.

A KVM/QEMU/libvirt stack and /dev/kvm are required only if this control host will run local guest VMs. They are not required for the bot to register a Local Node record or manage registered remote nodes. Network routing and public IPv4 still depend on the node/provider; a release archive cannot allocate public IPv4 addresses. Do not use documentation/test IP ranges in production.

HARDENED SETUP.SH — RELEASE 9.4.0
--------------------------------
The installer now prints a six-phase progress sequence for OS detection, dependency repair, optional host tools, source/venv preparation, systemd/regression validation, and 24/7 startup. The regression checker uses cached UTF-8 byte-offset source slices rather than repeatedly invoking the expensive standard-library AST source extractor; its static suite completed in about three seconds in the build environment. It performs a fail-fast, read-only regression check before changing host services. It serializes install/repair runs with a lock, verifies the embedded controller and remote-node agent digests, checks supported OS/Python versions and disk headroom, and validates path/service-name settings before writing privileged files. It never runs `.env` as shell code.

- `.env`, code, the systemd unit and the KVM controller receive protected snapshots. On a detected failure, the installer attempts to restore prior code/config/unit/controller state and the service's active/enabled state. Database backup uses SQLite's online backup API; live VM disks, metadata and VPS data are not replaced. This is best-effort rollback, not a transaction across OS package installation or an unavailable host.
- The installer rejects `.env` symlinks and unsafe pre-existing `.venv` ownership/permissions, keeps `.env` at mode 0600, verifies the generated systemd unit with `systemd-analyze verify`, and uses atomic file replacement for the unit/controller.
- The control-host bot process is bounded by systemd: default CPU quota 100% (about one logical CPU), `MemoryHigh` at 80% of the configured memory cap, `MemoryMax=1024M`, `TasksMax=512`, and low scheduling/IO weights. These are control-bot limits, separate from VPS guest RAM/CPU/disk plans. They are configurable in `.env` within guarded ranges; increasing them should be based on measured capacity.
- Dependency installation uses retries and only repairs/names required packages by default. The wizard offers `apt-get full-upgrade` explicitly because a full OS upgrade may restart services, replace kernels/hypervisor packages or require a reboot; this operation is not rollbackable. Non-interactive setup skips full-upgrade unless `sudo env RGNODES_FULL_UPGRADE=1 bash setup.sh` is explicitly supplied.
- On a fresh interactive install, optional prompts can install and enable host Docker Engine and install `neofetch` (or `fastfetch` if `neofetch` is absent). These optional prompts default to **No** unless the matching `.env` option is already enabled. Host Docker is separate from Docker Engine installed inside a customer guest.
- The wizard validates `MAIN_ADMIN_ID` and comma-separated `ADMIN_USER_IDS` as 15-22 digit Discord IDs, constrains default resource selections to configured ceilings, retains the existing command prefix on Enter, allows explicit Pinggy / public-IPv4 choices, and asks whether optional local KVM/QEMU/libvirt packages should be installed. Remote-only mode is not exposed or supported. A bot is not started until both its token and main admin ID are valid.
- The 24/7 process is a systemd service, enabled at boot and restarted after unexpected exits/failures (manual `systemctl stop` remains respected). The installer verifies the generated unit and confirms both enabled and active state. After `--static` checks finish, a separate progress line confirms the installer is continuing; only `setup.sh --check` exits in read-only mode.
- Setup output uses colored RGNODES status text only in an interactive terminal; `NO_COLOR` disables color, and logs/CI remain plain text.
- Runtime config consistency is enforced in `bot.py` too: CPU and disk defaults are clamped to canonical hard ceilings even when `.env` is edited without the wizard. The browser-terminal bind task is tracked so reconnecting Discord gateway events cannot race into duplicate port binds.
- `.env` now documents all frequently tuned runtime knobs (background repair concurrency, guest access retry interval, tunnel start timeout, audit snapshot lines, storage pool and backup directory); the Discord token and terminal token stay blank in the release template; configured administrator IDs are retained from the supplied configuration.

Recommended safe preflight:
  sudo bash setup.sh --check
  sudo bash check.sh --host

The first command is read-only and runs the bundle's static/regression suite using cached source slices (no repeated `ast.get_source_segment` scans). A `KeyboardInterrupt` traceback means the check was manually interrupted; it is not by itself evidence of a bot runtime exception. The second checks host readiness and does not replace real production validation. Installation may still require manual repair if the host loses power, the filesystem fails, dependencies cannot be downloaded, or a provider service is unavailable.


LOCAL + REMOTE NODE MODE (RELEASE 9.4.0)
---------------------------------------
Local + Remote routing is fixed on; `.env` and the setup wizard do not offer a remote-only mode. `setup.sh` asks whether to install KVM/QEMU/libvirt on this control host; the safe default is **No** to keep the main VPS lean. On bot startup, `init_db()` automatically creates the `Local Node` database record if missing and best-effort detects its city/region/country from the control host public egress IP (with a timezone fallback). The external geo lookup runs only when the Local Node has no meaningful saved location and uses a short timeout; this sends the host egress IP to the configured geo provider. `LOCAL_KVM_ENABLED=false` means the installer will not install/start host KVM services, but a previously working local KVM stack remains eligible. If local KVM is unavailable, new deployments select a registered remote node; if none exists, the bot returns a clear readiness error rather than pretending the Local Node is ready. Register remote nodes with `!node create`. After installing a release that changes the embedded controller or node agent, run the matching `sudo bash node.sh` on each remote KVM node as well; updating only the Discord bot host does not remotely replace an already-installed node agent/controller. `DEFAULT_NODE_ID=0` prefers Local Node only when KVM/libvirt is ready; an explicit remote ID pins the preferred remote node. A local node can deploy real VMs only when the provider exposes `/dev/kvm`, libvirt is ready, and there is sufficient host/network/storage capacity.


BRANDING, FIXED DEVELOPER IDENTITY & HOSTNAME
--------------------------------------------
The developer identity is hard-coded in `bot.py` as `𝐌ɾ. 𝐙ᥱ𝚝ɾ𝐢𝐱`; `BOT_DEVELOPER` is removed from `.env` and installer migrations remove any legacy override. The guest hostname base is fixed as `rgnodes-vps`; `VPS_HOSTNAME` is also removed from `.env`. `BOT_NAME` and `HOST_PROVIDER_NAME` remain configurable display/provider labels. The installer never calls `hostnamectl set-hostname` and does not change the main control host hostname. `BOT_NAME` changes only the bot's displayed label, not the Discord application's actual account username.

Change the displayed bot label in one command:
  sudo bash rename-bot.sh "RGNODES™ Edge"

This validates the label, backs up `.env`, writes it atomically and restarts the default `bot.service` if installed. If your systemd service uses a different name, set `RGNODES_SERVICE_NAME` for the command.

DEPLOY PROGRESS AND RESOURCE DISPLAY
------------------------------------
The deployment card uses the 15 RGNODES stages below, a moving activity bar and a completion bar. Each stage advances after its associated operation returns; external tunnel readiness is not falsely shown as online merely because a background bootstrap was queued.

1. Receiving VPS ID
2. Checking KVM / QEMU
3. Creating VPS Container
4. Applying Resource
5. Configure Package
6. 🐳 Docker Ready
7. Booting VPS
8. Fixing systemctl
9. Register In Bot Database
10. Installing SSH + Password
11. Making Public Real IPv4
12. Creating SSH
13. Creating PINGGY
14. Final Full Check and Repair
15. Finished

The deployment resource field shows RAM, CPU and disk only. Discord standard embeds are created without a custom accent colour (`EMBED_COLOR=none`). Discord itself controls the card background; standard embeds cannot force a fully black card on every client theme. Pinggy setup is asynchronous to prevent a slow provider from holding up the main VPS creation flow; its health state is confirmed separately by the repair/check worker. SSHX has been removed from active features. Older guests are checked by the existing low-frequency baseline repair task, which removes legacy SSHX artifacts only if they are found.

STATUS COMMANDS
---------------
The current bot command architecture is prefix-based. With the default prefix `!`:
  !kvm-status [node_id]             Admin-only KVM/QEMU/libvirt health
  !ssh-status <VPS ID or name>      VPS owner/admin SSH service status
  !docker-status <VPS ID or name>   VPS owner/admin Docker status
  !access-check <VPS ID or name>    Verify/repair guest SSH and the selected node port mapping
  !repair-access <VPS ID or name>   Alias for access-check

Replace `!` if PREFIX in .env has changed. Status commands do not reveal root passwords or node API keys.

GUEST MOTD INSTALLER (CONFIGURED IN .env)
-----------------------------------------
`AUTO_MOTD_INSTALLER=true` enables the configured `MOTD_INSTALL_COMMAND`. The supplied `.env` accepts the operator-provided Bash installer command in `HOST_MOTD` (and the canonical `MOTD_INSTALL_COMMAND` alias):

  `bash <(curl -sSL https://raw.githubusercontent.com/mrzetrixyt-525/vm-/main/MOTD-Installer)`

The bot passes this exact single-line command to Bash inside the new guest, with a bounded timeout (`MOTD_INSTALL_TIMEOUT`, default 180 seconds). A command-fingerprint marker prevents repeat execution of the same command on that guest. The control bot does not download, inspect or bundle the installer source. Only keep this enabled when you trust the remote repository and its maintainer. Set `AUTO_MOTD_INSTALLER=false` to disable the external command and use the built-in local MOTD fallback instead.

RGNODES™ OPENSSH TERMINAL (PUBLIC HTTPS DOMAIN)
------------------------------------------------
Public terminal URL default: `https://ssh.rgnodes.bond` (change `WEB_TERMINAL_PUBLIC_URL` in `.env` to your own domain).
Local backend default: `http://127.0.0.1:9090` (loopback only; do not expose port 9090 publicly). `WEB_TERMINAL_PORT` is configurable; when changing it, update the `proxy_pass` ports in the Nginx config too.

The bot serves the browser terminal only on 127.0.0.1. For the HTTPS domain to work, these server-side requirements must all be satisfied:
- DNS A/AAAA records for the configured terminal domain point only to the real host that will serve this terminal. Remove an incorrect AAAA record if IPv6 is not actually routed.
- Public TCP ports 80 and 443 reach the Nginx host.
- A valid certificate and key exist at `/etc/letsencrypt/live/YOUR_TERMINAL_DOMAIN/fullchain.pem` and `privkey.pem` (adjust the Nginx config paths to match).
- The included nginx-ssh-terminal.conf is installed and enabled; it rate-limits logins, forwards WebSockets and overwrites X-Forwarded-For with Nginx's actual client address. For a custom domain, update both `server_name` entries and the TLS certificate/key paths in that file, then obtain a certificate for the same domain before reloading Nginx.

Obtain a certificate first. If an existing Nginx site is already serving the domain, the common option is:
  sudo certbot certonly --nginx -d YOUR_TERMINAL_DOMAIN

Use standalone mode only if port 80 is free (stop any service already listening on port 80 first):
  sudo certbot certonly --standalone -d YOUR_TERMINAL_DOMAIN

Then install the reference config and reload Nginx:
  sudo install -m 0644 nginx-ssh-terminal.conf /etc/nginx/conf.d/rgnodes-ssh-terminal.conf
  sudo nginx -t && sudo systemctl reload nginx

Confirm the bot is running with `WEB_TERMINAL_ENABLED=true`, `WEB_TERMINAL_PORT=9090` and the intended `WEB_TERMINAL_PUBLIC_URL` in `.env`, and allow dependencies from requirements.txt to install. Then open the exact URL configured in `WEB_TERMINAL_PUBLIC_URL`. The DNS, certificate, firewall and Nginx proxy are on your server/provider; they cannot be activated from the ZIP itself.

FIRST LOGIN TOKEN
-----------------
The first successful bot startup creates a random token at:
  /var/lib/rgnodes-vps/data/web_terminal.token

Read it locally from a trusted server shell (the file is mode 0600):
  sudo cat /var/lib/rgnodes-vps/data/web_terminal.token

If RGNODES_DATA_DIR is configured, look for web_terminal.token under that configured data directory instead. You can set WEB_TERMINAL_TOKEN manually in .env, but use at least 32 random characters and keep it secret. The terminal uses token authentication, constant-time token comparison, a login rate limit, short-lived HttpOnly/SameSite cookies, a session cap and an SSH process cap. It is a basic browser shell, not a web File Manager or SFTP browser.

LOCAL ACCESS / MOBILE ACCESS
----------------------------
On the server itself, open:
  http://localhost:909

For a PC or phone without using the public domain, create an SSH local port-forward from that device:
  ssh -L 9090:127.0.0.1:9090 root@YOUR_SERVER_IP

Then open http://localhost:909 on that same device and enter the private token. The basic responsive console supports interactive shell input, password prompts and common control keys; it is not a full xterm.js emulator for every full-screen terminal application. Only connect to systems you own or are authorized to administer.

RESOURCE / LOAD POLICY
----------------------
The browser SSH terminal is configured for up to 3 concurrent SSH processes by default. It has no high-frequency monitoring loop; guest baseline repair continues at its existing 18-hour interval. Deployment uses actual operation results for status and keeps Pinggy startup asynchronous. To avoid overload, keep RAM/CPU/disk admission limits enabled and do not raise session/resource caps without checking your real host capacity.

VERIFICATION AND TEST LIMITS
----------------------------
Run `bash check.sh --static` after installation for syntax, source integrity, command-alias, network guard, and embedded controller checks. The development sandbox regression suite covers embedded KVM controller allocation/rollback/health logic and static checks. This environment cannot prove a live Discord login, real /dev/kvm VM boot, provider-assigned public IPv4 route, external Pinggy readiness, production HTTPS certificate or DNS resolution. Those need a verification run on your configured production host. No software package can honestly guarantee zero errors on every OS/provider; test a first VPS before bulk deployment.


## Updated resource defaults and housekeeping

- Standard `!deploy`: default plan is 8 GiB RAM, 2 CPU cores, 25 GiB disk.
- Admin `!create <RAM> <CPU> <DISK> @user VPS`: up to 22 GiB RAM, 10 CPU cores, 100 GiB disk.
- Actual allocations are still subject to per-node RAM/CPU/disk reservations and live host-capacity preflight. The bot rejects or fits requests when the configured node cannot safely provide them; these ceilings are not a promise of physical capacity.
- Adaptive resource auto-scaling is disabled by default and, if explicitly enabled, checks at no less than five-minute intervals.
- Every five minutes the bot performs low-impact process-cache expiry, orphaned app-temp-file cleanup (only stale RGNODES atomic-write files under the private data directory), opportunistic SQLite optimization/passive checkpointing, and young-generation garbage collection. It does **not** flush Linux page cache, clear all of `/tmp`, delete VPS disks, or delete backups.
- Discord custom emoji provisioning uses the authoritative guild emoji list and skips creation when that list cannot be fetched, preventing restart-time duplicate names.


IDENTITY / HOSTNAME / DISPLAY NAME
----------------------------------
The developer identity is fixed in bot.py to `𝐌ɾ. 𝐙ᥱ𝚝ɾ𝐢𝐱` and ignores `.env` overrides. The managed guest hostname base is fixed to `rgnodes-vps`; the installer never runs hostnamectl or changes the main control host hostname. `BOT_NAME` is the configurable display name used in embeds/panels. Change it in one command from the application folder: `sudo bash rename-bot.sh "RGNODES™ Edge"`. The helper validates the label, backs up `.env`, writes atomically, keeps mode 0600, and restarts the configured systemd service when present. It changes the RGNODES display label only, not the Discord account username; Discord account username changes must be performed in the Discord Developer Portal.

CHECKER PERFORMANCE FIX
-----------------------
The static checker parses bot.py once and uses cached UTF-8 byte offsets to inspect AST source spans instead of calling Python's `ast.get_source_segment()` repeatedly. On the release environment, `bash check.sh --static` completes in about 3 seconds. If a user presses Ctrl+C, that interrupts the check; it does not mean bot.py raised an application error.


ADDED COMMANDS / QUICK REFERENCE
--------------------------------
The original command set is retained. The following requested names are available; overlapping features use aliases rather than duplicate command implementations:

User commands:
- `!ping [node-name]`, `!uptime [node-name]`
- `!plans` / `!freeplans`, `!myvps`, `!list`, `!info <vps-id>`, `!stats [vps-id]`
- `!manage <vps-id>`, `!start <vps-id>`, `!stop <vps-id>`, `!restart <vps-id>`
- `!claimfree inv <1-6>`, `!claimfree boost <1-5>`
- `!share-user @user <vps-id>`, `!share-ruser @user <vps-id>`, `!manage-shared @owner <vps-id>`

Admin commands:
- `!addinv`, `!removeinv`, `!addboost`, `!removeboost`, `!user-stats`, `!invite-logs`, `!boost-logs`
- `!change-prefix`, `!change-mode`, `!check-resources`, `!machine-status`, `!start-all`
- `!purge-prot`, `!purge-remove-prot`, `!purge-status`, `!purge-list-prot`, `!purge-list-unprot`, `!purge-vm-all`

Invite attribution requires the bot to have Manage Server permission and an unambiguous invite-use delta. Boost events are tracked when Discord reports a member becoming or ceasing to be a server booster. Admin credit adjustments are available for reconciliation. `!claimfree` checks the recorded credits but the existing one-VPS-per-account deployment rule still applies.

`!purge-vm-all` is deliberately preview-only and never bulk-deletes customer VPS. This release offers **KVM VPS** and **Docker VPS** products. Both are isolated KVM/QEMU virtual machines; a Docker VPS has Docker Engine installed and its daemon verified inside the guest before deployment is marked successful. Set `DOCKER_VPS_ENABLED=false` to hide/disable the Docker VPS product. `DOCKER_INSTALL_ON_DEPLOY` controls optional Docker installation on ordinary KVM VPSs. LXC/LXD VPS creation is not included.

The web terminal is a shell interface only. A secure browser File Manager/SFTP upload-download interface is not implemented in this release; no non-working File Manager button is shown. Tmate and SSHX management buttons are not included. Existing Discord custom emoji names are checked before provisioning; matching names are preserved and not recreated.

`LOCAL_NODE_SLOTS` controls the auto-created Local Node's configured slot capacity (1-10000; default 100). The Local Node database record is auto-created on bot startup even when local KVM installation is disabled; real local deployments still require a working KVM/libvirt host.


NAT NETWORKING, REAL PUBLIC IPv4 AND ACCESS (RELEASE 9.4.0)
----------------------------------------------------------
The default network mode is now `nat` for single-public-IPv4 hosts. Each guest receives a private DHCP address on `10.231.0.0/24`; the host/node public IPv4 is detected from the default-route source and, when needed, a public IPv4 check service. SSH/SFTP and each public guest port use a unique host port from `PORT_HOST_MIN..PORT_HOST_MAX` and tagged DNAT rules. Restart reconciliation updates mappings if the guest DHCP address changes. The bot labels this as a shared node IPv4; it does NOT present the node address as a dedicated guest IP.

For incoming access, the VPS provider/network firewall must permit TCP ports `PORT_HOST_MIN..PORT_HOST_MAX` (default 20000-50000) to the node. A detected egress IPv4 is not proof that the provider permits inbound traffic: cloud NAT/CGNAT without inbound mapping cannot accept external SSH. Ask the provider for a public inbound IPv4 or supported port-forwarding, or use a routed public IP/subnet. Direct/bridge mode is supported only when each guest is genuinely routed/assigned a public address. Do not switch an already deployed live node from direct/bridge to NAT without a planned migration; an existing remote node keeps the mode reported by its node agent.

NAT settings in the bot `.env` and remote node `/etc/rgnodes/node-agent.env` must agree: `KVM_NETWORK_MODE=nat`, `KVM_NAT_CIDR=10.231.0.0/24`, `KVM_NAT_GATEWAY=10.231.0.1`, `KVM_NAT_BRIDGE=virbr-rgnodes`, `RGNODES_KVM_NETWORK=rgnodes-nat`, `AUTO_DETECT_PUBLIC_IP=true`. Re-run the supplied `node.sh` to update the remote node agent/controller, or edit its env file and restart `rgnodes-node-agent`. Back up existing VM state before changing network configuration. Host NAT requires `iptables`, IPv4 forwarding, `/dev/kvm`, libvirt and a non-overlapping private subnet. The setup script now installs `iptables`.

SSH and SFTP access are generated per VPS using the actual selected node's network mode. `!ssh`, `!webssh`, `!file-manager`/`!sftp`, `!access-check`/`!repair-access` and the Manage panel share the same guest-SSH readiness and endpoint-reconciliation flow. `!access-check <vps-id>` verifies guest SSH readiness and reapplies the selected node's SSH NAT mapping before issuing the access details. Web SSH is a browser terminal (not a browser file manager); `!file-manager` sends standard SFTP details for a compatible client such as FileZilla/WinSCP or the `sftp` CLI. Root password and one-time Web SSH tickets are sent by DM, never posted in the public channel. On NAT, connect using `ssh -p HOST_PORT root@NODE_PUBLIC_IPV4`; the exact command is delivered in DM. SSH on guest port 22 is reserved for VPS management and does not consume the user's optional application-port quota. The bot replays its idempotent `port-add` operation when access is requested and during the bounded access-repair task, so stale SQLite rows do not prevent firewall-rule recovery after a node reboot. The cloud provider/security-group must still allow inbound TCP ports in `PORT_HOST_MIN..PORT_HOST_MAX` to the node.

PREFIX DETECTION AND CUSTOM EMOJIS
----------------------------------
The default prefix is `!`. `!prefix`/`!myprefix` displays the current configured prefix; natural English questions such as `what is your prefix?` also receive a short reply with the live prefix. The prefix shown comes from the active bot configuration rather than a hard-coded example.

The Docker VPS indicator uses the `docker` emoji name. The OS emoji mappings are `ubantu`, `debian`, `alpine`, and `centos` (the legacy `centos7` name is treated as an alias for CentOS Stream). The emoji uploader does not purchase slots or bypass Discord limits; it reuses existing emojis and uploads only when the guild has free capacity.

The emoji mappings in `.env` now target the names visible in the supplied Discord emoji screenshots (including `logo`, `Cpu`, `RAM`, `SSD`, `StatusOnline`, `StatusOffline`, `right`, `arrow1`, `boost`, `boostplan`, `booster`, `verified`, `money`, `gift`, `ann`, `mc`, `dc`, `yt`, `tsu`, `rgnodes_logo`, `bedrock`, and the other listed names). Matching is case-insensitive. The bot fetches the authoritative server emoji list before creating anything; any existing matching name is reused, and the bot never deletes or replaces an existing emoji. Automatic creation of missing names requires Manage Expressions permission and available emoji slots.

RELEASE VALIDATION
------------------
`bash check.sh --static` validates source syntax, extracts the embedded KVM controller before running its regression tests, checks controller/remote-agent hashes, command uniqueness, deployment stages, emoji/prefix integration, and regression fixtures. The extraction order prevents a stale OS assertion from cascading into a misleading `ModuleNotFoundError`. `sudo bash check.sh --host` checks the actual host prerequisites. Static tests do not simulate the provider firewall, Discord gateway, cloud-init mirror availability, remote node reachability, or inbound Internet path; complete live acceptance must be performed on the target node.


ENGLISH LANGUAGE AND AUTOMATIC EMOJI SYNC (RELEASE 9.4.0)
--------------------------------------------------------
All bot replies, help text, setup prompts, and release documentation are English-only. The default command prefix is `!`; asking `prefix`, `what is your prefix?`, or `which prefix do you use?` returns the live configured prefix in English.

Emoji sync runs automatically when the bot becomes ready and when it joins a server. It first fetches the authoritative server emoji list, performs a case-insensitive name match, then checks equivalent names such as `cpu`/`Cpu`, `ram`/`RAM`, and `ssd`/`SSD`. Existing matches are reused. Only unique names still missing after those checks are uploaded. The bot never deletes, renames, or replaces an existing emoji. It requires the bot to have Manage Expressions permission and sufficient server emoji capacity. Generated emoji assets use animated GIFs when supported by the installed image library and use PNG as a safe fallback.

If you add the bot to a server after changing permissions or emoji capacity, restart it to run the automatic sync again. The bot also records a summary in its log: created, reused, missing, pending, and remaining slots. A Discord API outage or an unreadable emoji list causes the bot to skip creation until a later ready/join event rather than risk duplicates.

Web terminal UI: `webssh.html` is served by the existing aiohttp app and uses the native authenticated WebSocket PTY. It does not poll HTTP for terminal output or send a separate HTTP request for each character; input is buffered and output is flushed per animation frame. xterm.js tries jsDelivr first and unpkg as a fallback. The app remains loopback-only on `127.0.0.1:9090`; Nginx terminates HTTPS and proxies the WebSocket. The installer includes `webssh.html` in the deployed file set.


OS image catalogue note (4 November 2026): The selector contains exactly the nine OS choices requested for this release: Ubuntu 26.04/24.04/22.04/20.04, Debian 13/12/11, Alpine 3.24 and CentOS Stream 10 (displayed as CentOS 10). No additional Fedora, Rocky or AlmaLinux options are exposed. Before caching, every downloaded image is checked with `qemu-img info` for a valid `qcow2` or `raw` disk format. Actual first boot depends on node KVM, cloud-init, outbound HTTPS and working libvirt networking.

`PUBLIC_VPS_MAX_PER_IP` remains in `.env` for compatibility, but Discord Gateway does not reveal a member's public IP. Per-IP enforcement requires a web signup/IP verification endpoint; this Discord-only build enforces account, global and per-user caps instead.


Configuration notes (4 November 2026): YOUR_SERVER_IP is intentionally blank so the bot/node can detect a public egress IPv4; the supplied 19-digit value is a Discord ID, not an IPv4 address. PUBLIC_VPS_MAX_PER_IP is retained in .env but cannot be enforced for Discord-only users because Discord Gateway does not expose their IP address. ANTI_MINING_BLOCK_PORTS is retained as a policy setting; the current guest anti-mining guard detects known miner processes and does not install blanket outbound port-blocking rules. WEBSSH_HOST is a compatibility setting; the WebSocket terminal service remains loopback-only behind the configured Nginx proxy.


## OS catalogue and LXC compatibility

The deployable KVM catalogue contains exactly nine choices: Ubuntu 26.04/24.04/22.04/20.04, Debian 13/12/11, Alpine 3.24 and CentOS Stream 10 (displayed as CentOS 10). LXC/LXD VPS provisioning remains disabled. `LXC_SLOTS=100` is retained as an editable compatibility setting only and does not create or allocate LXC guests.

## Libvirt NAT troubleshooting

The KVM controller checks the configured libvirt NAT network before creating a guest. If it cannot start, it gathers read-only `virsh`, `ip`, `ss` and libvirt journal diagnostics. It may reuse an existing verified NAT network only when its XML, private IPv4 subnet, bridge and DHCP range are valid. It will not stop system dnsmasq, flush firewall rules, delete networks or touch existing VM disks. Review `journalctl -u libvirtd -u virtnetworkd -u dnsmasq` for the underlying host conflict.
